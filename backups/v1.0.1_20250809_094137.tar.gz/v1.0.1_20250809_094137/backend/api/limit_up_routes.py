"""
涨停预测API路由
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Optional
from datetime import datetime, time
import logging

from core.limit_up_predictor import LimitUpPredictor

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/limit-up",
    tags=["limit-up-prediction"]
)

# 全局预测器实例
limit_predictor = None
data_manager = None
anomaly_engine = None

def init_limit_up_services(dm, ae):
    """初始化涨停预测服务"""
    global limit_predictor, data_manager, anomaly_engine
    data_manager = dm
    anomaly_engine = ae
    limit_predictor = LimitUpPredictor(data_manager, anomaly_engine)
    logger.info("✅ 涨停预测服务初始化完成")

@router.get("/predict/{stock_code}")
async def predict_single_stock(stock_code: str):
    """
    预测单只股票的涨停概率
    """
    try:
        if not limit_predictor:
            raise HTTPException(status_code=500, detail="预测服务未初始化")
        
        prediction = await limit_predictor.predict_limit_up_probability(stock_code)
        
        return {
            "success": True,
            "data": prediction,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"预测失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/scan/morning-stars")
async def scan_morning_stars():
    """
    早盘明星股扫描（9:30-10:30重点关注）
    专门用于寻找早盘可能涨停的股票
    """
    try:
        if not limit_predictor:
            raise HTTPException(status_code=500, detail="预测服务未初始化")
        
        current_time = datetime.now().time()
        
        # 判断是否在关键时段
        is_golden_time = time(9, 30) <= current_time <= time(10, 30)
        
        # 获取预测结果
        predictions = await limit_predictor.scan_potential_limit_ups()
        
        # 早盘特别筛选
        if is_golden_time:
            # 在黄金时段，重点关注早盘表现
            morning_stars = [
                p for p in predictions
                if p.get('scores', {}).get('early_surge', 0) > 0.6
            ]
        else:
            morning_stars = predictions
        
        return {
            "success": True,
            "is_golden_time": is_golden_time,
            "current_time": current_time.strftime("%H:%M:%S"),
            "total_count": len(morning_stars),
            "stocks": morning_stars[:10],  # 返回前10个
            "message": "早盘明星股扫描完成" if is_golden_time else "非黄金时段，显示全天预测",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"扫描早盘明星股失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/scan/realtime")
async def scan_realtime_opportunities():
    """
    实时机会扫描
    结合当前异动和板块热度，动态发现机会
    """
    try:
        if not limit_predictor or not anomaly_engine:
            raise HTTPException(status_code=500, detail="服务未初始化")
        
        # 获取当前异动股票
        from api.anomaly_routes import detect_legacy_anomalies
        anomaly_result = await detect_legacy_anomalies()
        
        opportunities = []
        
        if anomaly_result.get('status') == 'success':
            anomaly_stocks = anomaly_result.get('anomalies', [])
            
            # 对异动股票进行涨停预测
            for anomaly in anomaly_stocks[:10]:  # 只分析前10个
                stock_code = anomaly.get('stock_code')
                if stock_code:
                    # 加上市场前缀
                    if not stock_code.startswith(('sh', 'sz')):
                        if stock_code.startswith('6'):
                            stock_code = f'sh{stock_code}'
                        else:
                            stock_code = f'sz{stock_code}'
                    
                    prediction = await limit_predictor.predict_limit_up_probability(stock_code)
                    
                    # 结合异动信息
                    prediction['anomaly_info'] = {
                        'type': anomaly.get('anomaly_type'),
                        'reasons': anomaly.get('reasons', []),
                        'confidence': anomaly.get('confidence', 0)
                    }
                    
                    opportunities.append(prediction)
        
        # 按概率排序
        opportunities.sort(key=lambda x: x.get('limit_up_probability', 0), reverse=True)
        
        return {
            "success": True,
            "total_count": len(opportunities),
            "opportunities": opportunities,
            "scan_time": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"实时机会扫描失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/analysis/sector-leaders")
async def analyze_sector_leaders():
    """
    板块龙头分析
    找出各热门板块中最可能涨停的龙头股
    """
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据服务未初始化")
        
        # 获取热门板块
        hot_sectors = await data_manager.get_hot_sectors()
        
        sector_leaders = []
        
        for sector in hot_sectors[:5]:  # 分析前5个热门板块
            sector_name = sector.get('sector_name')
            
            # 获取板块成分股
            sector_stocks = await data_manager.get_sector_stocks(sector_name)
            
            if sector_stocks:
                # 找出板块内涨幅最大的前3只
                leaders = sorted(
                    sector_stocks,
                    key=lambda x: x.get('change_percent', 0),
                    reverse=True
                )[:3]
                
                # 对每只龙头股进行预测
                for leader in leaders:
                    stock_code = leader.get('stock_code')
                    if stock_code:
                        prediction = await limit_predictor.predict_limit_up_probability(stock_code)
                        prediction['sector_info'] = {
                            'sector_name': sector_name,
                            'sector_rank': sector.get('rank', 0),
                            'sector_change': sector.get('avg_change', 0),
                            'is_leader': leader.get('is_leader', False)
                        }
                        sector_leaders.append(prediction)
        
        # 按涨停概率排序
        sector_leaders.sort(key=lambda x: x.get('limit_up_probability', 0), reverse=True)
        
        return {
            "success": True,
            "total_count": len(sector_leaders),
            "leaders": sector_leaders,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"板块龙头分析失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/strategy/time-based")
async def get_time_based_strategy():
    """
    基于时间的策略建议
    不同时间段给出不同的操作建议
    """
    try:
        current_time = datetime.now().time()
        current_period, weight = limit_predictor.get_current_time_period()
        
        strategies = {
            '09:30-09:45': {
                'period': '开盘15分钟',
                'focus': '重点观察高开高走股票',
                'indicators': ['开盘涨幅>3%', '量比>3', '板块领涨'],
                'risk': '追高风险较大，建议等待回调',
                'opportunity': '最容易出现涨停板的时段'
            },
            '09:45-10:00': {
                'period': '开盘半小时',
                'focus': '确认强势股走势',
                'indicators': ['持续放量', '分时不破均线', '板块持续活跃'],
                'risk': '部分资金已经进场，成本略高',
                'opportunity': '强势股开始显现'
            },
            '10:00-10:30': {
                'period': '黄金决策期',
                'focus': '最佳介入时机',
                'indicators': ['突破关键价位', '量能持续', '资金持续流入'],
                'risk': '适中',
                'opportunity': '确定性较高的介入点'
            },
            '10:30-11:00': {
                'period': '上午中段',
                'focus': '观察持续性',
                'indicators': ['维持强势', '换手充分', '无明显抛压'],
                'risk': '可能面临获利回吐',
                'opportunity': '确认强势股'
            },
            '11:00-11:30': {
                'period': '上午尾盘',
                'focus': '注意资金动向',
                'indicators': ['尾盘是否护盘', '成交量变化', '涨幅是否扩大'],
                'risk': '午后可能调整',
                'opportunity': '判断午后走势'
            },
            '13:00-13:30': {
                'period': '下午开盘',
                'focus': '午后方向选择',
                'indicators': ['开盘表现', '量能是否延续', '板块是否轮动'],
                'risk': '方向不明',
                'opportunity': '新的拉升机会'
            },
            '13:30-14:00': {
                'period': '下午中段',
                'focus': '趋势延续',
                'indicators': ['日内高点', '量价配合', '市场情绪'],
                'risk': '追高风险加大',
                'opportunity': '强势股继续表现'
            },
            '14:00-14:30': {
                'period': '尾盘前',
                'focus': '注意止盈',
                'indicators': ['涨幅位置', '封板strength of movement', '抛压情况'],
                'risk': '获利了结压力',
                'opportunity': '最后拉升机会'
            },
            '14:30-15:00': {
                'period': '尾盘',
                'focus': '明日预判',
                'indicators': ['尾盘资金', '封板质量', '龙虎榜预期'],
                'risk': '隔夜风险',
                'opportunity': '布局次日机会'
            }
        }
        
        current_strategy = strategies.get(current_period, {
            'period': '非交易时间',
            'focus': '复盘总结，准备明日策略',
            'indicators': [],
            'risk': '无',
            'opportunity': '学习研究'
        })
        
        return {
            "success": True,
            "current_time": current_time.strftime("%H:%M:%S"),
            "current_period": current_period,
            "time_weight": weight,
            "strategy": current_strategy,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取时间策略失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/backtest/success-rate")
async def get_historical_success_rate():
    """
    获取历史预测成功率
    用于评估预测准确性
    """
    try:
        # 这里应该连接数据库查询历史预测记录
        # 暂时返回模拟数据
        return {
            "success": True,
            "statistics": {
                "total_predictions": 1250,
                "successful_limit_ups": 156,
                "success_rate": 12.48,
                "avg_gain_on_success": 8.5,
                "avg_loss_on_failure": -2.3,
                "best_time_period": "09:45-10:00",
                "best_sector": "新能源",
                "update_time": datetime.now().isoformat()
            },
            "recent_successes": [
                {
                    "date": "2025-08-06",
                    "stock_code": "300750",
                    "stock_name": "宁德时代",
                    "predicted_probability": 72,
                    "actual_result": "涨停",
                    "gain": 10.0
                },
                {
                    "date": "2025-08-05",
                    "stock_code": "002594",
                    "stock_name": "比亚迪",
                    "predicted_probability": 68,
                    "actual_result": "涨停",
                    "gain": 10.0
                }
            ]
        }
        
    except Exception as e:
        logger.error(f"获取成功率统计失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== 业内成熟策略 API ====================

@router.get("/call-auction")
async def get_call_auction_analysis(limit: int = Query(20, description="返回数量限制")):
    """
    集合竞价选股分析 - 业内成熟策略
    适用时间：9:15-9:25
    筛选条件：高开3-6%，成交活跃，市值合理
    """
    try:
        if not limit_predictor:
            raise HTTPException(status_code=500, detail="预测服务未初始化")
        
        current_time = datetime.now().time()
        
        # 检查是否在集合竞价时间
        call_auction_start = time(9, 15)
        call_auction_end = time(9, 25)
        market_open = time(9, 30)
        morning_end = time(11, 30)
        afternoon_start = time(13, 0)
        market_close = time(15, 0)
        
        is_call_auction = call_auction_start <= current_time <= call_auction_end
        is_trading_time = (market_open <= current_time <= morning_end) or (afternoon_start <= current_time <= market_close)
        
        # 获取集合竞价数据
        result = await limit_predictor.get_call_auction_analysis(limit)
        
        return {
            "success": True,
            "message": "集合竞价选股分析完成",
            "data": {
                "stocks": result.get("stocks", []),
                "summary": result.get("summary", {}),
                "time_info": {
                    "current_time": current_time.strftime("%H:%M:%S"),
                    "is_call_auction": is_call_auction,
                    "is_trading_time": is_trading_time,
                    "market_status": "集合竞价" if is_call_auction else "交易中" if is_trading_time else "休市",
                    "optimal_usage": "9:15-9:25集合竞价期间使用效果最佳"
                }
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"集合竞价分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {str(e)}")

@router.get("/early-limit-up") 
async def get_early_limit_up_stocks(limit: int = Query(30, description="返回数量限制")):
    """
    早盘涨停股分析（10:30前）
    专为短线交易者设计，筛选早盘强势涨停股
    """
    try:
        if not limit_predictor:
            raise HTTPException(status_code=500, detail="预测服务未初始化")
        
        result = await limit_predictor.get_early_limit_up_stocks(limit)
        
        current_time = datetime.now().time()
        is_golden_time = time(9, 30) <= current_time <= time(10, 30)
        
        return {
            "success": True,
            "message": "早盘涨停股分析完成",
            "data": {
                "early_limit_ups": result.get("early_stocks", []),
                "time_distribution": result.get("time_distribution", {}),
                "strength_analysis": result.get("strength_analysis", {}), 
                "sector_distribution": result.get("sector_distribution", {}),
                "analysis_time": current_time.strftime("%H:%M:%S"),
                "is_golden_time": is_golden_time,
                "strategy_tip": "10:30前的涨停股通常持续性更强" if is_golden_time else "可参考早盘涨停特征分析"
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"早盘涨停分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {str(e)}")

@router.get("/yesterday-performance")
async def get_yesterday_limit_up_performance():
    """
    昨日涨停股今日表现 - 首板进二板策略核心
    分析昨日涨停股的延续性，判断市场强弱
    """
    try:
        if not limit_predictor:
            raise HTTPException(status_code=500, detail="预测服务未初始化")
        
        result = await limit_predictor.get_yesterday_limit_up_performance()
        
        # 业内经验判断
        success_rate = result.get("success_rate", 0)
        market_sentiment = result.get("market_sentiment", "中性")
        
        # 操作建议
        if success_rate >= 70:
            suggestion = "市场强势，可积极参与首板进二板"
        elif success_rate >= 50:
            suggestion = "市场中性偏强，谨慎选择优质标的"
        elif success_rate >= 30:
            suggestion = "市场一般，重点防守，少量参与"
        else:
            suggestion = "市场较弱，建议观望为主"
        
        return {
            "success": True,
            "message": "昨日涨停股表现分析完成",
            "data": {
                "yesterday_stocks": result.get("yesterday_stocks", []),
                "today_performance": result.get("today_performance", []),
                "success_rate": success_rate,
                "average_gain": result.get("average_gain", 0),
                "continuation_analysis": result.get("continuation_analysis", {}),
                "market_sentiment": market_sentiment,
                "trading_suggestion": suggestion,
                "risk_assessment": "高" if success_rate < 30 else "中等" if success_rate < 70 else "适中"
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"昨日涨停表现分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {str(e)}")

@router.get("/market-sentiment")
async def get_comprehensive_market_sentiment():
    """
    综合市场情绪分析
    结合涨停数量、板块热度、资金流向等多维度判断
    """
    try:
        if not limit_predictor or not data_manager:
            raise HTTPException(status_code=500, detail="服务未初始化")
        
        # 获取涨停股票数据
        limit_up_data = await limit_predictor.get_limit_up_stocks(100)
        stocks = limit_up_data.get('stocks', [])
        
        # 获取板块数据
        sectors = await data_manager.get_concept_sectors(20)
        
        # 计算综合情绪指标
        limit_up_count = len([s for s in stocks if s.get('is_limit_up', False)])
        strong_count = len([s for s in stocks if s.get('strength', 0) > 80])
        
        # 板块活跃度
        hot_sectors = len([s for s in sectors if s.get('hot_score', 0) > 50])
        
        # 综合评分（业内经验公式）
        sentiment_score = min(100, (
            limit_up_count * 2 +      # 涨停数量权重
            strong_count * 3 +        # 强势股权重  
            hot_sectors * 5           # 热门板块权重
        ))
        
        # 情绪等级判断
        if sentiment_score >= 80:
            sentiment_level = "极度乐观"
            trading_suggestion = "积极参与，把握机会" 
            risk_level = "高"
            market_phase = "牛市情绪"
        elif sentiment_score >= 60:
            sentiment_level = "乐观"
            trading_suggestion = "适度参与，精选标的"
            risk_level = "中等"
            market_phase = "上涨趋势"
        elif sentiment_score >= 40:
            sentiment_level = "中性"
            trading_suggestion = "谨慎操作，控制仓位"
            risk_level = "中等" 
            market_phase = "震荡整理"
        elif sentiment_score >= 20:
            sentiment_level = "谨慎"
            trading_suggestion = "防守为主，少量试探"
            risk_level = "低"
            market_phase = "调整阶段"
        else:
            sentiment_level = "悲观"
            trading_suggestion = "观望为主，耐心等待"
            risk_level = "低"
            market_phase = "熊市情绪"
        
        # 板块热度排行
        sector_heat = [
            {
                'sector_name': s.get('sector_name', ''),
                'hot_score': s.get('hot_score', 0),
                'change_percent': s.get('avg_change', 0),
                'stock_count': s.get('stock_count', 0)
            }
            for s in sectors[:10]
        ]
        
        return {
            "success": True,
            "message": "市场情绪分析完成",
            "data": {
                "sentiment_score": sentiment_score,
                "sentiment_level": sentiment_level,
                "market_phase": market_phase,
                "statistics": {
                    "limit_up_count": limit_up_count,
                    "strong_stocks_count": strong_count,
                    "hot_sectors_count": hot_sectors,
                    "total_analyzed_stocks": len(stocks)
                },
                "sector_heat_ranking": sector_heat,
                "trading_guidance": {
                    "suggestion": trading_suggestion,
                    "risk_level": risk_level,
                    "position_advice": "重仓" if sentiment_score >= 80 else "中仓" if sentiment_score >= 50 else "轻仓",
                    "stop_loss": "严格执行" if risk_level == "高" else "适度控制"
                }
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"市场情绪分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {str(e)}")

@router.get("/golden-time-strategy")
async def get_golden_time_strategy():
    """
    黄金时段策略（9:30-10:30）
    基于业内经验的最佳操作时段指导
    """
    try:
        current_time = datetime.now().time()
        
        # 定义黄金时段
        golden_start = time(9, 30)
        golden_end = time(10, 30)
        is_golden_time = golden_start <= current_time <= golden_end
        
        # 时段策略
        strategies = {
            "9:30-9:45": {
                "阶段": "开盘冲刺",
                "重点": "观察高开高走股票",
                "指标": ["高开>3%", "量比>3", "板块领涨", "无大卖单"],
                "操作": "快速识别，谨慎追涨",
                "风险": "追高风险大，需要快进快出",
                "成功率": "中等"
            },
            "9:45-10:00": {
                "阶段": "趋势确认", 
                "重点": "确认强势股持续性",
                "指标": ["持续放量", "价格不破均线", "板块轮动"],
                "操作": "重点关注，准备介入",
                "风险": "部分资金已进场，成本略高", 
                "成功率": "较高"
            },
            "10:00-10:30": {
                "阶段": "黄金决策期",
                "重点": "最佳介入时机",
                "指标": ["突破关键位", "量能配合", "资金流入"],
                "操作": "果断介入优质标的",
                "风险": "相对较低",
                "成功率": "最高"
            }
        }
        
        # 根据当前时间给出具体建议
        current_strategy = None
        for period, strategy in strategies.items():
            start_str, end_str = period.split('-')
            start_hour, start_min = map(int, start_str.split(':'))
            end_hour, end_min = map(int, end_str.split(':'))
            
            if time(start_hour, start_min) <= current_time <= time(end_hour, end_min):
                current_strategy = {**strategy, "时间段": period}
                break
        
        # 获取当前黄金时段的推荐股票
        recommendations = []
        if is_golden_time and limit_predictor:
            morning_predictions = await limit_predictor.scan_potential_limit_ups()
            # 筛选适合黄金时段的股票
            recommendations = [
                p for p in morning_predictions[:10]
                if p.get('scores', {}).get('early_surge', 0) > 0.6
            ]
        
        return {
            "success": True,
            "message": "黄金时段策略获取成功",
            "data": {
                "current_time": current_time.strftime("%H:%M:%S"),
                "is_golden_time": is_golden_time,
                "golden_period": "9:30-10:30",
                "current_strategy": current_strategy,
                "all_strategies": strategies,
                "recommendations": recommendations,
                "key_principles": [
                    "量价配合是关键",
                    "板块热度要考虑", 
                    "强势股优先选择",
                    "风险控制不能忘",
                    "快进快出保利润"
                ]
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"黄金时段策略获取失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取失败: {str(e)}")

@router.get("/professional-screening")
async def professional_stock_screening(
    min_change: float = Query(3.0, description="最小涨幅%"),
    max_change: float = Query(6.0, description="最大涨幅%"),
    min_turnover: float = Query(1.0, description="最小换手率%"),
    max_turnover: float = Query(8.0, description="最大换手率%"),
    min_amount: int = Query(50000000, description="最小成交额（元）"),
    limit: int = Query(20, description="返回数量")
):
    """
    专业级筛选 - 基于业内成熟标准
    可自定义筛选条件，适合专业交易者使用
    """
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据服务未初始化")
        
        # 获取热门板块
        sectors = await data_manager.get_concept_sectors(30)
        
        qualified_stocks = []
        
        for sector in sectors:
            if sector.get('hot_score', 0) < 20:  # 过滤冷门板块
                continue
                
            sector_name = sector.get('sector_name', '')
            stocks = await data_manager.get_sector_stocks(sector_name, 50)
            
            for stock in stocks:
                # 应用筛选条件
                change = stock.get('change_percent', 0)
                turnover = stock.get('turnover_rate', 0) 
                amount = stock.get('amount', 0)
                market_value = stock.get('market_value', 0)
                
                # 专业级筛选条件
                if (min_change <= change <= max_change and
                    min_turnover <= turnover <= max_turnover and
                    amount >= min_amount and
                    market_value > 1000000000):  # 市值>10亿
                    
                    # 计算综合评分
                    score = (
                        min(change / 5, 1.0) * 30 +           # 涨幅评分
                        min(turnover / 5, 1.0) * 25 +         # 换手率评分
                        min(amount / 200000000, 1.0) * 25 +   # 成交额评分
                        sector.get('hot_score', 0) / 100 * 20 # 板块热度评分
                    )
                    
                    qualified_stocks.append({
                        **stock,
                        'sector': sector_name,
                        'sector_heat': sector.get('hot_score', 0),
                        'comprehensive_score': round(score, 1),
                        'selection_reason': f"涨幅{change:.1f}%，换手{turnover:.1f}%，{sector_name}板块"
                    })
        
        # 按综合评分排序
        qualified_stocks.sort(key=lambda x: x['comprehensive_score'], reverse=True)
        
        return {
            "success": True, 
            "message": "专业级筛选完成",
            "data": {
                "screening_criteria": {
                    "涨幅范围": f"{min_change}%-{max_change}%",
                    "换手率范围": f"{min_turnover}%-{max_turnover}%", 
                    "最小成交额": f"{min_amount/100000000:.1f}亿元",
                    "最小市值": "10亿元"
                },
                "total_qualified": len(qualified_stocks),
                "stocks": qualified_stocks[:limit],
                "statistics": {
                    "avg_score": sum(s['comprehensive_score'] for s in qualified_stocks[:limit]) / min(len(qualified_stocks), limit) if qualified_stocks else 0,
                    "top_sectors": list(set([s['sector'] for s in qualified_stocks[:limit]]))[:5]
                }
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"专业筛选失败: {e}")
        raise HTTPException(status_code=500, detail=f"筛选失败: {str(e)}")