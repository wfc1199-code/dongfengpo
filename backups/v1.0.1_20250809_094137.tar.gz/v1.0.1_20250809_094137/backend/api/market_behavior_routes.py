"""
主力行为分析API路由
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Dict, List, Optional, Any
from datetime import datetime
import asyncio
import pandas as pd

from core.market_behavior_analyzer import MarketBehaviorAnalyzer
from core.cache_manager import cache_manager
from core.data_sources import StockDataManager

router = APIRouter()
analyzer = MarketBehaviorAnalyzer()
data_manager = StockDataManager()


def _sanitize_types(obj: Any) -> Any:
    """将返回结果中的 numpy/pandas 类型递归转换为原生 Python 类型，避免序列化报错。"""
    try:
        import numpy as np
    except Exception:
        np = None  # 兜底

    if obj is None:
        return None
    if isinstance(obj, (str, bool, int, float)):
        # 确保 numpy 标量也被转换
        if np is not None:
            if isinstance(obj, (np.bool_,)):
                return bool(obj)
            if isinstance(obj, (np.integer,)):
                return int(obj)
            if isinstance(obj, (np.floating,)):
                return float(obj)
        return obj
    if isinstance(obj, dict):
        return {str(k): _sanitize_types(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_types(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(_sanitize_types(v) for v in obj)
    # pandas/numpy 对象处理
    if np is not None:
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.ndarray,)):
            return [_sanitize_types(x) for x in obj.tolist()]
    # 其他不可序列化对象，转字符串兜底
    return str(obj)


def _infer_prefixed_code(code: str) -> str:
    """根据代码推断并补全交易所前缀。"""
    if code.startswith(('sh', 'sz')):
        return code
    if code.startswith('6'):
        return f'sh{code}'
    return f'sz{code}'


def _generate_mock_timeshare_from_realtime(
    stock_code: str,
    current_price: float
) -> List[Dict[str, Any]]:
    """在外部API不可用时，生成简易分时数据以不中断分析。"""
    import random
    random.seed(hash(stock_code) % 100000)
    points: List[Dict[str, Any]] = []
    price = current_price if current_price > 0 else max(1.0, random.uniform(10, 50))
    total_amount = 0.0
    total_volume = 0
    # 生成120个点（近两小时），时间标签简单递增
    hour = 9
    minute = 30
    for _ in range(120):
        drift = random.uniform(-0.003, 0.003)  # ±0.3%
        price = max(0.1, price * (1 + drift))
        volume = random.randint(1000, 10000)
        amount = price * volume
        total_volume += volume
        total_amount += amount
        avg_price = total_amount / total_volume if total_volume else price
        time_str = f"{hour:02d}:{minute:02d}"
        points.append({
            'time': time_str,
            'price': round(price, 2),
            'volume': volume,
            'amount': round(amount, 2),
            'avgPrice': round(avg_price, 2),
            'changePercent': 0
        })
        minute += 1
        if minute >= 60:
            minute = 0
            hour += 1
    return points


async def _fetch_minute_data_with_fallback(stock_code: str) -> Dict[str, Any]:
    """获取分时数据：原始代码 -> 补前缀 -> 兜底模拟。"""
    # 0) 先查缓存（原始代码键）
    cached = await cache_manager.get_stock_minute_data(stock_code)
    if cached:
        return {
            'code': stock_code,
            'name': '',
            'minute_data': cached
        }

    # 1) 原始代码尝试
    try:
        data = await data_manager.get_minute_data(stock_code)
        if data and data.get('minute_data'):
            # 写入缓存
            await cache_manager.set_stock_minute_data(stock_code, data['minute_data'])
            return data
    except Exception:
        pass

    # 2) 前缀代码尝试
    try:
        prefixed = _infer_prefixed_code(stock_code)
        cached2 = await cache_manager.get_stock_minute_data(prefixed)
        if cached2:
            return {
                'code': prefixed,
                'name': '',
                'minute_data': cached2
            }
        data = await data_manager.get_minute_data(prefixed)
        if data and data.get('minute_data'):
            await cache_manager.set_stock_minute_data(prefixed, data['minute_data'])
            return data
    except Exception:
        pass

    # 3) 兜底：用实时价生成简易分时数据
    try:
        prefixed = _infer_prefixed_code(stock_code)
        realtime = await data_manager.get_realtime_data([prefixed])
        rt = realtime.get(prefixed, {}) if isinstance(realtime, dict) else {}
        mock_points = _generate_mock_timeshare_from_realtime(prefixed, float(rt.get('current_price', 0)))
        await cache_manager.set_stock_minute_data(prefixed, mock_points)
        return {
            'code': prefixed,
            'name': rt.get('name', ''),
            'minute_data': mock_points,
            'yesterday_close': rt.get('yesterday_close')
        }
    except Exception:
        # 最终仍失败
        return {}

@router.get("/api/stocks/{stock_code}/behavior/analysis")
async def analyze_market_behavior(
    stock_code: str,
    include_details: bool = Query(default=True, description="是否包含成交明细分析")
) -> Dict:
    """
    分析股票分时图主力行为
    
    参数:
        stock_code: 股票代码
        include_details: 是否包含成交明细分析
    
    返回:
        主力行为分析结果
    """
    try:
        # 获取分时数据（含前缀重试与兜底）
        minute_data = await _fetch_minute_data_with_fallback(stock_code)

        if not minute_data or not minute_data.get('minute_data'):
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的分时数据")

        # 构造分时数据格式
        timeshare_list = []
        for item in minute_data['minute_data']:
            timeshare_list.append({
                'time': item.get('time', ''),
                'price': item.get('price', 0),
                'volume': item.get('volume', 0),
                'amount': item.get('amount', 0),
                'avgPrice': item.get('avgPrice', item.get('price', 0)),
                'changePercent': item.get('changePercent', 0)
            })

        # 获取成交明细（如果需要）
        trade_details = [] if include_details else None

        # 执行分析
        analysis_result = analyzer.analyze_timeshare_behavior(
            timeshare_list,
            trade_details
        )

        # 添加股票基本信息
        analysis_result['stock_code'] = stock_code
        analysis_result['stock_name'] = minute_data.get('name', '')
        # 当前价取分时最后一条
        last_point = timeshare_list[-1] if timeshare_list else {}
        analysis_result['current_price'] = last_point.get('price', 0)
        analysis_result['change_percent'] = last_point.get('changePercent', 0)
        analysis_result['update_time'] = datetime.now().isoformat()

        return _sanitize_types(analysis_result)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/stocks/{stock_code}/behavior/alerts")
async def get_behavior_alerts(stock_code: str) -> List[Dict]:
    """
    获取股票实时行为警报
    
    参数:
        stock_code: 股票代码
    
    返回:
        警报列表
    """
    try:
        # 获取分时数据
        minute_data = await data_manager.get_minute_data(stock_code)

        if not minute_data or not minute_data.get('minute_data'):
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的分时数据")

        # 构造分时数据格式
        timeshare_list = []
        for item in minute_data['minute_data']:
            timeshare_list.append({
                'time': item.get('time', ''),
                'price': item.get('price', 0),
                'volume': item.get('volume', 0),
                'amount': item.get('amount', 0),
                'avgPrice': item.get('avgPrice', item.get('price', 0)),
                'changePercent': item.get('changePercent', 0)
            })

        # 快速分析
        analysis_result = analyzer.analyze_timeshare_behavior(timeshare_list)

        # 获取警报
        alerts = analyzer.get_realtime_alerts(analysis_result)

        return alerts
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/api/stocks/{stock_code}/behavior/suggestions")
async def get_trading_suggestions(stock_code: str) -> Dict:
    """
    获取操作建议
    
    参数:
        stock_code: 股票代码
    
    返回:
        操作建议
    """
    try:
        # 获取分时数据
        minute_data = await data_manager.get_minute_data(stock_code)

        if not minute_data or not minute_data.get('minute_data'):
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的分时数据")

        # 构造分时数据格式
        timeshare_list = []
        for item in minute_data['minute_data']:
            timeshare_list.append({
                'time': item.get('time', ''),
                'price': item.get('price', 0),
                'volume': item.get('volume', 0),
                'amount': item.get('amount', 0),
                'avgPrice': item.get('avgPrice', item.get('price', 0)),
                'changePercent': item.get('changePercent', 0)
            })

        # 深度分析
        analysis_result = analyzer.analyze_timeshare_behavior(timeshare_list, None)

        # 返回建议
        last_point = timeshare_list[-1] if timeshare_list else {}
        return {
            'stock_code': stock_code,
            'stock_name': minute_data.get('name', ''),
            'current_price': last_point.get('price', 0),
            'behavior': analysis_result['behavior'],
            'confidence': analysis_result['confidence'],
            'suggestions': analysis_result['suggestions'],
            'signals': analysis_result['signals'],
            'update_time': datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# WebSocket和历史功能暂时移除，保持API简单