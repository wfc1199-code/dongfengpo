"""
版本管理API路由
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

from core.version_manager import version_manager

router = APIRouter(prefix="/api/versions", tags=["版本管理"])


class CreateVersionRequest(BaseModel):
    version_name: str
    description: Optional[str] = ""
    tags: Optional[List[str]] = []


class VersionResponse(BaseModel):
    id: int
    version_name: str
    version_code: str
    description: str
    created_at: str
    file_size: int
    checksum: str
    tags: List[str]
    status: str
    metadata: dict
    changes_count: int = 0


class VersionChangeResponse(BaseModel):
    type: str
    path: str
    description: str


@router.post("/create", response_model=dict)
async def create_version(request: CreateVersionRequest, background_tasks: BackgroundTasks):
    """创建新版本"""
    try:
        # 在后台任务中创建版本，避免阻塞请求
        def create_version_task():
            return version_manager.create_version(
                version_name=request.version_name,
                description=request.description,
                tags=request.tags
            )
        
        # 直接执行，因为创建过程需要返回结果
        result = create_version_task()
        
        return {
            "success": True,
            "message": f"版本 {result['version_code']} 创建成功",
            "data": result
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"创建版本失败: {str(e)}")


@router.get("/list", response_model=List[VersionResponse])
async def get_versions(limit: int = 50):
    """获取版本列表"""
    try:
        versions = version_manager.get_versions(limit=limit)
        
        # 为每个版本添加变更数量
        for version in versions:
            changes = version_manager.get_version_changes(version["id"])
            version["changes_count"] = len(changes)
        
        return versions
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取版本列表失败: {str(e)}")


@router.get("/{version_id}/changes", response_model=List[VersionChangeResponse])
async def get_version_changes(version_id: int):
    """获取版本变更记录"""
    try:
        changes = version_manager.get_version_changes(version_id)
        return changes
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取版本变更失败: {str(e)}")


@router.delete("/{version_id}")
async def delete_version(version_id: int):
    """删除版本"""
    try:
        success = version_manager.delete_version(version_id)
        
        if success:
            return {"success": True, "message": f"版本 {version_id} 删除成功"}
        else:
            raise HTTPException(status_code=404, detail="版本不存在")
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"删除版本失败: {str(e)}")


@router.get("/stats")
async def get_version_stats():
    """获取版本统计信息"""
    try:
        versions = version_manager.get_versions(limit=1000)  # 获取所有版本进行统计
        
        total_versions = len(versions)
        total_size = sum(v.get("file_size", 0) for v in versions)
        
        # 按创建时间分组统计
        monthly_stats = {}
        for version in versions:
            created_at = datetime.fromisoformat(version["created_at"])
            month_key = created_at.strftime("%Y-%m")
            
            if month_key not in monthly_stats:
                monthly_stats[month_key] = {"count": 0, "size": 0}
            
            monthly_stats[month_key]["count"] += 1
            monthly_stats[month_key]["size"] += version.get("file_size", 0)
        
        return {
            "total_versions": total_versions,
            "total_size": total_size,
            "total_size_mb": round(total_size / 1024 / 1024, 2),
            "monthly_stats": monthly_stats,
            "latest_version": versions[0] if versions else None
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取统计信息失败: {str(e)}")


@router.post("/save-current")
async def save_current_version():
    """保存当前系统状态为新版本"""
    try:
        # 自动生成版本名称
        current_time = datetime.now()
        version_name = f"性能优化版本 v{current_time.strftime('%Y.%m.%d')}"
        
        description = """
        🚀 主要更新内容：
        • K线图性能优化 - 添加数据缓存机制，提升切换速度
        • 错误处理改进 - 优化非交易时间和超时错误的处理
        • 请求管理优化 - 实现竞态条件防护，避免重复请求
        • API响应提速 - 缩短请求间隔，提高数据获取速度
        • 用户体验改善 - 添加即时加载反馈和状态提示
        
        🔧 技术改进：
        • 前端数据缓存系统 (5分钟有效期)
        • 后端请求间隔优化 (降至30ms)
        • 完善的错误分类和提示
        • 内存管理和清理机制
        """
        
        result = version_manager.create_version(
            version_name=version_name,
            description=description.strip(),
            tags=["performance", "optimization", "stable", "v1.2"]
        )
        
        return {
            "success": True,
            "message": "当前系统状态已保存为新版本",
            "data": result
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存当前版本失败: {str(e)}")