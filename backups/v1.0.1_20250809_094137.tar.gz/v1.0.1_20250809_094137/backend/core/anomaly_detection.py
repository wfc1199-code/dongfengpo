"""
异动拉升检测核心算法
基于东风破1.0.8版本的AI算法逻辑 - 增强版（提前预警）
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta, time
import logging
from enum import Enum
import asyncio
import aiohttp
import json

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class StockState(Enum):
    """股票状态枚举"""
    IDLE = "空闲"           # 无异动
    PRE_ALERT = "预警"      # 预警状态（提前检测）
    STARTING = "开始"       # 开始拉升
    CONTINUING = "持续"     # 持续拉升  
    NEAR_LIMIT = "快停"     # 快要涨停
    LIMIT_UP = "涨停"       # 已涨停


class AnomalyType(Enum):
    """异动类型"""
    PRE_VOLUME_SURGE = "成交量预警"    # 成交量提前放大
    PRE_BIG_ORDER = "大单预警"         # 大单频率提前异动
    PRE_BID_ASK = "买卖盘预警"         # 买卖盘比例异常
    SPEED_UP = "涨速异动"              # 涨幅增速异动
    VOLUME_SURGE = "放量异动"          # 成交量异动
    BIG_ORDER = "大单异动"             # 大单异动
    CAPITAL_INFLOW = "资金流入"        # 主动资金流入
    BREAKTHROUGH = "突破前高"          # 突破前面最大峰值


class TimeSegment:
    """时间分段类 - 每5分钟一个时间段"""
    
    def __init__(self, start_time: datetime):
        self.start_time = start_time
        # 向下取整到5分钟边界
        minute = (start_time.minute // 5) * 5
        self.segment_start = start_time.replace(minute=minute, second=0, microsecond=0)
        self.segment_end = self.segment_start + timedelta(minutes=5)
        
    @property
    def segment_id(self) -> str:
        """生成时间段ID，格式：HHMM"""
        return self.segment_start.strftime("%H%M")
    
    @property
    def display_time(self) -> str:
        """显示时间，格式：HH:MM"""
        return self.segment_start.strftime("%H:%M")
    
    def contains(self, timestamp: datetime) -> bool:
        """判断时间是否在此时间段内"""
        return self.segment_start <= timestamp < self.segment_end


class AnomalyPoint:
    """异动点数据类"""
    
    def __init__(self, timestamp: datetime, price: float, change_percent: float, 
                 volume: int, speed: float, anomaly_type: AnomalyType,
                 confidence: float = 0.0, is_early_warning: bool = False):
        self.timestamp = timestamp
        self.price = price
        self.change_percent = change_percent
        self.volume = volume
        self.speed = speed  # 涨幅增速
        self.anomaly_type = anomaly_type
        self.confidence = confidence  # 预警置信度
        self.is_early_warning = is_early_warning  # 是否为提前预警
        self.time_segment = TimeSegment(timestamp)
        
    def to_dict(self) -> Dict:
        return {
            'timestamp': self.timestamp.isoformat(),
            'price': self.price,
            'change_percent': self.change_percent,
            'volume': self.volume,
            'speed': self.speed,
            'anomaly_type': self.anomaly_type.value,
            'confidence': self.confidence,
            'is_early_warning': self.is_early_warning,
            'time_segment_id': self.time_segment.segment_id,
            'display_time': self.time_segment.display_time
        }


class EarlyWarningDetector:
    """提前预警检测器"""
    
    def __init__(self, config: Dict):
        self.volume_surge_threshold = config.get('volume_surge_threshold', 2.0)  # 成交量放大倍数
        self.big_order_frequency_threshold = config.get('big_order_frequency', 3)  # 大单频率阈值
        self.bid_ask_ratio_threshold = config.get('bid_ask_ratio', 1.5)  # 买卖盘比例阈值
        self.early_detection_window = config.get('early_detection_window', 3)  # 提前检测窗口（分钟）
    
    def detect_volume_pre_surge(self, recent_volumes: List[int], historical_avg: float) -> Tuple[bool, float]:
        """检测成交量提前放大"""
        if len(recent_volumes) < 2 or historical_avg <= 0:
            return False, 0.0
        
        current_volume = recent_volumes[-1]
        volume_ratio = current_volume / historical_avg
        
        # 检测近期成交量是否持续放大
        surge_count = sum(1 for v in recent_volumes[-3:] if v / historical_avg > self.volume_surge_threshold)
        
        if surge_count >= 2 and volume_ratio > self.volume_surge_threshold:
            confidence = min(0.9, volume_ratio / self.volume_surge_threshold * 0.3)
            return True, confidence
        
        return False, 0.0
    
    def detect_big_order_frequency(self, recent_big_orders: List[Dict]) -> Tuple[bool, float]:
        """检测大单频率异常"""
        if len(recent_big_orders) < self.big_order_frequency_threshold:
            return False, 0.0
        
        # 检查最近时间窗口内的大单频率
        now = datetime.now()
        window_start = now - timedelta(minutes=self.early_detection_window)
        
        recent_orders = [order for order in recent_big_orders 
                         if order['timestamp'] >= window_start]
        
        if len(recent_orders) >= self.big_order_frequency_threshold:
            # 计算大单密度
            total_amount = sum(order.get('amount', 0) for order in recent_orders)
            confidence = min(0.8, len(recent_orders) / self.big_order_frequency_threshold * 0.2)
            return True, confidence
        
        return False, 0.0
    
    def detect_bid_ask_anomaly(self, bid_volume: float, ask_volume: float) -> Tuple[bool, float]:
        """检测买卖盘异常"""
        if ask_volume <= 0:
            return False, 0.0
        
        bid_ask_ratio = bid_volume / ask_volume
        
        if bid_ask_ratio > self.bid_ask_ratio_threshold:
            confidence = min(0.7, bid_ask_ratio / self.bid_ask_ratio_threshold * 0.3)
            return True, confidence
        
        return False, 0.0


class BigOrderDetector:
    """大单检测器"""
    
    def __init__(self):
        self.hand_threshold = 6000      # 大于6000手
        self.amount_threshold = 3000000  # 大于300万元
    
    def detect_big_orders(self, tick_data: List[Dict]) -> List[Dict]:
        """检测大单交易"""
        big_orders = []
        
        for tick in tick_data:
            volume = tick.get('volume', 0)
            amount = tick.get('amount', 0)
            
            if volume > self.hand_threshold or amount > self.amount_threshold:
                big_orders.append({
                    'timestamp': tick.get('timestamp', ''),
                    'price': tick.get('price', 0),
                    'volume': volume,
                    'amount': amount,
                    'is_big_order': True
                })
        
        return big_orders


class CapitalFlowCalculator:
    """资金流向计算器"""
    
    @staticmethod
    def calculate_active_capital(tick_data: List[Dict], minutes: int = 2) -> Dict:
        """计算主动资金流向"""
        current_time = datetime.now()
        cutoff_time = current_time - timedelta(minutes=minutes)
        
        total_buy_amount = 0
        total_sell_amount = 0
        recent_buy_amount = 0
        recent_sell_amount = 0
        
        for tick in tick_data:
            timestamp_str = tick.get('timestamp', '') or datetime.now().isoformat()
            timestamp = datetime.fromisoformat(timestamp_str)
            amount = tick.get('amount', 0)
            direction = tick.get('direction', 'unknown')  # 'buy' or 'sell'
            
            if direction == 'buy':
                total_buy_amount += amount
                if timestamp >= cutoff_time:
                    recent_buy_amount += amount
            elif direction == 'sell':
                total_sell_amount += amount
                if timestamp >= cutoff_time:
                    recent_sell_amount += amount
        
        return {
            'total_capital': total_buy_amount - total_sell_amount,
            'recent_capital': recent_buy_amount - recent_sell_amount,
            'total_buy_amount': total_buy_amount,
            'total_sell_amount': total_sell_amount,
            'recent_buy_amount': recent_buy_amount,
            'recent_sell_amount': recent_sell_amount
        }


class AnomalyDetector:
    """异动检测核心算法 - 增强版"""
    
    def __init__(self, config: Dict):
        self.speed_threshold = config.get('speed_threshold', 0.5)  # 涨速阈值
        self.volume_ratio_threshold = config.get('volume_ratio_threshold', 2.0)  # 放量阈值
        self.anomaly_interval = config.get('anomaly_interval', 5)  # 异动间隔（分钟）
        
        # 涨停阈值设置
        self.main_board_limit = 9.8      # 主板涨停
        self.growth_board_limit = 19.8   # 创业板/科创板涨停
        self.near_limit_threshold = 0.2  # 接近涨停的阈值
        
        self.big_order_detector = BigOrderDetector()
        self.capital_calculator = CapitalFlowCalculator()
        self.early_warning_detector = EarlyWarningDetector(config.get('early_warning', {}))
        
        # 历史数据缓存
        self.volume_history = {}  # {stock_code: [volumes]}
        self.big_order_history = {}  # {stock_code: [big_orders]}
    
    def calculate_speed(self, price_data: List[Dict], window: int = 3) -> float:
        """计算涨幅增速"""
        if len(price_data) < window:
            return 0.0
        
        recent_data = price_data[-window:]
        changes = [d.get('change_percent', 0) for d in recent_data]
        times = [datetime.fromisoformat(d.get('timestamp', '') or datetime.now().isoformat()) for d in recent_data]
        
        if len(changes) < 2:
            return 0.0
        
        # 计算斜率（涨幅增速）
        x = [(t - times[0]).total_seconds() / 60 for t in times]  # 转为分钟
        y = changes
        
        if len(x) >= 2:
            # 简单线性回归计算斜率
            n = len(x)
            sum_x = sum(x)
            sum_y = sum(y)
            sum_xy = sum(x[i] * y[i] for i in range(n))
            sum_x2 = sum(x[i] ** 2 for i in range(n))
            
            if n * sum_x2 - sum_x ** 2 != 0:
                slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
                return slope
        
        return 0.0
    
    def detect_early_warnings(self, stock_code: str, tick_data: List[Dict]) -> List[AnomalyPoint]:
        """检测提前预警信号"""
        early_warnings = []
        
        if len(tick_data) < 2:
            return early_warnings
        
        current_tick = tick_data[-1]
        timestamp_str = current_tick.get('timestamp', '') or datetime.now().isoformat()
        current_time = datetime.fromisoformat(timestamp_str)
        
        # 更新历史数据
        if stock_code not in self.volume_history:
            self.volume_history[stock_code] = []
        if stock_code not in self.big_order_history:
            self.big_order_history[stock_code] = []
        
        # 添加当前成交量
        current_volume = current_tick.get('volume', 0)
        self.volume_history[stock_code].append(current_volume)
        
        # 保持历史数据在合理范围内（最近30个tick）
        if len(self.volume_history[stock_code]) > 30:
            self.volume_history[stock_code] = self.volume_history[stock_code][-30:]
        
        # 1. 检测成交量提前放大
        if len(self.volume_history[stock_code]) >= 10:
            historical_avg = np.mean(self.volume_history[stock_code][:-5])  # 排除最近5个点计算历史平均
            recent_volumes = self.volume_history[stock_code][-5:]  # 最近5个点
            
            volume_surge, confidence = self.early_warning_detector.detect_volume_pre_surge(
                recent_volumes, historical_avg)
            
            if volume_surge:
                anomaly = AnomalyPoint(
                    timestamp=current_time,
                    price=current_tick.get('price', 0),
                    change_percent=current_tick.get('change_percent', 0),
                    volume=current_volume,
                    speed=0.0,
                    anomaly_type=AnomalyType.PRE_VOLUME_SURGE,
                    confidence=confidence,
                    is_early_warning=True
                )
                early_warnings.append(anomaly)
        
        # 2. 检测大单频率异常
        big_orders = self.big_order_detector.detect_big_orders([current_tick])
        if big_orders:
            self.big_order_history[stock_code].extend(big_orders)
            # 保持历史数据在合理范围内
            if len(self.big_order_history[stock_code]) > 50:
                self.big_order_history[stock_code] = self.big_order_history[stock_code][-50:]
        
        big_order_freq, confidence = self.early_warning_detector.detect_big_order_frequency(
            self.big_order_history.get(stock_code, []))
        
        if big_order_freq:
            anomaly = AnomalyPoint(
                timestamp=current_time,
                price=current_tick.get('price', 0),
                change_percent=current_tick.get('change_percent', 0),
                volume=current_volume,
                speed=0.0,
                anomaly_type=AnomalyType.PRE_BIG_ORDER,
                confidence=confidence,
                is_early_warning=True
            )
            early_warnings.append(anomaly)
        
        # 3. 检测买卖盘异常（如果有数据的话）
        bid_volume = current_tick.get('bid_volume', 0)
        ask_volume = current_tick.get('ask_volume', 0)
        
        if bid_volume > 0 and ask_volume > 0:
            bid_ask_anomaly, confidence = self.early_warning_detector.detect_bid_ask_anomaly(
                bid_volume, ask_volume)
            
            if bid_ask_anomaly:
                anomaly = AnomalyPoint(
                    timestamp=current_time,
                    price=current_tick.get('price', 0),
                    change_percent=current_tick.get('change_percent', 0),
                    volume=current_volume,
                    speed=0.0,
                    anomaly_type=AnomalyType.PRE_BID_ASK,
                    confidence=confidence,
                    is_early_warning=True
                )
                early_warnings.append(anomaly)
        
        return early_warnings
    
    def detect_anomalies(self, stock_code: str, tick_data: List[Dict]) -> List[AnomalyPoint]:
        """检测异动点（包含提前预警）"""
        anomalies = []
        
        if len(tick_data) < 3:
            return anomalies
        
        # 1. 首先检测提前预警信号
        early_warnings = self.detect_early_warnings(stock_code, tick_data)
        anomalies.extend(early_warnings)
        
        # 2. 然后检测传统的涨速异动
        for i in range(2, len(tick_data)):
            current_data = tick_data[i-2:i+1]  # 取3个点计算
            
            # 计算涨幅增速
            speed = self.calculate_speed(current_data)
            
            # 检测涨速异动
            if speed > self.speed_threshold:
                current_tick = tick_data[i]
                anomaly = AnomalyPoint(
                    timestamp=datetime.fromisoformat(current_tick.get('timestamp', '') or datetime.now().isoformat()),
                    price=current_tick.get('price', 0),
                    change_percent=current_tick.get('change_percent', 0),
                    volume=current_tick.get('volume', 0),
                    speed=speed,
                    anomaly_type=AnomalyType.SPEED_UP,
                    confidence=0.8,
                    is_early_warning=False
                )
                anomalies.append(anomaly)
        
        return anomalies
    
    def determine_stock_state(self, stock_code: str, anomalies: List[AnomalyPoint], 
                            current_change: float) -> StockState:
        """判断股票当前状态"""
        if not anomalies:
            return StockState.IDLE
        
        # 判断涨停阈值
        is_growth_board = stock_code.startswith('sz30') or stock_code.startswith('sh688')
        limit_threshold = self.growth_board_limit if is_growth_board else self.main_board_limit
        near_limit_threshold = limit_threshold - self.near_limit_threshold
        
        # 判断状态
        if current_change >= limit_threshold:
            return StockState.LIMIT_UP
        elif current_change >= near_limit_threshold:
            return StockState.NEAR_LIMIT
        
        # 检查是否有预警信号
        recent_time = datetime.now() - timedelta(minutes=10)
        recent_anomalies = [a for a in anomalies if a.timestamp >= recent_time]
        early_warnings = [a for a in recent_anomalies if a.is_early_warning]
        
        if early_warnings:
            return StockState.PRE_ALERT
        
        # 检查是否有连续异动
        if len(recent_anomalies) > 1:
            return StockState.CONTINUING
        elif len(recent_anomalies) == 1:
            return StockState.STARTING
        
        return StockState.IDLE
    
    def calculate_continuous_anomalies(self, anomalies: List[AnomalyPoint]) -> int:
        """计算连续异动次数"""
        if not anomalies:
            return 0
        
        # 按时间排序
        sorted_anomalies = sorted(anomalies, key=lambda x: x.timestamp)
        
        continuous_count = 1
        max_continuous = 1
        
        for i in range(1, len(sorted_anomalies)):
            time_diff = (sorted_anomalies[i].timestamp - sorted_anomalies[i-1].timestamp).total_seconds() / 60
            
            if time_diff <= self.anomaly_interval:  # 5分钟内算连续
                continuous_count += 1
                max_continuous = max(max_continuous, continuous_count)
            else:
                continuous_count = 1
        
        return max_continuous
    
    def calculate_recent_anomaly_count(self, anomalies: List[AnomalyPoint], count: int = 10) -> int:
        """计算最近N次中的异动次数"""
        if len(anomalies) <= count:
            return len(anomalies)
        
        # 取最近的N次交易中的异动次数
        recent_anomalies = sorted(anomalies, key=lambda x: x.timestamp)[-count:]
        return len(recent_anomalies)


class TimeSegmentManager:
    """时间分段管理器"""
    
    def __init__(self):
        self.segments = {}  # {segment_id: {stock_code: [anomalies]}}
        self.current_segment_id = None
        
    def get_current_segment(self) -> TimeSegment:
        """获取当前时间段"""
        return TimeSegment(datetime.now())
    
    def add_anomaly(self, stock_code: str, anomaly: AnomalyPoint):
        """添加异动到相应时间段"""
        segment_id = anomaly.time_segment.segment_id
        
        if segment_id not in self.segments:
            self.segments[segment_id] = {}
        
        if stock_code not in self.segments[segment_id]:
            self.segments[segment_id][stock_code] = []
        
        self.segments[segment_id][stock_code].append(anomaly)
    
    def get_segment_anomalies(self, segment_id: str) -> Dict[str, List[AnomalyPoint]]:
        """获取指定时间段的异动"""
        return self.segments.get(segment_id, {})
    
    def get_available_segments(self, date: str = None) -> List[str]:
        """获取可用的时间段列表"""
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        # 筛选指定日期的时间段
        available_segments = []
        for segment_id in self.segments.keys():
            # segment_id格式为HHMM，需要结合日期判断
            if len(segment_id) == 4:  # HHMM格式
                available_segments.append(segment_id)
        
        return sorted(available_segments)
    
    def get_segment_summary(self, segment_id: str) -> Dict:
        """获取时间段摘要信息"""
        segment_data = self.segments.get(segment_id, {})
        
        total_stocks = len(segment_data)
        total_anomalies = sum(len(anomalies) for anomalies in segment_data.values())
        early_warnings = 0
        
        for anomalies in segment_data.values():
            early_warnings += sum(1 for a in anomalies if a.is_early_warning)
        
        # 解析时间段
        if len(segment_id) == 4:
            hour = int(segment_id[:2])
            minute = int(segment_id[2:])
            display_time = f"{hour:02d}:{minute:02d}"
        else:
            display_time = segment_id
        
        return {
            'segment_id': segment_id,
            'display_time': display_time,
            'total_stocks': total_stocks,
            'total_anomalies': total_anomalies,
            'early_warnings': early_warnings,
            'has_data': total_anomalies > 0
        }


class HotSectorDetector:
    """热门板块检测器"""
    
    def __init__(self):
        self.sector_mapping = self._load_sector_mapping()
    
    def _load_sector_mapping(self) -> Dict[str, str]:
        """加载股票与板块的映射关系"""
        # 这里应该从数据文件或API加载
        # 简化示例，实际应该有完整的板块分类数据
        return {
            'sh600000': '银行',
            'sh600036': '银行', 
            'sz000001': '银行',
            'sz000002': '地产',
            # ... 更多映射关系
        }
    
    def detect_hot_sectors(self, anomaly_stocks: List[Dict], time_window: int = 30) -> List[Dict]:
        """检测热门板块"""
        # 统计时间窗口内各板块的异动股票数量
        sector_counts = {}
        current_time = datetime.now()
        cutoff_time = current_time - timedelta(minutes=time_window)
        
        for stock in anomaly_stocks:
            stock_code = stock.get('code', '')
            sector = self.sector_mapping.get(stock_code, '其他')
            
            anomalies = stock.get('anomalies', [])
            recent_anomalies = [a for a in anomalies if 
                              a.timestamp >= cutoff_time]
            
            if recent_anomalies:
                if sector not in sector_counts:
                    sector_counts[sector] = 0
                sector_counts[sector] += len(recent_anomalies)
        
        # 排序并返回热门板块
        hot_sectors = []
        for sector, count in sorted(sector_counts.items(), key=lambda x: x[1], reverse=True):
            hot_sectors.append({
                'sector': sector,
                'anomaly_count': count,
                'time_window': time_window
            })
        
        return hot_sectors


class StockAnalysisEngine:
    """股票分析引擎 - 整合所有分析功能"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.anomaly_detector = AnomalyDetector(config.get('anomaly', {}))
        self.hot_sector_detector = HotSectorDetector()
        self.time_segment_manager = TimeSegmentManager()
        
        # 存储历史数据
        self.anomaly_history = {}  # {stock_code: [AnomalyPoint]}
        self.peak_prices = {}      # {stock_code: max_price}
    
    def analyze_stock(self, stock_code: str, tick_data: List[Dict], 
                     current_price: float, current_change: float) -> Dict:
        """分析单只股票的异动情况"""
        
        # 1. 检测异动点（包含提前预警）
        anomalies = self.anomaly_detector.detect_anomalies(stock_code, tick_data)
        
        # 2. 更新历史记录和时间分段
        if stock_code not in self.anomaly_history:
            self.anomaly_history[stock_code] = []
        
        # 添加新检测到的异动到历史记录和时间分段
        for anomaly in anomalies:
            self.anomaly_history[stock_code].append(anomaly)
            self.time_segment_manager.add_anomaly(stock_code, anomaly)
        
        # 3. 计算各种指标
        all_anomalies = self.anomaly_history[stock_code]
        continuous_count = self.anomaly_detector.calculate_continuous_anomalies(all_anomalies)
        recent_10_count = self.anomaly_detector.calculate_recent_anomaly_count(all_anomalies, 10)
        
        # 4. 判断股票状态
        current_state = self.anomaly_detector.determine_stock_state(
            stock_code, all_anomalies, current_change)
        
        # 5. 计算资金流向
        capital_flow = self.anomaly_detector.capital_calculator.calculate_active_capital(tick_data)
        
        # 6. 检测大单
        big_orders = self.anomaly_detector.big_order_detector.detect_big_orders(tick_data)
        max_order_amount = max([o.get('amount', 0) for o in big_orders]) if big_orders else 0
        
        # 7. 计算总速度（整体趋势）
        if all_anomalies:
            first_anomaly = min(all_anomalies, key=lambda x: x.timestamp)
            time_span = (datetime.now() - first_anomaly.timestamp).total_seconds() / 60  # 分钟
            total_speed = (current_change - first_anomaly.change_percent) / time_span if time_span > 0 else 0
        else:
            total_speed = 0
        
        # 8. 计算近期增速
        recent_speed = 0
        if len(tick_data) >= 3:
            recent_speed = self.anomaly_detector.calculate_speed(tick_data[-3:])
        
        # 9. 检测突破前高
        peak_breakthrough = self._check_peak_breakthrough(stock_code, current_price, tick_data)
        
        # 10. 统计提前预警信息
        early_warnings = [a for a in anomalies if a.is_early_warning]
        early_warning_count = len(early_warnings)
        
        return {
            'code': stock_code,
            'current_price': current_price,
            'current_change': current_change,
            'state': current_state.value,
            'anomaly_count': len(all_anomalies),
            'continuous_anomalies': continuous_count,
            'recent_10_anomalies': recent_10_count,
            'early_warning_count': early_warning_count,
            'total_speed': total_speed,
            'recent_speed': recent_speed,
            'total_capital': capital_flow['total_capital'],
            'recent_capital': capital_flow['recent_capital'],
            'max_order_amount': max_order_amount,
            'big_orders_count': len(big_orders),
            'peak_breakthrough': peak_breakthrough,
            'anomaly_points': [a.to_dict() for a in anomalies],
            'early_warnings': [a.to_dict() for a in early_warnings],
            'analysis_time': datetime.now().isoformat(),
            'current_segment': self.time_segment_manager.get_current_segment().segment_id
        }
    
    def _check_peak_breakthrough(self, stock_code: str, current_price: float, 
                               tick_data: List[Dict]) -> bool:
        """检测是否突破前面最大峰值"""
        if stock_code not in self.peak_prices:
            # 初始化峰值价格
            if tick_data:
                self.peak_prices[stock_code] = max([t.get('price', 0) for t in tick_data])
            else:
                self.peak_prices[stock_code] = current_price
        
        peak_price = self.peak_prices[stock_code]
        
        # 更新峰值
        if current_price > peak_price:
            self.peak_prices[stock_code] = current_price
            return True
        
        return False
    
    def generate_champion_list(self, stock_analyses: List[Dict], 
                             sort_by: str = 'recent_speed') -> List[Dict]:
        """生成冠绝榜（异动股票排行榜）"""
        
        # 筛选有异动的股票
        anomaly_stocks = [s for s in stock_analyses if s.get('anomaly_count', 0) > 0]
        
        # 排序
        reverse = True  # 大部分指标都是越大越好
        if sort_by == 'state':
            # 状态排序：预警 > 开始 > 持续 > 快停 > 涨停 > 空闲
            state_order = {'预警': 5, '开始': 4, '持续': 3, '快停': 2, '涨停': 1, '空闲': 0}
            anomaly_stocks.sort(key=lambda x: state_order.get(x.get('state', ''), 0), reverse=True)
        else:
            anomaly_stocks.sort(key=lambda x: x.get(sort_by, 0), reverse=reverse)
        
        return anomaly_stocks
    
    def detect_hot_sectors(self, stock_analyses: List[Dict], time_window: int = 30) -> List[Dict]:
        """检测热门板块"""
        return self.hot_sector_detector.detect_hot_sectors(stock_analyses, time_window)
    
    def get_time_segments(self, date: str = None) -> List[Dict]:
        """获取可用时间段列表"""
        segments = self.time_segment_manager.get_available_segments(date)
        return [self.time_segment_manager.get_segment_summary(seg_id) for seg_id in segments]
    
    def get_segment_anomalies(self, segment_id: str) -> Dict:
        """获取指定时间段的异动数据"""
        anomalies_dict = self.time_segment_manager.get_segment_anomalies(segment_id)
        summary = self.time_segment_manager.get_segment_summary(segment_id)
        
        # 转换格式以便前端显示
        segment_data = []
        for stock_code, anomalies in anomalies_dict.items():
            stock_anomalies = [a.to_dict() for a in anomalies]
            segment_data.append({
                'stock_code': stock_code,
                'anomalies': stock_anomalies,
                'anomaly_count': len(stock_anomalies),
                'early_warning_count': sum(1 for a in anomalies if a.is_early_warning)
            })
        
        return {
            'segment_info': summary,
            'stocks': segment_data
        }


def is_trading_time() -> bool:
    """
    检查当前是否为股票交易时间
    交易时间：上午9:30-11:30，下午13:00-15:00
    """
    now = datetime.now()
    current_time = now.time()
    current_weekday = now.weekday()  # 0=星期一, 6=星期日
    
    # 检查是否为工作日（周一到周五）
    if current_weekday >= 5:  # 周六(5)和周日(6)
        logger.info(f"📅 当前是周末，不在交易时间内")
        return False
    
    # 定义交易时间段
    morning_start = time(9, 30)   # 上午9:30
    morning_end = time(11, 30)    # 上午11:30
    afternoon_start = time(13, 0) # 下午13:00
    afternoon_end = time(15, 0)   # 下午15:00
    
    # 检查是否在交易时间内
    is_morning_trading = morning_start <= current_time <= morning_end
    is_afternoon_trading = afternoon_start <= current_time <= afternoon_end
    
    if is_morning_trading:
        logger.info(f"🌅 当前时间 {current_time.strftime('%H:%M')} - 上午交易时间")
        return True
    elif is_afternoon_trading:
        logger.info(f"🌇 当前时间 {current_time.strftime('%H:%M')} - 下午交易时间")
        return True
    else:
        if current_time < morning_start:
            logger.info(f"⏰ 当前时间 {current_time.strftime('%H:%M')} - 交易未开始（9:30开盘）")
        elif morning_end < current_time < afternoon_start:
            logger.info(f"🍽️ 当前时间 {current_time.strftime('%H:%M')} - 中午休市时间（13:00开盘）")
        else:
            logger.info(f"🌙 当前时间 {current_time.strftime('%H:%M')} - 交易已结束（15:00收盘）")
        return False

def get_trading_time_segments() -> List[str]:
    """
    根据交易时间生成合理的时间段
    返回当前交易日的时间段列表
    """
    now = datetime.now()
    segments = []
    
    if not is_trading_time():
        # 如果不在交易时间，返回最近的交易时间段（用于回看）
        logger.info("📊 生成历史交易时间段用于回看")
        
        # 生成上午时间段（每30分钟一段）
        morning_segments = ["09:30", "10:00", "10:30", "11:00", "11:30"]
        # 生成下午时间段（每30分钟一段）  
        afternoon_segments = ["13:00", "13:30", "14:00", "14:30", "15:00"]
        
        segments = morning_segments + afternoon_segments
    else:
        # 如果在交易时间，生成到当前时间的时间段
        current_time = now.time()
        
        # 上午时间段
        if current_time >= time(9, 30):
            segments.append("09:30")
        if current_time >= time(10, 0):
            segments.append("10:00") 
        if current_time >= time(10, 30):
            segments.append("10:30")
        if current_time >= time(11, 0):
            segments.append("11:00")
        if current_time >= time(11, 30):
            segments.append("11:30")
            
        # 下午时间段  
        if current_time >= time(13, 0):
            segments.append("13:00")
        if current_time >= time(13, 30):
            segments.append("13:30")
        if current_time >= time(14, 0):
            segments.append("14:00")
        if current_time >= time(14, 30):
            segments.append("14:30")
        if current_time >= time(15, 0):
            segments.append("15:00")
    
    return segments


# 测试函数
def test_anomaly_detection():
    """测试异动检测功能"""
    config = {
        'anomaly': {
            'speed_threshold': 0.5,
            'volume_ratio_threshold': 2.0,
            'anomaly_interval': 5
        },
        'early_warning': {
            'volume_surge_threshold': 1.8,
            'big_order_frequency': 3,
            'bid_ask_ratio': 1.5,
            'early_detection_window': 3
        }
    }
    
    engine = StockAnalysisEngine(config)
    
    # 模拟tick数据
    test_tick_data = [
        {'timestamp': '2023-12-07T09:30:00', 'price': 10.0, 'change_percent': 0.0, 'volume': 1000},
        {'timestamp': '2023-12-07T09:31:00', 'price': 10.1, 'change_percent': 1.0, 'volume': 1200},
        {'timestamp': '2023-12-07T09:32:00', 'price': 10.3, 'change_percent': 3.0, 'volume': 2000},
        {'timestamp': '2023-12-07T09:33:00', 'price': 10.5, 'change_percent': 5.0, 'volume': 3000},
        {'timestamp': '2023-12-07T09:34:00', 'price': 10.8, 'change_percent': 8.0, 'volume': 5000},
    ]
    
    analysis = engine.analyze_stock('sh600000', test_tick_data, 10.8, 8.0)
    
    print("异动检测分析结果:")
    print(f"股票代码: {analysis['code']}")
    print(f"当前状态: {analysis['state']}")
    print(f"异动次数: {analysis['anomaly_count']}")
    print(f"提前预警: {analysis['early_warning_count']}")
    print(f"连续异动: {analysis['continuous_anomalies']}")
    print(f"近期增速: {analysis['recent_speed']:.3f}")
    print(f"总资金: {analysis['total_capital']}")
    print(f"异动点: {len(analysis['anomaly_points'])}")
    print(f"当前时间段: {analysis['current_segment']}")


if __name__ == "__main__":
    test_anomaly_detection() 