"""
系统监控模块 - 性能指标收集和可观测性
"""

import time
import psutil
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
from collections import defaultdict, deque
import json

logger = logging.getLogger(__name__)

try:
    from prometheus_client import Counter, Histogram, Gauge, CollectorRegistry, generate_latest
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    logger.warning("Prometheus客户端不可用，使用内置监控")


@dataclass
class MetricPoint:
    """指标数据点"""
    timestamp: datetime
    value: float
    labels: Dict[str, str] = None


class MetricsCollector:
    """指标收集器"""
    
    def __init__(self):
        self.metrics = defaultdict(lambda: deque(maxlen=1000))  # 保留最近1000个数据点
        self.counters = defaultdict(int)
        self.gauges = defaultdict(float)
        
        # Prometheus指标（如果可用）
        if PROMETHEUS_AVAILABLE:
            self.registry = CollectorRegistry()
            self._setup_prometheus_metrics()
    
    def _setup_prometheus_metrics(self):
        """设置Prometheus指标"""
        if not PROMETHEUS_AVAILABLE:
            return
        
        self.prom_api_requests = Counter(
            'api_requests_total', 
            'API请求总数', 
            ['method', 'endpoint', 'status'],
            registry=self.registry
        )
        
        self.prom_api_duration = Histogram(
            'api_request_duration_seconds', 
            'API响应时间',
            registry=self.registry
        )
        
        self.prom_errors = Counter(
            'errors_total', 
            '错误总数', 
            ['type', 'component'],
            registry=self.registry
        )
        
        self.prom_memory_usage = Gauge(
            'memory_usage_bytes', 
            '内存使用量',
            registry=self.registry
        )
        
        self.prom_cpu_usage = Gauge(
            'cpu_usage_percent', 
            'CPU使用率',
            registry=self.registry
        )
        
        self.prom_active_stocks = Gauge(
            'active_stocks_count', 
            '活跃股票数量',
            registry=self.registry
        )
        
        self.prom_anomaly_count = Counter(
            'anomalies_detected_total', 
            '检测到的异动总数',
            registry=self.registry
        )
    
    def record_api_request(self, method: str, endpoint: str, status: int, duration: float):
        """记录API请求"""
        # 内置指标
        key = f"api_request_{method}_{endpoint}"
        self.metrics[key].append(MetricPoint(
            timestamp=datetime.now(),
            value=duration,
            labels={'method': method, 'endpoint': endpoint, 'status': str(status)}
        ))
        
        self.counters[f"api_requests_{status}"] += 1
        
        # Prometheus指标
        if PROMETHEUS_AVAILABLE:
            self.prom_api_requests.labels(method=method, endpoint=endpoint, status=str(status)).inc()
            self.prom_api_duration.observe(duration)
    
    def record_error(self, error_type: str, component: str):
        """记录错误"""
        self.counters[f"error_{error_type}"] += 1
        
        if PROMETHEUS_AVAILABLE:
            self.prom_errors.labels(type=error_type, component=component).inc()
    
    def record_system_metrics(self):
        """记录系统指标"""
        now = datetime.now()
        
        # CPU使用率
        cpu_percent = psutil.cpu_percent(interval=1)
        self.metrics['cpu_usage'].append(MetricPoint(now, cpu_percent))
        self.gauges['cpu_usage'] = cpu_percent
        
        # 内存使用
        memory = psutil.virtual_memory()
        memory_usage = memory.used
        memory_percent = memory.percent
        
        self.metrics['memory_usage'].append(MetricPoint(now, memory_usage))
        self.metrics['memory_percent'].append(MetricPoint(now, memory_percent))
        self.gauges['memory_usage'] = memory_usage
        self.gauges['memory_percent'] = memory_percent
        
        # 磁盘使用
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        self.metrics['disk_usage'].append(MetricPoint(now, disk_percent))
        self.gauges['disk_usage'] = disk_percent
        
        # 网络IO
        net_io = psutil.net_io_counters()
        self.metrics['network_bytes_sent'].append(MetricPoint(now, net_io.bytes_sent))
        self.metrics['network_bytes_recv'].append(MetricPoint(now, net_io.bytes_recv))
        
        # 更新Prometheus指标
        if PROMETHEUS_AVAILABLE:
            self.prom_cpu_usage.set(cpu_percent)
            self.prom_memory_usage.set(memory_usage)
    
    def record_business_metrics(self, active_stocks: int, anomaly_count: int):
        """记录业务指标"""
        now = datetime.now()
        
        self.metrics['active_stocks'].append(MetricPoint(now, active_stocks))
        self.metrics['anomaly_count'].append(MetricPoint(now, anomaly_count))
        self.gauges['active_stocks'] = active_stocks
        
        if PROMETHEUS_AVAILABLE:
            self.prom_active_stocks.set(active_stocks)
            self.prom_anomaly_count.inc(anomaly_count)
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """获取指标摘要"""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'counters': dict(self.counters),
            'gauges': dict(self.gauges),
            'recent_metrics': {}
        }
        
        # 获取最近的指标数据
        for metric_name, points in self.metrics.items():
            if points:
                recent_points = list(points)[-10:]  # 最近10个点
                summary['recent_metrics'][metric_name] = [
                    {
                        'timestamp': point.timestamp.isoformat(),
                        'value': point.value,
                        'labels': point.labels
                    }
                    for point in recent_points
                ]
        
        return summary
    
    def get_prometheus_metrics(self) -> str:
        """获取Prometheus格式的指标"""
        if not PROMETHEUS_AVAILABLE:
            return "# Prometheus not available\n"
        
        return generate_latest(self.registry).decode('utf-8')


class AlertManager:
    """告警管理器"""
    
    def __init__(self):
        self.alert_rules = []
        self.active_alerts = {}
        self.alert_history = deque(maxlen=1000)
    
    def add_rule(self, name: str, condition: callable, threshold: float, 
                 severity: str = 'warning', cooldown: int = 300):
        """添加告警规则"""
        rule = {
            'name': name,
            'condition': condition,
            'threshold': threshold,
            'severity': severity,
            'cooldown': cooldown,
            'last_triggered': None
        }
        self.alert_rules.append(rule)
    
    def check_alerts(self, metrics: Dict[str, Any]):
        """检查告警条件"""
        now = datetime.now()
        
        for rule in self.alert_rules:
            try:
                # 检查冷却时间
                if (rule['last_triggered'] and 
                    (now - rule['last_triggered']).total_seconds() < rule['cooldown']):
                    continue
                
                # 评估条件
                if rule['condition'](metrics, rule['threshold']):
                    alert_id = f"{rule['name']}_{int(now.timestamp())}"
                    
                    alert = {
                        'id': alert_id,
                        'name': rule['name'],
                        'severity': rule['severity'],
                        'message': f"Alert: {rule['name']} triggered",
                        'timestamp': now,
                        'metrics': metrics
                    }
                    
                    self.active_alerts[alert_id] = alert
                    self.alert_history.append(alert)
                    rule['last_triggered'] = now
                    
                    logger.warning(f"🚨 告警触发: {rule['name']}")
                    
            except Exception as e:
                logger.error(f"告警规则检查失败 {rule['name']}: {e}")
    
    def get_active_alerts(self) -> List[Dict]:
        """获取活跃告警"""
        return list(self.active_alerts.values())
    
    def resolve_alert(self, alert_id: str):
        """解决告警"""
        if alert_id in self.active_alerts:
            del self.active_alerts[alert_id]
            logger.info(f"✅ 告警已解决: {alert_id}")


class SystemMonitor:
    """系统监控器"""
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.alert_manager = AlertManager()
        self.monitoring_task = None
        self.is_running = False
        
        # 设置默认告警规则
        self._setup_default_alerts()
    
    def _setup_default_alerts(self):
        """设置默认告警规则"""
        # CPU使用率告警
        self.alert_manager.add_rule(
            name="high_cpu_usage",
            condition=lambda m, t: m.get('gauges', {}).get('cpu_usage', 0) > t,
            threshold=80.0,
            severity='warning'
        )
        
        # 内存使用率告警
        self.alert_manager.add_rule(
            name="high_memory_usage",
            condition=lambda m, t: m.get('gauges', {}).get('memory_percent', 0) > t,
            threshold=85.0,
            severity='warning'
        )
        
        # 错误率告警
        self.alert_manager.add_rule(
            name="high_error_rate",
            condition=lambda m, t: self._calculate_error_rate(m) > t,
            threshold=0.05,  # 5%错误率
            severity='critical'
        )
    
    def _calculate_error_rate(self, metrics: Dict) -> float:
        """计算错误率"""
        counters = metrics.get('counters', {})
        total_requests = sum(v for k, v in counters.items() if k.startswith('api_requests_'))
        error_requests = sum(v for k, v in counters.items() if k.startswith('api_requests_5'))
        
        if total_requests == 0:
            return 0.0
        
        return error_requests / total_requests
    
    async def start_monitoring(self, interval: int = 30):
        """开始监控"""
        if self.is_running:
            return
        
        self.is_running = True
        self.monitoring_task = asyncio.create_task(self._monitoring_loop(interval))
        logger.info(f"✅ 系统监控已启动，间隔: {interval}秒")
    
    async def stop_monitoring(self):
        """停止监控"""
        self.is_running = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        logger.info("系统监控已停止")
    
    async def _monitoring_loop(self, interval: int):
        """监控循环"""
        while self.is_running:
            try:
                # 收集系统指标
                self.metrics_collector.record_system_metrics()
                
                # 获取指标摘要
                metrics_summary = self.metrics_collector.get_metrics_summary()
                
                # 检查告警
                self.alert_manager.check_alerts(metrics_summary)
                
                await asyncio.sleep(interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"监控循环错误: {e}")
                await asyncio.sleep(interval)
    
    def get_health_status(self) -> Dict[str, Any]:
        """获取健康状态"""
        metrics = self.metrics_collector.get_metrics_summary()
        alerts = self.alert_manager.get_active_alerts()
        
        # 计算健康分数
        health_score = 100
        if alerts:
            critical_alerts = [a for a in alerts if a['severity'] == 'critical']
            warning_alerts = [a for a in alerts if a['severity'] == 'warning']
            health_score -= len(critical_alerts) * 20 + len(warning_alerts) * 10
        
        health_score = max(0, health_score)
        
        status = 'healthy'
        if health_score < 60:
            status = 'unhealthy'
        elif health_score < 80:
            status = 'degraded'
        
        return {
            'status': status,
            'health_score': health_score,
            'active_alerts': len(alerts),
            'critical_alerts': len([a for a in alerts if a['severity'] == 'critical']),
            'uptime': time.time() - self.metrics_collector.gauges.get('start_time', time.time()),
            'last_check': datetime.now().isoformat()
        }


# 全局监控实例
system_monitor = SystemMonitor()
