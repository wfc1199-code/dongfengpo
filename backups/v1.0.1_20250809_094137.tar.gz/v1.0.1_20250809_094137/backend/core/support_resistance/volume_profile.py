"""
成交量分布分析模块
Volume Profile Analysis
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class VolumeProfileAnalyzer:
    """成交量分布分析器"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.bins = self.config.get('bins', 50)  # 价格区间数量
        self.value_area_percent = self.config.get('value_area_percent', 0.7)  # 价值区域百分比
        self.hvn_threshold = self.config.get('hvn_threshold', 1.5)  # 高成交量节点阈值
        self.lvn_threshold = self.config.get('lvn_threshold', 0.5)  # 低成交量节点阈值
        
    def analyze(self, 
                prices: List[float], 
                volumes: List[float],
                timestamps: Optional[List[str]] = None) -> Dict:
        """
        分析成交量分布
        
        Args:
            prices: 价格序列
            volumes: 成交量序列
            timestamps: 时间戳序列（可选）
            
        Returns:
            成交量分布分析结果
        """
        if len(prices) != len(volumes) or len(prices) < 10:
            return {}
            
        # 1. 创建价格-成交量分布
        volume_profile = self._create_volume_profile(prices, volumes)
        
        # 2. 找出POC（控制点）
        poc = self._find_poc(volume_profile)
        
        # 3. 计算价值区域
        value_area = self._calculate_value_area(volume_profile, poc)
        
        # 4. 识别HVN和LVN
        hvn_levels, lvn_levels = self._identify_volume_nodes(volume_profile)
        
        # 5. 计算支撑压力强度
        sr_levels = self._volume_based_sr_levels(volume_profile, prices)
        
        return {
            'volume_profile': volume_profile,
            'poc': poc,
            'value_area': value_area,
            'hvn_levels': hvn_levels,
            'lvn_levels': lvn_levels,
            'sr_levels': sr_levels,
            'statistics': self._calculate_statistics(volume_profile, prices, volumes)
        }
        
    def _create_volume_profile(self, 
                              prices: List[float], 
                              volumes: List[float]) -> Dict[float, float]:
        """创建价格-成交量分布图"""
        # 确定价格范围
        min_price = min(prices)
        max_price = max(prices)
        price_range = max_price - min_price
        
        # 创建价格区间
        bin_size = price_range / self.bins
        price_bins = defaultdict(float)
        
        # 累计每个价格区间的成交量
        for price, volume in zip(prices, volumes):
            bin_index = int((price - min_price) / bin_size)
            bin_price = min_price + bin_index * bin_size + bin_size / 2
            price_bins[round(bin_price, 2)] += volume
            
        # 转换为排序的字典
        sorted_profile = dict(sorted(price_bins.items()))
        
        return sorted_profile
        
    def _find_poc(self, volume_profile: Dict[float, float]) -> Dict:
        """找出POC（Point of Control）- 最大成交量价位"""
        if not volume_profile:
            return {}
            
        max_volume = max(volume_profile.values())
        poc_price = [price for price, vol in volume_profile.items() 
                     if vol == max_volume][0]
        
        return {
            'price': poc_price,
            'volume': max_volume,
            'percentage': max_volume / sum(volume_profile.values()) * 100
        }
        
    def _calculate_value_area(self, 
                             volume_profile: Dict[float, float],
                             poc: Dict) -> Dict:
        """计算价值区域（70%成交量集中区域）"""
        if not volume_profile or not poc:
            return {}
            
        total_volume = sum(volume_profile.values())
        target_volume = total_volume * self.value_area_percent
        
        # 从POC开始向两边扩展
        poc_price = poc['price']
        prices = sorted(volume_profile.keys())
        poc_index = prices.index(poc_price)
        
        accumulated_volume = volume_profile[poc_price]
        high_index = poc_index
        low_index = poc_index
        
        # 交替向上下扩展
        while accumulated_volume < target_volume:
            expanded = False
            
            # 尝试向上扩展
            if high_index < len(prices) - 1:
                high_index += 1
                accumulated_volume += volume_profile[prices[high_index]]
                expanded = True
                
            if accumulated_volume >= target_volume:
                break
                
            # 尝试向下扩展
            if low_index > 0:
                low_index -= 1
                accumulated_volume += volume_profile[prices[low_index]]
                expanded = True
                
            if not expanded:
                break
                
        return {
            'high': prices[high_index],
            'low': prices[low_index],
            'volume': accumulated_volume,
            'percentage': accumulated_volume / total_volume * 100,
            'range': prices[high_index] - prices[low_index]
        }
        
    def _identify_volume_nodes(self, 
                              volume_profile: Dict[float, float]) -> Tuple[List[Dict], List[Dict]]:
        """识别高成交量节点(HVN)和低成交量节点(LVN)"""
        if not volume_profile:
            return [], []
            
        avg_volume = np.mean(list(volume_profile.values()))
        hvn_levels = []  # High Volume Nodes
        lvn_levels = []  # Low Volume Nodes
        
        for price, volume in volume_profile.items():
            volume_ratio = volume / avg_volume
            
            if volume_ratio >= self.hvn_threshold:
                hvn_levels.append({
                    'price': price,
                    'volume': volume,
                    'ratio': volume_ratio,
                    'type': 'hvn'
                })
            elif volume_ratio <= self.lvn_threshold:
                lvn_levels.append({
                    'price': price,
                    'volume': volume,
                    'ratio': volume_ratio,
                    'type': 'lvn'
                })
                
        # 按成交量排序
        hvn_levels.sort(key=lambda x: x['volume'], reverse=True)
        lvn_levels.sort(key=lambda x: x['volume'])
        
        return hvn_levels, lvn_levels
        
    def _volume_based_sr_levels(self,
                               volume_profile: Dict[float, float],
                               prices: List[float]) -> List[Dict]:
        """基于成交量分布识别支撑压力位"""
        sr_levels = []
        current_price = prices[-1] if prices else 0
        
        # HVN通常形成支撑或压力
        hvn_levels, lvn_levels = self._identify_volume_nodes(volume_profile)
        
        for hvn in hvn_levels[:10]:  # 只取前10个最强的
            level_type = 'support' if hvn['price'] < current_price else 'resistance'
            
            sr_levels.append({
                'price': hvn['price'],
                'type': level_type,
                'source': 'volume_hvn',
                'strength': min(hvn['ratio'] * 30, 100),  # 转换为0-100分数
                'volume': hvn['volume'],
                'description': f'高成交量区域 (HVN)'
            })
            
        # LVN可能成为突破后的目标位
        for lvn in lvn_levels[:5]:  # 只取前5个
            sr_levels.append({
                'price': lvn['price'],
                'type': 'target',
                'source': 'volume_lvn',
                'strength': 20,  # LVN强度较低
                'volume': lvn['volume'],
                'description': f'低成交量区域 (LVN) - 潜在突破目标'
            })
            
        return sr_levels
        
    def _calculate_statistics(self,
                            volume_profile: Dict[float, float],
                            prices: List[float],
                            volumes: List[float]) -> Dict:
        """计算统计信息"""
        total_volume = sum(volumes)
        avg_price = np.mean(prices)
        
        # 计算VWAP（成交量加权平均价格）
        vwap = sum(p * v for p, v in zip(prices, volumes)) / total_volume
        
        # 计算成交量分布的偏度
        profile_values = list(volume_profile.values())
        volume_skew = self._calculate_skewness(profile_values)
        
        return {
            'total_volume': total_volume,
            'average_price': round(avg_price, 2),
            'vwap': round(vwap, 2),
            'volume_skew': round(volume_skew, 2),
            'profile_bins': len(volume_profile),
            'price_range': max(prices) - min(prices)
        }
        
    def _calculate_skewness(self, values: List[float]) -> float:
        """计算偏度"""
        if len(values) < 3:
            return 0.0
            
        mean = np.mean(values)
        std = np.std(values)
        
        if std == 0:
            return 0.0
            
        skew = np.mean([(x - mean) ** 3 for x in values]) / (std ** 3)
        return skew
        
    def get_volume_at_price(self, 
                           volume_profile: Dict[float, float],
                           target_price: float) -> float:
        """获取特定价格的成交量"""
        # 找到最接近的价格区间
        if not volume_profile:
            return 0.0
            
        prices = list(volume_profile.keys())
        closest_price = min(prices, key=lambda x: abs(x - target_price))
        
        return volume_profile.get(closest_price, 0.0)