#!/usr/bin/env python3
"""测试实时异动检测功能"""

import os
import sys
import asyncio
from datetime import datetime

# 设置测试模式环境变量
os.environ['DONGFENG_TEST_MODE'] = 'true'

# 添加backend目录到Python路径
sys.path.insert(0, '/Users/wangfangchun/东风破/backend')

from core.anomaly_detection import StockAnalysisEngine
from core.data_sources import StockDataManager

async def test_realtime_detection():
    """测试实时异动检测"""
    
    print("=" * 60)
    print("🧪 东风破 - 实时异动检测测试")
    print("=" * 60)
    
    # 初始化数据源管理器
    data_manager = StockDataManager()
    
    # 初始化异动检测引擎
    anomaly_engine = StockAnalysisEngine(data_manager)
    
    # 测试股票列表
    test_stocks = [
        "sh600519",  # 贵州茅台
        "sz000858",  # 五粮液
        "sz300750",  # 宁德时代
        "sz002594",  # 比亚迪
        "sh600036",  # 招商银行
    ]
    
    print(f"\n📊 测试股票列表: {test_stocks}")
    print(f"⏰ 当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n" + "-" * 60)
    
    # 获取实时数据
    print("\n🔍 获取实时行情数据...")
    realtime_data = await data_manager.get_realtime_data(test_stocks)
    
    if not realtime_data:
        print("❌ 无法获取实时数据")
        return
    
    print(f"✅ 成功获取 {len(realtime_data)} 只股票的数据\n")
    
    # 显示每只股票的基本信息
    for code, data in realtime_data.items():
        if data:
            name = data.get('name', '未知')
            price = data.get('current', 0)
            change = data.get('change_percent', 0)
            volume = data.get('volume', 0)
            turnover = data.get('turnoverRate', 0)
            
            print(f"📈 {name} ({code})")
            print(f"   价格: ¥{price:.2f}")
            print(f"   涨跌: {change:+.2f}%")
            print(f"   成交量: {volume/10000:.0f}万手")
            print(f"   换手率: {turnover:.2f}%")
            print()
    
    print("-" * 60)
    print("\n🚨 检测异动...")
    
    # 检测异动
    anomalies = []
    for code, data in realtime_data.items():
        if data:
            change_percent = data.get('change_percent', 0)
            turnover_rate = data.get('turnoverRate', 0)
            
            # 简单的异动判断逻辑
            if abs(change_percent) > 3 or turnover_rate > 5:
                anomaly_type = []
                if change_percent > 3:
                    anomaly_type.append("大幅上涨")
                elif change_percent < -3:
                    anomaly_type.append("大幅下跌")
                if turnover_rate > 5:
                    anomaly_type.append("高换手")
                
                anomalies.append({
                    'code': code,
                    'name': data.get('name', ''),
                    'type': ', '.join(anomaly_type),
                    'change': change_percent,
                    'turnover': turnover_rate
                })
    
    if anomalies:
        print(f"\n🔥 发现 {len(anomalies)} 个异动:\n")
        for anomaly in anomalies:
            print(f"  ⚠️ {anomaly['name']} ({anomaly['code']})")
            print(f"     异动类型: {anomaly['type']}")
            print(f"     涨跌幅: {anomaly['change']:+.2f}%")
            print(f"     换手率: {anomaly['turnover']:.2f}%")
            print()
    else:
        print("\n✅ 未发现明显异动")
    
    print("=" * 60)
    print("测试完成！")
    print("=" * 60)

if __name__ == "__main__":
    # 运行异步测试
    asyncio.run(test_realtime_detection())