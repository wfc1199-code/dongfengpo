import React, { useState } from 'react';
import './AlertPanel.css';

interface Alert {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

const AlertPanel: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: '1',
      type: 'info',
      title: '系统启动',
      message: '东风破异动检测系统已启动，正在监控市场数据',
      timestamp: new Date(),
      read: false
    },
    {
      id: '2',
      type: 'success',
      title: '数据连接正常',
      message: '已成功连接数据源，实时数据更新中',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      read: false
    }
  ]);

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'success': return '✅';
      case 'warning': return '⚠️';
      case 'error': return '❌';
      case 'info': return 'ℹ️';
      default: return '📢';
    }
  };

  const formatTime = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    return timestamp.toLocaleDateString();
  };

  const markAsRead = (id: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === id ? { ...alert, read: true } : alert
      )
    );
  };

  const clearAll = () => {
    setAlerts([]);
  };

  const unreadCount = alerts.filter(alert => !alert.read).length;

  return (
    <div className="alert-panel">
      <div className="panel-header">
        <h3>系统通知</h3>
        <div className="alert-controls">
          {unreadCount > 0 && (
            <span className="unread-badge">{unreadCount}</span>
          )}
          <button 
            className="clear-btn" 
            onClick={clearAll}
            title="清空所有通知"
          >
            🗑️
          </button>
        </div>
      </div>

      <div className="alerts-list">
        {alerts.length === 0 ? (
          <div className="no-alerts">
            <div className="no-data-icon">🔔</div>
            <p>暂无系统通知</p>
          </div>
        ) : (
          alerts.map((alert) => (
            <div 
              key={alert.id} 
              className={`alert-item ${alert.type} ${alert.read ? 'read' : 'unread'}`}
              onClick={() => markAsRead(alert.id)}
            >
              <div className="alert-icon">
                {getAlertIcon(alert.type)}
              </div>
              
              <div className="alert-content">
                <div className="alert-title">
                  {alert.title}
                  {!alert.read && <span className="new-indicator">●</span>}
                </div>
                <div className="alert-message">
                  {alert.message}
                </div>
                <div className="alert-time">
                  {formatTime(alert.timestamp)}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="panel-footer">
        <div className="system-status">
          <span className="status-indicator online">●</span>
          <span>系统运行正常</span>
        </div>
      </div>
    </div>
  );
};

export default AlertPanel; 