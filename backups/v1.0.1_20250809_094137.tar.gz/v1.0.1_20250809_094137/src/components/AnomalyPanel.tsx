import React from 'react';
import './AnomalyPanel.css';

interface AnomalyData {
  stock_code: string;
  stock_name: string;
  anomaly_type: string;
  confidence: number;
  timestamp: string;
  details: any;
}

interface AnomalyPanelProps {
  anomalies: AnomalyData[];
  onStockSelect?: (stockCode: string) => void; // 添加股票选择回调
  tradingStatus?: {
    status: string;
    message?: string;
    nextTradingTime?: string;
  } | null;
}

const AnomalyPanel: React.FC<AnomalyPanelProps> = ({ anomalies, onStockSelect, tradingStatus }) => {
  const getAnomalyTypeText = (type: string) => {
    const typeMap: Record<string, string> = {
      'volume_spike': '成交量异动',
      'price_surge': '价格拉升',
      'big_order': '大单买入',
      'breakthrough': '横盘突破',
      'capital_inflow': '资金流入',
      'momentum_acceleration': '动量加速'
    };
    return typeMap[type] || type;
  };

  const getConfidenceLevel = (confidence: number) => {
    if (confidence >= 0.8) return { level: 'high', text: '高' };
    if (confidence >= 0.6) return { level: 'medium', text: '中' };
    return { level: 'low', text: '低' };
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const formatDetails = (details: any) => {
    if (!details) return null;
    
    const items = [];
    if (details.volume_ratio) {
      items.push(`量比: ${details.volume_ratio.toFixed(2)}`);
    }
    if (details.price_change) {
      items.push(`涨幅: ${(details.price_change * 100).toFixed(2)}%`);
    }
    if (details.amount) {
      items.push(`金额: ${(details.amount / 10000).toFixed(0)}万`);
    }
    if (details.breakout_strength) {
      items.push(`突破强度: ${details.breakout_strength.toFixed(2)}`);
    }
    
    return items.join(' | ');
  };

  // 处理股票点击事件
  const handleStockClick = (stockCode: string, stockName: string) => {
    if (onStockSelect) {
      onStockSelect(stockCode);
      console.log(`🤖 AI异动股票点击: ${stockCode} (${stockName})`);
    }
  };

  return (
    <div className="anomaly-panel">
      <div className="panel-header">
        <h3>AI异动检测</h3>
        <div className="anomaly-stats">
          <span className="total-count">{anomalies.length}</span>
          <span className="stats-text">条异动</span>
        </div>
      </div>

      <div className="anomaly-list">
        {tradingStatus && tradingStatus.status === 'closed' ? (
          <div className="no-anomalies">
            <div className="no-data-icon">🕐</div>
            <p>{tradingStatus.message || '当前非交易时间'}</p>
            <small>下次开盘时间: {tradingStatus.nextTradingTime || '待定'}</small>
          </div>
        ) : anomalies.length === 0 ? (
          <div className="no-anomalies">
            <div className="no-data-icon">📊</div>
            <p>暂无异动检测</p>
            <small>系统正在监控中...</small>
          </div>
        ) : (
          anomalies.map((anomaly, index) => {
            const confidenceInfo = getConfidenceLevel(anomaly.confidence);
            return (
              <div 
                key={index} 
                className={`anomaly-item ${onStockSelect ? 'clickable' : ''}`}
                onClick={() => handleStockClick(anomaly.stock_code, anomaly.stock_name)}
              >
                <div className="anomaly-header">
                  <div className="stock-info">
                    <span className="stock-code">{anomaly.stock_code}</span>
                    <span className="stock-name">{anomaly.stock_name}</span>
                  </div>
                  <div className="time">{formatTime(anomaly.timestamp)}</div>
                  {onStockSelect && (
                    <div className="click-hint">📊</div>
                  )}
                </div>

                <div className="anomaly-content">
                  <div className="anomaly-type">
                    <span className="type-badge">
                      {getAnomalyTypeText(anomaly.anomaly_type)}
                    </span>
                    <span className={`confidence ${confidenceInfo.level}`}>
                      {confidenceInfo.text}信度 {(anomaly.confidence * 100).toFixed(0)}%
                    </span>
                  </div>

                  {anomaly.details && (
                    <div className="anomaly-details">
                      {formatDetails(anomaly.details)}
                    </div>
                  )}
                </div>

                <div className="anomaly-indicator">
                  <div 
                    className={`indicator-bar ${confidenceInfo.level}`}
                    style={{ width: `${anomaly.confidence * 100}%` }}
                  ></div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="panel-footer">
        <div className="legend">
          <div className="legend-item">
            <div className="legend-color high"></div>
            <span>高可信度 (≥80%)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color medium"></div>
            <span>中可信度 (60-80%)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color low"></div>
            <span>低可信度 (&lt;60%)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnomalyPanel; 