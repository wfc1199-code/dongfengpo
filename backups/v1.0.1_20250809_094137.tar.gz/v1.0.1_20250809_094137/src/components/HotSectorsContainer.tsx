import React, { useState, useEffect } from 'react';
import HotSectors from './HotSectors';

interface HotSector {
  sector_name: string;
  stock_count: number;
  avg_change: number;
  total_amount: number;
  rank: number;
  anomaly_count?: number;
  anomaly_ratio?: number;
  avg_volume_ratio?: number;
  hot_score?: number;
  trend?: string;
  category?: string;
  description?: string;
}

interface HotSectorsContainerProps {
  selectedStock?: string;
  onStockSelect?: (stockCode: string) => void;
}

const HotSectorsContainer: React.FC<HotSectorsContainerProps> = ({ 
  selectedStock, 
  onStockSelect 
}) => {
  const [sectors, setSectors] = useState<HotSector[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchHotSectors = async () => {
    try {
              const response = await fetch('http://localhost:9000/api/anomaly/hot-sectors?sort_by=hot_score&limit=10');
      if (response.ok) {
        const data = await response.json();
        setSectors(data.sectors || []);
      } else {
        console.error('Failed to fetch hot sectors:', response.status);
        setSectors([]);
      }
    } catch (error) {
      console.error('Error fetching hot sectors:', error);
      setSectors([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHotSectors();
    const interval = setInterval(fetchHotSectors, 30000); // 每30秒更新一次
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="hot-sectors">
        <div className="panel-header">
          <h3>热门板块</h3>
        </div>
        <div style={{ padding: '20px', textAlign: 'center' }}>
          <div>⏳ 加载中...</div>
        </div>
      </div>
    );
  }

  return (
    <HotSectors 
      sectors={sectors}
      selectedStock={selectedStock}
      onStockSelect={onStockSelect}
    />
  );
};

export default HotSectorsContainer; 