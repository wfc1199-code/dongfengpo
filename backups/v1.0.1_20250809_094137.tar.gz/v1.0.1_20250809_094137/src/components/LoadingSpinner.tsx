import React from 'react';
import './LoadingSpinner.css';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  message?: string;
  color?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  size = 'medium', 
  message = '加载中...', 
  color = '#1890ff' 
}) => {
  return (
    <div className={`loading-spinner ${size}`}>
      <div className="spinner-circle" style={{ borderTopColor: color }}>
        <div className="spinner-inner" style={{ borderTopColor: color }}></div>
      </div>
      {message && <div className="spinner-message">{message}</div>}
    </div>
  );
};

export default LoadingSpinner;