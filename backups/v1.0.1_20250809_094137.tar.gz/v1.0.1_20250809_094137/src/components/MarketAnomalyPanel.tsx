import React, { useState, useEffect, useCallback } from 'react';
import './MarketAnomalyPanel.css';

interface AnomalyItem {
  code: string;
  name: string;
  time: string;
  price: number;
  change_percent: number;
  volume_ratio: number;
  type: string;
  severity: string;
  message: string;
  amount: number;
  turnover_rate: number;
  industry?: string;
}

interface MarketAnomalyPanelProps {
  refreshInterval?: number;
  onStockClick?: (code: string) => void;
}

const MarketAnomalyPanel: React.FC<MarketAnomalyPanelProps> = ({
  refreshInterval = 30000,
  onStockClick
}) => {
  const [anomalies, setAnomalies] = useState<AnomalyItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'surge' | 'plunge' | 'volume' | 'limit'>('all');
  const [severityFilter, setSeverityFilter] = useState<'all' | 'S' | 'A' | 'B' | 'C'>('all');
  const [autoRefresh, setAutoRefresh] = useState(true);

  // 获取异动数据
  const fetchAnomalies = useCallback(async () => {
    try {
      setLoading(true);
      
      const params = new URLSearchParams();
      if (severityFilter !== 'all') {
        params.append('severity', severityFilter);
      }
      if (filter !== 'all' && filter !== 'limit') {
        params.append('type', filter);
      }
      // 特殊处理涨跌停，不通过type参数过滤，而是在前端过滤
      
      const response = await fetch(`http://localhost:9000/api/market-scanner/anomalies?${params}`);
      
      if (!response.ok) {
        throw new Error('获取异动数据失败');
      }
      
      const data = await response.json();
      
      if (data.success) {
        let filteredAnomalies = data.anomalies || [];
        
        // 前端过滤涨跌停
        if (filter === 'limit') {
          filteredAnomalies = filteredAnomalies.filter((item: AnomalyItem) => 
            item.type === 'limit_up' || item.type === 'limit_down'
          );
        }
        
        setAnomalies(filteredAnomalies);
        setLastScanTime(data.scan_time);
      }
      
    } catch (error) {
      console.error('获取异动数据失败:', error);
    } finally {
      setLoading(false);
    }
  }, [filter, severityFilter]);

  // 启动市场扫描
  const startScan = useCallback(async () => {
    try {
      setScanning(true);
      
      const response = await fetch('http://localhost:9000/api/market-scanner/scan');
      
      if (!response.ok) {
        throw new Error('启动扫描失败');
      }
      
      const data = await response.json();
      
      if (data.success) {
        if (!data.scanning && data.anomalies) {
          // 如果立即返回了结果（缓存）
          setAnomalies(data.anomalies);
          setLastScanTime(data.scan_time);
          setScanning(false);
        } else {
          // 等待扫描完成，然后获取结果
          setTimeout(() => {
            fetchAnomalies();
            setScanning(false);
          }, 3000);
        }
      }
      
    } catch (error) {
      console.error('启动扫描失败:', error);
      setScanning(false);
    }
  }, [fetchAnomalies]);

  // 已删除测试数据生成功能，始终使用真实数据

  // 初始加载和定时刷新
  useEffect(() => {
    // 初始加载异动数据
    fetchAnomalies();
    
    // 定时刷新
    if (autoRefresh) {
      const interval = setInterval(fetchAnomalies, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchAnomalies, refreshInterval, autoRefresh]);

  // 获取类型标签
  const getTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      'surge': '🚀 拉升',
      'plunge': '📉 下跌',
      'volume_spike': '📊 放量',
      'limit_up': '🔴 涨停',
      'limit_down': '🟢 跌停'
    };
    return labels[type] || type;
  };

  // 获取严重程度样式
  const getSeverityClass = (severity: string) => {
    return `severity-${severity.toLowerCase()}`;
  };

  // 获取涨跌样式
  const getChangeClass = (change: number) => {
    if (change > 0) return 'price-up';
    if (change < 0) return 'price-down';
    return 'price-flat';
  };

  // 格式化时间
  const formatTime = (timeStr: string) => {
    if (!timeStr) return '-';
    const date = new Date(timeStr);
    if (isNaN(date.getTime())) return timeStr;
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className="market-anomaly-panel">
      <div className="panel-header">
        <h3>🔥 全市场异动监控</h3>
        <div className="header-controls">
          <button 
            className={`scan-btn ${scanning ? 'scanning' : ''}`}
            onClick={startScan}
            disabled={scanning}
          >
            {scanning ? '扫描中...' : '🔍 扫描市场'}
          </button>
          
          <label className="auto-refresh">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
            />
            <span>自动刷新</span>
          </label>
          
          {lastScanTime && (
            <span className="scan-time">
              更新: {formatTime(lastScanTime)}
            </span>
          )}
        </div>
      </div>

      <div className="filter-bar">
        <div className="filter-group">
          <label>类型筛选:</label>
          <div className="filter-buttons">
            <button
              className={filter === 'all' ? 'active' : ''}
              onClick={() => setFilter('all')}
            >
              全部
            </button>
            <button
              className={filter === 'surge' ? 'active' : ''}
              onClick={() => setFilter('surge')}
            >
              拉升
            </button>
            <button
              className={filter === 'plunge' ? 'active' : ''}
              onClick={() => setFilter('plunge')}
            >
              下跌
            </button>
            <button
              className={filter === 'volume' ? 'active' : ''}
              onClick={() => setFilter('volume')}
            >
              放量
            </button>
            <button
              className={filter === 'limit' ? 'active' : ''}
              onClick={() => setFilter('limit')}
            >
              涨跌停
            </button>
          </div>
        </div>

        <div className="filter-group">
          <label>等级筛选:</label>
          <div className="filter-buttons">
            <button
              className={severityFilter === 'all' ? 'active' : ''}
              onClick={() => setSeverityFilter('all')}
            >
              全部
            </button>
            <button
              className={`${severityFilter === 'S' ? 'active' : ''} severity-s`}
              onClick={() => setSeverityFilter('S')}
            >
              S级
            </button>
            <button
              className={`${severityFilter === 'A' ? 'active' : ''} severity-a`}
              onClick={() => setSeverityFilter('A')}
            >
              A级
            </button>
            <button
              className={`${severityFilter === 'B' ? 'active' : ''} severity-b`}
              onClick={() => setSeverityFilter('B')}
            >
              B级
            </button>
            <button
              className={`${severityFilter === 'C' ? 'active' : ''} severity-c`}
              onClick={() => setSeverityFilter('C')}
            >
              C级
            </button>
          </div>
        </div>
      </div>

      <div className="anomaly-list">
        {loading && anomalies.length === 0 ? (
          <div className="loading">加载中...</div>
        ) : anomalies.length === 0 ? (
          <div className="no-data">
            <p>暂无异动数据</p>
            <p className="hint">点击"扫描市场"或"测试数据"按钮开始</p>
          </div>
        ) : (
          anomalies.map((item, index) => (
            <div
              key={`${item.code}-${item.time}-${index}`}
              className={`anomaly-item ${getSeverityClass(item.severity)}`}
              onClick={() => onStockClick?.(item.code)}
            >
              <div className="item-header">
                <div className="stock-info">
                  <span className="stock-name">{item.name}</span>
                  <span className="stock-code">{item.code}</span>
                  {item.industry && (
                    <span className="industry">{item.industry}</span>
                  )}
                </div>
                <div className="anomaly-badges">
                  <span className="type-badge">{getTypeLabel(item.type)}</span>
                  <span className={`severity-badge ${getSeverityClass(item.severity)}`}>
                    {item.severity}级
                  </span>
                </div>
              </div>
              
              <div className="item-body">
                <div className="price-info">
                  <span className="current-price">¥{item.price.toFixed(2)}</span>
                  <span className={`change-percent ${getChangeClass(item.change_percent)}`}>
                    {item.change_percent > 0 ? '+' : ''}{item.change_percent.toFixed(2)}%
                  </span>
                </div>
                
                <div className="volume-info">
                  <span className="volume-ratio">量比: {item.volume_ratio.toFixed(2)}</span>
                  <span className="turnover">换手: {item.turnover_rate.toFixed(2)}%</span>
                  <span className="amount">成交: {(item.amount / 100000000).toFixed(2)}亿</span>
                </div>
                
                <div className="message">
                  {item.message}
                </div>
                
                <div className="time">
                  {item.time}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="panel-footer">
        <div className="stats">
          共 {anomalies.length} 个异动
          {anomalies.length > 0 && (
            <>
              <span className="separator">|</span>
              <span className="stat-item">
                涨停: {anomalies.filter(a => a.type === 'limit_up').length}
              </span>
              <span className="stat-item">
                跌停: {anomalies.filter(a => a.type === 'limit_down').length}
              </span>
              <span className="stat-item">
                S级: {anomalies.filter(a => a.severity === 'S').length}
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketAnomalyPanel;