import React, { useState, useEffect } from 'react';
import './MonitoringScope.css';

interface MonitoringStock {
  code: string;
  name: string;
  current_price: number;
  change_percent: number;
  source: 'favorite' | 'hot_sector';
}

interface MonitoringScopeData {
  total_monitoring: number;
  user_favorites_count: number;
  hot_sector_stocks_count: number;
  user_favorites: MonitoringStock[];
  hot_sector_stocks: MonitoringStock[];
  next_update_in_seconds: number;
  timestamp: string;
}

const MonitoringScope: React.FC = () => {
  const [data, setData] = useState<MonitoringScopeData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [updateCountdown, setUpdateCountdown] = useState<number>(0);

  const fetchMonitoringData = async () => {
    try {
              const response = await fetch('http://localhost:9000/api/system/monitoring-stocks');
      if (response.ok) {
        const result = await response.json();
        setData(result);
        setUpdateCountdown(result.next_update_in_seconds);
      }
    } catch (error) {
      console.error('获取监控数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMonitoringData();
    const interval = setInterval(fetchMonitoringData, 30000); // 每30秒更新一次
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (updateCountdown > 0) {
      const timer = setInterval(() => {
        setUpdateCountdown(prev => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [updateCountdown]);

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getChangeColor = (change: number): string => {
    if (change > 0) return '#ec0000';
    if (change < 0) return '#00da3c'; 
    return '#cccccc';
  };

  if (loading) {
    return (
      <div className="monitoring-scope loading">
        <div className="loading-spinner">⏳</div>
        <p>加载监控范围...</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="monitoring-scope error">
        <p>❌ 无法获取监控数据</p>
      </div>
    );
  }

  return (
    <div className="monitoring-scope">
      <div className="scope-header" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="header-left">
          <span className="scope-icon">🎯</span>
          <h3>监控范围</h3>
          <span className="total-count">({data.total_monitoring}只)</span>
        </div>
        <div className="header-right">
          <div className="update-info">
            <span className="update-timer">
              下次更新: {formatTime(updateCountdown)}
            </span>
          </div>
          <button className="expand-btn">
            {isExpanded ? '▼' : '▶'}
          </button>
        </div>
      </div>

      <div className="scope-summary">
        <div className="summary-item favorite">
          <span className="item-label">自选股</span>
          <span className="item-count">{data.user_favorites_count}只</span>
        </div>
        <div className="summary-item hot">
          <span className="item-label">热门板块</span>
          <span className="item-count">{data.hot_sector_stocks_count}只</span>
        </div>
        <div className="summary-item coverage">
          <span className="item-label">异动覆盖</span>
          <span className="item-count">
            {Math.round((data.hot_sector_stocks_count / data.total_monitoring) * 100)}%
          </span>
        </div>
      </div>

      {isExpanded && (
        <div className="scope-details">
          {/* 自选股 */}
          <div className="stock-section">
            <h4 className="section-title">
              ⭐ 自选股 ({data.user_favorites_count}只)
            </h4>
            <div className="stock-grid">
              {data.user_favorites.map(stock => (
                <div key={stock.code} className="stock-item favorite-stock">
                  <div className="stock-info">
                    <span className="stock-name">{stock.name}</span>
                    <span className="stock-code">({stock.code})</span>
                  </div>
                  <div className="stock-data">
                    <span className="stock-price">¥{stock.current_price}</span>
                    <span 
                      className="stock-change"
                      style={{ color: getChangeColor(stock.change_percent) }}
                    >
                      {stock.change_percent > 0 ? '+' : ''}{stock.change_percent.toFixed(2)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 热门板块股票 */}
          <div className="stock-section">
            <h4 className="section-title">
              🔥 热门板块 ({data.hot_sector_stocks_count}只)
              <span className="section-subtitle">动态更新中</span>
            </h4>
            <div className="stock-grid">
              {data.hot_sector_stocks.map(stock => (
                <div key={stock.code} className="stock-item hot-stock">
                  <div className="stock-info">
                    <span className="stock-name">{stock.name}</span>
                    <span className="stock-code">({stock.code})</span>
                  </div>
                  <div className="stock-data">
                    <span className="stock-price">¥{stock.current_price}</span>
                    <span 
                      className="stock-change"
                      style={{ color: getChangeColor(stock.change_percent) }}
                    >
                      {stock.change_percent > 0 ? '+' : ''}{stock.change_percent.toFixed(2)}%
                    </span>
                  </div>
                  {Math.abs(stock.change_percent) > 5 && (
                    <div className="anomaly-badge">🚀 强势</div>
                  )}
                </div>
              ))}
            </div>
            
            {data.hot_sector_stocks_count > 20 && (
              <div className="more-indicator">
                <p>...还有 {data.hot_sector_stocks_count - 20} 只热门板块股票</p>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="scope-footer">
        <small>
          💡 系统智能监控热门板块成分股，每10分钟动态更新
        </small>
      </div>
    </div>
  );
};

export default MonitoringScope; 