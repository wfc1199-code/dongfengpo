import React, { useEffect, useState, useRef } from 'react';
import './PriceAlertOverlay.css';

interface PriceAlert {
  id: string;
  type: 'surge' | 'plunge';  // 拉升或下跌
  time: string;
  price: number;
  changePercent: number;
  volume: number;
  message: string;
  timestamp: number;
}

interface PriceAlertOverlayProps {
  timeshareData: any[];
  currentPrice: number;
  yesterdayClose: number;
  enabled?: boolean;
  surgeThreshold?: number;  // 拉升阈值（百分比）
  plungeThreshold?: number; // 下跌阈值（百分比）
  volumeThreshold?: number; // 成交量阈值（相对均量倍数）
  alertDuration?: number;   // 提示显示时长（毫秒）
}

const PriceAlertOverlay: React.FC<PriceAlertOverlayProps> = ({
  timeshareData,
  currentPrice,
  yesterdayClose,
  enabled = true,
  surgeThreshold = 1.5,   // 默认1.5%触发拉升提示
  plungeThreshold = -1.5, // 默认-1.5%触发下跌提示
  volumeThreshold = 2,     // 默认2倍均量
  alertDuration = 10000   // 默认显示10秒
}) => {
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [recentAlerts, setRecentAlerts] = useState<PriceAlert[]>([]);
  const lastDataRef = useRef<any>(null);
  const alertIdRef = useRef(0);

  // 监控价格变化
  useEffect(() => {
    if (!enabled || !timeshareData || timeshareData.length === 0) return;

    const latestData = timeshareData[timeshareData.length - 1];
    if (!latestData) return;

    // 计算5分钟、1分钟变化率
    const dataLength = timeshareData.length;
    
    const checkPriceMovement = () => {
      
      // 5分钟变化（约5个数据点）
      if (dataLength >= 5) {
        const data5MinAgo = timeshareData[dataLength - 5];
        const change5Min = ((latestData.price - data5MinAgo.price) / data5MinAgo.price) * 100;
        
        // 检查5分钟急涨急跌
        if (change5Min >= surgeThreshold) {
          createAlert('surge', latestData, change5Min, '5分钟急速拉升');
        } else if (change5Min <= plungeThreshold) {
          createAlert('plunge', latestData, change5Min, '5分钟急速下跌');
        }
      }
      
      // 1分钟变化（最新数据点）
      if (lastDataRef.current) {
        const change1Min = ((latestData.price - lastDataRef.current.price) / lastDataRef.current.price) * 100;
        
        // 检查1分钟急涨急跌（阈值更严格）
        if (change1Min >= surgeThreshold * 0.5) {
          createAlert('surge', latestData, change1Min, '1分钟快速拉升');
        } else if (change1Min <= plungeThreshold * 0.5) {
          createAlert('plunge', latestData, change1Min, '1分钟快速下跌');
        }
      }
      
      // 检查成交量异常
      checkVolumeAnomaly(latestData);
    };

    // 检查成交量异常
    const checkVolumeAnomaly = (data: any) => {
      if (dataLength >= 20) {
        const recent20 = timeshareData.slice(-20);
        const avgVolume = recent20.reduce((sum, d) => sum + d.volume, 0) / 20;
        
        if (data.volume > avgVolume * volumeThreshold) {
          const changePercent = ((data.price - yesterdayClose) / yesterdayClose) * 100;
          if (Math.abs(changePercent) > 0.5) {
            createAlert(
              changePercent > 0 ? 'surge' : 'plunge',
              data,
              changePercent,
              '放量' + (changePercent > 0 ? '上涨' : '下跌')
            );
          }
        }
      }
    };

    checkPriceMovement();
    lastDataRef.current = latestData;
  }, [timeshareData, enabled, surgeThreshold, plungeThreshold, volumeThreshold, yesterdayClose]);

  // 创建提示
  const createAlert = (type: 'surge' | 'plunge', data: any, changePercent: number, message: string) => {
    const alertId = `alert_${++alertIdRef.current}`;
    const newAlert: PriceAlert = {
      id: alertId,
      type,
      time: data.time,
      price: data.price,
      changePercent,
      volume: data.volume,
      message,
      timestamp: Date.now()
    };

    setAlerts(prev => [...prev, newAlert]);
    setRecentAlerts(prev => [...prev, newAlert].slice(-5)); // 保留最近5条

    // 自动移除过期提示
    setTimeout(() => {
      setAlerts(prev => prev.filter(a => a.id !== alertId));
    }, alertDuration);
  };

  // 清理过期提示
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setAlerts(prev => prev.filter(a => now - a.timestamp < alertDuration));
    }, 1000);

    return () => clearInterval(interval);
  }, [alertDuration]);

  if (!enabled) return null;

  return (
    <>
      {/* 浮动提示区域 */}
      <div className="price-alerts-container">
        {alerts.map(alert => (
          <div
            key={alert.id}
            className={`price-alert ${alert.type} fade-in`}
            style={{
              animationDuration: '0.3s'
            }}
          >
            <div className="alert-icon">
              {alert.type === 'surge' ? '🚀' : '⚠️'}
            </div>
            <div className="alert-content">
              <div className="alert-title">{alert.message}</div>
              <div className="alert-details">
                <span className="alert-price">¥{alert.price.toFixed(2)}</span>
                <span className={`alert-change ${alert.type}`}>
                  {alert.changePercent > 0 ? '+' : ''}{alert.changePercent.toFixed(2)}%
                </span>
                <span className="alert-time">{alert.time}</span>
              </div>
              {alert.volume > 0 && (
                <div className="alert-volume">
                  成交量: {(alert.volume / 100).toFixed(0)}手
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 图表内标记提示 */}
      <div className="chart-markers">
        {recentAlerts.map(alert => (
          <div
            key={alert.id}
            className={`chart-marker ${alert.type}`}
            title={`${alert.message}\n价格: ¥${alert.price.toFixed(2)}\n涨幅: ${alert.changePercent.toFixed(2)}%`}
          >
            <span className="marker-icon">
              {alert.type === 'surge' ? '↑' : '↓'}
            </span>
          </div>
        ))}
      </div>

      {/* 实时监控状态 */}
      <div className="monitor-status">
        <div className={`status-indicator ${alerts.length > 0 ? 'active' : ''}`}>
          <span className="status-dot"></span>
          <span className="status-text">
            {alerts.length > 0 ? '异动监控中' : '监控正常'}
          </span>
        </div>
      </div>
    </>
  );
};

export default PriceAlertOverlay;