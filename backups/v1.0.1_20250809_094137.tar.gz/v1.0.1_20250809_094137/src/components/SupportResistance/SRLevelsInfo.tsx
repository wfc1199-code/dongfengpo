/**
 * 支撑压力位信息展示组件
 */

import React from 'react';
import { SupportResistanceLevel } from '../../types/supportResistance';
import './SRLevelsInfo.css';

interface SRLevelsInfoProps {
  levels: SupportResistanceLevel[];
  currentPrice: number;
  maxDisplay?: number;
}

export const SRLevelsInfo: React.FC<SRLevelsInfoProps> = ({
  levels,
  currentPrice,
  maxDisplay = 10
}) => {
  // 分离支撑和压力位
  const supports = levels
    .filter(l => l.price < currentPrice && (l.type === 'support' || l.type === 'both'))
    .sort((a, b) => b.price - a.price)
    .slice(0, maxDisplay / 2);
    
  const resistances = levels
    .filter(l => l.price > currentPrice && (l.type === 'resistance' || l.type === 'both'))
    .sort((a, b) => a.price - b.price)
    .slice(0, maxDisplay / 2);
  
  const getRatingColor = (rating: string) => {
    const colors: Record<string, string> = {
      'S': '#FF1744',
      'A': '#FF6F00',
      'B': '#FFA000',
      'C': '#FFD600',
      'D': '#BDBDBD'
    };
    return colors[rating] || '#BDBDBD';
  };
  
  const getDistanceText = (price: number) => {
    const distance = Math.abs(currentPrice - price);
    const percentage = (distance / currentPrice * 100).toFixed(2);
    return `${distance.toFixed(2)} (${percentage}%)`;
  };
  
  const renderLevel = (level: SupportResistanceLevel) => {
    const distance = ((currentPrice - level.price) / currentPrice * 100).toFixed(2);
    const isApproaching = Math.abs(parseFloat(distance)) < 1;
    
    return (
      <div 
        key={`${level.type}-${level.price}`}
        className={`level-item ${isApproaching ? 'approaching' : ''}`}
      >
        <div className="level-main">
          <span 
            className="level-rating"
            style={{ backgroundColor: getRatingColor(level.rating) }}
          >
            {level.rating}
          </span>
          <span className="level-price">¥{level.price.toFixed(2)}</span>
          <span className={`level-distance ${parseFloat(distance) > 0 ? 'below' : 'above'}`}>
            {distance}%
          </span>
        </div>
        <div className="level-details">
          <span className="level-strength">
            强度: {level.strength.toFixed(0)}
          </span>
          {level.touches && (
            <span className="level-touches">
              触及: {level.touches}次
            </span>
          )}
        </div>
        {level.ratingDetails?.recommendation && (
          <div className="level-recommendation">
            {level.ratingDetails.recommendation}
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div className="sr-levels-info">
      <div className="levels-section resistance-section">
        <div className="section-header">
          <span className="section-title">压力位</span>
          <span className="section-count">{resistances.length}</span>
        </div>
        <div className="levels-list">
          {resistances.length > 0 ? (
            resistances.map(renderLevel)
          ) : (
            <div className="no-levels">暂无压力位</div>
          )}
        </div>
      </div>
      
      <div className="current-price-divider">
        <span className="current-price-label">当前价</span>
        <span className="current-price-value">¥{currentPrice.toFixed(2)}</span>
      </div>
      
      <div className="levels-section support-section">
        <div className="section-header">
          <span className="section-title">支撑位</span>
          <span className="section-count">{supports.length}</span>
        </div>
        <div className="levels-list">
          {supports.length > 0 ? (
            supports.map(renderLevel)
          ) : (
            <div className="no-levels">暂无支撑位</div>
          )}
        </div>
      </div>
    </div>
  );
};