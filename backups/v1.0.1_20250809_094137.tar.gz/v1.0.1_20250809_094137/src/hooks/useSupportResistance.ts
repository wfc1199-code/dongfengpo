/**
 * 支撑压力系统Hook
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { SupportResistanceLevel, SRAnalysisResponse, SRAlert } from '../types/supportResistance';

interface UseSupportResistanceOptions {
  stockCode: string;
  enabled?: boolean;
  updateInterval?: number;
  alertThreshold?: number; // 价格接近支撑压力位的阈值（百分比）
}

export const useSupportResistance = ({
  stockCode,
  enabled = true,
  updateInterval = 5000, // 5秒更新一次
  alertThreshold = 0.01 // 1%
}: UseSupportResistanceOptions) => {
  const [levels, setLevels] = useState<SupportResistanceLevel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [alerts, setAlerts] = useState<SRAlert[]>([]);
  const [analysis, setAnalysis] = useState<SRAnalysisResponse | null>(null);
  
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  
  // 获取支撑压力数据
  const fetchSupportResistance = useCallback(async () => {
    if (!enabled || !stockCode) return;
    
    // 取消之前的请求
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    
    abortControllerRef.current = new AbortController();
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(
        `http://localhost:9000/api/support-resistance/${stockCode}`,
        { signal: abortControllerRef.current.signal }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data: SRAnalysisResponse = await response.json();
      
      // 为每个level添加视觉样式（如果API没有提供的话）
      const styledLevels = data.levels.map(level => ({
        ...level,
        visualStyle: level.visualStyle || getVisualStyle(level)
      }));
      
      setLevels(styledLevels);
      setAnalysis(data);
      
      // 检查价格预警
      if (data.currentPrice) {
        checkAlerts(styledLevels, data.currentPrice);
      }
      
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('获取支撑压力数据失败:', err);
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  }, [stockCode, enabled]);
  
  // 获取视觉样式
  const getVisualStyle = (level: SupportResistanceLevel) => {
    // 检测是否为暗色主题
    const isDarkTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    const baseColors = {
      support: isDarkTheme ? '#4CAF50' : '#00C853',
      resistance: isDarkTheme ? '#FF5722' : '#FF1744',
      both: isDarkTheme ? '#FFC107' : '#FFD600',
      target: isDarkTheme ? '#64B5F6' : '#2196F3'
    };
    
    const lineStyles = {
      S: { style: 'solid', width: 3, opacity: 1 },
      A: { style: 'solid', width: 2, opacity: 0.9 },
      B: { style: 'dashed', width: 1.5, opacity: 0.8 },
      C: { style: 'dotted', width: 1, opacity: 0.7 },
      D: { style: 'dotted', width: 1, opacity: 0.5 }
    };
    
    const rating = level.rating || 'C';
    const styleConfig = lineStyles[rating as keyof typeof lineStyles];
    
    return {
      color: baseColors[level.type],
      lineStyle: styleConfig.style as 'solid' | 'dashed' | 'dotted',
      lineWidth: styleConfig.width + (isDarkTheme ? 0.5 : 0), // 暗色主题下线条稍微粗一点
      opacity: Math.min(styleConfig.opacity + (isDarkTheme ? 0.1 : 0), 1), // 暗色主题下不透明度稍高
      animation: rating === 'S' || rating === 'A'
    };
  };
  
  // 检查价格预警
  const checkAlerts = (levels: SupportResistanceLevel[], currentPrice: number) => {
    const newAlerts: SRAlert[] = [];
    
    levels.forEach(level => {
      const distance = Math.abs(currentPrice - level.price) / level.price;
      
      if (distance <= alertThreshold) {
        newAlerts.push({
          level,
          distance: distance * 100,
          approaching: currentPrice > level.price ? 'above' : 'below',
          alertType: 'approaching',
          message: `价格接近${level.type === 'support' ? '支撑' : '压力'}位 ¥${level.price}（${level.rating}级）`
        });
      }
    });
    
    setAlerts(newAlerts);
  };
  
  // 获取最近的支撑和压力位
  const getNearestLevels = useCallback((currentPrice: number, count: number = 3) => {
    const supports = levels
      .filter(l => l.price < currentPrice && (l.type === 'support' || l.type === 'both'))
      .sort((a, b) => b.price - a.price)
      .slice(0, count);
      
    const resistances = levels
      .filter(l => l.price > currentPrice && (l.type === 'resistance' || l.type === 'both'))
      .sort((a, b) => a.price - b.price)
      .slice(0, count);
      
    return { supports, resistances };
  }, [levels]);
  
  // 根据评级过滤
  const filterByRating = useCallback((ratings: string[]) => {
    return levels.filter(level => ratings.includes(level.rating));
  }, [levels]);
  
  // 根据类型过滤
  const filterByType = useCallback((type: 'support' | 'resistance' | 'both') => {
    return levels.filter(level => level.type === type || level.type === 'both');
  }, [levels]);
  
  // 设置定时更新
  useEffect(() => {
    if (!enabled) return;
    
    // 立即获取一次
    fetchSupportResistance();
    
    // 设置定时器
    intervalRef.current = setInterval(fetchSupportResistance, updateInterval);
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [fetchSupportResistance, enabled, updateInterval]);
  
  return {
    levels,
    loading,
    error,
    alerts,
    analysis,
    getNearestLevels,
    filterByRating,
    filterByType,
    refresh: fetchSupportResistance
  };
};