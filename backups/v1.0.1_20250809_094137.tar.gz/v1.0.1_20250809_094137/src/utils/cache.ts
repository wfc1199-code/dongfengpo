/**
 * 前端缓存管理工具
 * 用于优化数据请求性能，减少重复API调用
 */

interface CacheItem<T> {
  data: T;
  timestamp: number;
  ttl: number; // 生存时间（毫秒）
}

class CacheManager {
  private cache: Map<string, CacheItem<any>> = new Map();
  private readonly defaultTTL = 30000; // 默认30秒

  /**
   * 设置缓存
   */
  set<T>(key: string, data: T, ttl: number = this.defaultTTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  /**
   * 获取缓存
   */
  get<T>(key: string): T | null {
    const item = this.cache.get(key);
    
    if (!item) {
      return null;
    }

    // 检查是否过期
    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.data;
  }

  /**
   * 删除缓存
   */
  delete(key: string): boolean {
    return this.cache.delete(key);
  }

  /**
   * 清空所有缓存
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * 清理过期缓存
   */
  cleanup(): void {
    const now = Date.now();
    const entries = Array.from(this.cache.entries());
    for (const [key, item] of entries) {
      if (now - item.timestamp > item.ttl) {
        this.cache.delete(key);
      }
    }
  }

  /**
   * 获取缓存状态
   */
  getStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    };
  }

  /**
   * 带缓存的异步请求包装器
   */
  async fetchWithCache<T>(
    key: string,
    fetcher: () => Promise<T>,
    ttl?: number
  ): Promise<T> {
    // 先尝试从缓存获取
    const cached = this.get<T>(key);
    if (cached !== null) {
      console.log(`📦 使用缓存数据: ${key}`);
      return cached;
    }

    // 缓存未命中，执行实际请求
    console.log(`🔄 缓存未命中，请求数据: ${key}`);
    const data = await fetcher();
    
    // 将结果存入缓存
    this.set(key, data, ttl);
    
    return data;
  }
}

// 创建全局缓存实例
export const cacheManager = new CacheManager();

// 定期清理过期缓存
setInterval(() => {
  cacheManager.cleanup();
  console.log('🧹 定期清理缓存完成', cacheManager.getStats());
}, 60000); // 每分钟清理一次

export default cacheManager;