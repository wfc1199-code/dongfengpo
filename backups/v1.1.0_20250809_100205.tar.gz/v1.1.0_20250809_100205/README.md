# 东风破 - 智能股票分析系统

## 项目简介

东风破是一个专业的A股智能分析系统，提供实时异动检测、技术分析、资金流向监控等多维度的市场分析功能。系统采用前后端分离架构，支持高并发实时数据处理。

## 🌟 核心功能

### 📈 实时行情监控
- **分时图表**: 高精度分时图展示，支持昨收价基准线
- **K线图表**: 多周期K线图（日线、周线、月线）
- **实时刷新**: 15秒自动刷新，实时捕捉市场变化
- **多股监控**: 支持同时监控55+只股票

### 🚀 AI异动检测
- **智能识别**: 基于机器学习的异动模式识别
- **多维分析**: 涨速、成交量、资金流等多维度异动检测
- **状态分类**: 开始拉升/持续/快停/涨停等精细状态
- **实时预警**: 异动发生时立即推送通知

### 📊 热门板块追踪
- **板块轮动**: 实时监控板块资金流向
- **热度排序**: 按异动数量和涨幅智能排序
- **成分股分析**: 深入分析板块内个股表现
- **时效性筛选**: 支持10分钟、30分钟等时间窗口

### 💰 资金流向分析
- **大单监控**: 识别超过300万元的主力大单
- **资金统计**: 主动买入/卖出资金实时计算
- **流向趋势**: 近2分钟、5分钟资金流向分析
- **主力行为**: 追踪主力建仓、洗盘、拉升行为

### 📍 支撑阻力分析
- **动态计算**: 基于成交密集区的支撑阻力位
- **多周期验证**: 日线、周线、月线多周期确认
- **强度评级**: 支撑阻力位强度量化评分
- **突破提醒**: 价格接近或突破关键位时预警

### 🔧 技术指标
- **均线系统**: MA5/10/20/60多周期均线
- **成交量分析**: 量比、换手率、成交额分析
- **技术形态**: 横盘突破、底部形态识别
- **动量指标**: RSI、MACD等经典指标

## 系统架构

### 技术栈
- **前端**: React 18 + TypeScript + ECharts 5
- **后端**: Python 3.8+ + FastAPI + Uvicorn
- **数据源**: 腾讯财经、东方财富、新浪财经
- **缓存**: 内存缓存 + 文件缓存
- **通信**: RESTful API + WebSocket（规划中）

### 项目结构

```
东风破/
├── frontend/                    # React前端应用
│   ├── src/
│   │   ├── components/         # React组件
│   │   │   ├── TimeShareChartFixed.tsx  # 分时图组件
│   │   │   ├── StockChart.tsx          # K线图组件
│   │   │   ├── AnomalyPanel.tsx        # 异动面板
│   │   │   ├── HotSectors.tsx          # 热门板块
│   │   │   └── SupportResistance/      # 支撑阻力组件
│   │   ├── services/           # API服务
│   │   │   ├── api.service.ts  # 统一API服务类
│   │   │   └── api.ts          # API接口定义
│   │   ├── hooks/              # 自定义Hooks
│   │   │   └── useResourceManager.ts  # 资源管理
│   │   └── App.tsx             # 主应用组件
│   └── package.json            # 前端依赖
│
├── backend/                    # Python后端服务
│   ├── api/                    # API路由
│   │   ├── anomaly_routes.py   # 异动检测接口
│   │   ├── market_scanner.py   # 市场扫描接口
│   │   ├── support_resistance_tdx.py  # 支撑阻力接口
│   │   └── transaction_routes.py      # 成交分析接口
│   ├── core/                   # 核心业务逻辑
│   │   ├── config.py           # 配置管理
│   │   ├── data_sources.py     # 数据源管理
│   │   ├── anomaly_detection.py       # 异动检测算法
│   │   ├── cache_manager.py    # 缓存管理
│   │   └── support_resistance/ # 支撑阻力算法
│   ├── main.py                 # FastAPI主服务
│   └── requirements.txt        # Python依赖
│
├── data/                       # 数据文件
│   └── config.json            # 用户配置
│
├── scripts/                    # 启动脚本
│   ├── start_dongfeng.sh      # 一键启动脚本
│   └── stop_dongfeng.sh       # 停止脚本
│
└── docs/                      # 项目文档
    ├── ARCHITECTURE_FIX.md    # 架构说明
    └── DEVELOPMENT_GUIDE.md   # 开发指南
```

## 快速开始

### 环境要求
- macOS 10.14+ / Linux / Windows
- Node.js 16+
- Python 3.8+
- 内存 4GB+

### 安装步骤

#### 1. 克隆项目
```bash
git clone https://github.com/yourusername/dongfengpo.git
cd dongfengpo
```

#### 2. 安装后端依赖
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

#### 3. 安装前端依赖
```bash
cd ../frontend
npm install
```

### 运行系统

#### 🚀 一键启动（推荐）
```bash
# 使用启动脚本
./scripts/start_dongfeng.sh

# 访问系统
# 前端: http://localhost:3000
# API文档: http://localhost:9000/docs
```

#### 手动启动
```bash
# 终端1：启动后端
cd backend
uvicorn main:app --host 0.0.0.0 --port 9000 --reload

# 终端2：启动前端
cd frontend
npm start
```

#### 停止系统
```bash
./scripts/stop_dongfeng.sh
```

## 配置说明

### 端口配置
- 前端: 3000（可在 frontend/.env 修改）
- 后端: 9000（可在 backend/.env 修改）

### 环境变量
创建 `backend/.env` 文件：
```env
API_HOST=0.0.0.0
API_PORT=9000
CORS_ORIGINS=["http://localhost:3000"]
ENABLE_CACHE=true
CACHE_TTL=300
MONITORING_INTERVAL=15
MAX_MONITORING_STOCKS=100
LOG_LEVEL=INFO
```

### 用户配置
编辑 `data/config.json` 自定义监控股票池和预警参数。

## API文档

### 主要接口

#### 股票数据
- `GET /api/stocks/{code}/realtime` - 实时行情
- `GET /api/stocks/{code}/timeshare` - 分时数据
- `GET /api/stocks/{code}/kline` - K线数据

#### 异动检测
- `GET /api/anomaly/detect-legacy` - AI异动检测
- `GET /api/anomaly/hot-sectors` - 热门板块
- `GET /api/anomaly/sector-stocks/{sector}` - 板块成分股

#### 技术分析
- `POST /api/support-resistance/tdx/calculate` - 支撑阻力计算
- `GET /api/transaction/analyze/{code}` - 成交分析

完整API文档访问: http://localhost:9000/docs

## 性能优化

### 已实现优化
- ✅ 多级缓存机制（内存+文件）
- ✅ 批量数据请求合并
- ✅ 异步并发处理
- ✅ 资源自动清理
- ✅ 错误重试机制

### 性能指标
- API响应时间: <100ms (缓存命中)
- 实时数据延迟: <1s
- 并发支持: 100+ 连接
- 内存占用: <500MB

## 开发指南

### 代码规范
- 前端: ESLint + Prettier
- 后端: Black + isort + mypy
- Git: Conventional Commits

### 测试
```bash
# 后端测试
cd backend
pytest tests/

# 前端测试
cd frontend
npm test
```

### 构建部署
```bash
# 前端构建
cd frontend
npm run build

# Docker部署（开发中）
docker-compose up -d
```

## 故障排除

### 常见问题

1. **端口占用**
   ```bash
   # 查找占用端口的进程
   lsof -i :3000
   lsof -i :9000
   ```

2. **依赖安装失败**
   ```bash
   # 使用国内镜像
   pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
   npm config set registry https://registry.npmmirror.com
   ```

3. **数据源连接失败**
   - 检查网络连接
   - 确认数据源API可用性
   - 查看 `logs/backend.log` 错误信息

## 贡献指南

欢迎提交Issue和Pull Request！

1. Fork项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 更新日志

### v1.0.0 (2025-01-08)
- 🎉 稳定版本发布
- ✨ 完成核心功能开发
- 🐛 修复分时图显示问题
- ⚡ 性能优化和代码重构

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 联系方式

- Issue: [GitHub Issues](https://github.com/yourusername/dongfengpo/issues)
- Email: your.email@example.com

---
*东风破 - 让投资决策更智能* 