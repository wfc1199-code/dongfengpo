"""
全市场异动扫描服务
实时监控所有A股股票的异动情况
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import asyncio
import aiohttp
import pandas as pd
from datetime import datetime, timedelta
import logging
import json
from concurrent.futures import ThreadPoolExecutor
import numpy as np

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
# 共享数据管理器，避免频繁创建导致未关闭的会话
from core.data_sources import StockDataManager as _SDM
from core.cache_manager import cache_manager
_shared_data_manager = _SDM()
router = APIRouter(
    prefix="/api/market-scanner",
    tags=["market-scanner"]
)

class AnomalyAlert(BaseModel):
    """异动警报模型"""
    code: str
    name: str
    time: str
    price: float
    change_percent: float
    volume_ratio: float
    type: str  # 'surge', 'plunge', 'volume_spike', 'limit_up', 'limit_down'
    severity: str  # 'S', 'A', 'B', 'C'
    message: str
    amount: float
    turnover_rate: float
    market_cap: Optional[float] = None
    industry: Optional[str] = None

class MarketScanner:
    """全市场扫描器"""
    
    def __init__(self):
        self.all_stocks = []
        self.scanning = False
        self.last_scan_time = None
        self.anomaly_cache = []
        self.executor = ThreadPoolExecutor(max_workers=20)
        
    async def get_all_stocks(self) -> List[Dict]:
        """
        获取所有A股股票列表
        包括沪深主板、创业板、科创板
        """
        try:
            stocks = []
            
            # 沪市主板 600xxx, 601xxx, 603xxx, 605xxx
            for prefix in ['600', '601', '603', '605']:
                for i in range(1000):
                    code = f"{prefix}{str(i).zfill(3)}"
                    stocks.append({'code': code, 'market': 'sh', 'board': 'main'})
            
            # 深市主板 000xxx, 001xxx
            for prefix in ['000', '001']:
                for i in range(1000):
                    code = f"{prefix}{str(i).zfill(3)}"
                    stocks.append({'code': code, 'market': 'sz', 'board': 'main'})
            
            # 创业板 300xxx, 301xxx
            for prefix in ['300', '301']:
                for i in range(1000):
                    code = f"{prefix}{str(i).zfill(3)}"
                    stocks.append({'code': code, 'market': 'sz', 'board': 'chinext'})
            
            # 科创板 688xxx
            for i in range(1000):
                code = f"688{str(i).zfill(3)}"
                stocks.append({'code': code, 'market': 'sh', 'board': 'star'})
            
            # 实际应用中应该从数据源获取真实的股票列表
            # 这里返回一些常见的活跃股票作为示例
            active_stocks = [
                {'code': '600519', 'name': '贵州茅台', 'market': 'sh', 'board': 'main'},
                {'code': '000858', 'name': '五粮液', 'market': 'sz', 'board': 'main'},
                {'code': '000002', 'name': '万科A', 'market': 'sz', 'board': 'main'},
                {'code': '600036', 'name': '招商银行', 'market': 'sh', 'board': 'main'},
                {'code': '300750', 'name': '宁德时代', 'market': 'sz', 'board': 'chinext'},
                {'code': '002594', 'name': '比亚迪', 'market': 'sz', 'board': 'main'},
                {'code': '000001', 'name': '平安银行', 'market': 'sz', 'board': 'main'},
                {'code': '600030', 'name': '中信证券', 'market': 'sh', 'board': 'main'},
                {'code': '300059', 'name': '东方财富', 'market': 'sz', 'board': 'chinext'},
                {'code': '002415', 'name': '海康威视', 'market': 'sz', 'board': 'main'},
            ]
            
            return active_stocks
            
        except Exception as e:
            logger.error(f"获取股票列表失败: {str(e)}")
            return []
    
    def detect_anomaly(self, stock_data: Dict) -> Optional[AnomalyAlert]:
        """
        检测单个股票的异动
        """
        try:
            code = stock_data.get('code', '')
            name = stock_data.get('name', '')
            current_price = stock_data.get('current_price', 0)
            change_percent = stock_data.get('change_percent', 0)
            volume = stock_data.get('volume', 0)
            amount = stock_data.get('amount', 0)
            yesterday_close = stock_data.get('yesterday_close', 0)
            avg_volume = stock_data.get('avg_volume', volume)
            
            # 计算成交量比
            volume_ratio = volume / avg_volume if avg_volume > 0 else 1
            
            # 计算换手率
            total_shares = stock_data.get('total_shares', 1)
            turnover_rate = (volume / total_shares * 100) if total_shares > 0 else 0
            
            # 异动检测规则
            anomaly_type = None
            severity = 'C'
            message = ''
            
            # 1. 涨停检测
            if change_percent >= 9.8:
                if '300' in code or '688' in code:  # 创业板和科创板
                    if change_percent >= 19.8:
                        anomaly_type = 'limit_up'
                        severity = 'S'
                        message = f"涨停! 涨幅{change_percent:.1f}%"
                else:  # 主板
                    if change_percent >= 9.8:
                        anomaly_type = 'limit_up'
                        severity = 'S'
                        message = f"涨停! 涨幅{change_percent:.1f}%"
            
            # 2. 跌停检测
            elif change_percent <= -9.8:
                if '300' in code or '688' in code:
                    if change_percent <= -19.8:
                        anomaly_type = 'limit_down'
                        severity = 'S'
                        message = f"跌停! 跌幅{abs(change_percent):.1f}%"
                else:
                    if change_percent <= -9.8:
                        anomaly_type = 'limit_down'
                        severity = 'S'
                        message = f"跌停! 跌幅{abs(change_percent):.1f}%"
            
            # 3. 急速拉升
            elif change_percent >= 5 and volume_ratio >= 2:
                anomaly_type = 'surge'
                severity = 'A' if change_percent >= 7 else 'B'
                message = f"急速拉升{change_percent:.1f}%, 量比{volume_ratio:.1f}"
            
            # 4. 快速下跌
            elif change_percent <= -5 and volume_ratio >= 2:
                anomaly_type = 'plunge'
                severity = 'A' if change_percent <= -7 else 'B'
                message = f"快速下跌{abs(change_percent):.1f}%, 量比{volume_ratio:.1f}"
            
            # 5. 巨量异动
            elif volume_ratio >= 5:
                anomaly_type = 'volume_spike'
                severity = 'A' if volume_ratio >= 10 else 'B'
                message = f"巨量异动! 量比{volume_ratio:.1f}, 换手{turnover_rate:.1f}%"
            
            # 6. 高换手异动
            elif turnover_rate >= 15:
                anomaly_type = 'volume_spike'
                severity = 'B'
                message = f"高换手! 换手率{turnover_rate:.1f}%"
            
            # 7. 大幅波动
            elif abs(change_percent) >= 3 and volume_ratio >= 1.5:
                anomaly_type = 'surge' if change_percent > 0 else 'plunge'
                severity = 'C'
                message = f"{'上涨' if change_percent > 0 else '下跌'}{abs(change_percent):.1f}%, 量比{volume_ratio:.1f}"
            
            if anomaly_type:
                return AnomalyAlert(
                    code=code,
                    name=name,
                    time=datetime.now().strftime('%H:%M:%S'),
                    price=current_price,
                    change_percent=change_percent,
                    volume_ratio=volume_ratio,
                    type=anomaly_type,
                    severity=severity,
                    message=message,
                    amount=amount,
                    turnover_rate=turnover_rate,
                    market_cap=stock_data.get('market_cap'),
                    industry=stock_data.get('industry')
                )
            
            return None
            
        except Exception as e:
            logger.error(f"检测异动失败 {stock_data.get('code', '')}: {str(e)}")
            return None
    
    async def scan_market(self) -> List[AnomalyAlert]:
        """
        扫描全市场异动
        """
        try:
            logger.info("开始全市场异动扫描...")
            self.scanning = True
            self.last_scan_time = datetime.now()
            
            # 获取所有股票列表
            stocks = await self.get_all_stocks()
            logger.info(f"准备扫描 {len(stocks)} 只股票")
            
            anomalies = []
            
            # 批量获取股票数据并检测异动
            for stock in stocks:
                # 模拟获取实时数据
                stock_data = await self.get_stock_realtime_data(stock['code'])
                
                if stock_data:
                    # 添加股票名称
                    stock_data['name'] = stock.get('name', stock['code'])
                    
                    # 检测异动
                    anomaly = self.detect_anomaly(stock_data)
                    if anomaly:
                        anomalies.append(anomaly)
            
            # 按严重程度和涨跌幅排序
            severity_order = {'S': 0, 'A': 1, 'B': 2, 'C': 3}
            anomalies.sort(key=lambda x: (
                severity_order.get(x.severity, 4),
                -abs(x.change_percent)
            ))
            
            # 缓存结果
            self.anomaly_cache = anomalies
            
            logger.info(f"扫描完成，发现 {len(anomalies)} 个异动")
            self.scanning = False
            
            return anomalies
            
        except Exception as e:
            logger.error(f"市场扫描失败: {str(e)}")
            self.scanning = False
            return []
    
    async def get_stock_realtime_data(self, code: str) -> Optional[Dict]:
        """
        获取股票实时数据
        """
        try:
            # 复用共享数据管理器
            data_manager = _shared_data_manager

            # 添加市场前缀
            if not code.startswith(('sh', 'sz')):
                # 根据股票代码判断市场
                if code.startswith('6'):
                    code = f'sh{code}'
                elif code.startswith(('0', '3')):
                    code = f'sz{code}'
            
            # 获取实时数据
            realtime_data = await data_manager.get_realtime_data([code])

            if realtime_data and code in realtime_data:
                stock_data = realtime_data[code]
                return {
                    'code': code.replace('sh', '').replace('sz', ''),
                    'current_price': stock_data.get('current_price', 0),
                    'yesterday_close': stock_data.get('yesterday_close', 0),
                    'change_percent': stock_data.get('change_percent', 0),
                    'volume': stock_data.get('volume', 0),
                    'amount': stock_data.get('amount', 0),
                    'avg_volume': stock_data.get('avg_volume', stock_data.get('volume', 0) / 2),
                    'total_shares': stock_data.get('total_shares', 0),
                    'market_cap': stock_data.get('market_cap', 0),
                    'industry': stock_data.get('industry', '未知')
                }
            
            return None
            
        except Exception as e:
            logger.error(f"获取股票数据失败 {code}: {str(e)}")
            return None

# 创建全局扫描器实例
market_scanner = MarketScanner()

@router.get("/scan")
async def scan_market_anomalies(background_tasks: BackgroundTasks):
    """
    扫描全市场异动
    """
    try:
        # 检查是否正在扫描
        if market_scanner.scanning:
            return {
                "success": False,
                "message": "正在扫描中，请稍后...",
                "scanning": True
            }
        
        # 如果有缓存且未过期（5分钟内），返回缓存
        if market_scanner.anomaly_cache and market_scanner.last_scan_time:
            if datetime.now() - market_scanner.last_scan_time < timedelta(minutes=5):
                return {
                    "success": True,
                    "anomalies": [a.dict() for a in market_scanner.anomaly_cache],
                    "count": len(market_scanner.anomaly_cache),
                    "scan_time": market_scanner.last_scan_time.isoformat(),
                    "cached": True
                }
        
        # 后台执行扫描
        background_tasks.add_task(market_scanner.scan_market)
        
        return {
            "success": True,
            "message": "已启动全市场扫描，请稍后查询结果",
            "scanning": True
        }
        
    except Exception as e:
        logger.error(f"启动市场扫描失败: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/anomalies")
async def get_market_anomalies(
    severity: Optional[str] = None,
    type: Optional[str] = None,
    limit: int = 100
):
    """
    获取市场异动列表
    """
    try:
        # 60秒TTL缓存（按过滤条件和limit区分）
        cache_key = f"market_scanner:anomalies:{severity or 'all'}:{type or 'all'}:{limit}"
        cached = await cache_manager.get(cache_key)
        if cached:
            return cached
        # 如果没有缓存，先执行一次扫描
        if not market_scanner.anomaly_cache:
            anomalies = await market_scanner.scan_market()
        else:
            anomalies = market_scanner.anomaly_cache
        
        # 过滤
        if severity:
            anomalies = [a for a in anomalies if a.severity == severity]
        
        if type:
            anomalies = [a for a in anomalies if a.type == type]
        
        # 限制返回数量
        anomalies = anomalies[:limit]
        
        response = {
            "success": True,
            "anomalies": [a.dict() for a in anomalies],
            "count": len(anomalies),
            "total": len(market_scanner.anomaly_cache),
            "scan_time": market_scanner.last_scan_time.isoformat() if market_scanner.last_scan_time else None
        }
        # 写入缓存，TTL 60s
        await cache_manager.set(cache_key, response, ttl=60)
        return response
        
    except Exception as e:
        logger.error(f"获取市场异动失败: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/status")
async def get_scanner_status():
    """
    获取扫描器状态
    """
    return {
        "scanning": market_scanner.scanning,
        "last_scan_time": market_scanner.last_scan_time.isoformat() if market_scanner.last_scan_time else None,
        "cached_count": len(market_scanner.anomaly_cache),
        "stocks_count": len(await market_scanner.get_all_stocks())
    }

@router.get("/realtime-stream")
async def get_realtime_anomalies():
    """
    获取实时异动流（最近5分钟的异动）
    """
    try:
        # 获取最近的异动
        recent_anomalies = []
        
        if market_scanner.anomaly_cache:
            # 获取最近5分钟的异动
            current_time = datetime.now()
            for anomaly in market_scanner.anomaly_cache:
                # 这里简化处理，实际应该根据异动的时间戳过滤
                recent_anomalies.append(anomaly)
        
        # 按时间倒序，最新的在前
        recent_anomalies = recent_anomalies[:20]  # 只返回最新的20条
        
        return {
            "success": True,
            "anomalies": [a.dict() for a in recent_anomalies],
            "count": len(recent_anomalies),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取实时异动失败: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# 已删除测试数据生成接口，始终使用真实数据