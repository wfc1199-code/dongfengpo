"""
成交明细相关API路由
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from core.data_sources import StockDataManager

router = APIRouter(prefix="/api/stocks", tags=["transactions"])

class TransactionAnalyzer:
    """成交明细分析器"""
    
    def __init__(self):
        self.data_source = StockDataManager()
        # 调整大单阈值，更符合实际市场
        self.large_order_threshold = 200000  # 20万（大单）
        self.medium_order_threshold = 50000  # 5万（中单）
        self.super_large_threshold = 1000000  # 100万（超大单）
    
    def get_transactions(self, stock_code: str, start_time: str, end_time: str) -> List[Dict]:
        """
        获取指定时间段的成交明细
        
        参数:
            stock_code: 股票代码
            start_time: 开始时间 (HH:MM:SS)
            end_time: 结束时间 (HH:MM:SS)
        """
        try:
            # 获取分笔成交数据
            # 这里使用tushare或其他数据源获取真实数据
            # df = ts.get_tick_data(stock_code, date=datetime.now().strftime('%Y-%m-%d'))
            
            # 模拟数据用于测试
            transactions = self._generate_mock_transactions(
                stock_code, start_time, end_time
            )
            
            return transactions
        except Exception as e:
            print(f"获取成交明细失败: {e}")
            return []
    
    def _generate_mock_transactions(self, stock_code: str, 
                                   start_time: str, end_time: str) -> List[Dict]:
        """生成模拟成交明细（实际应从数据源获取）"""
        import random
        
        transactions = []
        base_price = 10.0 + random.random() * 50
        
        # 解析时间
        start_h, start_m, start_s = map(int, start_time.split(':'))
        end_h, end_m, end_s = map(int, end_time.split(':'))
        
        # 生成时间序列
        current_time = datetime(2024, 1, 1, start_h, start_m, start_s)
        end_datetime = datetime(2024, 1, 1, end_h, end_m, end_s)
        
        # 计数器用于模拟不同阶段
        transaction_count = 0
        
        # 用于生成连续大单
        continuous_large_order = None
        continuous_count = 0
        
        while current_time <= end_datetime:
            transaction_count += 1
            
            # 根据不同阶段设置不同的成交模式
            if transaction_count < 20:
                # 准备阶段：以小单为主
                if random.random() < 0.8:
                    volume = random.randint(5, 35) * 100  # 500-3500股
                else:
                    volume = random.randint(30, 110) * 100  # 3000-11000股
            elif transaction_count < 80:
                # 主要阶段：大单频繁
                rand = random.random()
                if rand < 0.3:  # 30%超大单
                    volume = random.randint(150, 450) * 100  # 15000-45000股
                elif rand < 0.7:  # 40%大单
                    volume = random.randint(80, 230) * 100  # 8000-23000股
                else:  # 30%中小单
                    volume = random.randint(20, 100) * 100  # 2000-10000股
            else:
                # 收尾阶段：以中小单为主
                if random.random() < 0.85:
                    volume = random.randint(10, 60) * 100  # 1000-6000股
                else:
                    volume = random.randint(60, 180) * 100  # 6000-18000股
            
            # 生成连续大单（在20-80笔之间有更高概率）
            if 20 <= transaction_count <= 80 and random.random() < 0.15:
                if continuous_large_order is None:
                    # 开始一组连续大单
                    continuous_large_order = {
                        'volume': random.randint(100, 300) * 100,  # 10000-30000股
                        'type': 'buy' if random.random() < 0.6 else 'sell',
                        'count': random.randint(3, 5)  # 连续3-5笔
                    }
                    continuous_count = 0
            
            # 如果在连续大单模式中
            if continuous_large_order and continuous_count < continuous_large_order['count']:
                volume = continuous_large_order['volume'] * (1 + (random.random() - 0.5) * 0.2)  # ±20%波动
                trade_type = continuous_large_order['type']
                continuous_count += 1
                if continuous_count >= continuous_large_order['count']:
                    continuous_large_order = None  # 结束连续大单
            else:
                # 判断买卖方向
                buy_prob = 0.5 + (random.random() - 0.5) * 0.3
                if random.random() < buy_prob:
                    trade_type = 'buy'
                elif random.random() < 0.8:
                    trade_type = 'sell'
                else:
                    trade_type = 'neutral'
            
            # 生成成交记录
            price = base_price * (1 + (random.random() - 0.5) * 0.02)
            amount = price * volume
            
            # 判断单子级别
            if amount >= self.super_large_threshold:
                level = 'super_large'
            elif amount >= self.large_order_threshold:
                level = 'large'
            elif amount >= self.medium_order_threshold:
                level = 'medium'
            else:
                level = 'small'
            
            transactions.append({
                'time': current_time.strftime('%H:%M:%S'),
                'price': round(price, 2),
                'volume': volume,
                'amount': round(amount, 2),
                'type': trade_type,
                'level': level
            })
            
            # 随机增加时间（1-10秒）
            current_time += timedelta(seconds=random.randint(1, 10))
        
        return transactions
    
    def analyze_transactions(self, transactions: List[Dict]) -> Dict:
        """
        分析成交明细，生成统计数据
        """
        if not transactions:
            return {}
        
        df = pd.DataFrame(transactions)
        
        # 基础统计
        total_count = len(df)
        buy_count = len(df[df['type'] == 'buy'])
        sell_count = len(df[df['type'] == 'sell'])
        neutral_count = len(df[df['type'] == 'neutral'])
        
        # 成交量和金额统计
        total_volume = df['volume'].sum()
        total_amount = df['amount'].sum()
        avg_price = df['price'].mean()
        avg_volume = df['volume'].mean()
        
        # 大单统计（包括大单和超大单）
        large_orders = df[df['level'].isin(['large', 'super_large'])]
        large_order_count = len(large_orders)
        large_order_volume = large_orders['volume'].sum() if len(large_orders) > 0 else 0
        large_order_amount = large_orders['amount'].sum() if len(large_orders) > 0 else 0
        
        # 分区间统计
        range_stats = {
            '5-10万': {'count': 0, 'amount': 0},
            '10-20万': {'count': 0, 'amount': 0},
            '20-50万': {'count': 0, 'amount': 0},
            '50-100万': {'count': 0, 'amount': 0},
            '100-200万': {'count': 0, 'amount': 0},
            '200-300万': {'count': 0, 'amount': 0},
            '300万以上': {'count': 0, 'amount': 0}
        }
        
        for _, row in large_orders.iterrows():
            amount = row['amount']
            if 50000 <= amount < 100000:
                range_stats['5-10万']['count'] += 1
                range_stats['5-10万']['amount'] += amount
            elif 100000 <= amount < 200000:
                range_stats['10-20万']['count'] += 1
                range_stats['10-20万']['amount'] += amount
            elif 200000 <= amount < 500000:
                range_stats['20-50万']['count'] += 1
                range_stats['20-50万']['amount'] += amount
            elif 500000 <= amount < 1000000:
                range_stats['50-100万']['count'] += 1
                range_stats['50-100万']['amount'] += amount
            elif 1000000 <= amount < 2000000:
                range_stats['100-200万']['count'] += 1
                range_stats['100-200万']['amount'] += amount
            elif 2000000 <= amount < 3000000:
                range_stats['200-300万']['count'] += 1
                range_stats['200-300万']['amount'] += amount
            else:
                range_stats['300万以上']['count'] += 1
                range_stats['300万以上']['amount'] += amount
        
        # 检测连续大单
        continuous_orders = []
        if len(large_orders) >= 3:
            large_orders_sorted = large_orders.sort_index()
            for i in range(len(large_orders_sorted) - 2):
                # 检查索引是否连续（允许间隔4笔以内）
                idx1 = large_orders_sorted.index[i]
                idx3 = large_orders_sorted.index[i+2]
                if idx3 - idx1 <= 4:
                    # 检查金额是否相近
                    amounts = [large_orders_sorted.iloc[i+j]['amount'] for j in range(3)]
                    avg_amount = np.mean(amounts)
                    if all(abs(a - avg_amount) / avg_amount < 0.3 for a in amounts):
                        # 检查是否同向
                        types = [large_orders_sorted.iloc[i+j]['type'] for j in range(3)]
                        if len(set(types)) == 1:
                            continuous_orders.append({
                                'count': 3,
                                'avg_amount': round(avg_amount, 2),
                                'total_amount': round(sum(amounts), 2),
                                'type': types[0],
                                'time_range': f"{large_orders_sorted.iloc[i]['time']}-{large_orders_sorted.iloc[i+2]['time']}"
                            })
        
        # 价格区间
        price_min = df['price'].min()
        price_max = df['price'].max()
        price_range = price_max - price_min
        
        # 成交量分布
        volume_by_level = df.groupby('level')['volume'].sum()
        volume_distribution = {
            'large': (volume_by_level.get('large', 0) / total_volume * 100) if total_volume > 0 else 0,
            'medium': (volume_by_level.get('medium', 0) / total_volume * 100) if total_volume > 0 else 0,
            'small': (volume_by_level.get('small', 0) / total_volume * 100) if total_volume > 0 else 0
        }
        
        # 时间分布
        start_time = df['time'].min()
        end_time = df['time'].max()
        
        # 计算持续时间（秒）
        start_dt = datetime.strptime(start_time, '%H:%M:%S')
        end_dt = datetime.strptime(end_time, '%H:%M:%S')
        duration = (end_dt - start_dt).total_seconds()
        
        # 成交频率
        frequency = (total_count / (duration / 60)) if duration > 0 else 0
        
        # 买卖力量分析
        buy_volume = df[df['type'] == 'buy']['volume'].sum()
        sell_volume = df[df['type'] == 'sell']['volume'].sum()
        buy_sell_ratio = (buy_volume / sell_volume) if sell_volume > 0 else 1
        
        # 价格趋势分析
        price_trend = 'neutral'
        if len(df) >= 2:
            first_price = df.iloc[0]['price']
            last_price = df.iloc[-1]['price']
            if last_price > first_price * 1.005:
                price_trend = 'upward'
            elif last_price < first_price * 0.995:
                price_trend = 'downward'
        
        return {
            'basic_stats': {
                'total_count': total_count,
                'buy_count': buy_count,
                'sell_count': sell_count,
                'neutral_count': neutral_count,
                'total_volume': int(total_volume),
                'total_amount': round(total_amount, 2),
                'avg_price': round(avg_price, 2),
                'avg_volume': round(avg_volume, 2)
            },
            'large_order_stats': {
                'count': large_order_count,
                'volume': int(large_order_volume),
                'amount': round(large_order_amount, 2),
                'percentage': round((large_order_count / total_count * 100) if total_count > 0 else 0, 2),
                'range_distribution': range_stats,
                'continuous_orders': continuous_orders
            },
            'price_range': {
                'min': round(price_min, 2),
                'max': round(price_max, 2),
                'range': round(price_range, 2),
                'volatility': round((price_range / price_min * 100) if price_min > 0 else 0, 2)
            },
            'volume_distribution': {
                'large': round(volume_distribution['large'], 2),
                'medium': round(volume_distribution['medium'], 2),
                'small': round(volume_distribution['small'], 2)
            },
            'time_distribution': {
                'start_time': start_time,
                'end_time': end_time,
                'duration_seconds': int(duration),
                'frequency_per_minute': round(frequency, 2)
            },
            'market_sentiment': {
                'buy_sell_ratio': round(buy_sell_ratio, 2),
                'price_trend': price_trend,
                'buy_volume': int(buy_volume),
                'sell_volume': int(sell_volume)
            }
        }

# 创建分析器实例
analyzer = TransactionAnalyzer()

@router.get("/{stock_code}/transactions")
async def get_stock_transactions(
    stock_code: str,
    start_time: str = Query(..., description="开始时间 HH:MM:SS"),
    end_time: str = Query(..., description="结束时间 HH:MM:SS")
):
    """
    获取股票指定时间段的成交明细
    
    参数:
        stock_code: 股票代码
        start_time: 开始时间 (格式: HH:MM:SS)
        end_time: 结束时间 (格式: HH:MM:SS)
    """
    try:
        # 验证时间格式
        try:
            datetime.strptime(start_time, '%H:%M:%S')
            datetime.strptime(end_time, '%H:%M:%S')
        except ValueError:
            raise HTTPException(status_code=400, detail="时间格式错误，应为 HH:MM:SS")
        
        # 获取成交明细
        transactions = analyzer.get_transactions(stock_code, start_time, end_time)
        
        if not transactions:
            return {
                "code": stock_code,
                "start_time": start_time,
                "end_time": end_time,
                "transactions": [],
                "statistics": {},
                "message": "暂无成交数据"
            }
        
        # 分析成交明细
        statistics = analyzer.analyze_transactions(transactions)
        
        return {
            "code": stock_code,
            "start_time": start_time,
            "end_time": end_time,
            "transactions": transactions,
            "statistics": statistics,
            "timestamp": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"获取成交明细失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取成交明细失败: {str(e)}")

@router.get("/{stock_code}/transactions/analysis")
async def analyze_transactions(
    stock_code: str,
    start_time: str = Query(..., description="开始时间 HH:MM:SS"),
    end_time: str = Query(..., description="结束时间 HH:MM:SS")
):
    """
    获取成交明细的深度分析
    """
    try:
        # 获取成交明细
        transactions = analyzer.get_transactions(stock_code, start_time, end_time)
        
        if not transactions:
            raise HTTPException(status_code=404, detail="无成交数据")
        
        # 深度分析
        statistics = analyzer.analyze_transactions(transactions)
        
        # 生成分析结论
        conclusions = []
        
        # 买卖力量分析
        if statistics['market_sentiment']['buy_sell_ratio'] > 1.5:
            conclusions.append({
                'type': 'positive',
                'text': f"买入力量强劲，买卖比达到 {statistics['market_sentiment']['buy_sell_ratio']:.2f}"
            })
        elif statistics['market_sentiment']['buy_sell_ratio'] < 0.67:
            conclusions.append({
                'type': 'negative',
                'text': f"卖出压力较大，买卖比仅为 {statistics['market_sentiment']['buy_sell_ratio']:.2f}"
            })
        
        # 大单分析
        if statistics['large_order_stats']['percentage'] > 20:
            conclusions.append({
                'type': 'positive',
                'text': f"大单活跃，占比达到 {statistics['large_order_stats']['percentage']:.1f}%"
            })
        
        # 价格趋势分析
        if statistics['market_sentiment']['price_trend'] == 'upward':
            conclusions.append({
                'type': 'positive',
                'text': "价格呈上升趋势"
            })
        elif statistics['market_sentiment']['price_trend'] == 'downward':
            conclusions.append({
                'type': 'warning',
                'text': "价格呈下降趋势"
            })
        
        # 成交频率分析
        if statistics['time_distribution']['frequency_per_minute'] > 10:
            conclusions.append({
                'type': 'warning',
                'text': f"成交频率较高，每分钟 {statistics['time_distribution']['frequency_per_minute']:.1f} 笔"
            })
        
        return {
            "code": stock_code,
            "statistics": statistics,
            "conclusions": conclusions,
            "timestamp": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"分析失败: {str(e)}")