"""
版本管理API路由
提供版本备份、恢复、查询等RESTful接口
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import List, Dict
from datetime import datetime

from core.version_controller import (
    version_controller,
    VersionInfo,
    VersionCreateRequest,
    VersionRestoreRequest
)

router = APIRouter(prefix="/api/version", tags=["版本管理"])

@router.get("/current", response_model=Dict)
async def get_current_version():
    """获取当前版本"""
    return {
        "version": version_controller.get_current_version(),
        "timestamp": datetime.now().isoformat()
    }

@router.get("/list", response_model=List[VersionInfo])
async def list_versions():
    """获取版本列表"""
    return version_controller.get_versions()

@router.get("/timeline", response_model=List[Dict])
async def get_version_timeline():
    """获取版本时间轴"""
    return version_controller.get_version_timeline()

@router.get("/stats", response_model=Dict)
async def get_backup_stats():
    """获取备份统计信息"""
    return version_controller.get_backup_stats()

@router.post("/backup", response_model=Dict)
async def create_backup(
    request: VersionCreateRequest,
    background_tasks: BackgroundTasks
):
    """创建版本备份"""
    try:
        # 在后台执行备份任务
        result = await version_controller.create_backup(
            version_type=request.type,
            message=request.message
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/restore", response_model=Dict)
async def restore_version(request: VersionRestoreRequest):
    """恢复到指定版本"""
    try:
        result = await version_controller.restore_version(request.version)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/cleanup", response_model=Dict)
async def cleanup_old_backups(keep_count: int = 10):
    """清理旧备份"""
    try:
        version_controller.cleanup_old_backups(keep_count)
        return {
            "status": "success",
            "message": f"已清理旧备份，保留最近{keep_count}个"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health", response_model=Dict)
async def version_health_check():
    """版本管理健康检查"""
    stats = version_controller.get_backup_stats()
    return {
        "status": "healthy",
        "current_version": stats["current_version"],
        "total_backups": stats["total_backups"],
        "last_backup": stats["latest_backup"]
    }