"""
缓存管理器 - 多层缓存策略实现
支持内存缓存、Redis缓存和数据持久化
"""

import json
import time
import hashlib
import asyncio
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import logging
from functools import wraps

logger = logging.getLogger(__name__)

try:
    # import aioredis  # 暂时注释掉，避免兼容性问题
    REDIS_AVAILABLE = False  # 暂时禁用Redis
except ImportError:
    REDIS_AVAILABLE = False
    logger.warning("Redis不可用，将使用内存缓存")


class CacheConfig:
    """缓存配置"""
    
    # Redis配置
    REDIS_HOST = "localhost"
    REDIS_PORT = 6379
    REDIS_DB = 0
    REDIS_PASSWORD = None
    
    # 缓存TTL配置（秒）
    REALTIME_DATA_TTL = 5      # 实时数据5秒
    MINUTE_DATA_TTL = 60       # 分时数据1分钟
    DAILY_DATA_TTL = 3600      # 日线数据1小时
    STOCK_INFO_TTL = 86400     # 股票基础信息1天
    ANOMALY_DATA_TTL = 300     # 异动数据5分钟
    
    # 内存缓存配置
    MEMORY_CACHE_SIZE = 1000   # 内存缓存最大条目数


class MemoryCache:
    """内存缓存 - LRU策略"""
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache = {}
        self.access_order = []
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存数据"""
        if key in self.cache:
            # 更新访问顺序
            self.access_order.remove(key)
            self.access_order.append(key)
            
            # 检查是否过期
            data, expire_time = self.cache[key]
            if expire_time and time.time() > expire_time:
                self.delete(key)
                return None
            
            return data
        return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """设置缓存数据"""
        expire_time = time.time() + ttl if ttl else None
        
        # 如果key已存在，更新数据
        if key in self.cache:
            self.cache[key] = (value, expire_time)
            self.access_order.remove(key)
            self.access_order.append(key)
        else:
            # 检查缓存大小限制
            if len(self.cache) >= self.max_size:
                # 删除最久未访问的项
                oldest_key = self.access_order.pop(0)
                del self.cache[oldest_key]
            
            self.cache[key] = (value, expire_time)
            self.access_order.append(key)
    
    def delete(self, key: str) -> None:
        """删除缓存数据"""
        if key in self.cache:
            del self.cache[key]
            self.access_order.remove(key)
    
    def clear(self) -> None:
        """清空缓存"""
        self.cache.clear()
        self.access_order.clear()
    
    def size(self) -> int:
        """获取缓存大小"""
        return len(self.cache)


class RedisCache:
    """Redis缓存管理器"""
    
    def __init__(self, config: CacheConfig):
        self.config = config
        self.redis = None
        self._connection_pool = None
    
    async def connect(self):
        """连接Redis"""
        if not REDIS_AVAILABLE:
            logger.warning("Redis不可用，跳过连接")
            return
        
        try:
            self.redis = await aioredis.from_url(
                f"redis://{self.config.REDIS_HOST}:{self.config.REDIS_PORT}/{self.config.REDIS_DB}",
                password=self.config.REDIS_PASSWORD,
                encoding="utf-8",
                decode_responses=True
            )
            logger.info("✅ Redis连接成功")
        except Exception as e:
            logger.error(f"❌ Redis连接失败: {e}")
            self.redis = None
    
    async def disconnect(self):
        """断开Redis连接"""
        if self.redis:
            await self.redis.close()
            logger.info("Redis连接已关闭")
    
    async def get(self, key: str) -> Optional[Any]:
        """获取缓存数据"""
        if not self.redis:
            return None
        
        try:
            data = await self.redis.get(key)
            if data:
                return json.loads(data)
        except Exception as e:
            logger.error(f"Redis获取数据失败 {key}: {e}")
        
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """设置缓存数据"""
        if not self.redis:
            return False
        
        try:
            data = json.dumps(value, ensure_ascii=False, default=str)
            if ttl:
                await self.redis.setex(key, ttl, data)
            else:
                await self.redis.set(key, data)
            return True
        except Exception as e:
            logger.error(f"Redis设置数据失败 {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """删除缓存数据"""
        if not self.redis:
            return False
        
        try:
            await self.redis.delete(key)
            return True
        except Exception as e:
            logger.error(f"Redis删除数据失败 {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """检查key是否存在"""
        if not self.redis:
            return False
        
        try:
            return await self.redis.exists(key) > 0
        except Exception as e:
            logger.error(f"Redis检查key失败 {key}: {e}")
            return False
    
    async def expire(self, key: str, ttl: int) -> bool:
        """设置key过期时间"""
        if not self.redis:
            return False
        
        try:
            await self.redis.expire(key, ttl)
            return True
        except Exception as e:
            logger.error(f"Redis设置过期时间失败 {key}: {e}")
            return False


class MultiLevelCache:
    """多层缓存管理器"""
    
    def __init__(self, config: CacheConfig = None):
        self.config = config or CacheConfig()
        self.memory_cache = MemoryCache(self.config.MEMORY_CACHE_SIZE)
        self.redis_cache = RedisCache(self.config)
        self._stats = {
            'memory_hits': 0,
            'redis_hits': 0,
            'misses': 0,
            'sets': 0
        }
        
        # 代码规范化：统一缓存键使用带交易所前缀的代码
        # 例如：'600519' -> 'sh600519'，'000001' -> 'sz000001'
        # 若已是 'sh/\sz' 开头，则直接使用
        
    def _normalize_code(self, stock_code: str) -> str:
        """统一股票代码：带上交易所前缀，用于缓存键规范化。"""
        if not stock_code:
            return stock_code
        if stock_code.startswith(('sh', 'sz')):
            return stock_code
        return f"sh{stock_code}" if stock_code.startswith('6') else f"sz{stock_code}"
    
    async def initialize(self):
        """初始化缓存系统"""
        await self.redis_cache.connect()
        logger.info("多层缓存系统初始化完成")
    
    async def cleanup(self):
        """清理缓存系统"""
        await self.redis_cache.disconnect()
        self.memory_cache.clear()
        logger.info("缓存系统已清理")
    
    def _generate_key(self, prefix: str, identifier: str, suffix: str = "") -> str:
        """生成缓存键"""
        key = f"{prefix}:{identifier}"
        if suffix:
            key += f":{suffix}"
        return key
    
    async def get(self, key: str) -> Optional[Any]:
        """获取缓存数据 - 多层查找"""
        # 1. 先查内存缓存
        data = self.memory_cache.get(key)
        if data is not None:
            self._stats['memory_hits'] += 1
            return data
        
        # 2. 查Redis缓存
        data = await self.redis_cache.get(key)
        if data is not None:
            self._stats['redis_hits'] += 1
            # 回写到内存缓存
            self.memory_cache.set(key, data, ttl=30)  # 内存缓存30秒
            return data
        
        # 3. 缓存未命中
        self._stats['misses'] += 1
        return None

    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """设置缓存数据 - 多层写入"""
        self._stats['sets'] += 1

        # 1. 写入内存缓存
        memory_ttl = min(ttl or 300, 300)  # 内存缓存最多5分钟
        self.memory_cache.set(key, value, memory_ttl)

        # 2. 写入Redis缓存
        redis_success = await self.redis_cache.set(key, value, ttl)

        return redis_success

    async def delete(self, key: str) -> bool:
        """删除缓存数据"""
        # 删除内存缓存
        self.memory_cache.delete(key)

        # 删除Redis缓存
        return await self.redis_cache.delete(key)

    async def clear_pattern(self, pattern: str) -> int:
        """清除匹配模式的缓存"""
        # 清除内存缓存中匹配的key
        memory_cleared = 0
        keys_to_delete = []
        for key in self.memory_cache.cache.keys():
            if pattern in key:
                keys_to_delete.append(key)

        for key in keys_to_delete:
            self.memory_cache.delete(key)
            memory_cleared += 1

        logger.info(f"清除内存缓存 {memory_cleared} 个key")
        return memory_cleared

    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        total_requests = self._stats['memory_hits'] + self._stats['redis_hits'] + self._stats['misses']

        return {
            'memory_hits': self._stats['memory_hits'],
            'redis_hits': self._stats['redis_hits'],
            'misses': self._stats['misses'],
            'sets': self._stats['sets'],
            'total_requests': total_requests,
            'memory_hit_rate': self._stats['memory_hits'] / total_requests if total_requests > 0 else 0,
            'redis_hit_rate': self._stats['redis_hits'] / total_requests if total_requests > 0 else 0,
            'overall_hit_rate': (self._stats['memory_hits'] + self._stats['redis_hits']) / total_requests if total_requests > 0 else 0,
            'memory_cache_size': self.memory_cache.size()
        }

    # 业务相关的缓存方法
    async def get_stock_realtime(self, stock_code: str) -> Optional[Dict]:
        """获取股票实时数据"""
        key = self._generate_key("stock", "realtime", stock_code)
        return await self.get(key)

    async def set_stock_realtime(self, stock_code: str, data: Dict) -> bool:
        """设置股票实时数据"""
        key = self._generate_key("stock", "realtime", stock_code)
        return await self.set(key, data, self.config.REALTIME_DATA_TTL)

    async def get_stock_minute_data(self, stock_code: str, date: str = None) -> Optional[List]:
        """获取股票分时数据"""
        suffix = date or datetime.now().strftime("%Y%m%d")
        normalized = self._normalize_code(stock_code)
        key = self._generate_key("stock", "minute", f"{normalized}:{suffix}")
        return await self.get(key)

    async def set_stock_minute_data(self, stock_code: str, data: List, date: str = None) -> bool:
        """设置股票分时数据"""
        suffix = date or datetime.now().strftime("%Y%m%d")
        normalized = self._normalize_code(stock_code)
        key = self._generate_key("stock", "minute", f"{normalized}:{suffix}")
        return await self.set(key, data, self.config.MINUTE_DATA_TTL)

    async def get_anomaly_data(self, stock_code: str) -> Optional[List]:
        """获取异动数据"""
        key = self._generate_key("anomaly", stock_code, "")
        return await self.get(key)

    async def set_anomaly_data(self, stock_code: str, data: List) -> bool:
        """设置异动数据"""
        key = self._generate_key("anomaly", stock_code, "")
        return await self.set(key, data, self.config.ANOMALY_DATA_TTL)

    async def get_stock_info(self, stock_code: str) -> Optional[Dict]:
        """获取股票基础信息"""
        key = self._generate_key("info", stock_code, "")
        return await self.get(key)

    async def set_stock_info(self, stock_code: str, data: Dict) -> bool:
        """设置股票基础信息"""
        key = self._generate_key("info", stock_code, "")
        return await self.set(key, data, self.config.STOCK_INFO_TTL)


def cache_result(ttl: int = 300, key_prefix: str = ""):
    """缓存装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 生成缓存key
            cache_key = f"{key_prefix}:{func.__name__}:{hashlib.md5(str(args + tuple(kwargs.items())).encode()).hexdigest()}"

            # 尝试从缓存获取
            if hasattr(wrapper, '_cache'):
                cached_result = await wrapper._cache.get(cache_key)
                if cached_result is not None:
                    return cached_result

            # 执行函数
            result = await func(*args, **kwargs)

            # 存入缓存
            if hasattr(wrapper, '_cache') and result is not None:
                await wrapper._cache.set(cache_key, result, ttl)

            return result

        return wrapper
    return decorator


# 全局缓存实例
cache_manager = MultiLevelCache()


async def init_cache():
    """初始化全局缓存"""
    await cache_manager.initialize()


async def cleanup_cache():
    """清理全局缓存"""
    await cache_manager.cleanup()
