import pandas as pd
import numpy as np
from typing import List, Dict


def compute_intraday_factors(df: pd.DataFrame) -> pd.DataFrame:
    """给定包含 columns=[time, price, volume] 的分钟级DataFrame，
    返回加入因子列与信号列的DataFrame。"""

    if df.empty:
        return df

    # 1. 价格动量 ROC5
    df['roc5'] = df['price'].pct_change(5).fillna(0) * 100

    # 2. VWAP 偏离
    cum_vol = df['volume'].cumsum()
    cum_pv = (df['price'] * df['volume']).cumsum()
    df['vwap'] = cum_pv / cum_vol
    df['dev'] = (df['price'] - df['vwap']) / df['vwap'] * 100

    # 3. 成交量 z-score 20
    df['vol_mean20'] = df['volume'].rolling(20, min_periods=1).mean()
    df['vol_std20'] = df['volume'].rolling(20, min_periods=1).std().replace(0, np.nan)
    df['volZ'] = ((df['volume'] - df['vol_mean20']) / df['vol_std20']).fillna(0)

    # 4. 简化斜率 8
    slope_n = 8
    df['slope'] = (df['price'] - df['price'].shift(slope_n)) / slope_n
    df['slope'] = df['slope'].fillna(0)

    # 5. ATR1 近似
    df['atr1'] = (df['price'] - df['price'].shift(1)).abs().fillna(0)

    # 归一化函数
    def norm(x):
        return np.tanh(x / 5)

    long_score = (
        1 * norm(df['roc5']) +
        0.8 * norm(df['volZ']) -
        0.6 * norm(df['dev']) +
        0.6 * norm(df['slope']) -
        0.4 * norm(df['atr1'])
    )

    short_score = (
        -1 * norm(df['roc5']) +
        0.8 * norm(df['volZ']) +
        0.6 * norm(df['dev']) -
        0.6 * norm(df['slope']) -
        0.4 * norm(df['atr1'])
    )

    diff = long_score - short_score
    conf = 1 / (1 + np.exp(-diff * 3))

    df['long_score'] = long_score
    df['short_score'] = short_score
    df['confidence'] = conf

    conditions_buy = (conf > 0.75) & (diff > 0)
    conditions_sell = (conf > 0.75) & (diff < 0)

    df['signal'] = np.select(
        [conditions_buy, conditions_sell],
        ['BUY', 'SELL'],
        default='HOLD'
    )

    # 仅返回所需列
    return df[['time', 'price', 'volume', 'signal', 'confidence']]


def factors_to_json(df: pd.DataFrame) -> List[Dict]:
    """将结果转为前端友好的JSON列表"""
    return df.to_dict(orient='records') 