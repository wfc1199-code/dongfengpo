"""
涨停预测核心模块
基于现有功能的综合分析，预测当日可能涨停的股票
"""

import asyncio
from datetime import datetime, time, timedelta
from typing import List, Dict, Tuple, Optional
import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)

class LimitUpPredictor:
    """涨停预测器 - 综合多维度信号 + 集合竞价选股"""
    
    def __init__(self, data_manager, anomaly_engine=None):
        self.data_manager = data_manager
        self.anomaly_engine = anomaly_engine
        self.monitoring = False
        self.cache = {}
        self.cache_expiry = {}
        
        # 时间段权重配置
        self.time_weights = {
            '09:30-09:45': 1.5,  # 开盘15分钟，最重要
            '09:45-10:00': 1.3,  # 第二个15分钟
            '10:00-10:30': 1.2,  # 关键决策时段
            '10:30-11:00': 1.0,  # 确认阶段
            '11:00-11:30': 0.8,  # 上午尾盘
            '13:00-13:30': 1.1,  # 下午开盘
            '13:30-14:00': 0.9,  # 下午中段
            '14:00-14:30': 0.8,  # 尾盘前
            '14:30-15:00': 0.7   # 尾盘
        }
        
        # 涨停预测因子权重
        self.factor_weights = {
            'sector_heat': 0.20,      # 板块热度
            'early_surge': 0.25,      # 早盘拉升
            'volume_burst': 0.15,     # 成交量爆发
            'capital_inflow': 0.15,   # 资金流入
            'technical_pattern': 0.10, # 技术形态
            'yesterday_strong': 0.10,  # 昨日强势
            'market_sentiment': 0.05   # 市场情绪
        }
    
    def get_current_time_period(self) -> Tuple[str, float]:
        """获取当前时间段及其权重"""
        now = datetime.now().time()
        
        for period, weight in self.time_weights.items():
            start_str, end_str = period.split('-')
            start_hour, start_min = map(int, start_str.split(':'))
            end_hour, end_min = map(int, end_str.split(':'))
            
            start_time = time(start_hour, start_min)
            end_time = time(end_hour, end_min)
            
            if start_time <= now <= end_time:
                return period, weight
        
        return 'non-trading', 0.0
    
    async def analyze_sector_momentum(self, stock_code: str) -> float:
        """
        分析板块动能
        - 板块涨幅排名
        - 板块内领涨股数量
        - 板块资金流入强度
        """
        try:
            # 获取股票所属板块
            stock_sectors = await self.get_stock_sectors(stock_code)
            if not stock_sectors:
                return 0.0
            
            sector_scores = []
            for sector in stock_sectors:
                # 板块涨幅
                sector_change = sector.get('avg_change', 0)
                
                # 板块内涨停股数量
                limit_up_count = sector.get('limit_up_count', 0)
                
                # 板块热度评分
                hot_score = sector.get('hot_score', 50)
                
                # 综合评分
                score = (
                    min(sector_change / 5, 1.0) * 0.4 +  # 板块涨幅贡献
                    min(limit_up_count / 3, 1.0) * 0.3 +  # 涨停股数量贡献
                    (hot_score / 100) * 0.3  # 热度贡献
                )
                sector_scores.append(score)
            
            return max(sector_scores) if sector_scores else 0.0
            
        except Exception as e:
            logger.error(f"分析板块动能失败: {e}")
            return 0.0
    
    async def analyze_early_surge_pattern(self, stock_code: str) -> float:
        """
        分析早盘拉升模式
        重点关注9:30-10:30的走势特征
        """
        try:
            current_period, time_weight = self.get_current_time_period()
            
            # 获取分时数据
            timeline_data = await self.data_manager.get_timeline_data([stock_code])
            if not timeline_data or stock_code not in timeline_data:
                return 0.0
            
            data = timeline_data[stock_code]
            
            # 分析关键指标
            indicators = {
                'opening_surge': 0,     # 开盘拉升
                'continuous_rise': 0,   # 持续上涨
                'volume_amplify': 0,    # 成交量放大
                'speed_accelerate': 0,  # 加速度
                'breakout': 0          # 突破
            }
            
            # 开盘涨幅
            open_change = data.get('open_change_percent', 0)
            if open_change > 3:
                indicators['opening_surge'] = min(open_change / 7, 1.0)
            
            # 当前涨幅
            current_change = data.get('change_percent', 0)
            if current_change > open_change:  # 持续上涨
                indicators['continuous_rise'] = min((current_change - open_change) / 3, 1.0)
            
            # 成交量放大倍数
            volume_ratio = data.get('volume_ratio', 1)
            if volume_ratio > 2:
                indicators['volume_amplify'] = min(volume_ratio / 5, 1.0)
            
            # 拉升速度（1分钟涨幅）
            speed = data.get('speed', 0)
            if speed > 0.5:
                indicators['speed_accelerate'] = min(speed / 2, 1.0)
            
            # 突破昨日高点
            if data.get('current', 0) > data.get('yesterday_high', 0):
                indicators['breakout'] = 1.0
            
            # 综合评分，考虑时间权重
            base_score = np.mean(list(indicators.values()))
            return base_score * time_weight
            
        except Exception as e:
            logger.error(f"分析早盘拉升模式失败: {e}")
            return 0.0
    
    async def analyze_volume_explosion(self, stock_code: str) -> float:
        """
        分析成交量爆发特征
        - 量比
        - 单笔大单
        - 主动买入比例
        """
        try:
            realtime_data = await self.data_manager.get_realtime_data([stock_code])
            if not realtime_data or stock_code not in realtime_data:
                return 0.0
            
            data = realtime_data[stock_code]
            
            score = 0.0
            
            # 量比分析
            volume_ratio = data.get('volume_ratio', 1)
            if volume_ratio > 3:
                score += min(volume_ratio / 10, 1.0) * 0.4
            
            # 换手率
            turnover = data.get('turnoverRate', 0)
            if turnover > 5:
                score += min(turnover / 15, 1.0) * 0.3
            
            # 大单比例
            big_order_ratio = data.get('big_order_ratio', 0)
            if big_order_ratio > 30:
                score += min(big_order_ratio / 60, 1.0) * 0.3
            
            return score
            
        except Exception as e:
            logger.error(f"分析成交量爆发失败: {e}")
            return 0.0
    
    async def analyze_capital_flow(self, stock_code: str) -> float:
        """
        分析资金流向
        - 主力净流入
        - 连续流入天数
        - 流入加速度
        """
        try:
            # 这里可以接入实际的资金流向数据
            # 暂时用模拟逻辑
            realtime_data = await self.data_manager.get_realtime_data([stock_code])
            if not realtime_data or stock_code not in realtime_data:
                return 0.0
            
            data = realtime_data[stock_code]
            
            # 根据成交额和涨跌估算资金流向
            amount = data.get('amount', 0)
            change = data.get('change_percent', 0)
            
            if change > 0 and amount > 100000000:  # 涨且成交额过亿
                return min(change / 7, 1.0) * min(amount / 500000000, 1.0)
            
            return 0.0
            
        except Exception as e:
            logger.error(f"分析资金流向失败: {e}")
            return 0.0
    
    async def analyze_technical_pattern(self, stock_code: str) -> float:
        """
        分析技术形态
        - 均线多头排列
        - 突破关键价位
        - 形态完美度
        """
        try:
            # 获取K线数据进行技术分析
            realtime_data = await self.data_manager.get_realtime_data([stock_code])
            if not realtime_data or stock_code not in realtime_data:
                return 0.0
            
            data = realtime_data[stock_code]
            
            score = 0.0
            
            # 价格位置（相对于日内最高最低）
            current = data.get('current', 0)
            high = data.get('high', current)
            low = data.get('low', current)
            
            if high > low:
                position = (current - low) / (high - low)
                if position > 0.8:  # 接近最高点
                    score += 0.5
            
            # 突破昨日高点
            yesterday_high = data.get('yesterday_high', 0)
            if current > yesterday_high * 1.02:  # 突破2%以上
                score += 0.5
            
            return score
            
        except Exception as e:
            logger.error(f"分析技术形态失败: {e}")
            return 0.0
    
    async def analyze_yesterday_performance(self, stock_code: str) -> float:
        """
        分析昨日表现
        - 昨日涨幅
        - 昨日量能
        - 连板情况
        """
        try:
            # 获取历史数据
            realtime_data = await self.data_manager.get_realtime_data([stock_code])
            if not realtime_data or stock_code not in realtime_data:
                return 0.0
            
            data = realtime_data[stock_code]
            
            # 这里需要获取昨日数据，暂时用简化逻辑
            # 如果今天开盘就很强，说明昨天可能也不错
            open_change = (data.get('open', 0) - data.get('yesterday_close', 1)) / data.get('yesterday_close', 1) * 100
            
            if open_change > 3:  # 高开3%以上
                return min(open_change / 7, 1.0)
            
            return 0.0
            
        except Exception as e:
            logger.error(f"分析昨日表现失败: {e}")
            return 0.0
    
    async def analyze_market_sentiment(self) -> float:
        """
        分析市场情绪
        - 涨停家数
        - 市场赚钱效应
        - 板块轮动节奏
        """
        try:
            # 这里可以统计整个市场的情况
            # 暂时返回中性值
            return 0.5
            
        except Exception as e:
            logger.error(f"分析市场情绪失败: {e}")
            return 0.3
    
    async def predict_limit_up_probability(self, stock_code: str) -> Dict:
        """
        预测涨停概率
        返回详细的评分和预测结果
        """
        try:
            # 并发执行所有分析任务
            tasks = [
                self.analyze_sector_momentum(stock_code),
                self.analyze_early_surge_pattern(stock_code),
                self.analyze_volume_explosion(stock_code),
                self.analyze_capital_flow(stock_code),
                self.analyze_technical_pattern(stock_code),
                self.analyze_yesterday_performance(stock_code),
                self.analyze_market_sentiment()
            ]
            
            results = await asyncio.gather(*tasks)
            
            # 计算各项得分
            scores = {
                'sector_heat': results[0],
                'early_surge': results[1],
                'volume_burst': results[2],
                'capital_inflow': results[3],
                'technical_pattern': results[4],
                'yesterday_strong': results[5],
                'market_sentiment': results[6]
            }
            
            # 计算加权总分
            total_score = sum(
                score * self.factor_weights[factor]
                for factor, score in scores.items()
            )
            
            # 获取股票基本信息
            realtime_data = await self.data_manager.get_realtime_data([stock_code])
            stock_info = realtime_data.get(stock_code, {}) if realtime_data else {}
            
            # 生成预测结果
            prediction = {
                'stock_code': stock_code,
                'stock_name': stock_info.get('name', ''),
                'current_price': stock_info.get('current', 0),
                'change_percent': stock_info.get('change_percent', 0),
                'limit_up_probability': total_score * 100,  # 转换为百分比
                'scores': scores,
                'prediction_level': self.get_prediction_level(total_score),
                'key_signals': self.extract_key_signals(scores),
                'suggested_action': self.get_suggested_action(total_score),
                'prediction_time': datetime.now().isoformat()
            }
            
            return prediction
            
        except Exception as e:
            logger.error(f"预测涨停概率失败: {e}")
            return {
                'stock_code': stock_code,
                'error': str(e),
                'limit_up_probability': 0
            }
    
    def get_prediction_level(self, score: float) -> str:
        """获取预测等级"""
        if score >= 0.8:
            return '极高'
        elif score >= 0.6:
            return '高'
        elif score >= 0.4:
            return '中'
        elif score >= 0.2:
            return '低'
        else:
            return '极低'
    
    def extract_key_signals(self, scores: Dict) -> List[str]:
        """提取关键信号"""
        signals = []
        
        if scores['sector_heat'] > 0.7:
            signals.append('板块强势领涨')
        if scores['early_surge'] > 0.7:
            signals.append('早盘快速拉升')
        if scores['volume_burst'] > 0.7:
            signals.append('成交量显著放大')
        if scores['capital_inflow'] > 0.7:
            signals.append('主力资金流入')
        if scores['technical_pattern'] > 0.7:
            signals.append('技术形态突破')
        
        return signals
    
    def get_suggested_action(self, score: float) -> str:
        """获取操作建议"""
        if score >= 0.7:
            return '强烈关注，可考虑介入'
        elif score >= 0.5:
            return '密切关注，等待确认信号'
        elif score >= 0.3:
            return '保持观察，暂不建议操作'
        else:
            return '不建议关注'
    
    async def scan_potential_limit_ups(self, stock_pool: List[str] = None) -> List[Dict]:
        """
        扫描潜在涨停股票
        """
        try:
            # 如果没有指定股票池，使用热门板块的股票
            if not stock_pool:
                stock_pool = await self.get_hot_stocks()
            
            # 并发预测所有股票
            predictions = []
            for batch in [stock_pool[i:i+10] for i in range(0, len(stock_pool), 10)]:
                batch_tasks = [self.predict_limit_up_probability(code) for code in batch]
                batch_results = await asyncio.gather(*batch_tasks)
                predictions.extend(batch_results)
            
            # 过滤并排序
            valid_predictions = [
                p for p in predictions 
                if 'error' not in p and p['limit_up_probability'] > 30
            ]
            
            valid_predictions.sort(key=lambda x: x['limit_up_probability'], reverse=True)
            
            return valid_predictions[:20]  # 返回前20个
            
        except Exception as e:
            logger.error(f"扫描潜在涨停股失败: {e}")
            return []
    
    async def get_hot_stocks(self) -> List[str]:
        """获取热门股票池"""
        # 这里应该从热门板块获取股票
        # 暂时返回一些示例
        return [
            'sh600519', 'sz000858', 'sz300750', 'sz002594',
            'sh600036', 'sz000001', 'sh600000', 'sz002415'
        ]
    
    async def get_stock_sectors(self, stock_code: str) -> List[Dict]:
        """获取股票所属板块信息"""
        # 这里应该查询股票所属的板块
        # 暂时返回模拟数据
        return [
            {
                'sector_name': '白酒',
                'avg_change': 3.5,
                'limit_up_count': 2,
                'hot_score': 85
            }
        ]
    
    # ==================== 集合竞价选股策略 ====================
    
    async def get_call_auction_analysis(self, limit: int = 20) -> Dict:
        """
        集合竞价选股分析 - 业内成熟策略
        9:15-9:25期间使用，筛选高开3-6%且成交活跃的股票
        """
        try:
            print("🔍 开始集合竞价选股分析...")
            
            # 获取概念板块数据，找出活跃板块
            sectors = await self.data_manager.get_concept_sectors(50)
            hot_sectors = [s for s in sectors if s.get('hot_score', 0) > 30][:10]
            
            call_auction_stocks = []
            
            # 遍历热门板块，获取成分股
            for sector in hot_sectors:
                sector_name = sector.get('sector_name', '')
                print(f"📊 分析板块: {sector_name}")
                
                # 获取板块成分股
                stocks = await self.data_manager.get_sector_stocks(sector_name, 20)
                
                for stock in stocks[:10]:  # 每个板块取前10只
                    stock_code = stock.get('stock_code', '')
                    stock_name = stock.get('stock_name', '')
                    change_percent = stock.get('change_percent', 0)
                    turnover_rate = stock.get('turnover_rate', 0)
                    volume = stock.get('volume', 0)
                    market_value = stock.get('market_value', 0)
                    
                    # 集合竞价选股条件
                    if self._is_call_auction_candidate(change_percent, turnover_rate, volume, market_value):
                        # 获取更详细的实时数据
                        full_code = f"sh{stock_code}" if stock_code.startswith('6') else f"sz{stock_code}"
                        realtime_data = await self.data_manager.get_realtime_data([full_code])
                        
                        if full_code in realtime_data:
                            stock_data = realtime_data[full_code]
                            
                            # 计算集合竞价评分
                            score = self._calculate_call_auction_score(stock_data, sector)
                            
                            call_auction_stocks.append({
                                'stock_code': stock_code,
                                'stock_name': stock_name,
                                'sector': sector_name,
                                'current_price': stock_data.get('current_price', 0),
                                'change_percent': stock_data.get('change_percent', 0),
                                'turnover_rate': stock_data.get('turnoverRate', 0),
                                'volume': stock_data.get('volume', 0),
                                'amount': stock_data.get('amount', 0),
                                'market_value': market_value,
                                'auction_score': score,
                                'sector_heat': sector.get('hot_score', 0),
                                'reason': self._get_selection_reason(stock_data, sector)
                            })
            
            # 按评分排序
            call_auction_stocks.sort(key=lambda x: x['auction_score'], reverse=True)
            
            # 取前limit只
            top_stocks = call_auction_stocks[:limit]
            
            # 统计分析
            summary = {
                'total_candidates': len(call_auction_stocks),
                'top_selected': len(top_stocks),
                'average_score': sum(s['auction_score'] for s in top_stocks) / len(top_stocks) if top_stocks else 0,
                'sector_distribution': self._analyze_sector_distribution(top_stocks),
                'risk_level': self._assess_risk_level(top_stocks)
            }
            
            print(f"✅ 集合竞价分析完成，筛选出{len(top_stocks)}只候选股")
            
            return {
                'stocks': top_stocks,
                'summary': summary
            }
            
        except Exception as e:
            print(f"❌ 集合竞价分析失败: {e}")
            return {'stocks': [], 'summary': {}}
    
    def _is_call_auction_candidate(self, change_percent: float, turnover_rate: float, 
                                 volume: int, market_value: float) -> bool:
        """判断是否为集合竞价候选股 - 业内标准"""
        return (
            3.0 <= change_percent <= 6.0 and  # 高开3-6%（业内经验）
            turnover_rate >= 1.0 and          # 换手率>=1%（有活跃度）
            volume > 100000 and               # 有一定成交量
            market_value > 1000000000         # 市值>10亿（避免过小盘股）
        )
    
    def _calculate_call_auction_score(self, stock_data: Dict, sector: Dict) -> float:
        """计算集合竞价评分 - 多维度评分体系"""
        score = 0
        
        # 基础分：涨幅（30分）
        change_percent = stock_data.get('change_percent', 0)
        if 3 <= change_percent <= 4:
            score += 30  # 最优区间
        elif 4 < change_percent <= 5:
            score += 25
        elif 5 < change_percent <= 6:
            score += 20
        elif change_percent > 6:
            score += 10  # 过高反而减分（可能假突破）
        
        # 成交量分（25分）
        turnover_rate = stock_data.get('turnoverRate', 0)
        if 2 <= turnover_rate <= 5:
            score += 25  # 合理换手率
        elif 1 <= turnover_rate < 2:
            score += 20
        elif 5 < turnover_rate <= 8:
            score += 15
        
        # 板块热度分（25分）
        sector_heat = sector.get('hot_score', 0)
        if sector_heat >= 50:
            score += 25
        elif sector_heat >= 30:
            score += 20
        elif sector_heat >= 20:
            score += 15
        
        # 资金流入分（20分）
        amount = stock_data.get('amount', 0)
        if amount > 100000000:  # 1亿以上
            score += 20
        elif amount > 50000000:  # 5000万以上
            score += 15
        elif amount > 20000000:  # 2000万以上
            score += 10
        
        return round(score, 1)
    
    def _get_selection_reason(self, stock_data: Dict, sector: Dict) -> str:
        """获取选股理由"""
        reasons = []
        
        change_percent = stock_data.get('change_percent', 0)
        if 3 <= change_percent <= 6:
            reasons.append(f"高开{change_percent:.1f}%")
        
        turnover_rate = stock_data.get('turnoverRate', 0)
        if turnover_rate >= 2:
            reasons.append(f"换手{turnover_rate:.1f}%")
        
        sector_heat = sector.get('hot_score', 0)
        if sector_heat >= 30:
            reasons.append(f"{sector.get('sector_name', '')}板块热度{sector_heat}")
        
        return "；".join(reasons)
    
    # ==================== 首板进二板策略 ====================
    
    async def get_yesterday_limit_up_performance(self) -> Dict:
        """昨日涨停股今日表现分析 - 首板进二板策略核心"""
        try:
            print("📊 分析昨日涨停股今日表现...")
            
            # 这里简化处理，实际需要数据库存储昨日涨停数据
            # 获取当前市场数据作为示例
            sectors = await self.data_manager.get_concept_sectors(20)
            
            yesterday_stocks = []
            today_performance = []
            
            # 模拟昨日涨停股（实际应从数据库获取）
            for sector in sectors[:5]:
                stocks = await self.data_manager.get_sector_stocks(sector['sector_name'], 5)
                
                for stock in stocks[:2]:
                    # 模拟昨日涨停股
                    yesterday_stocks.append({
                        'stock_code': stock['stock_code'],
                        'stock_name': stock['stock_name'],
                        'sector': sector['sector_name'],
                        'yesterday_close': stock['current_price'] / (1 + stock['change_percent'] / 100),
                        'limit_up_strength': 85,  # 模拟强度
                        'limit_up_time': '09:45'  # 模拟时间
                    })
                    
                    # 今日表现
                    today_performance.append({
                        'stock_code': stock['stock_code'],
                        'stock_name': stock['stock_name'],
                        'today_change': stock['change_percent'],
                        'today_high': stock['current_price'] * 1.02,
                        'today_low': stock['current_price'] * 0.98,
                        'turnover_rate': stock['turnover_rate'],
                        'is_continued': stock['change_percent'] > 0,
                        'continuation_strength': min(100, max(0, stock['change_percent'] * 10))
                    })
            
            # 计算成功率
            successful = len([p for p in today_performance if p['is_continued']])
            success_rate = (successful / len(today_performance) * 100) if today_performance else 0
            
            # 计算平均收益
            average_gain = sum(p['today_change'] for p in today_performance) / len(today_performance) if today_performance else 0
            
            # 连续性分析
            continuation_analysis = {
                'continued_count': successful,
                'failed_count': len(today_performance) - successful,
                'strong_continuation': len([p for p in today_performance if p['continuation_strength'] > 50]),
                'average_continuation_strength': sum(p['continuation_strength'] for p in today_performance) / len(today_performance) if today_performance else 0
            }
            
            # 市场情绪判断（业内经验）
            if success_rate >= 70:
                market_sentiment = "强势"
            elif success_rate >= 50:
                market_sentiment = "中性偏强"
            elif success_rate >= 30:
                market_sentiment = "中性"
            else:
                market_sentiment = "弱势"
            
            return {
                'yesterday_stocks': yesterday_stocks,
                'today_performance': today_performance,
                'success_rate': round(success_rate, 1),
                'average_gain': round(average_gain, 2),
                'continuation_analysis': continuation_analysis,
                'market_sentiment': market_sentiment
            }
            
        except Exception as e:
            print(f"❌ 昨日涨停表现分析失败: {e}")
            return {
                'yesterday_stocks': [],
                'today_performance': [],
                'success_rate': 0,
                'average_gain': 0,
                'continuation_analysis': {},
                'market_sentiment': '中性'
            }
    
    # ==================== 早盘涨停筛选 ====================
    
    async def get_early_limit_up_stocks(self, limit: int = 30) -> Dict:
        """获取早盘涨停股票（10:30前） - 专为短线交易设计"""
        try:
            print("🌅 分析早盘涨停股票...")
            
            current_time = datetime.now().time()
            
            # 获取涨停股票
            limit_up_data = await self.get_limit_up_stocks(100)
            all_limit_ups = limit_up_data.get('stocks', [])
            
            # 筛选早盘涨停（基于强度和换手率特征）
            early_limit_ups = []
            
            for stock in all_limit_ups:
                # 早盘涨停特征：强度高，换手率相对较低（筹码锁定）
                if (stock['strength'] >= 70 and 
                    stock['turnover_rate'] <= 8 and
                    stock['is_limit_up']):
                    
                    early_limit_ups.append({
                        **stock,
                        'early_probability': self._calculate_early_probability(stock)
                    })
            
            # 按早盘概率排序
            early_limit_ups.sort(key=lambda x: x['early_probability'], reverse=True)
            
            # 时间分布分析
            time_distribution = {
                '9:30-10:00': len([s for s in early_limit_ups if s['early_probability'] > 80]),
                '10:00-10:30': len([s for s in early_limit_ups if 60 <= s['early_probability'] <= 80]),
                '10:30-11:30': len([s for s in early_limit_ups if s['early_probability'] < 60])
            }
            
            # 强度分析
            strength_analysis = {
                'very_strong': len([s for s in early_limit_ups if s['strength'] >= 90]),
                'strong': len([s for s in early_limit_ups if 70 <= s['strength'] < 90]),
                'medium': len([s for s in early_limit_ups if 50 <= s['strength'] < 70])
            }
            
            # 板块分布
            sector_distribution = {}
            for stock in early_limit_ups:
                sector = stock['sector']
                if sector in sector_distribution:
                    sector_distribution[sector] += 1
                else:
                    sector_distribution[sector] = 1
            
            return {
                'early_stocks': early_limit_ups[:limit],
                'time_distribution': time_distribution,
                'strength_analysis': strength_analysis,
                'sector_distribution': dict(sorted(sector_distribution.items(), key=lambda x: x[1], reverse=True))
            }
            
        except Exception as e:
            print(f"❌ 早盘涨停分析失败: {e}")
            return {'early_stocks': [], 'time_distribution': {}, 'strength_analysis': {}, 'sector_distribution': {}}
    
    async def get_limit_up_stocks(self, limit: int = 50) -> Dict:
        """获取当日涨停股票"""
        try:
            print("📈 获取当日涨停股票...")
            
            # 获取热门概念板块
            sectors = await self.data_manager.get_concept_sectors(30)
            
            limit_up_stocks = []
            
            for sector in sectors:
                if sector.get('avg_change', 0) < 2:  # 只看涨幅较好的板块
                    continue
                    
                sector_name = sector.get('sector_name', '')
                stocks = await self.data_manager.get_sector_stocks(sector_name, 30)
                
                for stock in stocks:
                    change_percent = stock.get('change_percent', 0)
                    
                    # 接近涨停或已涨停（A股涨停约10%，科创板20%）
                    if change_percent >= 9.8 or (stock.get('stock_code', '').startswith('688') and change_percent >= 19.8):
                        
                        # 获取详细数据
                        stock_code = stock.get('stock_code', '')
                        full_code = f"sh{stock_code}" if stock_code.startswith('6') else f"sz{stock_code}"
                        realtime_data = await self.data_manager.get_realtime_data([full_code])
                        
                        if full_code in realtime_data:
                            stock_data = realtime_data[full_code]
                            
                            # 判断涨停强度
                            strength = self._assess_limit_up_strength(stock_data)
                            
                            limit_up_stocks.append({
                                'stock_code': stock_code,
                                'stock_name': stock.get('stock_name', ''),
                                'sector': sector_name,
                                'current_price': stock_data.get('current_price', 0),
                                'change_percent': stock_data.get('change_percent', 0),
                                'turnover_rate': stock_data.get('turnoverRate', 0),
                                'volume': stock_data.get('volume', 0),
                                'amount': stock_data.get('amount', 0),
                                'strength': strength,
                                'limit_up_time': self._estimate_limit_up_time(stock_data),
                                'is_limit_up': change_percent >= 9.8,
                                'sector_rank': stock.get('is_leader', False)
                            })
            
            # 按涨幅和强度排序
            limit_up_stocks.sort(key=lambda x: (x['change_percent'], x['strength']), reverse=True)
            
            # 统计数据
            statistics = {
                'total_limit_up': len([s for s in limit_up_stocks if s['is_limit_up']]),
                'near_limit_up': len([s for s in limit_up_stocks if not s['is_limit_up']]),
                'strong_stocks': len([s for s in limit_up_stocks if s['strength'] > 70]),
                'sector_count': len(set(s['sector'] for s in limit_up_stocks))
            }
            
            return {
                'stocks': limit_up_stocks[:limit],
                'statistics': statistics
            }
            
        except Exception as e:
            print(f"❌ 获取涨停股票失败: {e}")
            return {'stocks': [], 'statistics': {}}
    
    def _calculate_early_probability(self, stock: Dict) -> float:
        """计算早盘涨停概率"""
        probability = 50  # 基础概率
        
        # 强度加分
        if stock['strength'] >= 90:
            probability += 30
        elif stock['strength'] >= 80:
            probability += 20
        elif stock['strength'] >= 70:
            probability += 10
        
        # 换手率加分（早盘涨停换手率不会太高）
        turnover = stock['turnover_rate']
        if 1 <= turnover <= 3:
            probability += 20
        elif 3 < turnover <= 5:
            probability += 10
        elif turnover > 8:
            probability -= 10
        
        # 涨幅加分
        if stock['change_percent'] >= 10:
            probability += 10
        
        return min(100, max(0, probability))
    
    def _assess_limit_up_strength(self, stock_data: Dict) -> float:
        """评估涨停强度"""
        strength = 0
        
        # 换手率评分（40分）
        turnover = stock_data.get('turnoverRate', 0)
        if 2 <= turnover <= 8:
            strength += 40
        elif 1 <= turnover < 2:
            strength += 35
        elif 8 < turnover <= 15:
            strength += 30
        else:
            strength += 20
        
        # 成交额评分（30分）
        amount = stock_data.get('amount', 0)
        if amount > 500000000:  # 5亿以上
            strength += 30
        elif amount > 200000000:  # 2亿以上
            strength += 25
        elif amount > 100000000:  # 1亿以上
            strength += 20
        else:
            strength += 15
        
        # 涨幅评分（30分）
        change_percent = stock_data.get('change_percent', 0)
        if change_percent >= 9.9:  # 强势涨停
            strength += 30
        elif change_percent >= 9.5:
            strength += 25
        else:
            strength += 20
        
        return round(strength, 1)
    
    def _estimate_limit_up_time(self, stock_data: Dict) -> Optional[str]:
        """估算涨停时间（简化版）"""
        change_percent = stock_data.get('change_percent', 0)
        
        if change_percent >= 9.9:
            if change_percent >= 10:
                return "早盘"
            else:
                return "盘中"
        
        return None
    
    def _analyze_sector_distribution(self, stocks: List[Dict]) -> Dict:
        """分析板块分布"""
        sector_count = {}
        for stock in stocks:
            sector = stock.get('sector', '未知')
            sector_count[sector] = sector_count.get(sector, 0) + 1
        
        return dict(sorted(sector_count.items(), key=lambda x: x[1], reverse=True))
    
    def _assess_risk_level(self, stocks: List[Dict]) -> str:
        """评估风险等级"""
        if not stocks:
            return "低"
        
        avg_score = sum(s['auction_score'] for s in stocks) / len(stocks)
        
        if avg_score >= 80:
            return "高"
        elif avg_score >= 60:
            return "中等"
        else:
            return "低"
    
    # ==================== 监控和管理 ====================
    
    async def start_monitoring(self):
        """启动监控"""
        self.monitoring = True
        print("🚀 涨停监控已启动")
        
    async def stop_monitoring(self):
        """停止监控"""
        self.monitoring = False
        print("📴 涨停监控已停止")