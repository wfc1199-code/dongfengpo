"""
支撑压力强度评级模块
Support & Resistance Strength Rating
"""

import numpy as np
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class SRStrengthRating:
    """支撑压力强度评级系统"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        
        # 评级阈值
        self.rating_thresholds = {
            'S': 80,  # S级：80分以上
            'A': 60,  # A级：60-80分
            'B': 40,  # B级：40-60分
            'C': 20   # C级：20-40分
        }
        
        # 各因素权重
        self.weights = {
            'touches': 0.25,          # 触及次数权重
            'volume': 0.20,           # 成交量权重
            'time_span': 0.15,        # 时间跨度权重
            'bounce_strength': 0.20,  # 反弹强度权重
            'multi_timeframe': 0.10,  # 多周期确认权重
            'recency': 0.10          # 最近触及权重
        }
        
    def rate_levels(self, sr_levels: List[Dict], market_data: Dict) -> List[Dict]:
        """
        对支撑压力位进行强度评级
        
        Args:
            sr_levels: 支撑压力位列表
            market_data: 市场数据（包含价格、成交量等）
            
        Returns:
            带有评级的支撑压力位列表
        """
        rated_levels = []
        
        for level in sr_levels:
            # 计算综合得分
            score = self._calculate_comprehensive_score(level, market_data)
            
            # 确定评级
            rating = self._determine_rating(score)
            
            # 生成评级报告
            level['strength_score'] = score
            level['rating'] = rating
            level['rating_details'] = self._generate_rating_details(level, market_data)
            
            rated_levels.append(level)
            
        # 按强度得分排序
        rated_levels.sort(key=lambda x: x['strength_score'], reverse=True)
        
        return rated_levels
        
    def _calculate_comprehensive_score(self, level: Dict, market_data: Dict) -> float:
        """计算综合强度得分"""
        scores = {}
        
        # 1. 触及次数得分
        scores['touches'] = self._score_touches(level.get('touches', 0))
        
        # 2. 成交量得分
        scores['volume'] = self._score_volume(level, market_data)
        
        # 3. 时间跨度得分
        scores['time_span'] = self._score_time_span(level, market_data)
        
        # 4. 反弹强度得分
        scores['bounce_strength'] = self._score_bounce_strength(level, market_data)
        
        # 5. 多周期确认得分
        scores['multi_timeframe'] = self._score_multi_timeframe(level)
        
        # 6. 最近触及得分
        scores['recency'] = self._score_recency(level, market_data)
        
        # 计算加权总分
        total_score = 0
        for factor, score in scores.items():
            weight = self.weights.get(factor, 0)
            total_score += score * weight
            
        # 保存各项得分明细
        level['score_details'] = scores
        
        return round(total_score, 1)
        
    def _score_touches(self, touches: int) -> float:
        """触及次数评分（0-100）"""
        if touches <= 0:
            return 0
        elif touches >= 10:
            return 100
        else:
            # 线性插值
            return touches * 10
            
    def _score_volume(self, level: Dict, market_data: Dict) -> float:
        """成交量评分（0-100）"""
        volume_data = level.get('volume_data', {})
        
        if not volume_data:
            # 如果没有成交量数据，使用默认分数
            return 50
            
        # 获取该价位的平均成交量
        level_avg_volume = volume_data.get('average', 0)
        
        # 获取整体平均成交量
        total_avg_volume = market_data.get('average_volume', 1)
        
        if total_avg_volume == 0:
            return 50
            
        # 计算成交量比率
        volume_ratio = level_avg_volume / total_avg_volume
        
        # 转换为分数（成交量越大分数越高）
        if volume_ratio >= 2.0:
            return 100
        elif volume_ratio >= 1.5:
            return 80
        elif volume_ratio >= 1.0:
            return 60
        elif volume_ratio >= 0.5:
            return 40
        else:
            return 20
            
    def _score_time_span(self, level: Dict, market_data: Dict) -> float:
        """时间跨度评分（0-100）"""
        # 获取第一次和最后一次触及的时间跨度
        first_touch_idx = level.get('first_touch_index', 0)
        last_touch_idx = level.get('last_touch_index', 0)
        
        total_periods = market_data.get('total_periods', 1)
        
        if total_periods == 0:
            return 50
            
        # 计算时间跨度比例
        span_ratio = (last_touch_idx - first_touch_idx) / total_periods
        
        # 时间跨度越大，说明该位置越重要
        if span_ratio >= 0.8:
            return 100
        elif span_ratio >= 0.6:
            return 80
        elif span_ratio >= 0.4:
            return 60
        elif span_ratio >= 0.2:
            return 40
        else:
            return 20
            
    def _score_bounce_strength(self, level: Dict, market_data: Dict) -> float:
        """反弹强度评分（0-100）"""
        bounce_data = level.get('bounce_data', [])
        
        if not bounce_data:
            return 50
            
        # 计算平均反弹幅度
        avg_bounce = np.mean([b.get('strength', 0) for b in bounce_data])
        
        # 反弹幅度越大，支撑压力越强
        if avg_bounce >= 0.05:  # 5%以上
            return 100
        elif avg_bounce >= 0.03:  # 3%以上
            return 80
        elif avg_bounce >= 0.02:  # 2%以上
            return 60
        elif avg_bounce >= 0.01:  # 1%以上
            return 40
        else:
            return 20
            
    def _score_multi_timeframe(self, level: Dict) -> float:
        """多周期确认评分（0-100）"""
        timeframes = level.get('confirmed_timeframes', [])
        
        # 根据确认的时间周期数量评分
        num_timeframes = len(timeframes)
        
        if num_timeframes >= 4:
            return 100
        elif num_timeframes >= 3:
            return 75
        elif num_timeframes >= 2:
            return 50
        elif num_timeframes >= 1:
            return 25
        else:
            return 0
            
    def _score_recency(self, level: Dict, market_data: Dict) -> float:
        """最近触及评分（0-100）"""
        last_touch_idx = level.get('last_touch_index', 0)
        total_periods = market_data.get('total_periods', 1)
        
        if total_periods == 0:
            return 50
            
        # 计算最近触及的位置比例
        recency_ratio = last_touch_idx / total_periods
        
        # 越近期触及的位置越重要
        if recency_ratio >= 0.9:
            return 100
        elif recency_ratio >= 0.7:
            return 80
        elif recency_ratio >= 0.5:
            return 60
        elif recency_ratio >= 0.3:
            return 40
        else:
            return 20
            
    def _determine_rating(self, score: float) -> str:
        """根据分数确定评级"""
        if score >= self.rating_thresholds['S']:
            return 'S'
        elif score >= self.rating_thresholds['A']:
            return 'A'
        elif score >= self.rating_thresholds['B']:
            return 'B'
        elif score >= self.rating_thresholds['C']:
            return 'C'
        else:
            return 'D'  # 低于C级
            
    def _generate_rating_details(self, level: Dict, market_data: Dict) -> Dict:
        """生成详细的评级报告"""
        score_details = level.get('score_details', {})
        
        # 找出最强和最弱的因素
        if score_details:
            sorted_factors = sorted(score_details.items(), key=lambda x: x[1], reverse=True)
            strongest_factor = sorted_factors[0] if sorted_factors else None
            weakest_factor = sorted_factors[-1] if sorted_factors else None
        else:
            strongest_factor = None
            weakest_factor = None
            
        return {
            'rating': level.get('rating', 'N/A'),
            'score': level.get('strength_score', 0),
            'strongest_factor': strongest_factor[0] if strongest_factor else None,
            'weakest_factor': weakest_factor[0] if weakest_factor else None,
            'recommendation': self._generate_recommendation(level),
            'confidence': self._calculate_confidence(level),
            'factors': score_details
        }
        
    def _generate_recommendation(self, level: Dict) -> str:
        """生成交易建议"""
        rating = level.get('rating', 'N/A')
        level_type = level.get('type', 'unknown')
        
        recommendations = {
            'S': {
                'support': '强支撑位，可考虑在此位置买入或加仓',
                'resistance': '强压力位，可考虑在此位置卖出或减仓',
                'both': '关键价位，突破方向将决定后续走势'
            },
            'A': {
                'support': '重要支撑位，关注是否有效支撑',
                'resistance': '重要压力位，关注能否有效突破',
                'both': '重要价位，需密切关注价格反应'
            },
            'B': {
                'support': '次要支撑位，可作为参考',
                'resistance': '次要压力位，可能形成短期阻力',
                'both': '参考价位，结合其他指标判断'
            },
            'C': {
                'support': '弱支撑位，可能被轻易突破',
                'resistance': '弱压力位，突破概率较大',
                'both': '参考价位，重要性较低'
            }
        }
        
        return recommendations.get(rating, {}).get(level_type, '等待更多数据')
        
    def _calculate_confidence(self, level: Dict) -> float:
        """计算置信度（0-1）"""
        # 基于多个因素计算置信度
        touches = level.get('touches', 0)
        score = level.get('strength_score', 0)
        
        # 触及次数越多，置信度越高
        touch_confidence = min(touches / 10, 1.0) * 0.5
        
        # 分数越高，置信度越高
        score_confidence = (score / 100) * 0.5
        
        return round(touch_confidence + score_confidence, 2)