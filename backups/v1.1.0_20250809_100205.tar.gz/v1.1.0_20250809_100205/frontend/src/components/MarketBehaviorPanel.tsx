import React, { useEffect, useState } from 'react';
import './MarketBehaviorPanel.css';

interface BehaviorAnalysis {
  behavior: 'washing' | 'shipping' | 'neutral' | 'unknown';
  confidence: number;
  alert_level: 'high' | 'opportunity' | 'medium' | 'low';
  suggestions: Array<{
    action: string;
    reason: string;
    confidence: number;
    risk_level: string;
    entry_price?: number;
    exit_price?: number;
    stop_loss?: number;
    target?: number;
  }>;
  signals: Array<{
    type: string;
    signal: string;
    meaning: string;
    strength: string;
  }>;
  volume_pattern?: {
    volume_ratio: number;
    is_heavy_volume: boolean;
    is_shrinking_volume: boolean;
    divergence: number;
    has_divergence: boolean;
  };
  price_pattern?: {
    volatility: number;
    rapid_drops: number;
    slow_rises: number;
    tail_movement: string;
    pattern: string;
  };
}

interface MarketBehaviorPanelProps {
  stockCode: string;
  currentPrice: number;
  position?: 'top-right' | 'bottom-right' | 'floating';
  autoRefresh?: boolean;
  refreshInterval?: number;
}

const MarketBehaviorPanel: React.FC<MarketBehaviorPanelProps> = ({
  stockCode,
  currentPrice,
  position = 'top-right',
  autoRefresh = true,
  refreshInterval = 5000
}) => {
  const [analysis, setAnalysis] = useState<BehaviorAnalysis | null>(null);
  const [alerts, setAlerts] = useState<Array<any>>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(true);

  // 获取行为分析数据
  const fetchBehaviorAnalysis = async () => {
    try {
      const response = await fetch(`http://localhost:9000/api/stocks/${stockCode}/behavior/analysis`);
      if (response.ok) {
        const data = await response.json();
        setAnalysis(data);
        
        // 生成实时提示
        generateRealTimeAlerts(data);
      }
    } catch (error) {
      console.error('Failed to fetch behavior analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  // 生成实时提示
  const generateRealTimeAlerts = (data: BehaviorAnalysis) => {
    const newAlerts: Array<{
      type: string;
      message: string;
      time: string;
    }> = [];
    
    // 根据行为类型生成提示
    if (data.behavior === 'washing' && data.confidence > 0.6) {
      newAlerts.push({
        type: 'opportunity',
        message: '📊 洗盘机会：主力可能在清洗浮筹，可关注低吸机会',
        time: new Date().toLocaleTimeString()
      });
    } else if (data.behavior === 'shipping' && data.confidence > 0.6) {
      newAlerts.push({
        type: 'warning',
        message: '⚠️ 风险提示：检测到出货迹象，建议谨慎操作',
        time: new Date().toLocaleTimeString()
      });
    }

    // 添加关键信号提示
    data.signals?.forEach(signal => {
      if (signal.strength === 'strong') {
        newAlerts.push({
          type: signal.type === 'volume' ? 'info' : 'signal',
          message: `${signal.signal}: ${signal.meaning}`,
          time: new Date().toLocaleTimeString()
        });
      }
    });

    setAlerts(prev => [...newAlerts, ...prev].slice(0, 5)); // 最多保留5条
  };

  useEffect(() => {
    if (!stockCode) return;

    fetchBehaviorAnalysis();

    if (autoRefresh) {
      const interval = setInterval(fetchBehaviorAnalysis, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [stockCode, autoRefresh, refreshInterval]);

  // 获取行为标签样式
  const getBehaviorStyle = (behavior: string) => {
    switch (behavior) {
      case 'washing':
        return { color: '#4CAF50', background: 'rgba(76, 175, 80, 0.1)' };
      case 'shipping':
        return { color: '#f44336', background: 'rgba(244, 67, 54, 0.1)' };
      case 'neutral':
        return { color: '#FF9800', background: 'rgba(255, 152, 0, 0.1)' };
      default:
        return { color: '#9E9E9E', background: 'rgba(158, 158, 158, 0.1)' };
    }
  };

  // 获取行为中文名称
  const getBehaviorName = (behavior: string) => {
    switch (behavior) {
      case 'washing': return '主力洗盘';
      case 'shipping': return '主力出货';
      case 'neutral': return '震荡整理';
      default: return '待判断';
    }
  };

  // 获取操作建议样式
  const getActionStyle = (action: string) => {
    if (action.includes('buy')) return 'action-buy';
    if (action.includes('sell')) return 'action-sell';
    return 'action-wait';
  };

  // 渲染置信度条
  const renderConfidenceBar = (confidence: number) => {
    const percentage = (confidence * 100).toFixed(0);
    return (
      <div className="confidence-bar">
        <div className="confidence-label">置信度</div>
        <div className="confidence-track">
          <div 
            className="confidence-fill" 
            style={{ 
              width: `${percentage}%`,
              background: confidence > 0.7 ? '#4CAF50' : confidence > 0.4 ? '#FF9800' : '#9E9E9E'
            }}
          />
        </div>
        <div className="confidence-value">{percentage}%</div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className={`behavior-panel ${position}`}>
        <div className="panel-loading">分析中...</div>
      </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className={`behavior-panel ${position} ${expanded ? 'expanded' : 'collapsed'}`}>
      {/* 面板标题 */}
      <div className="panel-header" onClick={() => setExpanded(!expanded)}>
        <div className="header-left">
          <span className="header-title">主力行为分析</span>
          <span 
            className="behavior-tag" 
            style={getBehaviorStyle(analysis.behavior)}
          >
            {getBehaviorName(analysis.behavior)}
          </span>
        </div>
        <div className="header-right">
          <span className="collapse-icon">{expanded ? '−' : '+'}</span>
        </div>
      </div>

      {expanded && (
        <>
          {/* 置信度显示 */}
          <div className="panel-section">
            {renderConfidenceBar(analysis.confidence)}
          </div>

          {/* 关键指标 */}
          <div className="panel-section indicators">
            <div className="indicator-row">
              <span className="indicator-label">成交量:</span>
              <span className="indicator-value">
                {analysis.volume_pattern?.is_heavy_volume ? '放量' : 
                 analysis.volume_pattern?.is_shrinking_volume ? '缩量' : '正常'}
              </span>
            </div>
            <div className="indicator-row">
              <span className="indicator-label">价格走势:</span>
              <span className="indicator-value">
                {analysis.price_pattern?.tail_movement === 'pull_up' ? '尾盘拉升' :
                 analysis.price_pattern?.tail_movement === 'dump' ? '尾盘跳水' : '平稳'}
              </span>
            </div>
            {analysis.volume_pattern?.has_divergence && (
              <div className="indicator-row warning">
                <span className="indicator-label">⚠️ 量价背离</span>
              </div>
            )}
          </div>

          {/* 操作建议 */}
          {analysis.suggestions && analysis.suggestions.length > 0 && (
            <div className="panel-section suggestions">
              <div className="section-title">操作建议</div>
              {analysis.suggestions.map((suggestion, index) => (
                <div key={index} className={`suggestion-card ${getActionStyle(suggestion.action)}`}>
                  <div className="suggestion-action">{suggestion.reason}</div>
                  {suggestion.entry_price && (
                    <div className="price-info">
                      <span>建议价: ¥{suggestion.entry_price.toFixed(2)}</span>
                      {suggestion.stop_loss && (
                        <span className="stop-loss">止损: ¥{suggestion.stop_loss.toFixed(2)}</span>
                      )}
                    </div>
                  )}
                  <div className="risk-level">
                    风险等级: <span className={`risk-${suggestion.risk_level}`}>{suggestion.risk_level}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 实时信号 */}
          {analysis.signals && analysis.signals.length > 0 && (
            <div className="panel-section signals">
              <div className="section-title">关键信号</div>
              <div className="signals-list">
                {analysis.signals.slice(0, 3).map((signal, index) => (
                  <div key={index} className={`signal-item strength-${signal.strength}`}>
                    <span className="signal-icon">
                      {signal.type === 'volume' ? '📊' : 
                       signal.type === 'price' ? '📈' : 
                       signal.type === 'support' ? '🛡️' : '💹'}
                    </span>
                    <div className="signal-content">
                      <div className="signal-name">{signal.signal}</div>
                      <div className="signal-meaning">{signal.meaning}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 实时警报 */}
          {alerts.length > 0 && (
            <div className="panel-section alerts">
              <div className="section-title">实时提示</div>
              <div className="alerts-list">
                {alerts.map((alert, index) => (
                  <div key={index} className={`alert-item alert-${alert.type}`}>
                    <div className="alert-message">{alert.message}</div>
                    <div className="alert-time">{alert.time}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default MarketBehaviorPanel;