import React, { useState, useEffect } from 'react';
import './StockList.css';

interface Stock {
  code: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  amount: number;
  turnoverRate?: number;
  isAnomaly?: boolean;
  anomalyType?: string;
}

interface AnomalyData {
  stock_code: string;
  stock_name: string;
  anomaly_type: string;
  confidence: number;
  timestamp: string;
  details: any;
}

interface StockListProps {
  stocks: Stock[];
  anomalies: AnomalyData[];
  selectedStock: string;
  onStockSelect: (stockCode: string) => void;
}

const StockList: React.FC<StockListProps> = ({
  stocks,
  anomalies,
  selectedStock,
  onStockSelect
}) => {
  // 自选股状态管理
  const [favoriteStocks, setFavoriteStocks] = useState<string[]>([]);
  const [showAddStock, setShowAddStock] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [searchResults, setSearchResults] = useState<{code: string, name: string}[]>([]);
  
  // 右键菜单状态管理
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    stockCode: string;
    stockName: string;
  }>({
    visible: false,
    x: 0,
    y: 0,
    stockCode: '',
    stockName: ''
  });

  // 默认监控的股票列表
  const defaultStocks = [
    { code: '000001', name: '平安银行' },
    { code: '000002', name: '万科A' },
    { code: '000858', name: '五粮液' },
    { code: '002415', name: '海康威视' },
    { code: '300498', name: '温氏股份' },
    { code: '600519', name: '贵州茅台' },
    { code: '600036', name: '招商银行' },
    { code: '000725', name: '京东方A' },
  ];

  // 加载自选股
  const loadFavorites = async () => {
    try {
      const response = await fetch('http://localhost:9000/api/config');
      if (response.ok) {
        const config = await response.json();
        const favorites = config?.user_customization?.自定义监控?.自选股票池 || [];
        setFavoriteStocks(favorites);
        console.log('加载自选股:', favorites);
      }
    } catch (error) {
      console.error('加载自选股失败:', error);
    }
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  // 搜索股票
  const handleSearch = async (input: string) => {
    setSearchInput(input);
    if (input.length < 1) {
      setSearchResults([]);
      return;
    }

    try {
      // 调用真实的股票搜索API
      const response = await fetch(`http://localhost:9000/api/stocks/search?q=${encodeURIComponent(input)}&limit=8`);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.stocks || []);
      } else {
        console.error('搜索API响应错误:', response.status);
        setSearchResults([]);
      }
    } catch (error) {
      console.error('搜索股票失败:', error);
      setSearchResults([]);
    }
  };

  // 添加自选股
  const addToFavorites = async (stockCode: string) => {
    if (favoriteStocks.includes(stockCode)) {
      alert('该股票已在自选股中');
      return;
    }

    const newFavorites = [...favoriteStocks, stockCode];

    try {
      // 更新配置
      const response = await fetch('http://localhost:9000/api/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_customization: {
            自定义监控: {
              自选股票池: newFavorites
            }
          }
        }),
      });

      if (response.ok) {
        console.log('自选股添加成功');
        // 重新加载配置以确保状态同步
        await loadFavorites();
        setShowAddStock(false);
        setSearchInput('');
        setSearchResults([]);
        alert(`已添加 ${stockCode} 到自选股`);
      } else {
        console.error('添加自选股失败，HTTP状态:', response.status);
        alert('添加失败，请重试');
      }
    } catch (error) {
      console.error('添加自选股失败:', error);
      alert('添加失败，请检查网络连接');
    }
  };

  // 删除自选股
  const removeFromFavorites = async (stockCode: string) => {
    const newFavorites = favoriteStocks.filter(code => code !== stockCode);

    try {
      const response = await fetch('http://localhost:9000/api/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_customization: {
            自定义监控: {
              自选股票池: newFavorites
            }
          }
        }),
      });

      if (response.ok) {
        console.log('自选股删除成功');
        // 重新加载配置以确保状态同步
        await loadFavorites();
        alert(`已删除 ${stockCode} 自选股`);
      } else {
        console.error('删除自选股失败，HTTP状态:', response.status);
        alert('删除失败，请重试');
      }
    } catch (error) {
      console.error('删除自选股失败:', error);
      alert('删除失败，请检查网络连接');
    }
  };

  // 处理右键菜单
  const handleContextMenu = (e: React.MouseEvent, stockCode: string, stockName: string) => {
    e.preventDefault(); // 阻止默认右键菜单
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      stockCode,
      stockName
    });
  };

  // 关闭右键菜单
  const closeContextMenu = () => {
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // 处理右键删除
  const handleContextDelete = () => {
    if (contextMenu.stockCode) {
      removeFromFavorites(contextMenu.stockCode);
    }
    closeContextMenu();
  };

  // 点击其他地方关闭右键菜单
  useEffect(() => {
    const handleClickOutside = () => {
      if (contextMenu.visible) {
        closeContextMenu();
      }
    };

    document.addEventListener('click', handleClickOutside);
    document.addEventListener('contextmenu', handleClickOutside);
    
    return () => {
      document.removeEventListener('click', handleClickOutside);
      document.removeEventListener('contextmenu', handleClickOutside);
    };
  }, [contextMenu.visible]);

  // 合并股票数据和异动数据
  let displayStocks;
  
  console.log('🔍 调试信息:', {
    favoriteStocks,
    stocksLength: stocks?.length,
    stockCodes: stocks?.map(s => s.code)
  });
  
     // 如果有自选股，只显示自选股；否则显示默认股票或API返回的所有股票
   if (favoriteStocks.length > 0) {
     // 有自选股：构建自选股列表，并从API数据中匹配详细信息
     displayStocks = favoriteStocks.map(favoriteCode => {
       // 从stocks数组中查找匹配的股票数据（stocks数组包含实时数据）
       const stockData = stocks.find(s => s.code === favoriteCode);
       const anomaly = Array.isArray(anomalies) ? anomalies.find(a => a.stock_code === favoriteCode) : null;
       
       console.log(`🔍 自选股 ${favoriteCode} 匹配结果:`, stockData);
       
       return {
         code: favoriteCode,
         name: stockData?.name || `股票${favoriteCode}`,
         price: stockData?.price || 0,
         change: stockData?.change || 0,
         changePercent: stockData?.changePercent || 0,
         volume: stockData?.volume || 0,
         amount: stockData?.amount || 0,
         turnoverRate: stockData?.turnoverRate || Math.random() * 5,
         isAnomaly: !!anomaly,
         anomalyType: anomaly?.anomaly_type,
         confidence: anomaly?.confidence
       };
     });
  } else if (stocks && stocks.length > 0) {
    // 没有自选股，显示API返回的所有股票
    displayStocks = stocks.map(stock => {
      const anomaly = Array.isArray(anomalies) ? anomalies.find(a => a.stock_code === stock.code) : null;
      
      return {
        ...stock,
        turnoverRate: stock.turnoverRate || Math.random() * 5,
        isAnomaly: !!anomaly,
        anomalyType: anomaly?.anomaly_type,
        confidence: anomaly?.confidence
      };
    });
  } else {
    // 没有自选股也没有API数据，显示默认股票
    displayStocks = defaultStocks.map(stock => {
      const anomaly = Array.isArray(anomalies) ? anomalies.find(a => a.stock_code === stock.code) : null;
      
      return {
        ...stock,
        price: 0,
        change: 0,
        changePercent: 0,
        volume: 0,
        amount: 0,
        turnoverRate: Math.random() * 5,
        isAnomaly: !!anomaly,
        anomalyType: anomaly?.anomaly_type,
        confidence: anomaly?.confidence
      };
    });
  }
  
  console.log('📊 显示股票列表:', displayStocks);

  const getChangeClass = (change: number) => {
    if (change > 0) return 'positive';
    if (change < 0) return 'negative';
    return 'neutral';
  };

  return (
    <div className="stock-list">
      <div className="stock-list-header">
        <span className="stock-count">自选 {displayStocks.length} 只</span>
        <div className="header-actions">
          <button 
            className="add-stock-btn"
            onClick={() => setShowAddStock(!showAddStock)}
            title="添加自选股"
          >
            ➕
          </button>
          <div className="anomaly-count">
            异动: <span className="count">{Array.isArray(anomalies) ? anomalies.length : 0}</span>
          </div>
        </div>
      </div>

      {/* 添加股票搜索框 */}
      {showAddStock && (
        <div className="add-stock-panel">
          <div className="search-input-wrapper">
            <input
              type="text"
              placeholder="输入股票代码、名称或拼音首字母"
              value={searchInput}
              onChange={(e) => handleSearch(e.target.value)}
              className="search-input"
            />
          </div>
          {(searchInput.length === 0 || searchResults.length > 0) && (
            <div className="search-results">
              {searchInput.length === 0 && (
                <div className="search-help">
                  <div>搜索方式：</div>
                  <div className="search-help-examples">
                    <span className="search-example" onClick={() => setSearchInput('000001')}>000001</span>
                    <span className="search-example" onClick={() => setSearchInput('平安')}>平安</span>
                    <span className="search-example" onClick={() => setSearchInput('payx')}>payx (平安银行)</span>
                    <span className="search-example" onClick={() => setSearchInput('gzmt')}>gzmt (贵州茅台)</span>
                    <span className="search-example" onClick={() => setSearchInput('wly')}>wly (五粮液)</span>
                  </div>
                </div>
              )}
              {searchResults.map((result) => (
                <div
                  key={result.code}
                  className="search-result-item"
                  onClick={() => addToFavorites(result.code)}
                >
                  <span className="result-code">{result.code}</span>
                  <span className="result-name">{result.name}</span>
                  {(result as any).pinyin_initials && (
                    <span style={{ color: '#888', fontSize: '10px', marginLeft: '4px' }}>
                      ({(result as any).pinyin_initials})
                    </span>
                  )}
                  <span className="add-icon">+</span>
                </div>
              ))}
            </div>
          )}
          {searchInput.length >= 2 && searchResults.length === 0 && (
            <div className="search-results">
              <div className="search-result-item">
                <span style={{ color: '#888' }}>没有找到匹配的股票</span>
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="stock-list-content">
        {displayStocks.map((stock) => (
          <div
            key={stock.code}
            className={`stock-item-inline ${selectedStock === stock.code ? 'selected' : ''} ${stock.isAnomaly ? 'anomaly' : ''}`}
            onClick={() => onStockSelect(stock.code)}
            onContextMenu={(e) => favoriteStocks.includes(stock.code) && handleContextMenu(e, stock.code, stock.name)}
            title={favoriteStocks.includes(stock.code) ? "右键删除自选股" : undefined}
          >
            <span className="stock-code">{stock.code}</span>
            <span className="stock-name">
              {stock.name || '无名称'}
            </span>
            <span className={`stock-price ${getChangeClass(stock.changePercent)}`}>
              {stock.price > 0 ? stock.price.toFixed(2) : '--'}
            </span>
            <span className={`stock-change ${getChangeClass(stock.changePercent)}`}>
              {stock.changePercent !== 0 ? 
                `${stock.changePercent >= 0 ? '+' : ''}${stock.changePercent.toFixed(2)}%` : 
                '--'
              }
            </span>
            <span className="stock-turnover">
              {stock.turnoverRate > 0 ? `${stock.turnoverRate.toFixed(2)}%` : '--'}
            </span>
            {stock.isAnomaly && (
              <span className="anomaly-indicator" title={`异动: ${stock.anomalyType}`}>
                ⚡
              </span>
            )}
            {favoriteStocks.includes(stock.code) && (
              <button
                className="remove-favorite-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  removeFromFavorites(stock.code);
                }}
                title="删除自选股"
              >
                ✕
              </button>
            )}
          </div>
        ))}
      </div>
      
      <div className="list-footer">
        <small>
          {favoriteStocks.length > 0 
            ? `自选股实时监控中...` 
            : '点击 ➕ 添加自选股'
          }
        </small>
      </div>

      {/* 右键上下文菜单 */}
      {contextMenu.visible && (
        <div
          className="context-menu"
          style={{
            position: 'fixed',
            left: contextMenu.x,
            top: contextMenu.y,
            zIndex: 1000
          }}
        >
          <div className="context-menu-header">
            <span className="context-menu-stock">
              {contextMenu.stockCode} - {contextMenu.stockName}
            </span>
          </div>
          <div className="context-menu-divider"></div>
          <div 
            className="context-menu-item delete"
            onClick={handleContextDelete}
          >
            <span className="context-menu-icon">🗑️</span>
            <span>删除自选股</span>
          </div>
          <div 
            className="context-menu-item"
            onClick={closeContextMenu}
          >
            <span className="context-menu-icon">❌</span>
            <span>取消</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default StockList; 