/**
 * 成交量分布图组件
 * Volume Profile Chart
 */

import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import { VolumeProfile, VolumeProfileBarData } from '../../types/supportResistance';
import './VolumeProfileChart.css';

interface VolumeProfileChartProps {
  volumeProfile: VolumeProfile | null;
  currentPrice: number;
  height: number;
  width?: number;
  orientation?: 'vertical' | 'horizontal';
}

export const VolumeProfileChart: React.FC<VolumeProfileChartProps> = ({
  volumeProfile,
  currentPrice,
  height,
  width = 100,
  orientation = 'vertical'
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    // 初始化图表
    if (!chartInstance.current) {
      chartInstance.current = echarts.init(chartRef.current);
    }
    
    if (!volumeProfile || !volumeProfile.poc || !volumeProfile.valueArea) {
      chartInstance.current.clear();
      return;
    }
    
    // 准备数据
    const profileData: VolumeProfileBarData[] = [];
    
    // 模拟volume profile数据（实际应从后端获取）
    const priceRange = volumeProfile.valueArea.high - volumeProfile.valueArea.low;
    const bins = 30;
    const binSize = priceRange / bins;
    
    for (let i = 0; i < bins; i++) {
      const price = volumeProfile.valueArea.low + i * binSize;
      const volume = Math.random() * 1000000; // 模拟数据
      const maxVolume = 2000000;
      
      profileData.push({
        price: price,
        volume: volume,
        percentage: (volume / maxVolume) * 100,
        isHVN: volume > maxVolume * 0.7,
        isLVN: volume < maxVolume * 0.2,
        isPOC: Math.abs(price - volumeProfile.poc.price) < binSize,
        isValueArea: price >= volumeProfile.valueArea.low && price <= volumeProfile.valueArea.high
      });
    }
    
    // 配置选项
    const option: echarts.EChartsOption = orientation === 'vertical' ? {
      grid: {
        left: 5,
        right: 5,
        top: 5,
        bottom: 5,
        containLabel: false
      },
      xAxis: {
        type: 'value',
        show: false,
        max: 100
      },
      yAxis: {
        type: 'value',
        show: false,
        min: volumeProfile.valueArea.low * 0.99,
        max: volumeProfile.valueArea.high * 1.01
      },
      series: [{
        type: 'bar',
        data: profileData.map(d => ({
          value: [d.percentage, d.price],
          itemStyle: {
            color: d.isPOC ? '#FF1744' : 
                   d.isHVN ? '#1976D2' : 
                   d.isLVN ? '#E0E0E0' : 
                   d.isValueArea ? '#42A5F5' : '#BDBDBD',
            borderRadius: [0, 2, 2, 0]
          }
        })),
        barWidth: '80%',
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(0,0,0,0.3)'
          }
        }
      }],
      tooltip: {
        trigger: 'item',
        formatter: (params: any) => {
          const data = profileData[params.dataIndex];
          return `价格: ¥${data.price.toFixed(2)}<br/>成交量: ${(data.volume/10000).toFixed(0)}万`;
        }
      }
    } : {
      // 水平方向的配置
      grid: {
        left: 50,
        right: 10,
        top: 5,
        bottom: 5
      },
      xAxis: {
        type: 'category',
        data: profileData.map(d => d.price.toFixed(2)),
        axisLabel: {
          rotate: 45,
          fontSize: 10
        }
      },
      yAxis: {
        type: 'value',
        show: false
      },
      series: [{
        type: 'bar',
        data: profileData.map(d => ({
          value: d.percentage,
          itemStyle: {
            color: d.isPOC ? '#FF1744' : 
                   d.isHVN ? '#1976D2' : 
                   d.isLVN ? '#E0E0E0' : 
                   d.isValueArea ? '#42A5F5' : '#BDBDBD'
          }
        })),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(0,0,0,0.3)'
          }
        }
      }]
    };
    
    // 添加当前价格线
    if (orientation === 'vertical' && option.series) {
      const series = Array.isArray(option.series) ? option.series : [option.series];
      series.push({
        type: 'line',
        markLine: {
          symbol: 'none',
          data: [{
            yAxis: currentPrice,
            lineStyle: {
              color: '#000',
              width: 2,
              type: 'solid'
            },
            label: {
              show: false
            }
          }]
        },
        data: []
      } as any);
      option.series = series;
    }
    
    chartInstance.current.setOption(option);
    
    // 响应式调整
    const handleResize = () => {
      chartInstance.current?.resize();
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [volumeProfile, currentPrice, orientation]);
  
  return (
    <div className="volume-profile-container">
      <div className="volume-profile-header">
        <span className="title">成交量分布</span>
        {volumeProfile && volumeProfile.poc && (
          <div className="poc-info">
            POC: ¥{volumeProfile.poc.price.toFixed(2)}
          </div>
        )}
      </div>
      <div 
        ref={chartRef}
        className="volume-profile-chart"
        style={{ 
          width: orientation === 'vertical' ? `${width}px` : '100%',
          height: `${height}px` 
        }}
      />
      <div className="volume-profile-legend">
        <div className="legend-item">
          <span className="color-box" style={{ backgroundColor: '#FF1744' }}></span>
          <span>POC</span>
        </div>
        <div className="legend-item">
          <span className="color-box" style={{ backgroundColor: '#1976D2' }}></span>
          <span>HVN</span>
        </div>
        <div className="legend-item">
          <span className="color-box" style={{ backgroundColor: '#42A5F5' }}></span>
          <span>价值区</span>
        </div>
      </div>
    </div>
  );
};