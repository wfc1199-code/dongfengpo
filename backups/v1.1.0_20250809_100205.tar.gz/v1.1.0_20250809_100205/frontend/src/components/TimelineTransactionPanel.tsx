import React, { useState, useEffect } from 'react';
import './TimelineTransactionPanel.css';

interface TransactionDetail {
  time: string;
  price: number;
  volume: number;
  amount: number;
  type: 'buy' | 'sell' | 'neutral';
  level: 'large' | 'medium' | 'small';
  priceImpact: number; // 对价格的影响百分比
  isActive: boolean; // 是否主动单
  cumulativeVolume?: number; // 累计成交量
  cumulativeAmount?: number; // 累计成交额
  priceChange?: number; // 价格变化
}

interface TimelineStats {
  // 时段统计
  startTime: string;
  endTime: string;
  duration: number; // 秒
  startPrice: number;
  endPrice: number;
  priceChange: number;
  priceChangePercent: number;
  
  // 成交统计
  totalCount: number;
  totalVolume: number;
  totalAmount: number;
  avgPrice: number;
  vwap: number; // 成交量加权平均价
  
  // 主动被动统计
  activeCount: number;
  passiveCount: number;
  activeBuyVolume: number;
  activeSellVolume: number;
  passiveBuyVolume: number;
  passiveSellVolume: number;
  
  // 大中小单统计
  largeOrderCount: number;
  largeOrderVolume: number;
  largeOrderAmount: number;
  largeOrderPercent: number;
  
  // 价格影响分析
  maxPriceImpact: number;
  avgPriceImpact: number;
  impactTrend: 'positive' | 'negative' | 'neutral';
  
  // 主力行为判断
  mainForceAction: 'accumulating' | 'distributing' | 'washing' | 'unclear';
  confidence: number;
}

interface TimelineTransactionPanelProps {
  anomaly: {
    time: string;
    price: number;
    type: 'surge' | 'plunge';
    changePercent: number;
    index: number;
  } | null;
  stockCode: string;
  onClose?: () => void;
}

const TimelineTransactionPanel: React.FC<TimelineTransactionPanelProps> = ({
  anomaly,
  stockCode,
  onClose
}) => {
  const [transactions, setTransactions] = useState<TransactionDetail[]>([]);
  const [stats, setStats] = useState<TimelineStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const [viewMode, setViewMode] = useState<'timeline' | 'table' | 'chart'>('timeline');
  const [selectedTransaction, setSelectedTransaction] = useState<TransactionDetail | null>(null);

  // 获取异动期间的成交明细（增强版）
  useEffect(() => {
    if (!anomaly) return;

    const fetchDetailedTransactions = async () => {
      setLoading(true);
      try {
        // 计算时间范围（前后5分钟，获取更完整的过程）
        const anomalyTime = anomaly.time;
        const [hour, minute] = anomalyTime.split(':').map(Number);
        
        let startHour = hour;
        let startMinute = minute - 5;
        if (startMinute < 0) {
          startMinute += 60;
          startHour -= 1;
        }
        
        let endHour = hour;
        let endMinute = minute + 5;
        if (endMinute >= 60) {
          endMinute -= 60;
          endHour += 1;
        }
        
        const startTime = `${startHour.toString().padStart(2, '0')}:${startMinute.toString().padStart(2, '0')}:00`;
        const endTime = `${endHour.toString().padStart(2, '0')}:${endMinute.toString().padStart(2, '0')}:00`;
        
        console.log(`获取详细成交明细: ${stockCode} ${startTime} - ${endTime}`);
        
        // 模拟获取增强的成交数据
        const mockTransactions = generateEnhancedMockTransactions(anomaly, startTime, endTime);
        setTransactions(mockTransactions);
        
        // 计算统计数据
        const statistics = calculateTimelineStats(mockTransactions, anomaly);
        setStats(statistics);
        
      } catch (error) {
        console.error('Failed to fetch detailed transactions:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDetailedTransactions();
  }, [anomaly, stockCode]);

  // 生成增强的模拟成交明细
  const generateEnhancedMockTransactions = (anomaly: any, startTime: string, endTime: string): TransactionDetail[] => {
    const transactions: TransactionDetail[] = [];
    const basePrice = anomaly.price;
    const isUpward = anomaly.type === 'surge';
    
    let cumulativeVolume = 0;
    let cumulativeAmount = 0;
    let currentPrice = basePrice * 0.98; // 从低点开始
    
    // 生成时间序列（每3-10秒一笔）
    const [startH, startM, startS] = startTime.split(':').map(Number);
    let currentTime = new Date(2024, 0, 1, startH, startM, startS);
    const [endH, endM, endS] = endTime.split(':').map(Number);
    const endDateTime = new Date(2024, 0, 1, endH, endM, endS);
    
    let phase = 'preparation'; // preparation -> main -> ending
    let transactionIndex = 0;
    
    while (currentTime <= endDateTime) {
      transactionIndex++;
      
      // 根据阶段调整交易特征
      if (transactionIndex < 20) {
        phase = 'preparation'; // 准备阶段
      } else if (transactionIndex < 80) {
        phase = 'main'; // 主升/主跌阶段
      } else {
        phase = 'ending'; // 收尾阶段
      }
      
      // 根据阶段生成不同特征的成交
      let volume = 0;
      let priceChange = 0;
      let isActive = false;
      let isBuy = false;
      
      if (phase === 'preparation') {
        // 准备阶段：小单试探，偶尔有中单
        volume = Math.random() > 0.8 ? 
                 Math.floor(Math.random() * 8000) + 3000 :  // 20%概率中单
                 Math.floor(Math.random() * 3000) + 500;
        priceChange = (Math.random() - 0.5) * 0.001;
        isActive = Math.random() > 0.6;
        isBuy = isUpward ? Math.random() > 0.4 : Math.random() > 0.6;
      } else if (phase === 'main') {
        // 主要阶段：大单推进
        const rand = Math.random();
        if (rand > 0.7) {
          // 30%概率超大单
          volume = Math.floor(Math.random() * 30000) + 15000;
        } else if (rand > 0.3) {
          // 40%概率大单
          volume = Math.floor(Math.random() * 15000) + 8000;
        } else {
          // 30%概率中小单
          volume = Math.floor(Math.random() * 8000) + 2000;
        }
        priceChange = isUpward ? Math.random() * 0.003 : -Math.random() * 0.003;
        isActive = Math.random() > 0.3;
        isBuy = isUpward ? Math.random() > 0.25 : Math.random() > 0.75;
      } else {
        // 收尾阶段：逐渐减弱，偶有大单
        volume = Math.random() > 0.85 ? 
                 Math.floor(Math.random() * 12000) + 6000 :  // 15%概率大单
                 Math.floor(Math.random() * 5000) + 1000;
        priceChange = (Math.random() - 0.5) * 0.002;
        isActive = Math.random() > 0.5;
        isBuy = Math.random() > 0.5;
      }
      
      currentPrice = currentPrice * (1 + priceChange);
      const amount = currentPrice * volume;
      cumulativeVolume += volume;
      cumulativeAmount += amount;
      
      // 计算对价格的影响
      const priceImpact = priceChange * 100;
      
      // 判断单子级别（调整为更合理的标准）
      let level: 'large' | 'medium' | 'small' = 'small';
      if (volume >= 10000 || amount >= 200000) level = 'large';  // 1万股或20万元以上为大单
      else if (volume >= 5000 || amount >= 50000) level = 'medium'; // 5千股或5万元以上为中单
      
      transactions.push({
        time: currentTime.toTimeString().slice(0, 8),
        price: parseFloat(currentPrice.toFixed(2)),
        volume: volume,
        amount: amount,
        type: isBuy ? 'buy' : (Math.random() > 0.8 ? 'neutral' : 'sell'),
        level: level,
        priceImpact: priceImpact,
        isActive: isActive,
        cumulativeVolume: cumulativeVolume,
        cumulativeAmount: cumulativeAmount,
        priceChange: priceChange * 100
      });
      
      // 随机增加时间（3-10秒）
      currentTime = new Date(currentTime.getTime() + (Math.floor(Math.random() * 7) + 3) * 1000);
    }
    
    return transactions;
  };

  // 计算时间轴统计数据
  const calculateTimelineStats = (transactions: TransactionDetail[], anomaly: any): TimelineStats => {
    if (transactions.length === 0) {
      return {} as TimelineStats;
    }
    
    const firstTx = transactions[0];
    const lastTx = transactions[transactions.length - 1];
    
    // 基础统计
    const totalVolume = transactions.reduce((sum, t) => sum + t.volume, 0);
    const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
    const avgPrice = totalAmount / totalVolume;
    
    // 主动被动统计
    const activeTransactions = transactions.filter(t => t.isActive);
    const passiveTransactions = transactions.filter(t => !t.isActive);
    
    const activeBuyVolume = activeTransactions
      .filter(t => t.type === 'buy')
      .reduce((sum, t) => sum + t.volume, 0);
    
    const activeSellVolume = activeTransactions
      .filter(t => t.type === 'sell')
      .reduce((sum, t) => sum + t.volume, 0);
    
    const passiveBuyVolume = passiveTransactions
      .filter(t => t.type === 'buy')
      .reduce((sum, t) => sum + t.volume, 0);
    
    const passiveSellVolume = passiveTransactions
      .filter(t => t.type === 'sell')
      .reduce((sum, t) => sum + t.volume, 0);
    
    // 大单统计
    const largeOrders = transactions.filter(t => t.level === 'large');
    const largeOrderVolume = largeOrders.reduce((sum, t) => sum + t.volume, 0);
    const largeOrderAmount = largeOrders.reduce((sum, t) => sum + t.amount, 0);
    
    // 价格影响分析
    const priceImpacts = transactions.map(t => t.priceImpact);
    const maxPriceImpact = Math.max(...priceImpacts);
    const avgPriceImpact = priceImpacts.reduce((sum, p) => sum + p, 0) / priceImpacts.length;
    
    // 判断趋势
    const positiveImpacts = priceImpacts.filter(p => p > 0).length;
    const negativeImpacts = priceImpacts.filter(p => p < 0).length;
    let impactTrend: 'positive' | 'negative' | 'neutral' = 'neutral';
    if (positiveImpacts > negativeImpacts * 1.5) impactTrend = 'positive';
    else if (negativeImpacts > positiveImpacts * 1.5) impactTrend = 'negative';
    
    // 主力行为判断
    let mainForceAction: 'accumulating' | 'distributing' | 'washing' | 'unclear' = 'unclear';
    let confidence = 50;
    
    const buyRatio = activeBuyVolume / (activeBuyVolume + activeSellVolume);
    const largeOrderPercent = (largeOrderVolume / totalVolume) * 100;
    
    if (buyRatio > 0.65 && largeOrderPercent > 40) {
      mainForceAction = 'accumulating';
      confidence = 85;
    } else if (buyRatio < 0.35 && largeOrderPercent > 40) {
      mainForceAction = 'distributing';
      confidence = 80;
    } else if (Math.abs(buyRatio - 0.5) < 0.15 && largeOrderPercent > 30) {
      mainForceAction = 'washing';
      confidence = 70;
    }
    
    // 计算时间差
    const startTimeParts = firstTx.time.split(':').map(Number);
    const endTimeParts = lastTx.time.split(':').map(Number);
    const duration = (endTimeParts[0] - startTimeParts[0]) * 3600 + 
                    (endTimeParts[1] - startTimeParts[1]) * 60 + 
                    (endTimeParts[2] - startTimeParts[2]);
    
    return {
      startTime: firstTx.time,
      endTime: lastTx.time,
      duration: duration,
      startPrice: firstTx.price,
      endPrice: lastTx.price,
      priceChange: lastTx.price - firstTx.price,
      priceChangePercent: ((lastTx.price - firstTx.price) / firstTx.price) * 100,
      
      totalCount: transactions.length,
      totalVolume: totalVolume,
      totalAmount: totalAmount,
      avgPrice: avgPrice,
      vwap: avgPrice,
      
      activeCount: activeTransactions.length,
      passiveCount: passiveTransactions.length,
      activeBuyVolume: activeBuyVolume,
      activeSellVolume: activeSellVolume,
      passiveBuyVolume: passiveBuyVolume,
      passiveSellVolume: passiveSellVolume,
      
      largeOrderCount: largeOrders.length,
      largeOrderVolume: largeOrderVolume,
      largeOrderAmount: largeOrderAmount,
      largeOrderPercent: largeOrderPercent,
      
      maxPriceImpact: maxPriceImpact,
      avgPriceImpact: avgPriceImpact,
      impactTrend: impactTrend,
      
      mainForceAction: mainForceAction,
      confidence: confidence
    };
  };

  // 格式化数字
  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return `${(num / 10000).toFixed(2)}万`;
    }
    return num.toFixed(0);
  };

  // 格式化金额
  const formatAmount = (amount: number): string => {
    if (amount >= 100000000) {
      return `${(amount / 100000000).toFixed(2)}亿`;
    }
    if (amount >= 10000) {
      return `${(amount / 10000).toFixed(2)}万`;
    }
    return amount.toFixed(2);
  };

  // 获取主力行为描述
  const getMainForceActionDesc = (action: string): string => {
    switch (action) {
      case 'accumulating': return '建仓吸筹';
      case 'distributing': return '派发出货';
      case 'washing': return '震荡洗盘';
      default: return '意图不明';
    }
  };

  // 渲染时间轴视图（紧凑单列布局）
  const renderTimeline = () => {
    return (
      <div className="timeline-container">
        <div className="timeline-table">
          <div className="timeline-header-row">
            <div className="col-time">时间</div>
            <div className="col-price">价格</div>
            <div className="col-volume">成交量</div>
            <div className="col-amount">成交额</div>
            <div className="col-type">性质</div>
            <div className="col-impact">影响</div>
            <div className="col-cumulative-volume">累计量</div>
            <div className="col-cumulative-amount">累计额</div>
          </div>
          
          <div className="timeline-body">
            {transactions.map((tx, idx) => {
              const isKeyPoint = tx.level === 'large' || Math.abs(tx.priceImpact) > 0.2;
              const phase = idx < 20 ? 'preparation' : idx < 80 ? 'main' : 'ending';
              
              return (
                <div 
                  key={idx} 
                  className={`timeline-row ${tx.type} ${tx.level} ${phase} ${isKeyPoint ? 'key-point' : ''}`}
                  onClick={() => setSelectedTransaction(tx)}
                >
                  <div className="col-time">
                    {tx.time}
                    {isKeyPoint && <span className="key-star">★</span>}
                  </div>
                  <div className="col-price">
                    <span className="price-value">¥{tx.price.toFixed(2)}</span>
                    <span className={`price-change ${tx.priceChange && tx.priceChange > 0 ? 'up' : 'down'}`}>
                      {tx.priceChange && tx.priceChange > 0 ? '↑' : '↓'}{Math.abs(tx.priceChange || 0).toFixed(2)}%
                    </span>
                  </div>
                  <div className="col-volume">
                    {formatNumber(tx.volume)}
                    {tx.level === 'large' && <span className="badge-large">大</span>}
                  </div>
                  <div className="col-amount">
                    {formatAmount(tx.amount)}
                  </div>
                  <div className="col-type">
                    <span className={`type-badge ${tx.isActive ? 'active' : 'passive'}`}>
                      {tx.isActive ? '主' : '被'}
                    </span>
                    <span className={`direction-badge ${tx.type}`}>
                      {tx.type === 'buy' ? '买' : tx.type === 'sell' ? '卖' : '中'}
                    </span>
                  </div>
                  <div className="col-impact">
                    <span className={`impact-value ${tx.priceImpact > 0 ? 'positive' : 'negative'}`}>
                      {tx.priceImpact > 0 ? '+' : ''}{tx.priceImpact.toFixed(2)}%
                    </span>
                  </div>
                  <div className="col-cumulative-volume">
                    {formatNumber(tx.cumulativeVolume || 0)}
                  </div>
                  <div className="col-cumulative-amount">
                    {formatAmount(tx.cumulativeAmount || 0)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  // 渲染图表统计
  const renderCharts = () => {
    if (!stats || transactions.length === 0) return null;
    
    // 准备时间分布数据
    const timeDistribution = prepareTimeDistribution();
    // 准备价格分布数据
    const priceDistribution = preparePriceDistribution();
    // 准备成交量分布数据
    const volumeDistribution = prepareVolumeDistribution();
    // 准备买卖分布数据
    const buySellDistribution = prepareBuySellDistribution();
    
    return (
      <div className="charts-container">
        <div className="chart-row">
          {/* 时间分布条形图 */}
          <div className="chart-card">
            <div className="chart-title">时间分布</div>
            <div className="bar-chart">
              {timeDistribution.map((item, idx) => (
                <div key={idx} className="bar-group">
                  <div className="bar-wrapper">
                    <div 
                      className="bar time-bar"
                      style={{ height: `${item.percentage}%` }}
                      title={`${item.label}: ${item.count}笔`}
                    >
                      <span className="bar-value">{item.count}</span>
                    </div>
                  </div>
                  <div className="bar-label">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          {/* 价格分布条形图 */}
          <div className="chart-card">
            <div className="chart-title">价格分布</div>
            <div className="bar-chart">
              {priceDistribution.map((item, idx) => (
                <div key={idx} className="bar-group">
                  <div className="bar-wrapper">
                    <div 
                      className="bar price-bar"
                      style={{ height: `${item.percentage}%` }}
                      title={`¥${item.label}: ${item.count}笔`}
                    >
                      <span className="bar-value">{item.count}</span>
                    </div>
                  </div>
                  <div className="bar-label">¥{item.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          {/* 成交量分布条形图 */}
          <div className="chart-card">
            <div className="chart-title">成交量分布</div>
            <div className="bar-chart">
              {volumeDistribution.map((item, idx) => (
                <div key={idx} className="bar-group">
                  <div className="bar-wrapper">
                    <div 
                      className={`bar volume-bar ${item.level}`}
                      style={{ height: `${item.percentage}%` }}
                      title={`${item.label}: ${item.volume}`}
                    >
                      <span className="bar-value">{formatNumber(item.volume)}</span>
                    </div>
                  </div>
                  <div className="bar-label">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="chart-row">
          {/* 主动被动买卖饼图 */}
          <div className="chart-card pie-chart-card">
            <div className="chart-title">主动/被动买卖分布</div>
            <div className="pie-chart-container">
              <svg className="pie-chart" viewBox="0 0 200 200">
                {renderPieChart(buySellDistribution)}
              </svg>
              <div className="pie-legend">
                {buySellDistribution.map((item, idx) => (
                  <div key={idx} className="legend-item">
                    <span className={`legend-color ${item.type}`}></span>
                    <span className="legend-label">{item.label}</span>
                    <span className="legend-value">{formatNumber(item.value)}</span>
                    <span className="legend-percent">({item.percentage.toFixed(1)}%)</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  // 准备时间分布数据
  const prepareTimeDistribution = () => {
    // 按分钟分组
    const timeGroups: { [key: string]: number } = {};
    transactions.forEach(tx => {
      const minute = tx.time.substring(0, 5); // HH:MM
      timeGroups[minute] = (timeGroups[minute] || 0) + 1;
    });
    
    const maxCount = Math.max(...Object.values(timeGroups));
    return Object.entries(timeGroups)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(0, 10) // 显示前10个时间段
      .map(([time, count]) => ({
        label: time,
        count: count,
        percentage: (count / maxCount) * 100
      }));
  };
  
  // 准备价格分布数据
  const preparePriceDistribution = () => {
    const prices = transactions.map(t => t.price);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const range = maxPrice - minPrice;
    const step = range / 5; // 分5档
    
    const priceGroups: { label: string; count: number; range: [number, number] }[] = [];
    for (let i = 0; i < 5; i++) {
      const start = minPrice + i * step;
      const end = minPrice + (i + 1) * step;
      const count = transactions.filter(t => t.price >= start && t.price < end).length;
      priceGroups.push({
        label: start.toFixed(2),
        count: count,
        range: [start, end]
      });
    }
    
    const maxCount = Math.max(...priceGroups.map(g => g.count));
    return priceGroups.map(g => ({
      ...g,
      percentage: (g.count / maxCount) * 100
    }));
  };
  
  // 准备成交量分布数据
  const prepareVolumeDistribution = () => {
    const largeVolume = transactions
      .filter(t => t.level === 'large')
      .reduce((sum, t) => sum + t.volume, 0);
    const mediumVolume = transactions
      .filter(t => t.level === 'medium')
      .reduce((sum, t) => sum + t.volume, 0);
    const smallVolume = transactions
      .filter(t => t.level === 'small')
      .reduce((sum, t) => sum + t.volume, 0);
    
    const maxVolume = Math.max(largeVolume, mediumVolume, smallVolume);
    
    return [
      { label: '大单', volume: largeVolume, level: 'large', percentage: (largeVolume / maxVolume) * 100 },
      { label: '中单', volume: mediumVolume, level: 'medium', percentage: (mediumVolume / maxVolume) * 100 },
      { label: '小单', volume: smallVolume, level: 'small', percentage: (smallVolume / maxVolume) * 100 }
    ];
  };
  
  // 准备买卖分布数据
  const prepareBuySellDistribution = () => {
    const activeBuy = stats?.activeBuyVolume || 0;
    const activeSell = stats?.activeSellVolume || 0;
    const passiveBuy = stats?.passiveBuyVolume || 0;
    const passiveSell = stats?.passiveSellVolume || 0;
    const total = activeBuy + activeSell + passiveBuy + passiveSell;
    
    return [
      { label: '主动买', value: activeBuy, type: 'active-buy', percentage: (activeBuy / total) * 100, color: '#ff4444' },
      { label: '主动卖', value: activeSell, type: 'active-sell', percentage: (activeSell / total) * 100, color: '#00cc00' },
      { label: '被动买', value: passiveBuy, type: 'passive-buy', percentage: (passiveBuy / total) * 100, color: '#ff8888' },
      { label: '被动卖', value: passiveSell, type: 'passive-sell', percentage: (passiveSell / total) * 100, color: '#44dd44' }
    ];
  };
  
  // 渲染饼图
  const renderPieChart = (data: any[]) => {
    let currentAngle = 0;
    const cx = 100;
    const cy = 100;
    const radius = 80;
    
    return (
      <>
        {data.map((item, idx) => {
          const startAngle = currentAngle;
          const endAngle = currentAngle + (item.percentage / 100) * 360;
          currentAngle = endAngle;
          
          const startAngleRad = (startAngle * Math.PI) / 180;
          const endAngleRad = (endAngle * Math.PI) / 180;
          
          const x1 = cx + radius * Math.cos(startAngleRad);
          const y1 = cy + radius * Math.sin(startAngleRad);
          const x2 = cx + radius * Math.cos(endAngleRad);
          const y2 = cy + radius * Math.sin(endAngleRad);
          
          const largeArcFlag = endAngle - startAngle > 180 ? 1 : 0;
          
          const pathData = [
            `M ${cx} ${cy}`,
            `L ${x1} ${y1}`,
            `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
            'Z'
          ].join(' ');
          
          return (
            <path
              key={idx}
              d={pathData}
              fill={item.color}
              stroke="rgba(255, 255, 255, 0.2)"
              strokeWidth="1"
              opacity="0.9"
            >
              <title>{item.label}: {item.percentage.toFixed(1)}%</title>
            </path>
          );
        })}
      </>
    );
  };

  // 渲染统计总结
  const renderStatsSummary = () => {
    if (!stats) return null;
    
    // 计算更多统计指标
    const buyCount = transactions.filter(t => t.type === 'buy').length;
    const sellCount = transactions.filter(t => t.type === 'sell').length;
    const neutralCount = transactions.filter(t => t.type === 'neutral').length;
    const netBuyVolume = stats.activeBuyVolume - stats.activeSellVolume;
    const netFlow = netBuyVolume > 0 ? '净流入' : '净流出';
    const transactionSpeed = stats.totalCount / (stats.duration / 60); // 每分钟成交笔数
    
    return (
      <div className="stats-summary">
        <div className="summary-header">
          <span className="summary-icon">📊</span>
          <span className="summary-title">深度统计分析</span>
          <span className="time-range">
            <span className="time-label">时段:</span> {stats.startTime} - {stats.endTime}
            <span className="duration">({Math.floor(stats.duration / 60)}分{stats.duration % 60}秒)</span>
          </span>
        </div>
        
        {/* 核心指标卡片 */}
        <div className="core-metrics">
          <div className="metric-card primary">
            <div className="metric-icon">💰</div>
            <div className="metric-content">
              <div className="metric-label">总成交额</div>
              <div className="metric-value">{formatAmount(stats.totalAmount)}</div>
              <div className="metric-detail">均价: ¥{stats.avgPrice.toFixed(2)}</div>
            </div>
          </div>
          
          <div className="metric-card">
            <div className="metric-icon">📈</div>
            <div className="metric-content">
              <div className="metric-label">价格变动</div>
              <div className={`metric-value ${stats.priceChangePercent > 0 ? 'positive' : 'negative'}`}>
                {stats.priceChangePercent > 0 ? '+' : ''}{stats.priceChangePercent.toFixed(2)}%
              </div>
              <div className="metric-detail">
                ¥{stats.startPrice.toFixed(2)} → ¥{stats.endPrice.toFixed(2)}
              </div>
            </div>
          </div>
        </div>
        
        {/* 详细分析网格 */}
        <div className="analysis-grid">
          {/* 成交分布 */}
          <div className="analysis-section">
            <div className="section-header">
              <span className="section-icon">📊</span>
              <span className="section-title">成交分布</span>
            </div>
            <div className="distribution-bars">
              <div className="dist-item">
                <div className="dist-label">买单</div>
                <div className="dist-bar-wrapper">
                  <div className="dist-bar buy" style={{ width: `${(buyCount / stats.totalCount) * 100}%` }}></div>
                </div>
                <div className="dist-values">
                  <span className="dist-count">{buyCount}笔</span>
                  <span className="dist-amount">{formatAmount(transactions.filter(t => t.type === 'buy').reduce((sum, t) => sum + t.amount, 0))}</span>
                </div>
              </div>
              <div className="dist-item">
                <div className="dist-label">卖单</div>
                <div className="dist-bar-wrapper">
                  <div className="dist-bar sell" style={{ width: `${(sellCount / stats.totalCount) * 100}%` }}></div>
                </div>
                <div className="dist-values">
                  <span className="dist-count">{sellCount}笔</span>
                  <span className="dist-amount">{formatAmount(transactions.filter(t => t.type === 'sell').reduce((sum, t) => sum + t.amount, 0))}</span>
                </div>
              </div>
              <div className="dist-item">
                <div className="dist-label">中性</div>
                <div className="dist-bar-wrapper">
                  <div className="dist-bar neutral" style={{ width: `${(neutralCount / stats.totalCount) * 100}%` }}></div>
                </div>
                <div className="dist-values">
                  <span className="dist-count">{neutralCount}笔</span>
                  <span className="dist-amount">{formatAmount(transactions.filter(t => t.type === 'neutral').reduce((sum, t) => sum + t.amount, 0))}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* 主动性分析 */}
          <div className="analysis-section">
            <div className="section-header">
              <span className="section-icon">🎯</span>
              <span className="section-title">主动性分析</span>
            </div>
            <div className="active-passive-detailed">
              <div className="ap-row">
                <span className="ap-label">主动买入:</span>
                <div className="ap-values">
                  <span className="ap-volume buy">{formatNumber(stats.activeBuyVolume)}</span>
                  <span className="ap-separator">|</span>
                  <span className="ap-amount buy">{formatAmount(stats.activeBuyVolume * stats.avgPrice)}</span>
                </div>
              </div>
              <div className="ap-row">
                <span className="ap-label">主动卖出:</span>
                <div className="ap-values">
                  <span className="ap-volume sell">{formatNumber(stats.activeSellVolume)}</span>
                  <span className="ap-separator">|</span>
                  <span className="ap-amount sell">{formatAmount(stats.activeSellVolume * stats.avgPrice)}</span>
                </div>
              </div>
              <div className="ap-row">
                <span className="ap-label">被动买入:</span>
                <div className="ap-values">
                  <span className="ap-volume passive-buy">{formatNumber(stats.passiveBuyVolume)}</span>
                  <span className="ap-separator">|</span>
                  <span className="ap-amount passive-buy">{formatAmount(stats.passiveBuyVolume * stats.avgPrice)}</span>
                </div>
              </div>
              <div className="ap-row">
                <span className="ap-label">被动卖出:</span>
                <div className="ap-values">
                  <span className="ap-volume passive-sell">{formatNumber(stats.passiveSellVolume)}</span>
                  <span className="ap-separator">|</span>
                  <span className="ap-amount passive-sell">{formatAmount(stats.passiveSellVolume * stats.avgPrice)}</span>
                </div>
              </div>
            </div>
            <div className="active-ratio-bar">
              <div className="ratio-bar active-buy" style={{ width: `${(stats.activeBuyVolume / stats.totalVolume) * 100}%` }}>
                主买{((stats.activeBuyVolume / stats.totalVolume) * 100).toFixed(1)}%
              </div>
              <div className="ratio-bar active-sell" style={{ width: `${(stats.activeSellVolume / stats.totalVolume) * 100}%` }}>
                主卖{((stats.activeSellVolume / stats.totalVolume) * 100).toFixed(1)}%
              </div>
              <div className="ratio-bar passive" style={{ width: `${((stats.passiveBuyVolume + stats.passiveSellVolume) / stats.totalVolume) * 100}%` }}>
                被动{(((stats.passiveBuyVolume + stats.passiveSellVolume) / stats.totalVolume) * 100).toFixed(1)}%
              </div>
            </div>
          </div>
          
          {/* 大单分析 */}
          <div className="analysis-section">
            <div className="section-header">
              <span className="section-icon">🐋</span>
              <span className="section-title">大单分析</span>
            </div>
            <div className="large-order-stats">
              <div className="lo-metric">
                <div className="lo-value">{stats.largeOrderCount}</div>
                <div className="lo-label">大单数量</div>
              </div>
              <div className="lo-metric">
                <div className="lo-value">{stats.largeOrderPercent.toFixed(1)}%</div>
                <div className="lo-label">占比</div>
              </div>
              <div className="lo-metric">
                <div className="lo-value">{formatAmount(stats.largeOrderAmount)}</div>
                <div className="lo-label">大单金额</div>
              </div>
            </div>
            <div className="order-size-distribution">
              <div className="size-bar large" style={{ width: `${stats.largeOrderPercent}%` }}>
                大单
              </div>
              <div className="size-bar medium" style={{ width: `${100 - stats.largeOrderPercent}%` }}>
                中小单
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!anomaly) return null;

  return (
    <div className="timeline-transaction-panel">
      <div className="panel-header">
        <div className="header-left">
          <span className="header-icon">⏱️</span>
          <span className="header-title">成交时间轴分析</span>
          <span className="header-badge">
            {anomaly.type === 'surge' ? '拉升' : '下跌'} {Math.abs(anomaly.changePercent).toFixed(2)}%
          </span>
        </div>
        <div className="header-right">
          <div className="view-switcher">
            <button 
              className={`view-btn ${viewMode === 'timeline' ? 'active' : ''}`}
              onClick={() => setViewMode('timeline')}
            >
              时间轴
            </button>
            <button 
              className={`view-btn ${viewMode === 'table' ? 'active' : ''}`}
              onClick={() => setViewMode('table')}
            >
              列表
            </button>
            <button 
              className={`view-btn ${viewMode === 'chart' ? 'active' : ''}`}
              onClick={() => setViewMode('chart')}
            >
              图表
            </button>
          </div>
          <button className="expand-btn" onClick={() => setExpanded(!expanded)}>
            {expanded ? '−' : '+'}
          </button>
          {onClose && (
            <button className="close-btn" onClick={onClose}>×</button>
          )}
        </div>
      </div>

      {expanded && (
        <>
          {loading ? (
            <div className="loading-state">加载成交明细中...</div>
          ) : (
            <>
              {viewMode === 'timeline' && renderTimeline()}
              {viewMode === 'chart' && renderCharts()}
              {viewMode !== 'table' && renderStatsSummary()}
            </>
          )}
        </>
      )}
      
      {selectedTransaction && (
        <div className="transaction-detail-popup">
          <div className="popup-header">
            <span>成交详情</span>
            <button onClick={() => setSelectedTransaction(null)}>×</button>
          </div>
          <div className="popup-content">
            <div className="detail-item">
              <span className="label">时间:</span>
              <span className="value">{selectedTransaction.time}</span>
            </div>
            <div className="detail-item">
              <span className="label">价格:</span>
              <span className="value">¥{selectedTransaction.price.toFixed(2)}</span>
            </div>
            <div className="detail-item">
              <span className="label">成交量:</span>
              <span className="value">{formatNumber(selectedTransaction.volume)}股</span>
            </div>
            <div className="detail-item">
              <span className="label">成交额:</span>
              <span className="value">{formatAmount(selectedTransaction.amount)}</span>
            </div>
            <div className="detail-item">
              <span className="label">性质:</span>
              <span className={`value ${selectedTransaction.type}`}>
                {selectedTransaction.isActive ? '主动' : '被动'}
                {selectedTransaction.type === 'buy' ? '买入' : selectedTransaction.type === 'sell' ? '卖出' : '中性'}
              </span>
            </div>
            <div className="detail-item">
              <span className="label">级别:</span>
              <span className={`value ${selectedTransaction.level}`}>
                {selectedTransaction.level === 'large' ? '大单' : selectedTransaction.level === 'medium' ? '中单' : '小单'}
              </span>
            </div>
            <div className="detail-item">
              <span className="label">价格影响:</span>
              <span className={`value ${selectedTransaction.priceImpact > 0 ? 'positive' : 'negative'}`}>
                {selectedTransaction.priceImpact > 0 ? '+' : ''}{selectedTransaction.priceImpact.toFixed(3)}%
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TimelineTransactionPanel;