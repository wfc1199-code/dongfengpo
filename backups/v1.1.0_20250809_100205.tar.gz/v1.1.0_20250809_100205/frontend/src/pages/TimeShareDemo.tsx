import React, { useState } from 'react';
import TimeShareChartFixed from '../components/TimeShareChartFixed';
import './TimeShareDemo.css';

const TimeShareDemo: React.FC = () => {
  const [stockCode, setStockCode] = useState('600519');
  const [inputCode, setInputCode] = useState('600519');
  const [showSupportResistance, setShowSupportResistance] = useState(true);

  const handleSearch = () => {
    if (inputCode.trim()) {
      setStockCode(inputCode.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // 热门股票列表
  const hotStocks = [
    { code: '600519', name: '贵州茅台' },
    { code: '000858', name: '五粮液' },
    { code: '000002', name: '万科A' },
    { code: '600036', name: '招商银行' },
    { code: '000001', name: '平安银行' },
    { code: '300750', name: '宁德时代' },
    { code: '002594', name: '比亚迪' },
    { code: '603259', name: '药明康德' }
  ];

  return (
    <div className="timeshare-demo-container">
      <div className="demo-header">
        <h1>分时图演示</h1>
        <div className="search-section">
          <input
            type="text"
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="输入股票代码"
            className="stock-input"
          />
          <button onClick={handleSearch} className="search-button">
            查询
          </button>
        </div>
      </div>

      <div className="hot-stocks-section">
        <h3>热门股票</h3>
        <div className="hot-stocks-grid">
          {hotStocks.map(stock => (
            <button
              key={stock.code}
              className={`hot-stock-item ${stockCode === stock.code ? 'active' : ''}`}
              onClick={() => {
                setStockCode(stock.code);
                setInputCode(stock.code);
              }}
            >
              <div className="stock-name">{stock.name}</div>
              <div className="stock-code">{stock.code}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="chart-controls">
        <label className="control-checkbox">
          <input
            type="checkbox"
            checked={showSupportResistance}
            onChange={(e) => setShowSupportResistance(e.target.checked)}
          />
          <span>显示专业支撑压力系统</span>
        </label>
      </div>

      <div className="chart-section">
        <TimeShareChartFixed
          stockCode={stockCode}
          height={500}
          showVolume={true}
          showMALine={true}
          showSupportResistance={showSupportResistance}
          refreshInterval={5000}
        />
      </div>

      <div className="features-section">
        <h3>功能特性</h3>
        <ul className="features-list">
          <li>实时分时数据展示</li>
          <li>分时价格走势图</li>
          <li>成交量柱状图</li>
          <li>均价线显示</li>
          <li>涨跌幅实时计算</li>
          <li>自动刷新（5秒间隔）</li>
          <li>交互式工具提示</li>
          <li>响应式设计</li>
          <li><strong>🎯 专业支撑压力系统</strong></li>
          <li>&nbsp;&nbsp;- 动态支撑压力识别</li>
          <li>&nbsp;&nbsp;- 成交量分布分析</li>
          <li>&nbsp;&nbsp;- S/A/B/C强度评级</li>
          <li>&nbsp;&nbsp;- 实时价格预警</li>
        </ul>
      </div>
    </div>
  );
};

export default TimeShareDemo;