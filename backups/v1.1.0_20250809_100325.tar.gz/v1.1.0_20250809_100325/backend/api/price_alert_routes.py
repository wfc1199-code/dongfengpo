"""
价格异动检测API路由
专门用于检测分时图中的急涨急跌
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Dict, List, Optional
from datetime import datetime, time
import numpy as np

from core.data_sources import StockDataManager

router = APIRouter()
data_manager = StockDataManager()

@router.get("/api/stocks/{stock_code}/price-alerts")
async def get_price_alerts(
    stock_code: str,
    surge_threshold: float = Query(default=1.0, description="拉升阈值(%)"),
    plunge_threshold: float = Query(default=-1.0, description="下跌阈值(%)"),
    time_window: int = Query(default=3, description="时间窗口(分钟)")
) -> Dict:
    """
    获取股票价格异动提示
    
    参数:
        stock_code: 股票代码
        surge_threshold: 拉升阈值，默认1%
        plunge_threshold: 下跌阈值，默认-1%
        time_window: 检测时间窗口，默认3分钟
    
    返回:
        异动提示列表
    """
    try:
        # 获取分时数据
        realtime_data = await data_manager.get_realtime_data([stock_code])
        
        if not realtime_data or stock_code not in realtime_data:
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的数据")
        
        stock_data = realtime_data[stock_code]
        
        # 分析价格异动
        alerts = analyze_price_movements(
            stock_data,
            surge_threshold,
            plunge_threshold,
            time_window
        )
        
        return {
            'stock_code': stock_code,
            'stock_name': stock_data.get('name', ''),
            'current_price': stock_data.get('current_price', 0),
            'alerts': alerts,
            'update_time': datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def analyze_price_movements(stock_data: Dict, surge_threshold: float, plunge_threshold: float, time_window: int) -> List[Dict]:
    """
    分析价格异动
    
    关键检测点:
    - 10:29-10:30 常见异动时间
    - 14:30-14:45 尾盘异动
    - 09:30-09:45 开盘异动
    """
    alerts = []
    
    if 'minute_data' not in stock_data or not stock_data['minute_data']:
        return alerts
    
    minute_data = stock_data['minute_data']
    
    # 关键时间点检测
    key_times = [
        ('10:29', '10:30', '盘中关键时刻'),
        ('14:30', '14:45', '尾盘时刻'),
        ('09:30', '09:45', '开盘时刻'),
        ('11:00', '11:10', '上午收盘前'),
        ('13:00', '13:10', '下午开盘')
    ]
    
    for i in range(len(minute_data)):
        current = minute_data[i]
        current_time = current.get('time', '')
        
        # 检查是否在关键时间点
        time_label = None
        for start, end, label in key_times:
            if start <= current_time <= end:
                time_label = label
                break
        
        # 计算不同时间窗口的变化
        changes = calculate_price_changes(minute_data, i, time_window)
        
        for window, change_pct, base_price in changes:
            # 检测急涨
            if change_pct >= surge_threshold:
                alerts.append({
                    'type': 'surge',
                    'time': current_time,
                    'price': current['price'],
                    'base_price': base_price,
                    'change_percent': change_pct,
                    'window_minutes': window,
                    'volume': current.get('volume', 0),
                    'message': f'{time_label or ""} {window}分钟急涨{change_pct:.2f}%',
                    'importance': get_alert_importance(change_pct, current_time, time_label)
                })
            
            # 检测急跌
            elif change_pct <= plunge_threshold:
                alerts.append({
                    'type': 'plunge',
                    'time': current_time,
                    'price': current['price'],
                    'base_price': base_price,
                    'change_percent': change_pct,
                    'window_minutes': window,
                    'volume': current.get('volume', 0),
                    'message': f'{time_label or ""} {window}分钟急跌{abs(change_pct):.2f}%',
                    'importance': get_alert_importance(change_pct, current_time, time_label)
                })
        
        # 成交量异常检测
        volume_alert = check_volume_anomaly(minute_data, i)
        if volume_alert:
            volume_alert['time'] = current_time
            volume_alert['price'] = current['price']
            if time_label:
                volume_alert['message'] = f"{time_label} {volume_alert['message']}"
            alerts.append(volume_alert)
    
    # 按重要性和时间排序
    alerts.sort(key=lambda x: (-x.get('importance', 0), x['time']), reverse=True)
    
    return alerts

def calculate_price_changes(minute_data: List, current_index: int, max_window: int) -> List:
    """
    计算不同时间窗口的价格变化
    返回: [(窗口分钟数, 变化百分比, 基准价格), ...]
    """
    changes = []
    current_price = minute_data[current_index]['price']
    
    # 检查1分钟、3分钟、5分钟变化
    windows = [1, 3, 5] if max_window >= 5 else [1, max_window]
    
    for window in windows:
        if current_index >= window:
            base_index = current_index - window
            base_price = minute_data[base_index]['price']
            if base_price > 0:
                change_pct = ((current_price - base_price) / base_price) * 100
                changes.append((window, change_pct, base_price))
    
    return changes

def check_volume_anomaly(minute_data: List, current_index: int) -> Optional[Dict]:
    """
    检查成交量异常
    """
    if current_index < 20:
        return None
    
    current = minute_data[current_index]
    current_volume = current.get('volume', 0)
    
    # 计算前20分钟平均成交量
    recent_volumes = [minute_data[i].get('volume', 0) for i in range(current_index - 20, current_index)]
    avg_volume = np.mean(recent_volumes) if recent_volumes else 0
    
    if avg_volume > 0 and current_volume > avg_volume * 3:
        volume_ratio = current_volume / avg_volume
        return {
            'type': 'volume_anomaly',
            'volume': current_volume,
            'avg_volume': avg_volume,
            'volume_ratio': volume_ratio,
            'message': f'成交量异常放大{volume_ratio:.1f}倍',
            'importance': min(volume_ratio / 3, 3)  # 重要性最高为3
        }
    
    return None

def get_alert_importance(change_pct: float, time_str: str, time_label: str = None) -> float:
    """
    计算异动重要性评分
    
    评分因素:
    1. 涨跌幅度
    2. 时间重要性
    3. 是否在关键时刻
    """
    importance = 0
    
    # 幅度评分 (最高3分)
    abs_change = abs(change_pct)
    if abs_change >= 3:
        importance += 3
    elif abs_change >= 2:
        importance += 2
    elif abs_change >= 1:
        importance += 1
    
    # 时间评分 (最高2分)
    if time_label:
        if '关键时刻' in time_label:
            importance += 2
        elif '尾盘' in time_label:
            importance += 1.5
        elif '开盘' in time_label:
            importance += 1
    
    # 特定时间点加分
    if '10:29' <= time_str <= '10:30':
        importance += 1  # 10:29是重要时间点
    elif '14:30' <= time_str <= '14:45':
        importance += 0.5  # 尾盘时间
    
    return importance

@router.get("/api/stocks/{stock_code}/realtime-monitor")
async def monitor_realtime_alerts(
    stock_code: str,
    target_time: str = Query(default=None, description="目标时间，如10:29")
) -> Dict:
    """
    实时监控特定时间的异动
    
    参数:
        stock_code: 股票代码
        target_time: 目标监控时间
    """
    try:
        # 获取实时数据
        realtime_data = await data_manager.get_realtime_data([stock_code])
        
        if not realtime_data or stock_code not in realtime_data:
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的数据")
        
        stock_data = realtime_data[stock_code]
        minute_data = stock_data.get('minute_data', [])
        
        # 查找目标时间的数据
        target_data = None
        if target_time and minute_data:
            for data in minute_data:
                if data.get('time', '') == target_time:
                    target_data = data
                    break
        
        # 如果找到目标时间数据，分析该时间点
        if target_data:
            # 找到该时间点在数组中的索引
            target_index = minute_data.index(target_data)
            
            # 计算该时间点的变化
            changes = calculate_price_changes(minute_data, target_index, 5)
            
            analysis = {
                'found': True,
                'time': target_time,
                'price': target_data['price'],
                'volume': target_data.get('volume', 0),
                'changes': [
                    {
                        'window': window,
                        'change_percent': change,
                        'base_price': base
                    } for window, change, base in changes
                ],
                'is_surge': any(change >= 1.0 for _, change, _ in changes),
                'is_plunge': any(change <= -1.0 for _, change, _ in changes)
            }
        else:
            analysis = {
                'found': False,
                'message': f'未找到时间 {target_time} 的数据'
            }
        
        return {
            'stock_code': stock_code,
            'stock_name': stock_data.get('name', ''),
            'target_time': target_time,
            'analysis': analysis,
            'current_time': datetime.now().strftime('%H:%M:%S')
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))