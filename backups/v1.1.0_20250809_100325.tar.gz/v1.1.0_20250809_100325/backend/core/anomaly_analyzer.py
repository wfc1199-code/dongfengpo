"""
异动深度分析器
通过成交量、大单、买卖力量等多维度分析判断主力意图
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

class MainForceIntent(Enum):
    """主力意图枚举"""
    ACCUMULATION = "吸筹"      # 主力吸筹
    WASHING = "洗盘"           # 主力洗盘
    SHIPPING = "出货"          # 主力出货
    PUMP = "拉升"             # 主力拉升
    SUPPRESS = "打压"         # 主力打压
    UNKNOWN = "未知"          # 意图不明

@dataclass
class AnomalyDetail:
    """异动详情"""
    time: str
    price: float
    change_percent: float
    volume: int
    volume_ratio: float        # 量比
    large_buy_volume: int      # 大单买入量
    large_sell_volume: int     # 大单卖出量
    buy_sell_ratio: float      # 买卖比
    avg_order_amount: float    # 平均单笔金额
    concentration: float       # 成交集中度
    
class DeepAnomalyAnalyzer:
    """异动深度分析器"""
    
    def __init__(self):
        self.large_order_threshold = 500000  # 大单阈值50万
        self.super_large_threshold = 2000000 # 超大单阈值200万
        
    def analyze_anomaly(self, 
                       anomaly_data: Dict,
                       historical_data: List[Dict],
                       order_flow: List[Dict] = None) -> Dict:
        """
        深度分析异动
        
        参数:
            anomaly_data: 异动时刻数据
            historical_data: 历史分时数据
            order_flow: 逐笔成交数据（可选）
            
        返回:
            深度分析结果
        """
        # 基础数据准备
        current_price = anomaly_data.get('price', 0)
        current_volume = anomaly_data.get('volume', 0)
        change_percent = anomaly_data.get('change_percent', 0)
        anomaly_time = anomaly_data.get('time', '')
        
        # 分析成交量特征
        volume_features = self._analyze_volume_features(
            anomaly_data, historical_data
        )
        
        # 分析价格行为
        price_behavior = self._analyze_price_behavior(
            anomaly_data, historical_data
        )
        
        # 分析大单情况
        large_order_analysis = self._analyze_large_orders(
            order_flow, current_price, anomaly_time
        ) if order_flow else {}
        
        # 判断主力意图
        intent, confidence = self._judge_main_force_intent(
            change_percent,
            volume_features,
            price_behavior,
            large_order_analysis
        )
        
        # 生成详细分析报告
        analysis_report = self._generate_analysis_report(
            intent,
            confidence,
            volume_features,
            price_behavior,
            large_order_analysis
        )
        
        return {
            'time': anomaly_time,
            'price': current_price,
            'change_percent': change_percent,
            'volume': current_volume,
            'intent': intent.value,
            'confidence': confidence,
            'volume_features': volume_features,
            'price_behavior': price_behavior,
            'large_orders': large_order_analysis,
            'analysis': analysis_report,
            'trading_suggestion': self._get_trading_suggestion(intent, confidence)
        }
    
    def _analyze_volume_features(self, current: Dict, historical: List[Dict]) -> Dict:
        """分析成交量特征"""
        features = {}
        
        # 计算量比
        if len(historical) >= 20:
            recent_volumes = [d.get('volume', 0) for d in historical[-20:]]
            avg_volume = np.mean(recent_volumes) if recent_volumes else 0
            volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1
            features['volume_ratio'] = volume_ratio
            
            # 判断量能类型
            if volume_ratio > 3:
                features['volume_type'] = '巨量'
            elif volume_ratio > 2:
                features['volume_type'] = '放量'
            elif volume_ratio < 0.5:
                features['volume_type'] = '缩量'
            else:
                features['volume_type'] = '正常'
        
        # 分析量能持续性
        if len(historical) >= 5:
            recent_5 = historical[-5:]
            continuous_heavy = all(
                d.get('volume', 0) > avg_volume * 1.5 for d in recent_5
            )
            features['continuous_heavy_volume'] = continuous_heavy
        
        # 分析量价配合
        price_up = current.get('change_percent', 0) > 0
        volume_up = current['volume'] > avg_volume if 'avg_volume' in locals() else False
        
        if price_up and volume_up:
            features['volume_price_match'] = '量价齐升'
        elif not price_up and volume_up:
            features['volume_price_match'] = '放量下跌'
        elif price_up and not volume_up:
            features['volume_price_match'] = '缩量上涨'
        else:
            features['volume_price_match'] = '缩量下跌'
        
        return features
    
    def _analyze_price_behavior(self, current: Dict, historical: List[Dict]) -> Dict:
        """分析价格行为特征"""
        behavior = {}
        
        if len(historical) < 10:
            return behavior
        
        prices = [d.get('price', 0) for d in historical]
        current_price = current.get('price', 0)
        
        # 分析涨跌速度
        if len(historical) >= 5:
            price_5min_ago = historical[-5].get('price', 0)
            if price_5min_ago > 0:
                speed_5min = ((current_price - price_5min_ago) / price_5min_ago) * 100
                behavior['speed_5min'] = speed_5min
                
                if abs(speed_5min) > 2:
                    behavior['speed_type'] = '急速' if speed_5min > 0 else '急跌'
                elif abs(speed_5min) > 1:
                    behavior['speed_type'] = '快速' if speed_5min > 0 else '快跌'
                else:
                    behavior['speed_type'] = '缓慢'
        
        # 分析是否突破
        recent_high = max(prices[-20:]) if len(prices) >= 20 else max(prices)
        recent_low = min(prices[-20:]) if len(prices) >= 20 else min(prices)
        
        if current_price > recent_high * 1.01:
            behavior['breakout'] = '向上突破'
        elif current_price < recent_low * 0.99:
            behavior['breakout'] = '向下突破'
        else:
            behavior['breakout'] = '区间震荡'
        
        # 分析拉升/下跌形态
        if len(historical) >= 3:
            last_3_prices = [d.get('price', 0) for d in historical[-3:]]
            
            # 检测直线拉升/砸盘
            price_changes = [
                (last_3_prices[i+1] - last_3_prices[i]) / last_3_prices[i] 
                for i in range(len(last_3_prices)-1) 
                if last_3_prices[i] > 0
            ]
            
            if all(c > 0.003 for c in price_changes):
                behavior['pattern'] = '直线拉升'
            elif all(c < -0.003 for c in price_changes):
                behavior['pattern'] = '直线砸盘'
            elif price_changes and price_changes[-1] * price_changes[0] < 0:
                behavior['pattern'] = '震荡'
            else:
                behavior['pattern'] = '趋势延续'
        
        return behavior
    
    def _analyze_large_orders(self, order_flow: List[Dict], 
                             current_price: float, 
                             target_time: str) -> Dict:
        """分析大单情况"""
        if not order_flow:
            return {}
        
        analysis = {
            'large_buy_count': 0,
            'large_sell_count': 0,
            'large_buy_amount': 0,
            'large_sell_amount': 0,
            'super_large_buy': 0,
            'super_large_sell': 0,
            'avg_order_size': 0,
            'order_concentration': 0,
            # 新增：分区间统计
            'range_distribution': {
                '100-200万': {'count': 0, 'amount': 0},
                '200-300万': {'count': 0, 'amount': 0},
                '300-500万': {'count': 0, 'amount': 0},
                '500-1000万': {'count': 0, 'amount': 0},
                '1000万以上': {'count': 0, 'amount': 0}
            },
            # 新增：连续大单检测
            'continuous_orders': []
        }
        
        total_amount = 0
        order_amounts = []
        # 用于检测连续大单
        last_large_orders = []
        
        for i, order in enumerate(order_flow):
            amount = order.get('amount', 0)
            order_type = order.get('type', '')
            
            total_amount += amount
            order_amounts.append(amount)
            
            # 统计大单
            if amount >= self.large_order_threshold:
                if order_type == 'buy':
                    analysis['large_buy_count'] += 1
                    analysis['large_buy_amount'] += amount
                else:
                    analysis['large_sell_count'] += 1
                    analysis['large_sell_amount'] += amount
                
                # 分区间统计
                if 1000000 <= amount < 2000000:
                    analysis['range_distribution']['100-200万']['count'] += 1
                    analysis['range_distribution']['100-200万']['amount'] += amount
                elif 2000000 <= amount < 3000000:
                    analysis['range_distribution']['200-300万']['count'] += 1
                    analysis['range_distribution']['200-300万']['amount'] += amount
                elif 3000000 <= amount < 5000000:
                    analysis['range_distribution']['300-500万']['count'] += 1
                    analysis['range_distribution']['300-500万']['amount'] += amount
                elif 5000000 <= amount < 10000000:
                    analysis['range_distribution']['500-1000万']['count'] += 1
                    analysis['range_distribution']['500-1000万']['amount'] += amount
                elif amount >= 10000000:
                    analysis['range_distribution']['1000万以上']['count'] += 1
                    analysis['range_distribution']['1000万以上']['amount'] += amount
                
                # 记录大单用于连续检测
                last_large_orders.append({
                    'index': i,
                    'amount': amount,
                    'type': order_type,
                    'time': order.get('time', '')
                })
            
            # 统计超大单
            if amount >= self.super_large_threshold:
                if order_type == 'buy':
                    analysis['super_large_buy'] += 1
                else:
                    analysis['super_large_sell'] += 1
        
        # 检测连续大单
        if len(last_large_orders) >= 3:
            for i in range(len(last_large_orders) - 2):
                # 检查是否连续（索引差小于等于3表示中间最多间隔2笔）
                if (last_large_orders[i+2]['index'] - last_large_orders[i]['index']) <= 4:
                    # 检查金额是否相近（误差在30%以内）
                    amounts = [last_large_orders[i+j]['amount'] for j in range(3)]
                    avg_amount = np.mean(amounts)
                    if all(abs(a - avg_amount) / avg_amount < 0.3 for a in amounts):
                        # 检查是否同向
                        types = [last_large_orders[i+j]['type'] for j in range(3)]
                        if len(set(types)) == 1:
                            analysis['continuous_orders'].append({
                                'count': 3,
                                'avg_amount': round(avg_amount, 2),
                                'total_amount': round(sum(amounts), 2),
                                'type': types[0],
                                'start_time': last_large_orders[i]['time'],
                                'end_time': last_large_orders[i+2]['time']
                            })
        
        # 计算平均单笔金额
        if order_amounts:
            analysis['avg_order_size'] = np.mean(order_amounts)
            
            # 计算集中度（大单占比）
            large_orders_amount = (
                analysis['large_buy_amount'] + analysis['large_sell_amount']
            )
            analysis['order_concentration'] = (
                large_orders_amount / total_amount if total_amount > 0 else 0
            )
        
        # 判断大单性质
        buy_sell_diff = analysis['large_buy_amount'] - analysis['large_sell_amount']
        if buy_sell_diff > 1000000:
            analysis['large_order_nature'] = '大单净买入'
        elif buy_sell_diff < -1000000:
            analysis['large_order_nature'] = '大单净卖出'
        else:
            analysis['large_order_nature'] = '大单平衡'
        
        return analysis
    
    def _judge_main_force_intent(self, 
                                change_percent: float,
                                volume_features: Dict,
                                price_behavior: Dict,
                                large_orders: Dict) -> Tuple[MainForceIntent, float]:
        """判断主力意图"""
        
        # 评分系统
        washing_score = 0     # 洗盘分数
        shipping_score = 0    # 出货分数
        pump_score = 0        # 拉升分数
        accumulation_score = 0 # 吸筹分数
        
        # 1. 基于量价关系判断
        volume_type = volume_features.get('volume_type', '')
        volume_price = volume_features.get('volume_price_match', '')
        
        if volume_price == '放量下跌':
            if volume_type == '巨量':
                shipping_score += 3
            else:
                washing_score += 2
        elif volume_price == '缩量下跌':
            washing_score += 3
        elif volume_price == '量价齐升':
            if volume_type == '巨量':
                pump_score += 3
            else:
                accumulation_score += 2
        elif volume_price == '缩量上涨':
            accumulation_score += 2
        
        # 2. 基于价格行为判断
        speed_type = price_behavior.get('speed_type', '')
        pattern = price_behavior.get('pattern', '')
        breakout = price_behavior.get('breakout', '')
        
        if pattern == '直线拉升':
            pump_score += 3
        elif pattern == '直线砸盘':
            if volume_type == '巨量':
                shipping_score += 3
            else:
                washing_score += 2
        
        if breakout == '向上突破' and volume_type in ['放量', '巨量']:
            pump_score += 2
        elif breakout == '向下突破' and volume_type == '巨量':
            shipping_score += 2
        
        # 3. 基于大单分析判断
        if large_orders:
            large_order_nature = large_orders.get('large_order_nature', '')
            concentration = large_orders.get('order_concentration', 0)
            
            if large_order_nature == '大单净买入':
                if concentration > 0.3:
                    pump_score += 3
                else:
                    accumulation_score += 2
            elif large_order_nature == '大单净卖出':
                if concentration > 0.3:
                    shipping_score += 3
                else:
                    washing_score += 1
            
            # 超大单判断
            if large_orders.get('super_large_buy', 0) > 2:
                pump_score += 2
            if large_orders.get('super_large_sell', 0) > 2:
                shipping_score += 2
        
        # 4. 综合判断
        scores = {
            MainForceIntent.WASHING: washing_score,
            MainForceIntent.SHIPPING: shipping_score,
            MainForceIntent.PUMP: pump_score,
            MainForceIntent.ACCUMULATION: accumulation_score
        }
        
        # 找出最高分
        max_score = max(scores.values())
        if max_score == 0:
            return MainForceIntent.UNKNOWN, 0.0
        
        # 获取最高分对应的意图
        intent = max(scores.items(), key=lambda x: x[1])[0]
        
        # 计算置信度
        total_score = sum(scores.values())
        confidence = max_score / total_score if total_score > 0 else 0
        
        # 如果是下跌但判断为洗盘，需要额外验证
        if change_percent < -1.5 and intent == MainForceIntent.WASHING:
            # 洗盘特征：缩量、有支撑、非恐慌
            if volume_type != '缩量' or not self._has_support(price_behavior):
                intent = MainForceIntent.SHIPPING
                confidence *= 0.8
        
        return intent, confidence
    
    def _has_support(self, price_behavior: Dict) -> bool:
        """判断是否有支撑"""
        # 简化判断：没有连续突破低点
        return price_behavior.get('breakout', '') != '向下突破'
    
    def _generate_analysis_report(self,
                                 intent: MainForceIntent,
                                 confidence: float,
                                 volume_features: Dict,
                                 price_behavior: Dict,
                                 large_orders: Dict) -> str:
        """生成分析报告"""
        
        report_lines = []
        
        # 主力意图判断
        report_lines.append(f"【主力意图】{intent.value} (置信度: {confidence*100:.1f}%)")
        
        # 量价分析
        report_lines.append(f"\n【量价分析】")
        report_lines.append(f"- 成交量: {volume_features.get('volume_type', '正常')}")
        report_lines.append(f"- 量比: {volume_features.get('volume_ratio', 1):.2f}")
        report_lines.append(f"- 量价关系: {volume_features.get('volume_price_match', '')}")
        
        # 价格行为
        report_lines.append(f"\n【价格行为】")
        report_lines.append(f"- 走势形态: {price_behavior.get('pattern', '震荡')}")
        report_lines.append(f"- 速度类型: {price_behavior.get('speed_type', '正常')}")
        report_lines.append(f"- 技术位置: {price_behavior.get('breakout', '区间内')}")
        
        # 大单分析
        if large_orders:
            report_lines.append(f"\n【大单分析】")
            report_lines.append(f"- 大单性质: {large_orders.get('large_order_nature', '平衡')}")
            report_lines.append(f"- 大买单: {large_orders.get('large_buy_count', 0)}笔")
            report_lines.append(f"- 大卖单: {large_orders.get('large_sell_count', 0)}笔")
            report_lines.append(f"- 成交集中度: {large_orders.get('order_concentration', 0)*100:.1f}%")
            
            # 分区间统计
            if 'range_distribution' in large_orders:
                report_lines.append(f"\n【大单区间分布】")
                for range_name, data in large_orders['range_distribution'].items():
                    if data['count'] > 0:
                        report_lines.append(f"- {range_name}: {data['count']}笔, {data['amount']/10000:.1f}万元")
            
            # 连续大单
            if 'continuous_orders' in large_orders and large_orders['continuous_orders']:
                report_lines.append(f"\n【连续大单】")
                for cont_order in large_orders['continuous_orders'][:3]:  # 只显示前3组
                    report_lines.append(f"- 连续{cont_order['count']}笔{cont_order['type']}单, "
                                      f"均价{cont_order['avg_amount']/10000:.1f}万元")
        
        # 特征解读
        report_lines.append(f"\n【特征解读】")
        if intent == MainForceIntent.WASHING:
            report_lines.append("✓ 缩量下跌或快速杀跌后回升")
            report_lines.append("✓ 在支撑位获得支撑")
            report_lines.append("✓ 大单卖出但有承接")
        elif intent == MainForceIntent.SHIPPING:
            report_lines.append("⚠ 放量下跌，抛压沉重")
            report_lines.append("⚠ 大单持续卖出")
            report_lines.append("⚠ 跌破重要支撑")
        elif intent == MainForceIntent.PUMP:
            report_lines.append("↑ 放量上攻")
            report_lines.append("↑ 大单持续买入")
            report_lines.append("↑ 突破压力位")
        elif intent == MainForceIntent.ACCUMULATION:
            report_lines.append("→ 温和放量或缩量")
            report_lines.append("→ 逢低有大单承接")
            report_lines.append("→ 底部区域震荡")
        
        return '\n'.join(report_lines)
    
    def _get_trading_suggestion(self, intent: MainForceIntent, confidence: float) -> Dict:
        """获取交易建议"""
        
        suggestions = {
            MainForceIntent.WASHING: {
                'action': '持有或逢低加仓',
                'reason': '主力洗盘，清洗浮筹',
                'risk': '中等',
                'strategy': '等待洗盘结束，关注量能变化'
            },
            MainForceIntent.SHIPPING: {
                'action': '减仓或离场',
                'reason': '主力出货，风险较高',
                'risk': '高',
                'strategy': '逢高减仓，避免追高'
            },
            MainForceIntent.PUMP: {
                'action': '持有或适量跟进',
                'reason': '主力拉升，趋势向上',
                'risk': '中等',
                'strategy': '持股待涨，注意量能持续性'
            },
            MainForceIntent.ACCUMULATION: {
                'action': '逢低建仓',
                'reason': '主力吸筹，底部区域',
                'risk': '低',
                'strategy': '分批建仓，耐心持有'
            },
            MainForceIntent.UNKNOWN: {
                'action': '观望',
                'reason': '意图不明，需要观察',
                'risk': '未知',
                'strategy': '等待明确信号'
            }
        }
        
        suggestion = suggestions.get(intent, suggestions[MainForceIntent.UNKNOWN])
        suggestion['confidence'] = confidence
        
        return suggestion
    
    def generate_simulated_anomaly_data(self, stock_code: str, stock_name: str, 
                                       base_price: float = None) -> Dict:
        """生成模拟的异动分析数据"""
        import random
        from datetime import datetime, timedelta
        
        if base_price is None:
            base_price = 10.0 + random.random() * 50
        
        # 随机生成异动类型
        anomaly_types = [
            ('强势拉升', 3.5, 8.0),
            ('快速下跌', -6.0, -3.0),
            ('放量突破', 2.0, 5.0),
            ('温和异动', 1.5, 3.0),
            ('震荡上行', 0.5, 2.5),
            ('主力吸筹', -1.0, 1.5),
            ('洗盘回调', -2.5, -0.5)
        ]
        
        anomaly_type, min_change, max_change = random.choice(anomaly_types)
        change_percent = random.uniform(min_change, max_change)
        current_price = base_price * (1 + change_percent / 100)
        
        # 生成成交量数据
        volume = random.randint(1000000, 50000000)
        amount = current_price * volume
        
        # 生成量比
        volume_ratio = random.uniform(0.5, 5.0)
        if abs(change_percent) > 3:
            volume_ratio = random.uniform(2.0, 8.0)  # 大幅变动时量比更高
        
        # 生成大单数据
        large_buy_count = random.randint(10, 100)
        large_sell_count = random.randint(10, 100)
        large_buy_amount = large_buy_count * random.uniform(1000000, 5000000)
        large_sell_amount = large_sell_count * random.uniform(1000000, 5000000)
        
        # 根据涨跌调整买卖比例
        if change_percent > 0:
            large_buy_amount *= random.uniform(1.2, 2.0)
            buy_sell_ratio = random.uniform(1.2, 3.0)
        else:
            large_sell_amount *= random.uniform(1.2, 2.0)
            buy_sell_ratio = random.uniform(0.3, 0.8)
        
        # 判断主力意图
        if change_percent > 3 and volume_ratio > 3:
            intent = MainForceIntent.PUMP
            confidence = random.uniform(0.7, 0.95)
        elif change_percent < -3 and volume_ratio > 3:
            intent = MainForceIntent.SHIPPING
            confidence = random.uniform(0.6, 0.85)
        elif abs(change_percent) < 2 and volume_ratio < 1:
            intent = MainForceIntent.ACCUMULATION
            confidence = random.uniform(0.5, 0.75)
        elif change_percent < -1 and volume_ratio < 1.5:
            intent = MainForceIntent.WASHING
            confidence = random.uniform(0.6, 0.8)
        else:
            intent = MainForceIntent.UNKNOWN
            confidence = random.uniform(0.3, 0.5)
        
        # 生成时间
        current_time = datetime.now()
        anomaly_time = current_time - timedelta(minutes=random.randint(0, 30))
        
        # 生成分析报告
        analysis_report = f"""【主力意图】{intent.value} (置信度: {confidence*100:.1f}%)

【量价分析】
- 成交量: {'放量' if volume_ratio > 2 else '缩量' if volume_ratio < 0.5 else '正常'}
- 量比: {volume_ratio:.2f}
- 量价关系: {'量价齐升' if change_percent > 0 and volume_ratio > 1 else '放量下跌' if change_percent < 0 and volume_ratio > 1 else '缩量调整'}

【价格行为】
- 走势形态: {anomaly_type}
- 涨跌幅: {change_percent:.2f}%
- 现价: {current_price:.2f}

【大单分析】
- 大单买入: {large_buy_count}笔, {large_buy_amount/10000:.1f}万元
- 大单卖出: {large_sell_count}笔, {large_sell_amount/10000:.1f}万元
- 买卖比: {buy_sell_ratio:.2f}
"""
        
        return {
            'stock_code': stock_code,
            'stock_name': stock_name,
            'time': anomaly_time.strftime('%Y-%m-%d %H:%M:%S'),
            'display_time': anomaly_time.strftime('%H:%M:%S'),
            'price': round(current_price, 2),
            'change_percent': round(change_percent, 2),
            'volume': volume,
            'amount': round(amount, 2),
            'anomaly_type': anomaly_type,
            'intent': intent.value,
            'confidence': round(confidence, 2),
            'volume_features': {
                'volume_ratio': round(volume_ratio, 2),
                'volume_type': '放量' if volume_ratio > 2 else '缩量' if volume_ratio < 0.5 else '正常'
            },
            'price_behavior': {
                'pattern': anomaly_type,
                'speed_type': '急速' if abs(change_percent) > 5 else '快速' if abs(change_percent) > 3 else '温和'
            },
            'large_orders': {
                'large_buy_count': large_buy_count,
                'large_sell_count': large_sell_count,
                'large_buy_amount': round(large_buy_amount, 2),
                'large_sell_amount': round(large_sell_amount, 2),
                'buy_sell_ratio': round(buy_sell_ratio, 2)
            },
            'analysis': analysis_report,
            'trading_suggestion': self._get_trading_suggestion(intent, confidence),
            # 用于前端显示
            'strength_score': min(100, int(abs(change_percent) * 10 + volume_ratio * 10)),
            'reasons': [
                f"涨幅{change_percent:.1f}%",
                f"量比{volume_ratio:.1f}",
                f"大单净{'买' if buy_sell_ratio > 1 else '卖'}入"
            ]
        }