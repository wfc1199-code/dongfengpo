"""
配置管理模块
统一管理应用配置，支持环境变量和默认值
"""

import os
import json
from typing import List, Optional
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import validator


class Settings(BaseSettings):
    """应用配置类"""
    
    # API配置
    api_host: str = "0.0.0.0"
    api_port: int = 9000
    
    # CORS配置
    cors_origins: List[str] = ["http://localhost:3000"]
    cors_allow_credentials: bool = True
    cors_allow_methods: List[str] = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    cors_allow_headers: List[str] = ["*"]
    
    # 数据源配置
    enable_cache: bool = True
    cache_ttl: int = 300  # 缓存过期时间（秒）
    
    # 监控配置
    monitoring_interval: int = 15  # 监控间隔（秒）
    max_monitoring_stocks: int = 100  # 最大监控股票数
    anomaly_threshold: float = 0.5  # 异动阈值
    volume_threshold: float = 2.0  # 成交量阈值
    
    # 日志配置
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    # 数据目录
    data_dir: Path = Path("data")
    
    @validator("cors_origins", pre=True)
    def parse_cors_origins(cls, v):
        """解析CORS源配置"""
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return [v]
        return v
    
    @validator("data_dir")
    def ensure_data_dir(cls, v):
        """确保数据目录存在"""
        v.mkdir(exist_ok=True, parents=True)
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# 创建全局配置实例
settings = Settings()


def get_config_path() -> Path:
    """获取配置文件路径"""
    return settings.data_dir / "config.json"


def load_user_config() -> dict:
    """加载用户配置"""
    config_path = get_config_path()
    if config_path.exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "user_customization": {
            "自定义监控": {
                "自选股票池": []
            }
        }
    }


def save_user_config(config: dict) -> None:
    """保存用户配置"""
    config_path = get_config_path()
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)