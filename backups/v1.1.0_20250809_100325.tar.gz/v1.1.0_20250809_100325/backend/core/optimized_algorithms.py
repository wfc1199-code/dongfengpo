"""
优化算法模块 - 高性能异动检测算法
使用NumPy向量化计算和并行处理
"""

import numpy as np
import asyncio
import time
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import multiprocessing as mp
import logging

logger = logging.getLogger(__name__)

try:
    from numba import jit, prange
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    logger.warning("Numba不可用，将使用标准NumPy计算")
    
    # 定义空装饰器
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    
    def prange(x):
        return range(x)


class OptimizedSpeedCalculator:
    """优化的涨速计算器"""
    
    @staticmethod
    @jit(nopython=True if NUMBA_AVAILABLE else False)
    def calculate_speed_vectorized(prices: np.ndarray, timestamps: np.ndarray) -> float:
        """向量化涨速计算"""
        if len(prices) < 2:
            return 0.0
        
        n = len(prices)
        if n < 2:
            return 0.0
        
        # 转换时间戳为分钟差
        x = (timestamps - timestamps[0]) / 60.0  # 转为分钟
        y = prices
        
        # 向量化线性回归
        sum_x = np.sum(x)
        sum_y = np.sum(y)
        sum_xy = np.sum(x * y)
        sum_x2 = np.sum(x * x)
        
        denominator = n * sum_x2 - sum_x * sum_x
        if abs(denominator) < 1e-10:
            return 0.0
        
        slope = (n * sum_xy - sum_x * sum_y) / denominator
        return slope
    
    @staticmethod
    @jit(nopython=True if NUMBA_AVAILABLE else False)
    def batch_calculate_speeds(price_matrix: np.ndarray, timestamp_matrix: np.ndarray) -> np.ndarray:
        """批量计算多只股票的涨速"""
        num_stocks = price_matrix.shape[0]
        speeds = np.zeros(num_stocks)
        
        for i in prange(num_stocks):
            prices = price_matrix[i]
            timestamps = timestamp_matrix[i]
            
            # 过滤有效数据
            valid_mask = ~np.isnan(prices)
            if np.sum(valid_mask) >= 2:
                valid_prices = prices[valid_mask]
                valid_timestamps = timestamps[valid_mask]
                speeds[i] = OptimizedSpeedCalculator.calculate_speed_vectorized(
                    valid_prices, valid_timestamps)
        
        return speeds


class VectorizedAnomalyDetector:
    """向量化异动检测器"""
    
    def __init__(self, config: Dict):
        self.speed_threshold = config.get('speed_threshold', 0.5)
        self.volume_ratio_threshold = config.get('volume_ratio_threshold', 2.0)
        self.batch_size = config.get('batch_size', 100)
        
        # 预分配数组以提高性能
        self.max_stocks = config.get('max_stocks', 5000)
        self.max_data_points = config.get('max_data_points', 100)
        
        # 预分配内存
        self._price_buffer = np.zeros((self.max_stocks, self.max_data_points))
        self._timestamp_buffer = np.zeros((self.max_stocks, self.max_data_points))
        self._volume_buffer = np.zeros((self.max_stocks, self.max_data_points))
    
    def prepare_batch_data(self, stock_data_list: List[Dict]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """准备批量处理数据"""
        num_stocks = min(len(stock_data_list), self.max_stocks)
        
        # 重置缓冲区
        self._price_buffer.fill(np.nan)
        self._timestamp_buffer.fill(np.nan)
        self._volume_buffer.fill(np.nan)
        
        for i, stock_data in enumerate(stock_data_list[:num_stocks]):
            tick_data = stock_data.get('tick_data', [])
            data_len = min(len(tick_data), self.max_data_points)
            
            if data_len > 0:
                # 提取价格、时间戳、成交量
                prices = np.array([tick.get('price', 0) for tick in tick_data[:data_len]])
                timestamps = np.array([
                    time.mktime(datetime.fromisoformat(
                        tick.get('timestamp', '') or datetime.now().isoformat()
                    ).timetuple()) for tick in tick_data[:data_len]
                ])
                volumes = np.array([tick.get('volume', 0) for tick in tick_data[:data_len]])
                
                self._price_buffer[i, :data_len] = prices
                self._timestamp_buffer[i, :data_len] = timestamps
                self._volume_buffer[i, :data_len] = volumes
        
        return (
            self._price_buffer[:num_stocks],
            self._timestamp_buffer[:num_stocks],
            self._volume_buffer[:num_stocks]
        )
    
    def detect_batch_anomalies(self, stock_data_list: List[Dict]) -> List[Dict]:
        """批量检测异动"""
        if not stock_data_list:
            return []
        
        # 准备数据
        price_matrix, timestamp_matrix, volume_matrix = self.prepare_batch_data(stock_data_list)
        
        # 批量计算涨速
        speeds = OptimizedSpeedCalculator.batch_calculate_speeds(price_matrix, timestamp_matrix)
        
        # 批量检测异动
        results = []
        for i, stock_data in enumerate(stock_data_list[:len(speeds)]):
            speed = speeds[i]
            stock_code = stock_data.get('code', '')
            
            # 判断是否异动
            is_anomaly = speed > self.speed_threshold
            
            # 计算置信度
            confidence = min(0.9, speed / self.speed_threshold * 0.3) if is_anomaly else 0.0
            
            result = {
                'code': stock_code,
                'speed': float(speed),
                'is_anomaly': is_anomaly,
                'confidence': confidence,
                'timestamp': datetime.now().isoformat()
            }
            
            results.append(result)
        
        return results


class ParallelStockAnalyzer:
    """并行股票分析器"""
    
    def __init__(self, max_workers: Optional[int] = None):
        self.max_workers = max_workers or min(mp.cpu_count(), 8)
        self.thread_executor = ThreadPoolExecutor(max_workers=self.max_workers)
        self.process_executor = ProcessPoolExecutor(max_workers=self.max_workers)
        self.detector = VectorizedAnomalyDetector({})
    
    async def analyze_stocks_parallel(self, stock_data_list: List[Dict]) -> List[Dict]:
        """并行分析股票"""
        if not stock_data_list:
            return []
        
        # 分批处理
        batch_size = 50
        batches = [
            stock_data_list[i:i + batch_size] 
            for i in range(0, len(stock_data_list), batch_size)
        ]
        
        # 并行处理批次
        loop = asyncio.get_event_loop()
        tasks = []
        
        for batch in batches:
            task = loop.run_in_executor(
                self.thread_executor,
                self._analyze_batch,
                batch
            )
            tasks.append(task)
        
        # 等待所有任务完成
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 合并结果
        all_results = []
        for result in batch_results:
            if isinstance(result, Exception):
                logger.error(f"批次处理失败: {result}")
                continue
            all_results.extend(result)
        
        return all_results
    
    def _analyze_batch(self, batch: List[Dict]) -> List[Dict]:
        """分析单个批次"""
        try:
            return self.detector.detect_batch_anomalies(batch)
        except Exception as e:
            logger.error(f"批次分析失败: {e}")
            return []
    
    async def cleanup(self):
        """清理资源"""
        self.thread_executor.shutdown(wait=True)
        self.process_executor.shutdown(wait=True)


class PerformanceMonitor:
    """性能监控器"""
    
    def __init__(self):
        self.metrics = {
            'total_requests': 0,
            'total_time': 0.0,
            'avg_response_time': 0.0,
            'max_response_time': 0.0,
            'min_response_time': 0.0,
            'error_count': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }
        self.start_time = time.time()
    
    def record_request(self, response_time: float, is_error: bool = False, cache_hit: bool = False):
        """记录请求指标"""
        self.metrics['total_requests'] += 1
        self.metrics['total_time'] += response_time
        
        if is_error:
            self.metrics['error_count'] += 1
        
        if cache_hit:
            self.metrics['cache_hits'] += 1
        else:
            self.metrics['cache_misses'] += 1
        
        # 更新响应时间统计
        self.metrics['max_response_time'] = max(self.metrics['max_response_time'], response_time)
        if self.metrics['min_response_time'] == 0.0 or response_time < self.metrics['min_response_time']:
            self.metrics['min_response_time'] = response_time
        self.metrics['avg_response_time'] = self.metrics['total_time'] / self.metrics['total_requests']
    
    def get_metrics(self) -> Dict[str, Any]:
        """获取性能指标"""
        uptime = time.time() - self.start_time
        total_requests = self.metrics['total_requests']
        
        return {
            **self.metrics,
            'uptime_seconds': uptime,
            'requests_per_second': total_requests / uptime if uptime > 0 else 0,
            'error_rate': self.metrics['error_count'] / total_requests if total_requests > 0 else 0,
            'cache_hit_rate': self.metrics['cache_hits'] / total_requests if total_requests > 0 else 0
        }
    
    def reset_metrics(self):
        """重置指标"""
        self.metrics = {
            'total_requests': 0,
            'total_time': 0.0,
            'avg_response_time': 0.0,
            'max_response_time': 0.0,
            'min_response_time': 0.0,
            'error_count': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }
        self.start_time = time.time()


def performance_monitor(monitor: PerformanceMonitor):
    """性能监控装饰器"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            is_error = False
            cache_hit = False
            
            try:
                result = await func(*args, **kwargs)
                # 检查是否是缓存命中（简单判断）
                if hasattr(result, '__dict__') and getattr(result, '_from_cache', False):
                    cache_hit = True
                return result
            except Exception as e:
                is_error = True
                raise
            finally:
                response_time = time.time() - start_time
                monitor.record_request(response_time, is_error, cache_hit)
        
        return wrapper
    return decorator


# 全局实例
parallel_analyzer = ParallelStockAnalyzer()
performance_monitor_instance = PerformanceMonitor()
