"""
安全模块 - 认证、授权、限流和输入验证
"""

import jwt
import time
import hashlib
import secrets
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from functools import wraps
import re
import logging
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

try:
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded
    SLOWAPI_AVAILABLE = True
except ImportError:
    SLOWAPI_AVAILABLE = False
    logger.warning("SlowAPI不可用，使用内置限流")


class SecurityConfig:
    """安全配置"""
    
    # JWT配置
    JWT_SECRET_KEY = "your-secret-key-change-in-production"
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRATION_HOURS = 24
    
    # 限流配置
    DEFAULT_RATE_LIMIT = "100/minute"
    API_RATE_LIMIT = "1000/hour"
    
    # 密码策略
    MIN_PASSWORD_LENGTH = 8
    REQUIRE_SPECIAL_CHARS = True
    
    # IP白名单（可选）
    ALLOWED_IPS = []  # 空列表表示允许所有IP


class TokenManager:
    """JWT令牌管理器"""
    
    def __init__(self, config: SecurityConfig = None):
        self.config = config or SecurityConfig()
        self.revoked_tokens = set()  # 已撤销的令牌
    
    def generate_token(self, user_id: str, permissions: List[str] = None) -> str:
        """生成JWT令牌"""
        now = datetime.utcnow()
        payload = {
            'user_id': user_id,
            'permissions': permissions or [],
            'iat': now,
            'exp': now + timedelta(hours=self.config.JWT_EXPIRATION_HOURS),
            'jti': secrets.token_hex(16)  # JWT ID，用于撤销
        }
        
        token = jwt.encode(payload, self.config.JWT_SECRET_KEY, algorithm=self.config.JWT_ALGORITHM)
        return token
    
    def verify_token(self, token: str) -> Optional[Dict]:
        """验证JWT令牌"""
        try:
            # 检查是否已撤销
            if token in self.revoked_tokens:
                return None
            
            payload = jwt.decode(
                token, 
                self.config.JWT_SECRET_KEY, 
                algorithms=[self.config.JWT_ALGORITHM]
            )
            
            return payload
            
        except jwt.ExpiredSignatureError:
            logger.warning("令牌已过期")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f"无效令牌: {e}")
            return None
    
    def revoke_token(self, token: str):
        """撤销令牌"""
        self.revoked_tokens.add(token)
    
    def cleanup_revoked_tokens(self):
        """清理过期的撤销令牌"""
        # 这里可以实现更复杂的清理逻辑
        # 例如，只保留最近24小时的撤销令牌
        pass


class RateLimiter:
    """内置限流器"""
    
    def __init__(self):
        self.requests = defaultdict(lambda: deque())
        self.blocked_ips = defaultdict(float)  # IP -> 解封时间
    
    def is_allowed(self, identifier: str, limit: str) -> bool:
        """检查是否允许请求"""
        # 解析限制格式 "100/minute"
        count, period = limit.split('/')
        count = int(count)
        
        period_seconds = {
            'second': 1,
            'minute': 60,
            'hour': 3600,
            'day': 86400
        }.get(period, 60)
        
        now = time.time()
        
        # 检查是否被封禁
        if identifier in self.blocked_ips:
            if now < self.blocked_ips[identifier]:
                return False
            else:
                del self.blocked_ips[identifier]
        
        # 清理过期请求
        request_times = self.requests[identifier]
        while request_times and now - request_times[0] > period_seconds:
            request_times.popleft()
        
        # 检查是否超过限制
        if len(request_times) >= count:
            # 临时封禁（可选）
            self.blocked_ips[identifier] = now + period_seconds
            return False
        
        # 记录请求
        request_times.append(now)
        return True


class InputValidator:
    """输入验证器"""
    
    @staticmethod
    def validate_stock_code(code: str) -> bool:
        """验证股票代码格式"""
        if not code or not isinstance(code, str):
            return False
        
        # 中国股票代码格式：6位数字
        pattern = r'^[0-9]{6}$'
        return bool(re.match(pattern, code))
    
    @staticmethod
    def validate_date(date_str: str) -> bool:
        """验证日期格式"""
        if not date_str or not isinstance(date_str, str):
            return False
        
        try:
            datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_number_range(value: Any, min_val: float = None, max_val: float = None) -> bool:
        """验证数字范围"""
        try:
            num_value = float(value)
            if min_val is not None and num_value < min_val:
                return False
            if max_val is not None and num_value > max_val:
                return False
            return True
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def sanitize_string(text: str, max_length: int = 1000) -> str:
        """清理字符串输入"""
        if not isinstance(text, str):
            return ""
        
        # 移除潜在的恶意字符
        text = re.sub(r'[<>"\']', '', text)
        
        # 限制长度
        return text[:max_length]
    
    @staticmethod
    def validate_password(password: str, config: SecurityConfig = None) -> tuple[bool, str]:
        """验证密码强度"""
        config = config or SecurityConfig()
        
        if len(password) < config.MIN_PASSWORD_LENGTH:
            return False, f"密码长度至少{config.MIN_PASSWORD_LENGTH}位"
        
        if config.REQUIRE_SPECIAL_CHARS:
            if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
                return False, "密码必须包含特殊字符"
            
            if not re.search(r'[A-Z]', password):
                return False, "密码必须包含大写字母"
            
            if not re.search(r'[a-z]', password):
                return False, "密码必须包含小写字母"
            
            if not re.search(r'[0-9]', password):
                return False, "密码必须包含数字"
        
        return True, "密码强度合格"


class SecurityMiddleware:
    """安全中间件"""
    
    def __init__(self, config: SecurityConfig = None):
        self.config = config or SecurityConfig()
        self.token_manager = TokenManager(config)
        self.rate_limiter = RateLimiter()
        self.validator = InputValidator()
    
    def check_ip_whitelist(self, client_ip: str) -> bool:
        """检查IP白名单"""
        if not self.config.ALLOWED_IPS:
            return True  # 空白名单表示允许所有IP
        
        return client_ip in self.config.ALLOWED_IPS
    
    def check_rate_limit(self, identifier: str, limit: str = None) -> bool:
        """检查限流"""
        limit = limit or self.config.DEFAULT_RATE_LIMIT
        
        if SLOWAPI_AVAILABLE:
            # 使用SlowAPI（需要在FastAPI应用中配置）
            return True
        else:
            # 使用内置限流器
            return self.rate_limiter.is_allowed(identifier, limit)
    
    def authenticate_request(self, token: str) -> Optional[Dict]:
        """认证请求"""
        if not token:
            return None
        
        # 移除Bearer前缀
        if token.startswith('Bearer '):
            token = token[7:]
        
        return self.token_manager.verify_token(token)
    
    def authorize_request(self, user_payload: Dict, required_permission: str) -> bool:
        """授权请求"""
        if not user_payload:
            return False
        
        user_permissions = user_payload.get('permissions', [])
        return required_permission in user_permissions or 'admin' in user_permissions


def require_auth(permission: str = None):
    """认证装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 这里需要从请求中获取token
            # 具体实现取决于框架（FastAPI/Flask等）
            
            # 示例实现（需要根据实际框架调整）
            request = kwargs.get('request')
            if not request:
                raise Exception("Unauthorized: No request object")
            
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                raise Exception("Unauthorized: No token provided")
            
            # 验证token
            security_middleware = SecurityMiddleware()
            user_payload = security_middleware.authenticate_request(auth_header)
            
            if not user_payload:
                raise Exception("Unauthorized: Invalid token")
            
            # 检查权限
            if permission and not security_middleware.authorize_request(user_payload, permission):
                raise Exception("Forbidden: Insufficient permissions")
            
            # 将用户信息添加到请求中
            kwargs['current_user'] = user_payload
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def rate_limit(limit: str = "100/minute"):
    """限流装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request = kwargs.get('request')
            if not request:
                return await func(*args, **kwargs)
            
            # 获取客户端IP
            client_ip = request.client.host if hasattr(request, 'client') else 'unknown'
            
            # 检查限流
            security_middleware = SecurityMiddleware()
            if not security_middleware.check_rate_limit(client_ip, limit):
                raise Exception("Rate limit exceeded")
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def validate_input(**validators):
    """输入验证装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            validator = InputValidator()
            
            for param_name, validation_func in validators.items():
                if param_name in kwargs:
                    value = kwargs[param_name]
                    if not validation_func(value):
                        raise Exception(f"Invalid input for parameter: {param_name}")
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


# 全局安全实例
security_middleware = SecurityMiddleware()
token_manager = TokenManager()
input_validator = InputValidator()
