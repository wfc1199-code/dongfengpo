"""
动态支撑压力识别模块
Dynamic Support & Resistance Detection
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
from datetime import datetime
# from scipy.signal import argrelextrema
# from sklearn.cluster import DBSCAN
import logging

logger = logging.getLogger(__name__)


class DynamicSRDetector:
    """动态支撑压力识别器"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.window_size = self.config.get('window_size', 20)
        self.min_touches = self.config.get('min_touches', 3)
        self.price_tolerance = self.config.get('price_tolerance', 0.002)  # 0.2%
        self.lookback_periods = self.config.get('lookback_periods', 100)
        
    def detect_levels(self, 
                     prices: List[float], 
                     volumes: Optional[List[float]] = None,
                     timestamps: Optional[List[str]] = None) -> List[Dict]:
        """
        检测动态支撑压力位
        
        Args:
            prices: 价格序列
            volumes: 成交量序列（可选）
            timestamps: 时间戳序列（可选）
            
        Returns:
            支撑压力位列表
        """
        if len(prices) < self.window_size * 2:
            return []
            
        # 转换为numpy数组
        price_array = np.array(prices)
        
        # 1. 识别局部极值点
        peaks, troughs = self._find_extrema(price_array)
        
        # 2. 合并所有极值点
        all_extrema = []
        for idx in peaks:
            all_extrema.append({
                'index': idx,
                'price': prices[idx],
                'type': 'peak',
                'volume': volumes[idx] if volumes else None
            })
        for idx in troughs:
            all_extrema.append({
                'index': idx,
                'price': prices[idx],
                'type': 'trough',
                'volume': volumes[idx] if volumes else None
            })
            
        if len(all_extrema) < self.min_touches:
            return []
            
        # 3. 使用DBSCAN聚类相近的价格点
        clusters = self._cluster_price_levels(all_extrema)
        
        # 4. 计算每个簇的支撑压力强度
        sr_levels = []
        for cluster_id, cluster_points in clusters.items():
            if cluster_id == -1:  # 噪声点
                continue
                
            level = self._analyze_cluster(cluster_points, prices, volumes)
            if level:
                sr_levels.append(level)
                
        # 5. 按强度排序
        sr_levels.sort(key=lambda x: x['strength'], reverse=True)
        
        return sr_levels
        
    def _find_extrema(self, prices: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """查找局部极值点（简化版本）"""
        window = self.window_size // 2
        peaks = []
        troughs = []
        
        for i in range(window, len(prices) - window):
            # 检查是否为局部最大值
            if all(prices[i] >= prices[j] for j in range(i - window, i + window + 1) if j != i):
                peaks.append(i)
            # 检查是否为局部最小值
            elif all(prices[i] <= prices[j] for j in range(i - window, i + window + 1) if j != i):
                troughs.append(i)
        
        return np.array(peaks), np.array(troughs)
        
    def _cluster_price_levels(self, extrema: List[Dict]) -> Dict[int, List[Dict]]:
        """使用简单聚类方法聚类价格水平"""
        if not extrema:
            return {}
            
        # 按价格排序
        sorted_extrema = sorted(extrema, key=lambda x: x['price'])
        
        # 简单聚类算法
        clusters = {}
        cluster_id = 0
        
        for i, point in enumerate(sorted_extrema):
            if i == 0:
                clusters[cluster_id] = [point]
            else:
                # 计算与前一个点的价格差距
                prev_price = sorted_extrema[i-1]['price']
                price_diff = abs(point['price'] - prev_price) / prev_price
                
                # 如果差距小于阈值，加入当前簇
                if price_diff <= self.price_tolerance:
                    clusters[cluster_id].append(point)
                else:
                    # 否则创建新簇
                    cluster_id += 1
                    clusters[cluster_id] = [point]
        
        # 过滤掉点数太少的簇
        filtered_clusters = {
            k: v for k, v in clusters.items() 
            if len(v) >= self.min_touches
        }
        
        return filtered_clusters
        
    def _analyze_cluster(self, 
                        cluster_points: List[Dict], 
                        prices: List[float],
                        volumes: Optional[List[float]] = None) -> Optional[Dict]:
        """分析价格簇，生成支撑压力位信息"""
        if len(cluster_points) < self.min_touches:
            return None
            
        # 计算平均价格
        avg_price = np.mean([p['price'] for p in cluster_points])
        
        # 计算触及次数
        touches = len(cluster_points)
        
        # 判断类型（支撑还是压力）
        peak_count = sum(1 for p in cluster_points if p['type'] == 'peak')
        trough_count = sum(1 for p in cluster_points if p['type'] == 'trough')
        
        if peak_count > trough_count:
            level_type = 'resistance'
        elif trough_count > peak_count:
            level_type = 'support'
        else:
            level_type = 'both'
            
        # 计算强度分数
        strength = self._calculate_strength(
            cluster_points, avg_price, prices, volumes
        )
        
        # 获取最近触及时间
        last_touch_idx = max(p['index'] for p in cluster_points)
        
        # 计算价格标准差（用于判断该位置的稳定性）
        price_std = np.std([p['price'] for p in cluster_points])
        
        return {
            'price': round(avg_price, 2),
            'type': level_type,
            'touches': touches,
            'strength': strength,
            'last_touch_index': last_touch_idx,
            'price_std': price_std,
            'peak_count': peak_count,
            'trough_count': trough_count,
            'cluster_points': cluster_points
        }
        
    def _calculate_strength(self,
                           cluster_points: List[Dict],
                           avg_price: float,
                           prices: List[float],
                           volumes: Optional[List[float]] = None) -> float:
        """
        计算支撑压力强度（0-100分）
        
        考虑因素：
        1. 触及次数
        2. 时间跨度
        3. 成交量（如果有）
        4. 价格反弹/回落幅度
        5. 最近触及时间
        """
        score = 0.0
        
        # 1. 触及次数得分（最高30分）
        touches = len(cluster_points)
        touch_score = min(touches * 5, 30)
        score += touch_score
        
        # 2. 时间跨度得分（最高20分）
        indices = [p['index'] for p in cluster_points]
        time_span = max(indices) - min(indices)
        span_ratio = time_span / len(prices)
        span_score = min(span_ratio * 40, 20)
        score += span_score
        
        # 3. 成交量得分（最高20分）
        if volumes:
            volume_scores = []
            for point in cluster_points:
                idx = point['index']
                if point['volume']:
                    # 计算该点成交量相对于平均成交量的比例
                    avg_volume = np.mean(volumes)
                    volume_ratio = point['volume'] / avg_volume
                    volume_scores.append(min(volume_ratio, 2.0))
            
            if volume_scores:
                avg_volume_score = np.mean(volume_scores) * 10
                score += min(avg_volume_score, 20)
                
        # 4. 价格反弹/回落幅度得分（最高20分）
        bounce_scores = []
        for point in cluster_points:
            idx = point['index']
            
            # 计算触及后的价格变化
            if idx + 5 < len(prices):
                price_change = abs(prices[idx + 5] - prices[idx]) / prices[idx]
                bounce_scores.append(min(price_change * 100, 2.0))
                
        if bounce_scores:
            avg_bounce_score = np.mean(bounce_scores) * 10
            score += min(avg_bounce_score, 20)
            
        # 5. 最近触及时间得分（最高10分）
        last_touch_idx = max(indices)
        recency_ratio = last_touch_idx / len(prices)
        recency_score = recency_ratio * 10
        score += recency_score
        
        return round(score, 1)
        
    def update_levels(self, 
                     existing_levels: List[Dict],
                     new_price: float,
                     new_volume: Optional[float] = None) -> List[Dict]:
        """
        使用新数据更新现有支撑压力位
        
        Args:
            existing_levels: 现有支撑压力位
            new_price: 新价格
            new_volume: 新成交量
            
        Returns:
            更新后的支撑压力位列表
        """
        updated_levels = []
        
        for level in existing_levels:
            # 检查是否触及该水平
            price_diff = abs(new_price - level['price']) / level['price']
            
            if price_diff <= self.price_tolerance:
                # 触及了该水平，更新信息
                level['touches'] += 1
                level['last_touch_index'] += 1
                
                # 重新计算强度
                # 这里简化处理，实际应该保存完整历史数据
                level['strength'] = min(level['strength'] + 2, 100)
                
            updated_levels.append(level)
            
        return updated_levels