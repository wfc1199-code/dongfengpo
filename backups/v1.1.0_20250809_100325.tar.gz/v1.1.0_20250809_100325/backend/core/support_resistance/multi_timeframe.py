"""
多时间周期支撑压力分析模块
Multi-Timeframe Support & Resistance Analysis
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class MultiTimeframeSR:
    """多时间周期支撑压力分析器"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        
        # 时间周期定义（分钟）
        self.timeframes = {
            '1m': 1,
            '5m': 5,
            '15m': 15,
            '30m': 30,
            '60m': 60,
            '1d': 1440,
            '1w': 10080,
            '1M': 43200
        }
        
        # 不同周期的权重（根据当前查看周期动态调整）
        self.default_weights = {
            '1m': 0.05,
            '5m': 0.10,
            '15m': 0.15,
            '30m': 0.15,
            '60m': 0.20,
            '1d': 0.25,
            '1w': 0.05,
            '1M': 0.05
        }
        
        # 价格容差（用于合并相近的支撑压力位）
        self.price_tolerance = self.config.get('price_tolerance', 0.002)  # 0.2%
        
    def analyze(self,
                timeframe_data: Dict[str, List[Dict]],
                current_timeframe: str = '5m') -> Dict:
        """
        分析多时间周期的支撑压力位
        
        Args:
            timeframe_data: 各时间周期的数据
                {
                    '1m': [{'price': x, 'volume': y, ...}, ...],
                    '5m': [...],
                    ...
                }
            current_timeframe: 当前查看的时间周期
            
        Returns:
            多时间周期支撑压力分析结果
        """
        # 动态调整权重
        weights = self._adjust_weights(current_timeframe)
        
        # 提取各周期的支撑压力位
        all_levels = {}
        for tf, data in timeframe_data.items():
            if data:
                levels = self._extract_sr_levels(data, tf)
                all_levels[tf] = levels
                
        # 合并多周期支撑压力位
        merged_levels = self._merge_levels(all_levels, weights)
        
        # 识别共振位（多周期确认的位置）
        confluence_levels = self._find_confluence_levels(all_levels)
        
        # 计算综合强度
        final_levels = self._calculate_final_strength(merged_levels, confluence_levels)
        
        return {
            'levels': final_levels,
            'timeframe_details': all_levels,
            'confluence_zones': confluence_levels,
            'weights_used': weights,
            'analysis_time': datetime.now().isoformat()
        }
        
    def _adjust_weights(self, current_timeframe: str) -> Dict[str, float]:
        """根据当前时间周期动态调整权重"""
        weights = self.default_weights.copy()
        
        # 获取当前周期的分钟数
        current_minutes = self.timeframes.get(current_timeframe, 5)
        
        # 调整权重：相近的周期权重更高
        for tf, minutes in self.timeframes.items():
            if tf in weights:
                # 计算周期差异比率
                ratio = abs(np.log(minutes / current_minutes))
                
                # 根据差异调整权重
                if ratio < 0.5:  # 非常接近
                    weights[tf] *= 1.5
                elif ratio < 1.0:  # 较接近
                    weights[tf] *= 1.2
                elif ratio > 3.0:  # 差异很大
                    weights[tf] *= 0.5
                    
        # 归一化权重
        total_weight = sum(weights.values())
        for tf in weights:
            weights[tf] /= total_weight
            
        return weights
        
    def _extract_sr_levels(self, data: List[Dict], timeframe: str) -> List[Dict]:
        """从单个时间周期数据中提取支撑压力位"""
        if len(data) < 20:
            return []
            
        prices = [d.get('close', 0) for d in data]
        volumes = [d.get('volume', 0) for d in data]
        
        # 使用简单的峰谷识别
        levels = []
        
        # 识别局部高点和低点
        for i in range(10, len(prices) - 10):
            # 局部高点
            if prices[i] == max(prices[i-10:i+11]):
                levels.append({
                    'price': prices[i],
                    'type': 'resistance',
                    'timeframe': timeframe,
                    'strength': 50,  # 基础强度
                    'index': i,
                    'volume': volumes[i]
                })
                
            # 局部低点
            if prices[i] == min(prices[i-10:i+11]):
                levels.append({
                    'price': prices[i],
                    'type': 'support',
                    'timeframe': timeframe,
                    'strength': 50,  # 基础强度
                    'index': i,
                    'volume': volumes[i]
                })
                
        return levels
        
    def _merge_levels(self, 
                     all_levels: Dict[str, List[Dict]], 
                     weights: Dict[str, float]) -> List[Dict]:
        """合并多个时间周期的支撑压力位"""
        merged = []
        
        # 收集所有价位
        all_price_levels = []
        for tf, levels in all_levels.items():
            for level in levels:
                level['weight'] = weights.get(tf, 0.1)
                all_price_levels.append(level)
                
        # 按价格排序
        all_price_levels.sort(key=lambda x: x['price'])
        
        # 合并相近的价位
        i = 0
        while i < len(all_price_levels):
            current_level = all_price_levels[i].copy()
            cluster = [current_level]
            
            # 查找相近的价位
            j = i + 1
            while j < len(all_price_levels):
                price_diff = abs(all_price_levels[j]['price'] - current_level['price']) / current_level['price']
                
                if price_diff <= self.price_tolerance:
                    cluster.append(all_price_levels[j])
                    j += 1
                else:
                    break
                    
            # 合并cluster中的价位
            if cluster:
                merged_level = self._merge_cluster(cluster)
                merged.append(merged_level)
                
            i = j if j > i + 1 else i + 1
            
        return merged
        
    def _merge_cluster(self, cluster: List[Dict]) -> Dict:
        """合并一组相近的价位"""
        # 计算加权平均价格
        total_weight = sum(level['weight'] * level.get('strength', 50) for level in cluster)
        weighted_price = sum(level['price'] * level['weight'] * level.get('strength', 50) 
                           for level in cluster) / total_weight
        
        # 确定类型
        support_count = sum(1 for level in cluster if level['type'] == 'support')
        resistance_count = sum(1 for level in cluster if level['type'] == 'resistance')
        
        if support_count > resistance_count:
            level_type = 'support'
        elif resistance_count > support_count:
            level_type = 'resistance'
        else:
            level_type = 'both'
            
        # 计算综合强度
        strength = sum(level['weight'] * level.get('strength', 50) for level in cluster) * 10
        strength = min(strength, 100)  # 限制最大值为100
        
        # 收集所有相关的时间周期
        timeframes = list(set(level['timeframe'] for level in cluster))
        
        return {
            'price': round(weighted_price, 2),
            'type': level_type,
            'strength': round(strength, 1),
            'timeframes': timeframes,
            'cluster_size': len(cluster),
            'confirmed_count': len(timeframes)
        }
        
    def _find_confluence_levels(self, all_levels: Dict[str, List[Dict]]) -> List[Dict]:
        """查找共振位（多个时间周期确认的价位）"""
        confluence_zones = []
        
        # 创建价格区间（每0.5%一个区间）
        all_prices = []
        for levels in all_levels.values():
            all_prices.extend([level['price'] for level in levels])
            
        if not all_prices:
            return []
            
        min_price = min(all_prices)
        max_price = max(all_prices)
        
        # 创建价格区间
        zone_size = (max_price - min_price) * 0.005  # 0.5%区间
        zones = {}
        
        # 统计每个区间的确认次数
        for tf, levels in all_levels.items():
            for level in levels:
                zone_idx = int((level['price'] - min_price) / zone_size)
                
                if zone_idx not in zones:
                    zones[zone_idx] = {
                        'price_sum': 0,
                        'count': 0,
                        'timeframes': set(),
                        'types': []
                    }
                    
                zones[zone_idx]['price_sum'] += level['price']
                zones[zone_idx]['count'] += 1
                zones[zone_idx]['timeframes'].add(tf)
                zones[zone_idx]['types'].append(level['type'])
                
        # 识别共振区域（至少3个时间周期确认）
        for zone_idx, zone_data in zones.items():
            if len(zone_data['timeframes']) >= 3:
                avg_price = zone_data['price_sum'] / zone_data['count']
                
                # 确定类型
                support_count = zone_data['types'].count('support')
                resistance_count = zone_data['types'].count('resistance')
                
                confluence_zones.append({
                    'price': round(avg_price, 2),
                    'type': 'support' if support_count > resistance_count else 'resistance',
                    'confirmation_count': len(zone_data['timeframes']),
                    'timeframes': list(zone_data['timeframes']),
                    'strength': min(len(zone_data['timeframes']) * 20, 100)
                })
                
        return confluence_zones
        
    def _calculate_final_strength(self, 
                                 merged_levels: List[Dict],
                                 confluence_levels: List[Dict]) -> List[Dict]:
        """计算最终的支撑压力强度"""
        final_levels = []
        
        # 将共振位的强度加成应用到合并后的价位上
        for level in merged_levels:
            final_level = level.copy()
            
            # 查找是否有对应的共振位
            for conf in confluence_levels:
                price_diff = abs(conf['price'] - level['price']) / level['price']
                
                if price_diff <= self.price_tolerance:
                    # 应用共振加成
                    final_level['strength'] = min(
                        level['strength'] + conf['strength'] * 0.5, 
                        100
                    )
                    final_level['is_confluence'] = True
                    final_level['confluence_count'] = conf['confirmation_count']
                    break
                    
            final_levels.append(final_level)
            
        # 按强度排序
        final_levels.sort(key=lambda x: x['strength'], reverse=True)
        
        return final_levels
        
    def get_nearest_levels(self, 
                          levels: List[Dict], 
                          current_price: float,
                          count: int = 3) -> Dict[str, List[Dict]]:
        """获取最近的支撑和压力位"""
        supports = []
        resistances = []
        
        for level in levels:
            if level['price'] < current_price and level['type'] in ['support', 'both']:
                supports.append(level)
            elif level['price'] > current_price and level['type'] in ['resistance', 'both']:
                resistances.append(level)
                
        # 支撑位按价格降序（离当前价最近的在前）
        supports.sort(key=lambda x: x['price'], reverse=True)
        
        # 压力位按价格升序（离当前价最近的在前）
        resistances.sort(key=lambda x: x['price'])
        
        return {
            'nearest_supports': supports[:count],
            'nearest_resistances': resistances[:count]
        }