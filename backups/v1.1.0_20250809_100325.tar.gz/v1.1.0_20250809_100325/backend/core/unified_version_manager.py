"""
统一版本管理系统
整合原有数据库管理和新的备份恢复功能
"""

import json
import os
import shutil
import sqlite3
import tarfile
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import zipfile
import subprocess

class UnifiedVersionManager:
    """统一版本管理器 - 整合数据库和文件系统"""
    
    def __init__(self, project_root: str = None):
        if project_root is None:
            project_root = Path(__file__).parent.parent.parent
        
        self.project_root = Path(project_root)
        self.versions_dir = self.project_root / "backend" / "versions"
        self.backups_dir = self.project_root / "backups"
        self.db_path = self.versions_dir / "versions.db"
        self.current_version_file = self.project_root / ".current_version"
        
        # 确保目录存在
        self.versions_dir.mkdir(exist_ok=True, parents=True)
        self.backups_dir.mkdir(exist_ok=True, parents=True)
        
        # 初始化数据库
        self._init_database()
        
        # 迁移旧数据
        self._migrate_old_versions()
    
    def _init_database(self):
        """初始化版本数据库（扩展原有结构）"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 保留原有表结构，添加新字段
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version_name TEXT NOT NULL,
                version_code TEXT UNIQUE NOT NULL,
                semantic_version TEXT,  -- 新增：语义化版本号
                description TEXT,
                created_at TEXT NOT NULL,
                created_by TEXT DEFAULT 'system',
                file_path TEXT NOT NULL,
                backup_path TEXT,       -- 新增：备份文件路径
                file_size INTEGER,
                checksum TEXT,
                tags TEXT,
                status TEXT DEFAULT 'active',
                metadata TEXT,
                is_stable BOOLEAN DEFAULT 0,  -- 新增：是否为稳定版本
                can_rollback BOOLEAN DEFAULT 1 -- 新增：是否可回滚
            )
        ''')
        
        # 变更记录表（保留原有）
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS version_changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version_id INTEGER,
                change_type TEXT,
                file_path TEXT,
                description TEXT,
                FOREIGN KEY (version_id) REFERENCES versions (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _migrate_old_versions(self):
        """迁移旧版本数据到新格式"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 检查是否需要迁移
        cursor.execute("PRAGMA table_info(versions)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'semantic_version' not in columns:
            # 添加新列
            try:
                cursor.execute("ALTER TABLE versions ADD COLUMN semantic_version TEXT")
                cursor.execute("ALTER TABLE versions ADD COLUMN backup_path TEXT")
                cursor.execute("ALTER TABLE versions ADD COLUMN is_stable BOOLEAN DEFAULT 0")
                cursor.execute("ALTER TABLE versions ADD COLUMN can_rollback BOOLEAN DEFAULT 1")
                
                # 为现有版本生成语义化版本号
                cursor.execute("SELECT id, created_at FROM versions ORDER BY created_at")
                versions = cursor.fetchall()
                for i, (vid, _) in enumerate(versions):
                    semantic_ver = f"v0.{i+1}.0"
                    cursor.execute("UPDATE versions SET semantic_version = ? WHERE id = ?", 
                                 (semantic_ver, vid))
                
                conn.commit()
            except sqlite3.OperationalError:
                pass  # 列已存在
        
        conn.close()
    
    def get_current_version(self) -> str:
        """获取当前版本号（语义化版本）"""
        if self.current_version_file.exists():
            return self.current_version_file.read_text().strip()
        
        # 从数据库获取最新版本
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT semantic_version FROM versions 
            WHERE semantic_version IS NOT NULL 
            ORDER BY created_at DESC LIMIT 1
        """)
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return result[0]
        return "v1.0.0"
    
    def generate_version_number(self, version_type: str = "patch") -> str:
        """生成新的语义化版本号"""
        current = self.get_current_version()
        version = current.lstrip('v')
        parts = version.split('.')
        
        major = int(parts[0]) if len(parts) > 0 else 1
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        
        if version_type == "major":
            major += 1
            minor = 0
            patch = 0
        elif version_type == "minor":
            minor += 1
            patch = 0
        else:  # patch
            patch += 1
        
        return f"v{major}.{minor}.{patch}"
    
    def create_version(self, 
                      version_name: str,
                      version_type: str = "patch",
                      description: str = "",
                      tags: List[str] = None,
                      created_by: str = "system") -> Dict:
        """创建新版本（整合数据库记录和文件备份）"""
        
        # 生成版本信息
        semantic_version = self.generate_version_number(version_type)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        version_code = f"{semantic_version}_{timestamp}"
        
        # 创建备份文件
        backup_name = f"{version_code}"
        backup_path = self.backups_dir / f"{backup_name}.tar.gz"
        
        # 创建临时目录
        temp_dir = self.backups_dir / f"temp_{timestamp}"
        temp_dir.mkdir(exist_ok=True)
        
        try:
            # 复制项目文件
            self._copy_project_files(temp_dir)
            
            # 保存版本信息
            version_info = {
                "version_name": version_name,
                "semantic_version": semantic_version,
                "version_code": version_code,
                "description": description,
                "created_at": datetime.now().isoformat(),
                "created_by": created_by,
                "tags": tags or [],
                "changes": self._detect_changes()
            }
            
            with open(temp_dir / "version_info.json", 'w') as f:
                json.dump(version_info, f, indent=2, ensure_ascii=False)
            
            # 创建压缩包
            with tarfile.open(backup_path, "w:gz") as tar:
                tar.add(temp_dir, arcname=backup_name)
            
            # 清理临时目录
            shutil.rmtree(temp_dir)
            
            # 计算文件大小和校验和
            file_size = backup_path.stat().st_size
            checksum = self._calculate_checksum(backup_path)
            
            # 保存到数据库
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO versions (
                    version_name, version_code, semantic_version,
                    description, created_at, created_by,
                    file_path, backup_path, file_size, checksum,
                    tags, status, metadata, is_stable, can_rollback
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                version_name, version_code, semantic_version,
                description, datetime.now().isoformat(), created_by,
                str(backup_path), str(backup_path), file_size, checksum,
                json.dumps(tags or []), 'active',
                json.dumps(version_info), 0, 1
            ))
            
            version_id = cursor.lastrowid
            
            # 记录变更（检查表结构）
            cursor.execute("PRAGMA table_info(version_changes)")
            columns = [col[1] for col in cursor.fetchall()]
            
            for change in version_info.get('changes', []):
                if 'description' in columns:
                    cursor.execute('''
                        INSERT INTO version_changes (version_id, change_type, file_path, description)
                        VALUES (?, ?, ?, ?)
                    ''', (version_id, change['type'], change['path'], change.get('description', '')))
                else:
                    cursor.execute('''
                        INSERT INTO version_changes (version_id, change_type, file_path)
                        VALUES (?, ?, ?)
                    ''', (version_id, change['type'], change['path']))
            
            conn.commit()
            conn.close()
            
            # 更新当前版本
            self.current_version_file.write_text(semantic_version)
            
            return {
                "success": True,
                "version": semantic_version,
                "version_code": version_code,
                "backup_path": str(backup_path),
                "file_size": self._format_size(file_size),
                "message": f"版本 {semantic_version} 创建成功"
            }
            
        except Exception as e:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            raise Exception(f"创建版本失败: {str(e)}")
    
    def restore_version(self, version: str) -> Dict:
        """恢复到指定版本"""
        # 查找版本信息
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, version_code, backup_path, semantic_version
            FROM versions 
            WHERE semantic_version = ? OR version_code = ?
        """, (version, version))
        
        result = cursor.fetchone()
        conn.close()
        
        if not result:
            raise ValueError(f"版本 {version} 不存在")
        
        version_id, version_code, backup_path, semantic_version = result
        
        if not backup_path or not Path(backup_path).exists():
            raise ValueError(f"备份文件不存在: {backup_path}")
        
        # 先备份当前版本
        self.create_version(
            f"回滚前备份_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "patch",
            f"恢复到版本 {semantic_version} 之前的自动备份"
        )
        
        # 停止服务
        try:
            subprocess.run([str(self.project_root / "scripts" / "stop_dongfeng.sh")], 
                          check=False, capture_output=True)
        except:
            pass
        
        # 解压恢复
        temp_dir = self.backups_dir / f"restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        temp_dir.mkdir(exist_ok=True)
        
        try:
            with tarfile.open(backup_path, "r:gz") as tar:
                tar.extractall(temp_dir)
            
            # 找到解压后的目录
            extracted_dirs = list(temp_dir.iterdir())
            if not extracted_dirs:
                raise ValueError("备份文件为空")
            
            source_dir = extracted_dirs[0]
            
            # 恢复文件
            for item in ["backend", "frontend/src", "scripts", "config"]:
                source = source_dir / item
                if source.exists():
                    dest = self.project_root / item
                    if dest.exists():
                        if dest.is_dir():
                            shutil.rmtree(dest)
                        else:
                            dest.unlink()
                    
                    if source.is_dir():
                        shutil.copytree(source, dest)
                    else:
                        shutil.copy2(source, dest)
            
            # 恢复配置文件
            for pattern in ["*.md", "*.json", "*.html"]:
                for file in source_dir.glob(pattern):
                    if file.name != "version_info.json":
                        shutil.copy2(file, self.project_root / file.name)
            
            # 清理
            shutil.rmtree(temp_dir)
            
            # 更新当前版本
            self.current_version_file.write_text(semantic_version)
            
            # 更新数据库状态
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("UPDATE versions SET status = 'restored' WHERE id = ?", (version_id,))
            conn.commit()
            conn.close()
            
            return {
                "success": True,
                "version": semantic_version,
                "message": f"成功恢复到版本 {semantic_version}"
            }
            
        except Exception as e:
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            raise Exception(f"恢复版本失败: {str(e)}")
    
    def list_versions(self, limit: int = 20) -> List[Dict]:
        """列出所有版本"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, version_name, version_code, semantic_version,
                   description, created_at, created_by, file_size,
                   tags, status, is_stable
            FROM versions
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))
        
        versions = []
        current_version = self.get_current_version()
        
        for row in cursor.fetchall():
            tags = json.loads(row[8]) if row[8] else []
            versions.append({
                "id": row[0],
                "version_name": row[1],
                "version_code": row[2],
                "semantic_version": row[3] or "N/A",
                "description": row[4],
                "created_at": row[5],
                "created_by": row[6],
                "file_size": self._format_size(row[7]) if row[7] else "N/A",
                "tags": tags,
                "status": row[9],
                "is_stable": bool(row[10]),
                "is_current": row[3] == current_version
            })
        
        conn.close()
        return versions
    
    def get_timeline(self, days: int = 30) -> List[Dict]:
        """获取版本时间轴"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        since_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
            SELECT semantic_version, version_name, created_at, created_by, tags
            FROM versions
            WHERE created_at >= ?
            ORDER BY created_at DESC
        """, (since_date,))
        
        timeline = []
        for row in cursor.fetchall():
            tags = json.loads(row[4]) if row[4] else []
            timeline.append({
                "version": row[0] or "N/A",
                "name": row[1],
                "date": row[2],
                "author": row[3],
                "tags": tags,
                "is_milestone": "major" in tags or "release" in tags
            })
        
        conn.close()
        return timeline
    
    def _copy_project_files(self, dest_dir: Path):
        """复制项目文件到目标目录"""
        items_to_copy = [
            "backend",
            "frontend/src",
            "frontend/package.json",
            "scripts",
            "config"
        ]
        
        for item in items_to_copy:
            source = self.project_root / item
            if source.exists():
                dest = dest_dir / item
                if source.is_dir():
                    shutil.copytree(source, dest, dirs_exist_ok=True)
                else:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, dest)
        
        # 复制根目录文件
        for pattern in ["*.md", "*.json", "*.html"]:
            for file in self.project_root.glob(pattern):
                if file.is_file():
                    shutil.copy2(file, dest_dir / file.name)
    
    def _detect_changes(self) -> List[Dict]:
        """检测文件变更"""
        # 简化版本，实际可以使用git diff
        changes = []
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.project_root,
                capture_output=True,
                text=True
            )
            
            for line in result.stdout.strip().split('\n'):
                if line:
                    status = line[:2]
                    file_path = line[3:]
                    change_type = "modified"
                    if status[0] == 'A':
                        change_type = "added"
                    elif status[0] == 'D':
                        change_type = "deleted"
                    
                    changes.append({
                        "type": change_type,
                        "path": file_path
                    })
        except:
            pass
        
        return changes
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """计算文件校验和"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def _format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}TB"
    
    def cleanup_old_versions(self, keep_count: int = 10):
        """清理旧版本"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 获取需要保留的版本
        cursor.execute("""
            SELECT id FROM versions
            WHERE is_stable = 1 OR status = 'active'
            ORDER BY created_at DESC
            LIMIT ?
        """, (keep_count,))
        
        keep_ids = [row[0] for row in cursor.fetchall()]
        
        # 删除旧版本的备份文件
        cursor.execute("""
            SELECT backup_path FROM versions
            WHERE id NOT IN ({}) AND backup_path IS NOT NULL
        """.format(','.join('?' * len(keep_ids))), keep_ids)
        
        for row in cursor.fetchall():
            backup_path = Path(row[0])
            if backup_path.exists():
                backup_path.unlink()
        
        # 更新数据库状态
        cursor.execute("""
            UPDATE versions
            SET status = 'archived', can_rollback = 0
            WHERE id NOT IN ({})
        """.format(','.join('?' * len(keep_ids))), keep_ids)
        
        conn.commit()
        conn.close()

# 创建全局实例
unified_version_manager = UnifiedVersionManager()

# 向后兼容
version_manager = unified_version_manager