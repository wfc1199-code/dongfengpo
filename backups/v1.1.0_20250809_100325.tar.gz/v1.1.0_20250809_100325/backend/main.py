#!/usr/bin/env python3
"""
东风破 - AI异动拉升检测系统 - macOS版
主API服务
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timedelta, time
import re

from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pypinyin import lazy_pinyin, Style

from core.data_sources import StockDataManager
from core.anomaly_detection import StockAnalysisEngine
from core.cache_manager import cache_manager, init_cache, cleanup_cache
from core.optimized_algorithms import parallel_analyzer, performance_monitor_instance
from core.monitoring import system_monitor
from core.security import security_middleware, rate_limit, require_auth, validate_input, input_validator
from core.config import settings, load_user_config, save_user_config
from api.anomaly_routes import router as anomaly_router, init_anomaly_services
from api.limit_up_routes import router as limit_up_router, init_limit_up_services
from api.version_routes import router as version_router
from api.transaction_routes import router as transaction_router
from api.support_resistance_tdx import router as sr_router  # 使用通达信风格版本
from api.market_behavior_routes import router as behavior_router  # 主力行为分析
from api.market_scanner import router as scanner_router  # 全市场异动扫描
from api.version_api import router as version_api_router  # 版本管理API

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 创建FastAPI应用
app = FastAPI(
    title="东风破 - AI异动拉升检测系统",
    description="专为macOS开发的股票异动拉升检测系统",
    version="1.0.0"
)

# CORS中间件 - 使用安全配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,  # 使用配置的域名
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=settings.cors_allow_methods,
    allow_headers=settings.cors_allow_headers,
)

# 全局变量
data_manager = None
anomaly_engine = None
config = None
monitoring_task = None
monitoring_results = {}
connected_clients = set()

# 动态监控股票列表（仅包含用户自选股和热门板块股票）
dynamic_stock_codes = set()
last_sector_update = datetime.min  # 上次更新板块的时间
sector_update_interval = 900  # 15分钟更新一次热门板块（优化性能）

class AlertRequest(BaseModel):
    """预警请求模型"""
    stock_code: str
    alert_type: str
    message: str


# 旧的启动和关闭事件已被新的优化版本替换


# 引入API路由
app.include_router(anomaly_router)
app.include_router(limit_up_router)
app.include_router(version_router)
app.include_router(sr_router)
app.include_router(behavior_router)
app.include_router(transaction_router)
app.include_router(scanner_router)
app.include_router(version_api_router)

# 导入价格异动路由
from api.price_alert_routes import router as price_alert_router
app.include_router(price_alert_router)


@app.get("/")
async def root():
    """根路径"""
    return {
        "message": "东风破 - AI异动拉升检测系统",
        "version": "1.0.0",
        "status": "running",
        "features": [
            "AI异动检测",
            "实时拉升监控", 
            "资金流向分析",
            "热门板块监控",
            "智能预警系统"
        ]
    }


@app.get("/api/system/status")
async def get_system_status():
    """获取系统状态"""
    return {
        "status": "running",
        "monitoring_stocks": len(dynamic_stock_codes),
        "connected_clients": len(connected_clients),
        "anomaly_engine_initialized": anomaly_engine is not None,
        "data_manager_initialized": data_manager is not None,
        "last_sector_update": last_sector_update.isoformat() if last_sector_update != datetime.min else None,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/system/monitoring-stocks")
async def get_monitoring_stocks():
    """获取当前监控的股票列表"""
    try:
        # 获取监控股票的详细信息（仅用户自选和热门板块股票）
        user_stocks = []
        hot_sector_stocks = []
        
        if data_manager and dynamic_stock_codes:
            # 获取用户自选股代码
            user_favorites = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', []) if config else []
            formatted_favorites = []
            for code in user_favorites:
                if code.startswith('6'):
                    formatted_favorites.append(f'sh{code}')
                elif code.startswith(('0', '3', '2')):
                    formatted_favorites.append(f'sz{code}')
                else:
                    formatted_favorites.append(code)
            
            # 区分用户自选股和热门板块股票
            user_codes = [code for code in dynamic_stock_codes if code in formatted_favorites]
            hot_codes = [code for code in dynamic_stock_codes if code not in formatted_favorites]
            
            # 获取用户自选股的实时数据
            if user_codes:
                user_data = await data_manager.get_realtime_data(user_codes)
                for code in user_codes:
                    if code in user_data:
                        data = user_data[code]
                        user_stocks.append({
                            'code': code,
                            'name': data.get('name', ''),
                            'current_price': data.get('current_price', 0),
                            'change_percent': data.get('change_percent', 0),
                            'source': 'favorite'
                        })
            
            # 获取热门板块股票的实时数据（限制显示数量）
            if hot_codes[:30]:  # 限制显示数量，避免API超时
                hot_data = await data_manager.get_realtime_data(hot_codes[:30])
                for code in hot_codes[:30]:
                    if code in hot_data:
                        data = hot_data[code]
                        hot_sector_stocks.append({
                            'code': code,
                            'name': data.get('name', ''),
                            'current_price': data.get('current_price', 0),
                            'change_percent': data.get('change_percent', 0),
                            'source': 'hot_sector'
                        })
        
        return {
            "total_monitoring": len(dynamic_stock_codes),
            "user_favorites_count": len(user_stocks),
            "hot_sector_stocks_count": len(hot_sector_stocks),
            "user_favorites": user_stocks,
            "hot_sector_stocks": hot_sector_stocks,
            "next_update_in_seconds": max(0, sector_update_interval - int((datetime.now() - last_sector_update).total_seconds())),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取监控股票列表失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取监控股票列表失败: {str(e)}")


@app.get("/api/config")
async def get_config():
    """获取当前配置"""
    return config


@app.post("/api/config")
async def update_config(new_config: dict):
    """更新配置"""
    global config
    if config is None:
        config = {}
    
    # 深度合并配置
    def deep_merge(target, source):
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                deep_merge(target[key], value)
            else:
                target[key] = value
    
    deep_merge(config, new_config)
    
    # 保存配置到文件
    config_path = Path("data/config.json")
    config_path.parent.mkdir(exist_ok=True)
    
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    logger.info(f"配置已更新: {list(new_config.keys())}")
    return {"message": "配置已更新", "config": config}


@app.get("/api/anomaly/detect-legacy", summary="传统异动检测API", tags=["异动检测"])
async def detect_anomaly_legacy():
    """传统异动检测API - 兼容原有前端调用"""
    try:
        # 导入交易时间检测函数
        from core.anomaly_detection import is_trading_time, get_trading_time_segments
        
        # 删除交易时间检查，始终获取真实数据
        logger.info("🚀 开始获取真实异动数据...")
        
        if not anomaly_engine:
            return {"error": "异动检测引擎未初始化"}
        
        # 获取监控的股票代码列表
        codes = list(dynamic_stock_codes) if dynamic_stock_codes else []
        if not codes:
            return {
                "status": "success", 
                "anomalies": [],
                "total_count": 0,
                "strong_stocks_count": 0,
                "trading_status": "open",
                "message": "暂无监控股票",
                "current_time": datetime.now().strftime("%H:%M:%S"),
                "trading_segments": get_trading_time_segments(),
                "timestamp": datetime.now().isoformat()
            }
        
        # 获取实时数据
        realtime_data = await data_manager.get_realtime_data(codes)
        
        # 构建异动数据
        anomalies = []
        for code, data in realtime_data.items():
            if data:
                # 使用现有的强势股检测逻辑
                clean_code = data.get('code', code.replace('sh', '').replace('sz', ''))
                change_percent = data.get('change_percent', 0)
                turnover_rate = data.get('turnoverRate', 0)
                volume = data.get('volume', 0)
                amount = data.get('amount', 0)
                
                # 计算强势得分
                strength_score = 0
                anomaly_reasons = []
                
                # 涨幅异动
                if change_percent > 7:
                    strength_score += 100
                    anomaly_reasons.append(f"强势拉升 +{change_percent:.2f}%")
                elif change_percent > 4:
                    strength_score += 70
                    anomaly_reasons.append(f"大幅上涨 +{change_percent:.2f}%")
                elif change_percent > 2:
                    strength_score += 40
                    anomaly_reasons.append(f"明显上涨 +{change_percent:.2f}%")
                
                # 换手率异动
                if turnover_rate > 10:
                    strength_score += 60
                    anomaly_reasons.append(f"超高换手 {turnover_rate:.2f}%")
                elif turnover_rate > 5:
                    strength_score += 40
                    anomaly_reasons.append(f"高换手 {turnover_rate:.2f}%")
                
                # 如果强势得分足够高，添加为异动
                if strength_score >= 60:
                    confidence = min(strength_score / 200, 0.95)
                    anomaly_type = "强势拉升" if strength_score >= 100 else "明显异动"
                    
                    anomaly_item = {
                        'stock_code': clean_code,
                        'stock_name': data.get('name', ''),
                        'anomaly_type': anomaly_type,
                        'confidence': confidence,
                        'strength_score': strength_score,
                        'reasons': anomaly_reasons,
                        'timestamp': datetime.now().isoformat(),
                        'details': {
                            'volume_ratio': turnover_rate / 2.0,
                            'price_change': change_percent / 100,
                            'amount': amount,
                            'recent_speed': change_percent / 10.0,
                            'turnover_rate': turnover_rate,
                            'volume': volume
                        }
                    }
                    anomalies.append(anomaly_item)
        
        # 按强势评分排序异动数据
        anomalies.sort(key=lambda x: x.get('strength_score', 0), reverse=True)
        
        # 将异动数据添加到时间段管理器中
        if anomaly_engine and hasattr(anomaly_engine, 'time_segment_manager'):
            from core.anomaly_detection import AnomalyPoint, AnomalyType, TimeSegment
            current_time = datetime.now()
            
            # 根据交易时间生成合理的时间段
            trading_segments = get_trading_time_segments()
            segment_count = len(trading_segments)
            
            logger.info(f"📅 将在 {segment_count} 个交易时间段中分配异动数据: {trading_segments}")
            
            for i, anomaly_data in enumerate(anomalies):
                # 将异动分配到对应的交易时间段
                segment_index = i % segment_count if segment_count > 0 else 0
                target_time_str = trading_segments[segment_index] if segment_count > 0 else "09:30"
                
                # 解析时间段字符串为具体时间
                hour, minute = map(int, target_time_str.split(':'))
                target_time = current_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
                
                try:
                    anomaly_point = AnomalyPoint(
                        timestamp=target_time,
                        price=anomaly_data.get('details', {}).get('price_change', 0) * 100 + 10,
                        change_percent=anomaly_data.get('details', {}).get('price_change', 0) * 100,
                        volume=anomaly_data.get('details', {}).get('volume', 0),
                        speed=anomaly_data.get('strength_score', 0),
                        anomaly_type=AnomalyType.PRICE_SURGE,
                        stock_info={
                            'code': anomaly_data.get('stock_code', ''),
                            'name': anomaly_data.get('stock_name', ''),
                            'confidence': anomaly_data.get('confidence', 0)
                        }
                    )
                    
                    anomaly_engine.time_segment_manager.add_anomaly(anomaly_point)
                    
                except Exception as e:
                    logger.warning(f"添加异动点到时间段管理器失败: {e}")
                    continue
            
            logger.info(f"📅 已将 {len(anomalies)} 个异动分配到 {segment_count} 个交易时间段")
            
        return {
            "status": "success", 
            "anomalies": anomalies,
            "total_count": len(anomalies),
            "strong_stocks_count": len([a for a in anomalies if a.get('strength_score', 0) > 70]),
            "trading_status": "open",
            "current_time": datetime.now().strftime("%H:%M:%S"),
            "trading_segments": get_trading_time_segments(),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"异动检测失败: {e}")
        return {"error": f"异动检测失败: {str(e)}"}

# 已删除模拟数据生成函数，始终使用真实数据

def get_next_trading_time() -> str:
    """获取下一个交易时间"""
    now = datetime.now()
    current_time = now.time()
    
    # 检查今天的交易时间
    if current_time < time(9, 30):
        return "今日 09:30"
    elif time(11, 30) < current_time < time(13, 0):
        return "今日 13:00"
    elif current_time > time(15, 0):
        # 明天的交易时间
        next_day = now + timedelta(days=1)
        # 跳过周末
        while next_day.weekday() >= 5:
            next_day += timedelta(days=1)
        return f"{next_day.strftime('%m月%d日')} 09:30"
    else:
        return "交易中"


@app.get("/api/anomaly/hot-sectors")
async def get_hot_sectors(sort_by: str = "hot_score", limit: int = 10):
    """获取热门板块（使用真实市场概念板块数据）"""
    try:
        print("🔥 正在获取真实概念板块数据...")
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 获取真实的概念板块数据
        sectors = await data_manager.get_concept_sectors(limit)
        
        if not sectors:
            print("⚠️ 获取概念板块失败，返回空数据")
            return {
                "sectors": [],
                "total_sectors": 0,
                "sort_by": sort_by,
                "timestamp": datetime.now().isoformat(),
                "summary": {
                    "avg_hot_score": 0,
                    "total_anomaly_stocks": 0,
                    "most_active_sector": None
                }
            }
        
        # 根据排序方式重新排序
        if sort_by == "avg_change":
            sectors.sort(key=lambda x: x['avg_change'], reverse=True)
        elif sort_by == "total_amount":
            sectors.sort(key=lambda x: x['total_amount'], reverse=True)
        elif sort_by == "anomaly_count":
            sectors.sort(key=lambda x: x['anomaly_count'], reverse=True)
        else:
            # 默认按综合热度排序（已经在数据源中排序过）
            pass
        
        # 设置排名
        for i, sector in enumerate(sectors[:limit]):
            sector['rank'] = i + 1
        
        # 限制返回数量
        limited_sectors = sectors[:limit]
        
        return {
            "sectors": limited_sectors,
            "total_sectors": len(sectors),
            "sort_by": sort_by,
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "avg_hot_score": round(sum(s['hot_score'] for s in limited_sectors) / max(len(limited_sectors), 1), 1),
                "total_anomaly_stocks": sum(s['anomaly_count'] for s in limited_sectors),
                "most_active_sector": limited_sectors[0]['sector_name'] if limited_sectors else None
            }
        }
        
    except Exception as e:
        logger.error(f"获取热门板块失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取热门板块失败: {str(e)}")


@app.get("/api/anomaly/sector-stocks/{sector_name}")
async def get_sector_stocks(sector_name: str, limit: int = 200):
    """获取指定概念板块的成分股信息"""
    try:
        print(f"🔍 正在获取 {sector_name} 板块成分股...")
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 获取板块成分股数据
        stocks = await data_manager.get_sector_stocks(sector_name, limit)
        
        if not stocks:
            return {
                "sector_name": sector_name,
                "stocks": [],
                "leader_stocks": [],
                "total_stocks": 0,
                "timestamp": datetime.now().isoformat(),
                "summary": {
                    "avg_change": 0,
                    "total_market_value": 0,
                    "leader_count": 0
                }
            }
        
        # 分离龙头股和普通股
        leader_stocks = [s for s in stocks if s.get('is_leader', False)]
        normal_stocks = [s for s in stocks if not s.get('is_leader', False)]
        
        # 计算板块汇总信息
        avg_change = round(sum(s['change_percent'] for s in stocks) / len(stocks), 2)
        total_market_value = sum(s['market_value'] for s in stocks)
        
        return {
            "sector_name": sector_name,
            "stocks": stocks,
            "leader_stocks": leader_stocks,
            "normal_stocks": normal_stocks,
            "total_stocks": len(stocks),
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "avg_change": avg_change,
                "total_market_value": int(total_market_value),
                "leader_count": len(leader_stocks),
                "up_stocks": len([s for s in stocks if s['change_percent'] > 0]),
                "down_stocks": len([s for s in stocks if s['change_percent'] < 0]),
                "flat_stocks": len([s for s in stocks if s['change_percent'] == 0])
            }
        }
        
    except Exception as e:
        logger.error(f"获取板块成分股失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取板块成分股失败: {str(e)}")


@app.get("/api/stocks/{stock_code}/realtime")
async def get_realtime_data(stock_code: str):
    """获取股票实时数据"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 格式化股票代码
        if not stock_code.startswith(('sh', 'sz')):
            if stock_code.startswith('6'):
                stock_code = 'sh' + stock_code
            else:
                stock_code = 'sz' + stock_code
        
        data = await data_manager.get_realtime_data([stock_code])
        
        if stock_code in data:
            return {
                "code": stock_code,
                "data": data[stock_code],
                "timestamp": data[stock_code].get('update_time')
            }
        else:
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的数据")
            
    except Exception as e:
        logger.error(f"获取实时数据失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取实时数据失败: {str(e)}")


@app.get("/api/stocks/{stock_code}/kline")
async def get_kline_data(stock_code: str, period: str = "daily", limit: int = 100):
    """获取K线数据"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 获取K线数据
        kline_data = await data_manager.get_kline_data(stock_code, period, limit)
        
        if kline_data and 'klines' in kline_data:
            return {
                "code": stock_code,
                "name": kline_data.get('name', ''),
                "period": period,
                "klines": kline_data['klines'],
                "timestamp": datetime.now().isoformat()
            }
        else:
            raise HTTPException(
                status_code=404, 
                detail=f"未找到股票 {stock_code} 的K线数据，可能是网络超时或数据源暂不可用"
            )
            
    except HTTPException:
        # 重新抛出HTTP异常
        raise
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504, 
            detail=f"获取股票 {stock_code} K线数据超时，请稍后重试"
        )
    except Exception as e:
        logger.error(f"获取K线数据失败: {e}")
        error_msg = str(e)
        if "TimeoutError" in error_msg or "timeout" in error_msg.lower():
            raise HTTPException(
                status_code=504, 
                detail=f"网络请求超时，无法获取股票 {stock_code} 的K线数据，请稍后重试"
            )
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"获取股票 {stock_code} K线数据失败: {error_msg}"
            )


@app.get("/api/kline/{stock_code}")
async def get_kline_data_simple(stock_code: str, period: str = "daily", limit: int = 100):
    """获取K线数据（简化路由）"""
    return await get_kline_data(stock_code, period, limit)


@app.get("/api/stocks/{stock_code}/minute")
async def get_minute_data(stock_code: str):
    """获取分时数据"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 检查是否为交易时间
        current_time = datetime.now().time()
        is_trading_hours = (
            (time(9, 30) <= current_time <= time(11, 30)) or 
            (time(13, 0) <= current_time <= time(15, 0))
        )
        
        # 统一兜底获取（前缀重试 + 模拟分时 + TTL缓存）
        cached = await cache_manager.get_stock_minute_data(stock_code)
        if cached:
            minute_data = {
                'code': stock_code,
                'name': '',
                'minute_data': cached
            }
        else:
            minute_data = await _fetch_minute_data_with_fallback(stock_code)
            if minute_data and minute_data.get('minute_data'):
                await cache_manager.set_stock_minute_data(stock_code, minute_data['minute_data'])
        
        if minute_data and minute_data.get('minute_data'):
            return {
                "code": stock_code,
                "name": minute_data.get('name', ''),
                "minute_data": minute_data['minute_data'],
                "yesterday_close": minute_data.get('yesterday_close'),
                "timestamp": datetime.now().isoformat()
            }
        else:
            # 提供更详细的错误信息
            if not is_trading_hours:
                raise HTTPException(
                    status_code=503, 
                    detail=f"当前非交易时间({current_time.strftime('%H:%M')}），无法获取股票 {stock_code} 的实时分时数据。交易时间：9:30-11:30, 13:00-15:00"
                )
            else:
                raise HTTPException(
                    status_code=404, 
                    detail=f"未找到股票 {stock_code} 的分时数据，可能是网络超时或数据源暂不可用"
                )
            
    except HTTPException:
        # 重新抛出HTTP异常
        raise
    except asyncio.TimeoutError:
        current_time = datetime.now().time()
        raise HTTPException(
            status_code=504, 
            detail=f"获取股票 {stock_code} 数据超时，当前时间：{current_time.strftime('%H:%M')}，请稍后重试"
        )
    except Exception as e:
        logger.error(f"获取分时数据完全失败: {e}")
        error_msg = str(e)
        if "TimeoutError" in error_msg or "timeout" in error_msg.lower():
            raise HTTPException(
                status_code=504, 
                detail=f"网络请求超时，无法获取股票 {stock_code} 的数据，请稍后重试"
            )
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"获取股票 {stock_code} 分时数据失败: {error_msg}"
            )


@app.get("/api/stocks/{stock_code}/timeshare")
async def get_timeshare_data(stock_code: str):
    """获取分时图数据（新增API）"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 格式化股票代码
        if not stock_code.startswith(('sh', 'sz')):
            if stock_code.startswith('6'):
                stock_code = 'sh' + stock_code
            else:
                stock_code = 'sz' + stock_code
        
        # 获取分时数据（带兜底 + TTL缓存）
        cached = await cache_manager.get_stock_minute_data(stock_code)
        if cached:
            minute_data = {
                'code': stock_code,
                'name': '',
                'minute_data': cached
            }
        else:
            minute_data = await _fetch_minute_data_with_fallback(stock_code)
            if minute_data and minute_data.get('minute_data'):
                await cache_manager.set_stock_minute_data(stock_code, minute_data['minute_data'])
        
        if minute_data and minute_data.get('minute_data'):
            # 获取股票基本信息
            realtime_data = await data_manager.get_realtime_data([stock_code])
            stock_info = realtime_data.get(stock_code, {})
            
            # 计算分时图所需的额外数据
            timeshare_data = []
            total_volume = 0
            total_amount = 0
            
            # 优先使用实时数据中的昨收价，其次使用分时数据中的昨收价
            yesterday_close = stock_info.get('yesterday_close', 0)
            if yesterday_close == 0:
                yesterday_close = minute_data.get('yesterday_close', 0)
            # 如果都没有，使用开盘价作为参考（但这种情况应该避免）
            if yesterday_close == 0 and stock_info.get('open_price', 0) > 0:
                yesterday_close = stock_info.get('open_price', 0)
                logger.warning(f"股票 {stock_code} 无法获取昨收价，使用开盘价 {yesterday_close} 作为参考")
            
            for item in minute_data['minute_data']:
                price = item.get('price', 0)
                volume = item.get('volume', 0)
                amount = item.get('amount', 0)
                
                total_volume += volume
                total_amount += amount
                
                # 计算涨跌幅
                change_percent = 0
                if yesterday_close > 0:
                    change_percent = ((price - yesterday_close) / yesterday_close) * 100
                
                timeshare_data.append({
                    'time': item.get('time', ''),
                    'price': price,
                    'volume': volume,
                    'amount': amount,
                    'avgPrice': item.get('avgPrice', price),
                    'changePercent': round(change_percent, 2)
                })
            
            return {
                "code": stock_code,
                "name": minute_data.get('name', stock_info.get('name', '')),
                "timeshare_data": timeshare_data,
                "yesterday_close": yesterday_close,
                "open_price": stock_info.get('open_price', 0),
                "high_price": stock_info.get('high_price', 0),
                "low_price": stock_info.get('low_price', 0),
                "current_price": stock_info.get('current_price', 0),
                "total_volume": total_volume,
                "total_amount": total_amount,
                "change_amount": stock_info.get('change', 0),
                "change_percent": stock_info.get('change_percent', 0),
                "timestamp": datetime.now().isoformat()
            }
        else:
            raise HTTPException(
                status_code=404, 
                detail=f"未找到股票 {stock_code} 的分时数据"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取分时图数据失败: {e}")
        raise HTTPException(
            status_code=500, 
            detail=f"获取股票 {stock_code} 分时图数据失败: {str(e)}"
        )


def generate_mock_realtime_minute_data(stock_code: str):
    """生成当日实时模拟分时数据"""
    minute_points = []
    
    # 获取基础价格
    clean_code = stock_code.replace('sh', '').replace('sz', '')
    seed = int(clean_code[:3]) if clean_code.isdigit() else 100
    base_price = 10.0 + (seed % 50) * 0.5
    
    current_price = base_price
    total_amount = 0
    total_volume = 0
    
    # 生成当日交易时间的分时数据
    import random
    random.seed(seed)
    
    # 上午时段 9:30-11:30 (120分钟)
    for hour in range(9, 12):
        start_min = 30 if hour == 9 else 0
        end_min = 30 if hour == 11 else 60
        
        for minute in range(start_min, end_min):
            if hour == 11 and minute >= 30:
                break
                
            time_str = f"{hour:02d}:{minute:02d}"
            
            # 价格小幅波动
            change = random.uniform(-0.015, 0.015)  # ±1.5%
            current_price = max(0.1, current_price * (1 + change))
            
            volume = random.randint(1000, 10000)
            amount = current_price * volume
            total_amount += amount
            total_volume += volume
            
            avg_price = total_amount / total_volume if total_volume > 0 else current_price
            
            minute_points.append({
                'time': time_str,
                'price': round(current_price, 2),
                'volume': volume,
                'amount': round(amount, 2),
                'avgPrice': round(avg_price, 2)
            })
    
    # 下午时段 13:00-15:00 (120分钟)
    for hour in range(13, 15):
        for minute in range(0, 60):
            time_str = f"{hour:02d}:{minute:02d}"
            
            # 价格小幅波动
            change = random.uniform(-0.015, 0.015)  # ±1.5%
            current_price = max(0.1, current_price * (1 + change))
            
            volume = random.randint(1000, 10000)
            amount = current_price * volume
            total_amount += amount
            total_volume += volume
            
            avg_price = total_amount / total_volume if total_volume > 0 else current_price
            
            minute_points.append({
                'time': time_str,
                'price': round(current_price, 2),
                'volume': volume,
                'amount': round(amount, 2),
                'avgPrice': round(avg_price, 2)
            })
    
    # 15:00 收盘
    time_str = "15:00"
    change = random.uniform(-0.01, 0.01)  # 收盘时小幅波动
    current_price = max(0.1, current_price * (1 + change))
    volume = random.randint(1000, 10000)
    amount = current_price * volume
    total_amount += amount
    total_volume += volume
    avg_price = total_amount / total_volume if total_volume > 0 else current_price
    
    minute_points.append({
        'time': time_str,
        'price': round(current_price, 2),
        'volume': volume,
        'amount': round(amount, 2),
        'avgPrice': round(avg_price, 2)
    })
    
    print(f"✅ 生成模拟分时数据: {stock_code} - {len(minute_points)}个数据点 - 价格范围 {minute_points[0]['price']:.2f} ~ {minute_points[-1]['price']:.2f}")
    
    return minute_points


async def _infer_prefixed_code(code: str) -> str:
    """根据股票代码推断并补全交易所前缀。"""
    if code.startswith(("sh", "sz")):
        return code
    if code.startswith("6"):
        return f"sh{code}"
    return f"sz{code}"


async def _fetch_minute_data_with_fallback(stock_code: str):
    """获取分时数据：原始代码 -> 补前缀 -> 使用本地模拟分时兜底。"""
    global data_manager
    # 1) 直接尝试
    try:
        data = await data_manager.get_minute_data(stock_code)
        if data and data.get("minute_data"):
            return data
    except Exception:
        pass

    # 2) 前缀重试
    prefixed = await _infer_prefixed_code(stock_code)
    try:
        data = await data_manager.get_minute_data(prefixed)
        if data and data.get("minute_data"):
            return data
    except Exception:
        pass

    # 3) 兜底：本地模拟分时
    try:
        points = generate_mock_realtime_minute_data(prefixed)
        return {
            "code": prefixed,
            "name": f"股票{prefixed.replace('sh','').replace('sz','')}",
            "minute_data": points,
            "yesterday_close": points[0]["price"] if points else 0
        }
    except Exception:
        return {}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket连接 - 实时推送数据"""
    await websocket.accept()
    connected_clients.add(websocket)
    
    try:
        while True:
            # 等待客户端消息（保持连接）
            await websocket.receive_text()
    except WebSocketDisconnect:
        connected_clients.remove(websocket)


async def update_monitoring_stocks():
    """动态更新监控股票列表 - 基于热门板块成分股"""
    global dynamic_stock_codes, last_sector_update, data_manager, config
    
    try:
        current_time = datetime.now()
        
        # 从配置中获取更新间隔
        update_interval = sector_update_interval
        if config and 'monitoring' in config:
            update_interval = config['monitoring'].get('update_intervals', {}).get('hot_sectors', 600)
        
        # 检查是否需要更新
        if (current_time - last_sector_update).total_seconds() < update_interval:
            return
        
        if not data_manager:
            return
            
        logger.info("🔥 开始更新热门板块监控股票列表...")
        
        # 1. 获取热门板块（获取更多数据以便智能筛选）
        hot_sectors = await data_manager.get_concept_sectors(limit=20)
        
        if not hot_sectors:
            logger.warning("⚠️ 未获取到热门板块数据，保持原有监控列表")
            return
        
        # 2. 智能筛选真正的强势板块
        qualified_sectors = []
        for sector in hot_sectors:
            sector_name = sector.get('sector_name', '')
            avg_change = sector.get('avg_change', 0)
            hot_score = sector.get('hot_score', 0)
            up_count = sector.get('up_count', 0)
            total_count = sector.get('stock_count', 1)
            total_amount = sector.get('total_amount', 0)
            
            # 优化的强势板块筛选条件（降低门槛，提高捕获率）
            is_qualified = (
                # 基础条件：涨幅大于0.3%且热度大于20（放宽条件）
                avg_change > 0.3 and hot_score > 20 and
                # 参与度条件：上涨股数比例大于30%（降低要求）
                (up_count / max(total_count, 1)) > 0.3 and
                # 成交活跃度：成交额超过10亿（大幅降低要求）
                total_amount > 1000000000 and
                # 板块规模：至少有3只股票（降低要求）
                total_count >= 3
            )
            
            # 备选条件：如果不满足严格条件，但满足以下任一条件也算合格
            backup_qualified = (
                # 高涨幅板块，即使其他条件不满足
                avg_change > 2.0 or
                # 高热度板块，即使涨幅不大
                hot_score > 50 or
                # 大成交额板块，即使涨幅不大
                total_amount > 5000000000
            )
            
            if is_qualified or backup_qualified:
                qualified_sectors.append(sector)
                logger.info(f"🔥 合格板块: {sector_name} - 涨幅{avg_change:.2f}% - 热度{hot_score} - 成交额{total_amount/100000000:.1f}亿")
        
        # 3. 收集新的监控股票（不再包含基础监控股票）
        new_monitoring_stocks = set()  # 从空集合开始，只包含用户自选和热门板块股票
        
        # 添加用户自选股到监控列表
        if config and 'user_customization' in config:
            user_favorites = config['user_customization'].get('自定义监控', {}).get('自选股票池', [])
            for favorite_code in user_favorites:
                # 格式化股票代码 - 沪市(6开头包含主板和科创板)、深市(0xx/3xx/2xx)
                if favorite_code.startswith('6'):  # 沪市主板(60x)和科创板(688)
                    formatted_code = f'sh{favorite_code}'
                elif favorite_code.startswith(('0', '3', '2')):  # 深市
                    formatted_code = f'sz{favorite_code}'
                else:
                    formatted_code = favorite_code
                new_monitoring_stocks.add(formatted_code)
            
            if user_favorites:
                logger.info(f"📌 添加 {len(user_favorites)} 只自选股到监控列表: {user_favorites}")
                # 显示格式化后的代码用于调试
                formatted_favorites = []
                for code in user_favorites:
                    if code.startswith('6'):  # 沪市
                        formatted_favorites.append(f'sh{code}')
                    elif code.startswith(('0', '3', '2')):  # 深市
                        formatted_favorites.append(f'sz{code}')
                    else:
                        formatted_favorites.append(code)
                logger.info(f"📌 格式化后的监控代码: {formatted_favorites}")
        
        sector_stocks_summary = []
        
        # 优先处理最强势的板块（最多8个板块）
        for sector in qualified_sectors[:8]:
            sector_name = sector.get('sector_name', '')
            sector_change = sector.get('avg_change', 0)
            
            if not sector_name:
                continue
                
            # 获取板块成分股（每个板块取前15只，增加覆盖面）
            stocks = await data_manager.get_sector_stocks(sector_name, limit=15)
            
            if stocks:
                # 多层级股票筛选策略
                priority_stocks = []
                
                for stock in stocks:
                    stock_code = stock.get('stock_code', '')
                    change_percent = stock.get('change_percent', 0)
                    is_leader = stock.get('is_leader', False)
                    turnover_rate = stock.get('turnover_rate', 0)
                    market_value = stock.get('market_value', 0)
                    
                    if not stock_code:
                        continue
                    
                    # 格式化为标准格式 (sh600000, sz000001)
                    if stock_code.startswith('6'):
                        formatted_code = f'sh{stock_code}'
                    else:
                        formatted_code = f'sz{stock_code}'
                    
                    # 计算股票强势评分
                    strength_score = 0
                    
                    # 龙头股加分
                    if is_leader:
                        strength_score += 50
                    
                    # 涨幅评分
                    if change_percent > 5:
                        strength_score += 40
                    elif change_percent > 2:
                        strength_score += 30
                    elif change_percent > 0.5:
                        strength_score += 20
                    
                    # 换手率评分（活跃度）
                    if turnover_rate > 5:
                        strength_score += 30
                    elif turnover_rate > 2:
                        strength_score += 20
                    elif turnover_rate > 1:
                        strength_score += 10
                    
                    # 市值评分（避免小盘操控）
                    if market_value > 100000000:  # 10亿以上
                        strength_score += 10
                    
                    # 强势股筛选条件
                    if (strength_score >= 60 or  # 综合评分高
                        is_leader or             # 龙头股
                        change_percent > 3.0 or  # 大涨个股  
                        (change_percent > 1.0 and turnover_rate > 3.0)):  # 温和上涨但换手活跃
                        
                        priority_stocks.append((formatted_code, change_percent, strength_score, is_leader))
                
                # 按强势评分排序
                priority_stocks.sort(key=lambda x: (x[2], x[1]), reverse=True)
                
                # 每个板块选择前8只最强势的股票
                added_count = 0
                for stock_code, change_percent, score, is_leader in priority_stocks[:8]:
                    new_monitoring_stocks.add(stock_code)
                    added_count += 1
                
                sector_stocks_summary.append({
                    'sector': sector_name,
                    'change': sector_change,
                    'added_stocks': added_count,
                    'total_stocks': len(stocks),
                    'qualified_stocks': len(priority_stocks)
                })
        
        # 4. 更新全局监控列表
        old_count = len(dynamic_stock_codes)
        dynamic_stock_codes = new_monitoring_stocks
        new_count = len(dynamic_stock_codes)
        
        last_sector_update = current_time
        
        # 5. 输出更新报告
        logger.info(f"✅ 监控股票列表已更新: {old_count} -> {new_count} 只股票")
        logger.info(f"📊 筛选出 {len(qualified_sectors)} 个强势板块:")
        
        for summary in sector_stocks_summary:
            logger.info(f"  🔥 {summary['sector']} (+{summary['change']:.2f}%) - 监控 {summary['added_stocks']}/{summary['qualified_stocks']} 只强势股")
        
        # 显示新增的监控股票（相比上次更新）
        if new_monitoring_stocks:
            logger.info(f"🆕 当前监控股票 ({len(new_monitoring_stocks)}只): {', '.join(list(new_monitoring_stocks)[:15])}...")
        
    except Exception as e:
        logger.error(f"❌ 更新监控股票列表失败: {e}")


async def real_time_monitoring():
    """实时监控任务"""
    global monitoring_results, data_manager, config, connected_clients, dynamic_stock_codes
    
    logger.info("启动实时异动监控...")
    
    while True:
        try:
            # 检查服务是否初始化
            if not data_manager:
                await asyncio.sleep(5)
                continue
            
            # 动态更新监控股票列表
            await update_monitoring_stocks()
                
            # 获取实时数据
            realtime_data = await data_manager.get_realtime_data(list(dynamic_stock_codes))
            
            # 强势票检测算法
            anomalies = []
            stock_updates = []
            strong_stocks = []  # 强势股列表
            
            for code, data in realtime_data.items():
                if data:
                    # 构建股票更新数据 - WebSocket推送格式（与自选股API一致的完整格式，同时保持前端兼容性）
                    clean_code = code.replace('sh', '').replace('sz', '')
                    
                    stock_update = {
                        'code': clean_code,
                        'name': data.get('name', ''),
                        # 新格式字段（与自选股API一致）
                        'current_price': data.get('current_price', 0),
                        'change': data.get('change', 0),
                        'change_percent': data.get('change_percent', 0),
                        'volume': data.get('volume', 0),
                        'amount': data.get('amount', 0),
                        'high_price': data.get('high_price', 0),
                        'low_price': data.get('low_price', 0),
                        'open_price': data.get('open_price', 0),
                        'yesterday_close': data.get('yesterday_close', 0),
                        'turnover_rate': data.get('turnoverRate', 0),
                        'market': 'SH' if clean_code.startswith('6') else 'SZ',
                        'update_time': data.get('update_time', ''),
                        'is_active': True,
                        # 兼容性字段（前端期望的字段名）
                        'price': data.get('current_price', 0),  # 兼容前端
                        'changePercent': data.get('change_percent', 0),  # 兼容前端
                        'turnoverRate': data.get('turnoverRate', 0),  # 兼容前端
                        'high': data.get('high_price', 0),  # 兼容前端
                        'low': data.get('low_price', 0)  # 兼容前端
                    }
                    
                    # 计算当日振幅
                    if stock_update['high_price'] > 0 and stock_update['low_price'] > 0 and stock_update['yesterday_close'] > 0:
                        amplitude = ((stock_update['high_price'] - stock_update['low_price']) / stock_update['yesterday_close']) * 100
                        stock_update['amplitude'] = round(amplitude, 2)
                    else:
                        stock_update['amplitude'] = 0
                    
                    # 计算市值（简化版）
                    if stock_update['current_price'] > 0:
                        estimated_shares = {
                            '000001': 19405918000,  # 平安银行
                            '300750': 4310894000,   # 宁德时代  
                            '002594': 2900000000,   # 比亚迪
                            '600519': 1256197000,   # 贵州茅台
                            '600036': 39169148000   # 招商银行
                        }.get(clean_code, 1000000000)  # 默认10亿股
                        
                        market_value = stock_update['current_price'] * estimated_shares / 100000000  # 转换为亿元
                        stock_update['market_value'] = round(market_value, 2)
                    else:
                        stock_update['market_value'] = 0
                    
                    stock_updates.append(stock_update)
                    
                    # 多维度强势股检测
                    change_percent = data.get('change_percent', 0)
                    turnover_rate = data.get('turnoverRate', 0)
                    volume = data.get('volume', 0)
                    amount = data.get('amount', 0)
                    current_price = data.get('current_price', 0)
                    high_price = data.get('high_price', 0)
                    low_price = data.get('low_price', 0)
                    
                    # 计算强势得分
                    strength_score = 0
                    anomaly_reasons = []
                    
                    # 1. 涨幅异动（权重最高）
                    if change_percent > 7:
                        strength_score += 100
                        anomaly_reasons.append(f"强势拉升 +{change_percent:.2f}%")
                    elif change_percent > 4:
                        strength_score += 70
                        anomaly_reasons.append(f"大幅上涨 +{change_percent:.2f}%")
                    elif change_percent > 2:
                        strength_score += 40
                        anomaly_reasons.append(f"明显上涨 +{change_percent:.2f}%")
                    elif change_percent > 0.8:
                        strength_score += 20
                        anomaly_reasons.append(f"温和上涨 +{change_percent:.2f}%")
                    
                    # 2. 换手率异动（活跃度）
                    if turnover_rate > 10:
                        strength_score += 60
                        anomaly_reasons.append(f"超高换手 {turnover_rate:.2f}%")
                    elif turnover_rate > 5:
                        strength_score += 40
                        anomaly_reasons.append(f"高换手 {turnover_rate:.2f}%")
                    elif turnover_rate > 2:
                        strength_score += 25
                        anomaly_reasons.append(f"活跃换手 {turnover_rate:.2f}%")
                    
                    # 3. 成交量异动
                    if volume > 0:
                        # 简单估算：如果成交量超过1000万股，视为大量
                        if volume > 10000000:
                            strength_score += 40
                            anomaly_reasons.append("巨量成交")
                        elif volume > 5000000:
                            strength_score += 25
                            anomaly_reasons.append("大量成交")
                        elif volume > 1000000:
                            strength_score += 15
                            anomaly_reasons.append("放量")
                    
                    # 4. 成交额异动（资金关注度）
                    if amount > 1000000000:  # 超过10亿
                        strength_score += 50
                        anomaly_reasons.append("资金巨量流入")
                    elif amount > 500000000:  # 超过5亿
                        strength_score += 30
                        anomaly_reasons.append("资金大量流入")
                    elif amount > 100000000:  # 超过1亿
                        strength_score += 15
                        anomaly_reasons.append("资金流入")
                    
                    # 5. 价格形态分析
                    if high_price > 0 and low_price > 0 and current_price > 0:
                        # 计算当日振幅
                        amplitude = ((high_price - low_price) / low_price) * 100
                        # 计算收盘位置（越接近最高价越强势）
                        close_position = ((current_price - low_price) / (high_price - low_price)) * 100 if high_price != low_price else 50
                        
                        if close_position > 90 and change_percent > 1:
                            strength_score += 30
                            anomaly_reasons.append("强势收高")
                        elif close_position > 80 and change_percent > 0.5:
                            strength_score += 20
                            anomaly_reasons.append("偏强走势")
                        
                        if amplitude > 8:
                            strength_score += 15
                            anomaly_reasons.append(f"大幅震荡 {amplitude:.1f}%")
                    
                    # 6. 突破性判断（简化版）
                    if change_percent > 3 and turnover_rate > 3:
                        strength_score += 25
                        anomaly_reasons.append("量价齐升")
                    
                    # 根据强势得分判断是否为异动/强势股
                    confidence = min(strength_score / 200, 0.95)  # 标准化为置信度
                    
                    if strength_score >= 100:  # 高强势
                        anomaly_type = "强势拉升"
                        anomalies.append({
                            'stock_code': code.replace('sh', '').replace('sz', ''),
                            'stock_name': data.get('name', ''),
                            'anomaly_type': anomaly_type,
                            'confidence': confidence,
                            'strength_score': strength_score,
                            'timestamp': datetime.now().isoformat(),
                            'reasons': anomaly_reasons,
                            'details': {
                                'volume_ratio': turnover_rate / 2.0,
                                'price_change': change_percent / 100,
                                'amount': amount,
                                'recent_speed': change_percent / 10.0,
                                'turnover_rate': turnover_rate,
                                'volume': volume
                            }
                        })
                        strong_stocks.append({
                            'code': code,
                            'name': data.get('name', ''),
                            'change_percent': change_percent,
                            'strength_score': strength_score,
                            'reasons': anomaly_reasons
                        })
                    elif strength_score >= 60:  # 中等强势
                        anomaly_type = "温和异动"
                        anomalies.append({
                            'stock_code': code.replace('sh', '').replace('sz', ''),
                            'stock_name': data.get('name', ''),
                            'anomaly_type': anomaly_type,
                            'confidence': confidence,
                            'strength_score': strength_score,
                            'timestamp': datetime.now().isoformat(),
                            'reasons': anomaly_reasons,
                            'details': {
                                'volume_ratio': turnover_rate / 2.0,
                                'price_change': change_percent / 100,
                                'amount': amount,
                                'recent_speed': change_percent / 10.0,
                                'turnover_rate': turnover_rate,
                                'volume': volume
                            }
                        })
            
            # 推送数据到所有连接的客户端
            if connected_clients:
                # 推送股票更新
                stock_message = {
                    'type': 'stock_update',
                    'data': stock_updates
                }
                await broadcast_message(stock_message)
                
                # 推送异动数据（优先推送强势股）
                if anomalies:
                    # 按强势得分排序
                    sorted_anomalies = sorted(anomalies, key=lambda x: x.get('strength_score', 0), reverse=True)
                    
                    for anomaly in sorted_anomalies[:10]:  # 只推送前10个最强势的
                        anomaly_message = {
                            'type': 'anomaly',
                            'data': anomaly
                        }
                        await broadcast_message(anomaly_message)
                
                # 推送热门板块（每分钟一次）
                import random
                if random.randint(1, 4) == 1:  # 25%概率推送
                    hot_sectors_data = await get_hot_sectors()
                    hot_sectors_message = {
                        'type': 'hot_sectors',
                        'data': hot_sectors_data
                    }
                    await broadcast_message(hot_sectors_message)
            
            # 输出强势股发现报告
            if strong_stocks:
                logger.info(f"🚀 发现 {len(strong_stocks)} 只强势股:")
                for stock in sorted(strong_stocks, key=lambda x: x['strength_score'], reverse=True)[:5]:
                    reasons_str = " | ".join(stock['reasons'][:2])  # 显示前2个原因
                    logger.info(f"  💎 {stock['name']} (+{stock['change_percent']:.2f}%) - {reasons_str}")
            
            monitoring_results = {
                'last_update': datetime.now().isoformat(),
                'stocks_count': len(stock_updates),
                'anomalies_count': len(anomalies),
                'strong_stocks_count': len(strong_stocks),
                'latest_anomalies': sorted(anomalies, key=lambda x: x.get('strength_score', 0), reverse=True)[:5]
            }
            
            # 等待下次监控
            interval = 8  # 优化：默认8秒
            if config and 'monitoring' in config:
                interval = config['monitoring'].get('update_intervals', {}).get('realtime_data', 8)
            await asyncio.sleep(interval)
            
        except asyncio.CancelledError:
            logger.info("实时监控任务被取消")
            break
        except Exception as e:
            logger.error(f"实时监控错误: {e}")
            await asyncio.sleep(10)


async def broadcast_message(message: dict):
    """广播消息给所有连接的客户端"""
    global connected_clients
    
    if connected_clients:
        disconnected_clients = set()
        for client in connected_clients:
            try:
                await client.send_text(json.dumps(message, ensure_ascii=False))
            except:
                disconnected_clients.add(client)
        
        # 移除断开的客户端
        connected_clients -= disconnected_clients


@app.post("/api/alert")
async def send_alert(alert: AlertRequest):
    """发送预警"""
    try:
        logger.info(f"预警: {alert.stock_code} - {alert.alert_type} - {alert.message}")
        
        # 广播预警消息
        alert_message = {
            'type': 'alert',
            'data': {
                'stock_code': alert.stock_code,
                'alert_type': alert.alert_type,
                'message': alert.message,
                'timestamp': datetime.now().isoformat()
            }
        }
        await broadcast_message(alert_message)
        
        return {
            "message": "预警已发送",
            "alert": alert.dict()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"发送预警失败: {str(e)}")


@app.get("/api/anomaly/strong-stocks")
async def get_strong_stocks(sort_by: str = "strength_score", limit: int = 20):
    """获取强势股排行榜"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 获取当前监控的所有股票实时数据
        realtime_data = await data_manager.get_realtime_data(list(dynamic_stock_codes))
        
        strong_stocks = []
        
        for code, data in realtime_data.items():
            if not data:
                continue
                
            # 多维度强势分析
            change_percent = data.get('change_percent', 0)
            turnover_rate = data.get('turnoverRate', 0)
            volume = data.get('volume', 0)
            amount = data.get('amount', 0)
            current_price = data.get('current_price', 0)
            high_price = data.get('high_price', 0)
            low_price = data.get('low_price', 0)
            
            # 计算强势得分（与实时监控相同的算法）
            strength_score = 0
            strength_reasons = []
            risk_level = "低"
            
            # 涨幅评分
            if change_percent > 7:
                strength_score += 100
                strength_reasons.append("强势拉升")
                risk_level = "高"
            elif change_percent > 4:
                strength_score += 70
                strength_reasons.append("大幅上涨")
                risk_level = "中高"
            elif change_percent > 2:
                strength_score += 40
                strength_reasons.append("明显上涨")
                risk_level = "中"
            elif change_percent > 0.8:
                strength_score += 20
                strength_reasons.append("温和上涨")
            
            # 换手率评分
            if turnover_rate > 10:
                strength_score += 60
                strength_reasons.append("超高换手")
            elif turnover_rate > 5:
                strength_score += 40
                strength_reasons.append("高换手")
            elif turnover_rate > 2:
                strength_score += 25
                strength_reasons.append("活跃换手")
            
            # 成交额评分
            if amount > 1000000000:
                strength_score += 50
                strength_reasons.append("巨额资金")
            elif amount > 500000000:
                strength_score += 30
                strength_reasons.append("大额资金")
            elif amount > 100000000:
                strength_score += 15
                strength_reasons.append("资金关注")
            
            # 形态评分
            if high_price > 0 and low_price > 0 and current_price > 0:
                close_position = ((current_price - low_price) / (high_price - low_price)) * 100 if high_price != low_price else 50
                amplitude = ((high_price - low_price) / low_price) * 100
                
                if close_position > 90 and change_percent > 1:
                    strength_score += 30
                    strength_reasons.append("强势收高")
                elif close_position > 80:
                    strength_score += 20
                    strength_reasons.append("偏强走势")
                
                if amplitude > 8:
                    strength_score += 15
                    strength_reasons.append("震荡活跃")
            
            # 量价配合评分
            if change_percent > 3 and turnover_rate > 3:
                strength_score += 25
                strength_reasons.append("量价齐升")
            
            # 只保留有一定强势特征的股票
            if strength_score >= 30:  # 降低门槛以获取更多候选
                # 判断趋势状态
                if strength_score >= 100:
                    trend_status = "强势突破"
                elif strength_score >= 70:
                    trend_status = "加速上涨"
                elif strength_score >= 50:
                    trend_status = "稳步上升"
                else:
                    trend_status = "温和启动"
                
                # 计算建议操作
                if strength_score >= 80 and change_percent < 8:
                    suggestion = "关注买入"
                elif strength_score >= 60:
                    suggestion = "谨慎观察"
                elif change_percent > 8:
                    suggestion = "高位谨慎"
                else:
                    suggestion = "观察为主"
                
                strong_stocks.append({
                    'stock_code': code.replace('sh', '').replace('sz', ''),
                    'stock_name': data.get('name', ''),
                    'current_price': current_price,
                    'change_percent': change_percent,
                    'change_amount': data.get('change', 0),
                    'turnover_rate': turnover_rate,
                    'volume': volume,
                    'amount': amount,
                    'strength_score': strength_score,
                    'strength_reasons': strength_reasons,
                    'trend_status': trend_status,
                    'risk_level': risk_level,
                    'suggestion': suggestion,
                    'market': 'SH' if code.startswith('sh6') else 'SZ',
                    'sector_type': '主板' if code.startswith(('sh6', 'sz00')) else ('创业板' if code.startswith('sz30') else '科创板'),
                    'timestamp': datetime.now().isoformat()
                })
        
        # 排序
        if sort_by == "change_percent":
            strong_stocks.sort(key=lambda x: x['change_percent'], reverse=True)
        elif sort_by == "turnover_rate":
            strong_stocks.sort(key=lambda x: x['turnover_rate'], reverse=True)
        elif sort_by == "amount":
            strong_stocks.sort(key=lambda x: x['amount'], reverse=True)
        else:  # 默认按强势得分排序
            strong_stocks.sort(key=lambda x: x['strength_score'], reverse=True)
        
        # 限制返回数量
        limited_stocks = strong_stocks[:limit]
        
        # 分类统计
        high_strength = [s for s in limited_stocks if s['strength_score'] >= 80]
        medium_strength = [s for s in limited_stocks if 50 <= s['strength_score'] < 80]
        low_strength = [s for s in limited_stocks if 30 <= s['strength_score'] < 50]
        
        return {
            "strong_stocks": limited_stocks,
            "total_count": len(strong_stocks),
            "returned_count": len(limited_stocks),
            "sort_by": sort_by,
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "high_strength_count": len(high_strength),
                "medium_strength_count": len(medium_strength),
                "low_strength_count": len(low_strength),
                "avg_change_percent": round(sum(s['change_percent'] for s in limited_stocks) / max(len(limited_stocks), 1), 2),
                "max_strength_score": max([s['strength_score'] for s in limited_stocks]) if limited_stocks else 0,
                "total_amount": sum(s['amount'] for s in limited_stocks)
            },
            "categories": {
                "强势突破": [s for s in limited_stocks if s['trend_status'] == '强势突破'],
                "加速上涨": [s for s in limited_stocks if s['trend_status'] == '加速上涨'],  
                "稳步上升": [s for s in limited_stocks if s['trend_status'] == '稳步上升'],
                "温和启动": [s for s in limited_stocks if s['trend_status'] == '温和启动']
            }
        }
        
    except Exception as e:
        logger.error(f"获取强势股排行榜失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取强势股排行榜失败: {str(e)}")


@app.get("/api/anomaly/market-overview")
async def get_market_overview():
    """获取市场强势概览"""
    try:
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 获取强势股数据
        strong_stocks_response = await get_strong_stocks(limit=100)
        strong_stocks = strong_stocks_response["strong_stocks"]
        
        # 获取热门板块数据
        hot_sectors_response = await get_hot_sectors(limit=10)
        hot_sectors = hot_sectors_response["sectors"]
        
        # 市场强势分析
        total_monitoring = len(dynamic_stock_codes)
        strong_count = len(strong_stocks)
        strong_ratio = (strong_count / max(total_monitoring, 1)) * 100
        
        # 涨跌分析
        up_stocks = len([s for s in strong_stocks if s['change_percent'] > 0])
        flat_stocks = len([s for s in strong_stocks if s['change_percent'] == 0])
        down_stocks = len([s for s in strong_stocks if s['change_percent'] < 0])
        
        # 强势级别分布
        ultra_strong = len([s for s in strong_stocks if s['strength_score'] >= 100])
        high_strong = len([s for s in strong_stocks if 70 <= s['strength_score'] < 100])
        medium_strong = len([s for s in strong_stocks if 40 <= s['strength_score'] < 70])
        
        # 市场情绪判断
        if strong_ratio > 15 and ultra_strong > 5:
            market_sentiment = "极度活跃"
            sentiment_color = "#ff4444"
        elif strong_ratio > 8 and high_strong > 3:
            market_sentiment = "活跃向上"
            sentiment_color = "#ff8800"
        elif strong_ratio > 4:
            market_sentiment = "温和活跃"
            sentiment_color = "#ffaa00"
        elif strong_ratio > 1:
            market_sentiment = "平稳整理"
            sentiment_color = "#888888"
        else:
            market_sentiment = "相对平静"
            sentiment_color = "#666666"
        
        return {
            "market_sentiment": market_sentiment,
            "sentiment_color": sentiment_color,
            "total_monitoring": total_monitoring,
            "strong_stocks_count": strong_count,
            "strong_ratio": round(strong_ratio, 2),
            "distribution": {
                "up_stocks": up_stocks,
                "flat_stocks": flat_stocks,
                "down_stocks": down_stocks
            },
            "strength_levels": {
                "ultra_strong": ultra_strong,
                "high_strong": high_strong,
                "medium_strong": medium_strong
            },
            "top_strong_stocks": strong_stocks[:5],
            "hot_sectors_count": len(hot_sectors),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取市场概览失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取市场概览失败: {str(e)}")


def get_pinyin_initials(text: str) -> str:
    """获取中文字符串的拼音首字母"""
    if not text:
        return ""
    
    # 清理文本，只保留中文字符
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
    if not chinese_chars:
        return ""
    
    # 获取拼音首字母
    initials = []
    for char in chinese_chars:
        pinyin_list = lazy_pinyin(char, style=Style.FIRST_LETTER)
        if pinyin_list:
            initials.append(pinyin_list[0].lower())
    
    return ''.join(initials)


def get_full_pinyin(text: str) -> str:
    """获取中文字符串的完整拼音（无声调）"""
    if not text:
        return ""
    
    # 清理文本，只保留中文字符
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
    if not chinese_chars:
        return ""
    
    # 获取完整拼音
    pinyin_list = lazy_pinyin(''.join(chinese_chars), style=Style.NORMAL)
    return ''.join(pinyin_list).lower()


@app.get("/api/stocks/search")
async def search_stocks(q: str, limit: int = 10):
    """搜索股票（使用东方财富搜索API）"""
    try:
        if len(q) < 1:
            return {"stocks": [], "total": 0, "query": q, "search_type": "api"}
        
        # 使用全局的data_manager进行搜索
        if not data_manager:
            raise HTTPException(status_code=500, detail="数据管理器未初始化")
        
        # 调用东方财富搜索API
        search_results = await data_manager.search_stocks(q, limit)
        
        if search_results:
            # 清理返回数据，确保格式一致
            clean_matches = []
            for match in search_results:
                clean_match = {
                    'code': match.get('code', ''),
                    'name': match.get('name', ''),
                    'full_code': match.get('full_code', ''),
                    'market': match.get('market', 'SZ'),
                    'source': 'eastmoney_api'
                }
                # 如果有拼音信息，也包含进去
                if 'pinyin_initials' in match:
                    clean_match['pinyin_initials'] = match['pinyin_initials']
                clean_matches.append(clean_match)
            
            return {
                "stocks": clean_matches,
                "total": len(search_results),
                "query": q,
                "search_type": "api"
            }
        else:
            return {
                "stocks": [],
                "total": 0,
                "query": q,
                "search_type": "api",
                "message": "未找到相关股票"
            }
        
    except Exception as e:
        logger.error(f"搜索股票失败: {e}")
        # 如果搜索失败，返回友好的错误信息而不是抛出异常
        return {
            "stocks": [],
            "total": 0,
            "query": q,
            "search_type": "api",
            "error": f"搜索服务暂时不可用: {str(e)}"
        }


@app.get("/api/config/favorites")
async def get_favorite_stocks():
    """获取自选股列表"""
    try:
        if not config:
            return {"favorites": []}
        
        favorites = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
        
        # 获取自选股的详细信息
        if favorites and data_manager:
            # 格式化股票代码为API格式
            formatted_codes = []
            for code in favorites:
                if not code.startswith(('sh', 'sz')):
                    if code.startswith('6'):
                        formatted_codes.append(f'sh{code}')
                    else:
                        formatted_codes.append(f'sz{code}')
                else:
                    formatted_codes.append(code)
            
            # 获取实时数据
            realtime_data = await data_manager.get_realtime_data(formatted_codes)
            
            # 构建返回数据 - 包含完整的股票信息
            favorite_details = []
            for code in favorites:
                formatted_code = f'sh{code}' if code.startswith('6') else f'sz{code}'
                if not code.startswith(('sh', 'sz')):
                    formatted_code = f'sh{code}' if code.startswith('6') else f'sz{code}'
                else:
                    formatted_code = code
                
                stock_data = realtime_data.get(formatted_code, {})
                
                # 返回完整的股票信息
                favorite_detail = {
                    'code': code,
                    'name': stock_data.get('name', f'股票{code}'),
                    'current_price': stock_data.get('current_price', 0),
                    'change': stock_data.get('change', 0),  # 涨跌额
                    'change_percent': stock_data.get('change_percent', 0),
                    'volume': stock_data.get('volume', 0),  # 成交量
                    'amount': stock_data.get('amount', 0),  # 成交额
                    'high_price': stock_data.get('high_price', 0),  # 最高价
                    'low_price': stock_data.get('low_price', 0),  # 最低价
                    'open_price': stock_data.get('open_price', 0),  # 开盘价
                    'yesterday_close': stock_data.get('yesterday_close', 0),  # 昨收价
                    'turnover_rate': stock_data.get('turnoverRate', 0),  # 换手率
                    'market': 'SH' if code.startswith('6') else 'SZ',  # 市场
                    'update_time': stock_data.get('update_time', ''),  # 更新时间
                    'is_active': bool(stock_data)
                }
                
                # 计算当日振幅
                if favorite_detail['high_price'] > 0 and favorite_detail['low_price'] > 0 and favorite_detail['yesterday_close'] > 0:
                    amplitude = ((favorite_detail['high_price'] - favorite_detail['low_price']) / favorite_detail['yesterday_close']) * 100
                    favorite_detail['amplitude'] = round(amplitude, 2)
                else:
                    favorite_detail['amplitude'] = 0
                
                # 计算市值（简化版，基于当前价格和虚拟股本）
                if favorite_detail['current_price'] > 0:
                    # 这里使用一个简化的市值计算，实际需要真实股本数据
                    estimated_shares = {
                        '000001': 19405918000,  # 平安银行
                        '300750': 4310894000,   # 宁德时代  
                        '002594': 2900000000,   # 比亚迪
                        '600519': 1256197000,   # 贵州茅台
                        '600036': 39169148000   # 招商银行
                    }.get(code, 1000000000)  # 默认10亿股
                    
                    market_value = favorite_detail['current_price'] * estimated_shares / 100000000  # 转换为亿元
                    favorite_detail['market_value'] = round(market_value, 2)
                else:
                    favorite_detail['market_value'] = 0
                
                favorite_details.append(favorite_detail)
            
            return {
                "favorites": favorite_details,
                "total": len(favorites),
                "timestamp": datetime.now().isoformat()
            }
        
        # 如果没有自选股或data_manager不可用，返回基础信息
        return {
            "favorites": [{"code": code, "name": f"股票{code}", "current_price": 0, "change_percent": 0, "is_active": False} for code in favorites],
            "total": len(favorites),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取自选股失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取自选股失败: {str(e)}")


@app.post("/api/config/favorites")
async def update_favorite_stocks(favorites: List[str], background_tasks: BackgroundTasks):
    """更新自选股列表"""
    global config, last_sector_update
    try:
        if not config:
            config = {}
        
        if 'user_customization' not in config:
            config['user_customization'] = {}
        
        if '自定义监控' not in config['user_customization']:
            config['user_customization']['自定义监控'] = {}
        
        # 更新自选股列表
        config['user_customization']['自定义监控']['自选股票池'] = favorites
        
        # 保存配置到文件 - 使用与startup事件中相同的路径逻辑
        config_path = Path("data/config.json")  # 与startup事件保持一致
        config_path.parent.mkdir(exist_ok=True)
        
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        logger.info(f"自选股列表已更新: {favorites}")
        
        # 立即触发监控列表更新（重置时间检查）
        last_sector_update = datetime.min
        background_tasks.add_task(update_monitoring_stocks)
        
        return {"message": "自选股列表更新成功", "favorites": favorites}
        
    except Exception as e:
        logger.error(f"更新自选股失败: {e}")
        raise HTTPException(status_code=500, detail=f"更新自选股失败: {str(e)}")


@app.delete("/api/config/favorites/{stock_code}")
async def remove_favorite_stock(stock_code: str, background_tasks: BackgroundTasks):
    """删除单只自选股"""
    global config, last_sector_update
    try:
        if not config:
            raise HTTPException(status_code=404, detail="配置文件不存在")
        
        # 获取当前自选股列表
        current_favorites = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
        
        if stock_code not in current_favorites:
            raise HTTPException(status_code=404, detail=f"股票 {stock_code} 不在自选股列表中")
        
        # 从列表中移除
        new_favorites = [code for code in current_favorites if code != stock_code]
        
        # 更新配置
        if 'user_customization' not in config:
            config['user_customization'] = {}
        if '自定义监控' not in config['user_customization']:
            config['user_customization']['自定义监控'] = {}
        
        config['user_customization']['自定义监控']['自选股票池'] = new_favorites
        
        # 保存配置到文件 - 使用与startup事件中相同的路径逻辑
        config_path = Path("data/config.json")  # 与startup事件保持一致
        config_path.parent.mkdir(exist_ok=True)
        
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        logger.info(f"已从自选股中移除: {stock_code}")
        
        # 立即触发监控列表更新
        last_sector_update = datetime.min
        background_tasks.add_task(update_monitoring_stocks)
        
        return {
            "message": f"股票 {stock_code} 已从自选股中移除",
            "removed_stock": stock_code,
            "remaining_favorites": new_favorites,
            "count": len(new_favorites)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"删除自选股失败: {e}")
        raise HTTPException(status_code=500, detail=f"删除自选股失败: {str(e)}")


# 启动和关闭事件
@app.on_event("startup")
async def startup_event():
    """应用启动事件"""
    global data_manager, anomaly_engine, config

    logger.info("🚀 启动东风破系统...")

    try:
        # 1. 初始化缓存系统
        await init_cache()
        logger.info("✅ 缓存系统初始化完成")

        # 2. 启动系统监控
        await system_monitor.start_monitoring(interval=30)
        logger.info("✅ 系统监控启动完成")

        # 3. 加载配置
        config_path = Path("data/config.json")
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
        else:
            config = {
                "refresh_interval": 10,
                "anomaly_threshold": 0.5,
                "volume_threshold": 2.0,
                "monitoring_stocks": []
            }

        # 4. 初始化数据管理器和异动引擎
        data_manager = StockDataManager()
        anomaly_engine = StockAnalysisEngine(config)

        # 5. 初始化异动服务
        init_anomaly_services(anomaly_engine, data_manager)
        
        # 6. 初始化涨停预测服务
        init_limit_up_services(data_manager, anomaly_engine)

        # 7. 初始化监控股票列表
        await update_monitoring_stocks()
        logger.info(f"✅ 初始监控股票列表: {len(dynamic_stock_codes)} 只")

        logger.info("🎉 东风破系统启动完成！")

    except Exception as e:
        logger.error(f"❌ 系统启动失败: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭事件"""
    logger.info("🔄 正在关闭东风破系统...")

    try:
        # 1. 停止系统监控
        await system_monitor.stop_monitoring()

        # 2. 清理缓存
        await cleanup_cache()

        # 3. 清理并行分析器
        await parallel_analyzer.cleanup()

        logger.info("✅ 东风破系统已安全关闭")

    except Exception as e:
        logger.error(f"❌ 系统关闭时出错: {e}")


# 添加性能监控和健康检查API
@app.get("/api/health")
async def health_check():
    """健康检查"""
    try:
        health_status = system_monitor.get_health_status()
        cache_stats = cache_manager.get_stats()
        performance_metrics = performance_monitor_instance.get_metrics()

        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "system": health_status,
            "cache": cache_stats,
            "performance": performance_metrics,
            "version": "1.0.0-optimized"
        }
    except Exception as e:
        logger.error(f"健康检查失败: {e}")
        raise HTTPException(status_code=500, detail="健康检查失败")


@app.get("/api/metrics")
async def get_metrics():
    """获取系统指标"""
    try:
        metrics_summary = system_monitor.metrics_collector.get_metrics_summary()
        return metrics_summary
    except Exception as e:
        logger.error(f"获取指标失败: {e}")
        raise HTTPException(status_code=500, detail="获取指标失败")


@app.get("/api/metrics/prometheus")
async def get_prometheus_metrics():
    """获取Prometheus格式指标"""
    try:
        prometheus_metrics = system_monitor.metrics_collector.get_prometheus_metrics()
        return {"metrics": prometheus_metrics}
    except Exception as e:
        logger.error(f"获取Prometheus指标失败: {e}")
        raise HTTPException(status_code=500, detail="获取Prometheus指标失败")


# 基础监控股票功能已删除

# 基础监控股票管理API已删除


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=9000,
        reload=True,
        log_level="info"
    ) 