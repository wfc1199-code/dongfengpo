import React, { useState, useEffect } from 'react';
import './App.css';
import StockList from './components/StockList';
import StockChart from './components/StockChart';
import AnomalyPanel from './components/AnomalyPanel';
import AnomalyAlerts from './components/AnomalyAlerts';
import HotSectorsContainer from './components/HotSectorsContainer';
import ManagementDashboard from './components/ManagementDashboard';
import PerformancePanel from './components/PerformancePanel';
import LoadingSpinner from './components/LoadingSpinner';
import VersionManager from './components/VersionManager';

interface Stock {
  code: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  amount: number;
  turnoverRate: number;
  isAnomaly?: boolean;
  anomalyType?: string;
}

interface AnomalyData {
  stock_code: string;
  stock_name: string;
  anomaly_type: string;
  confidence: number;
  timestamp: string;
  details: any;
}

function App() {
  const [selectedStock, setSelectedStock] = useState<string>('000001');
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [anomalies, setAnomalies] = useState<AnomalyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tradingStatus, setTradingStatus] = useState<{
    status: string;
    message?: string;
    nextTradingTime?: string;
  } | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true); // 默认开启自动刷新
  const [refreshInterval, setRefreshInterval] = useState(20000); // 优化：默认20秒刷新间隔
  const [lastUpdateTime, setLastUpdateTime] = useState<string>('');
  const [leftPanelTab, setLeftPanelTab] = useState<'stocks' | 'anomalies'>('anomalies'); // 左侧面板Tab状态：AI异动检测或实时异动
  const [rightPanelTab, setRightPanelTab] = useState<'stocks' | 'sectors'>('stocks'); // 右侧面板Tab状态：自选股或热门板块
  const [currentView, setCurrentView] = useState<'main' | 'management' | 'versions'>('main'); // 添加视图状态
  // const [centerPanelTab, setCenterPanelTab] = useState<'chart'>('chart'); // 中心面板Tab状态：图表 - 已不需要
  const [showPerformancePanel, setShowPerformancePanel] = useState(false); // 性能监控面板显示状态

  // 获取数据的函数
  const fetchData = async () => {
    try {
      // 并行获取异动数据和自选股数据
      const [anomalyResponse, configResponse] = await Promise.all([
        fetch('http://localhost:9000/api/anomaly/detect-legacy'),
        fetch('http://localhost:9000/api/config')
      ]);
      
      // 处理异动数据
      if (anomalyResponse.ok) {
        const responseData = await anomalyResponse.json();
        
        // 检查交易状态
        if (responseData.trading_status) {
          setTradingStatus({
            status: responseData.trading_status,
            message: responseData.message,
            nextTradingTime: responseData.next_trading_time
          });
        }
        
        // 检查返回数据格式
        if (responseData.anomalies) {
          // 新格式：包含status和anomalies字段
          setAnomalies(Array.isArray(responseData.anomalies) ? responseData.anomalies : []);
          console.log('AI异动检测数据:', responseData.anomalies.length, '条');
        } else if (responseData.stocks && responseData.anomalies) {
          // 兼容旧格式：包含stocks和anomalies
          setAnomalies(Array.isArray(responseData.anomalies) ? responseData.anomalies : []);
        } else if (Array.isArray(responseData)) {
          // 旧格式：只返回异动数组
          setAnomalies(responseData);
        } else {
          console.warn('未知的异动数据格式:', responseData);
          setAnomalies([]);
        }
      }

      // 处理自选股数据
      if (configResponse.ok) {
        const config = await configResponse.json();
        const favoriteStocks = config?.user_customization?.自定义监控?.自选股票池 || [];
        
        if (favoriteStocks.length > 0) {
          // 获取自选股的实时数据
          const stockDataPromises = favoriteStocks.map(async (code: string) => {
            try {
              const response = await fetch(`http://localhost:9000/api/stocks/${code}/realtime`);
              if (response.ok) {
                const result = await response.json();
                const data = result.data || result; // 兼容不同的数据结构
                return {
                  code: data.code || code,  // 使用API返回的code，如果没有则使用原始code
                  name: data.name || `股票${code}`,
                  price: data.current_price || data.price || 0,
                  change: data.change || 0,
                  changePercent: data.change_percent || data.changePercent || 0,
                  volume: data.volume || 0,
                  amount: data.amount || 0,
                  turnoverRate: data.turnoverRate || 0
                };
              }
            } catch (error) {
              console.warn(`获取股票 ${code} 数据失败:`, error);
            }
            return null;
          });

          const stockResults = await Promise.all(stockDataPromises);
          const validStocks = stockResults.filter(stock => stock !== null);
          setStocks(validStocks);
        } else {
          // 没有自选股，设置空数组
          setStocks([]);
        }
      }

      // 更新最后更新时间
      setLastUpdateTime(new Date().toLocaleTimeString());
      setError(null);
    } catch (error) {
      console.error('数据获取失败:', error);
      setError('数据获取失败，请检查后端服务');
      // 发生错误时确保设置默认值
      setAnomalies([]);
      setStocks([]);
    }
  };

  // 手动刷新函数
  const handleManualRefresh = () => {
    setLoading(true);
    fetchData().finally(() => setLoading(false));
  };

  // 切换自动刷新模式
  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
  };

  // 切换左侧面板Tab
  const handleLeftPanelTabChange = (tab: 'stocks' | 'anomalies') => {
    setLeftPanelTab(tab);
  };

  // 切换右侧面板Tab
  const handleRightPanelTabChange = (tab: 'stocks' | 'sectors') => {
    setRightPanelTab(tab);
  };

  // 切换中心面板Tab
  // const handleCenterPanelTabChange = (tab: 'chart') => {
  //   setCenterPanelTab(tab);
  // };

  // 切换视图
  const toggleView = () => {
    setCurrentView(currentView === 'main' ? 'management' : 'main');
  };

  const switchToVersions = () => {
    setCurrentView('versions');
  };

  const switchToMain = () => {
    setCurrentView('main');
  };

  // WebSocket连接
  useEffect(() => {
    let ws: WebSocket | null = null;
    let reconnectTimer: NodeJS.Timeout | null = null;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;

    const connectWebSocket = () => {
      try {
        ws = new WebSocket('ws://localhost:9000/ws');
        
        ws.onopen = () => {
          console.log('WebSocket连接已建立');
          reconnectAttempts = 0; // 重置重连次数
          setError(null); // 清除连接错误
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            
            if (data.type === 'anomaly') {
              // 确保data.data是有效的异动数据对象
              if (data.data && typeof data.data === 'object') {
                setAnomalies(prev => [data.data, ...prev.slice(0, 49)]); // 保持最新50条
              }
            } else if (data.type === 'stock_update') {
              // 确保data.data是数组
              if (Array.isArray(data.data)) {
                setStocks(data.data);
                setLastUpdateTime(new Date().toLocaleTimeString());
              }
            } else if (data.type === 'hot_sectors') {
              // 热门板块数据由SectorAnalysis组件自行处理
              console.log('热门板块数据更新', data.data);
            }
          } catch (error) {
            console.error('WebSocket数据解析错误:', error);
          }
        };

        ws.onerror = (error) => {
          console.error('WebSocket错误:', error);
        };

        ws.onclose = (event) => {
          console.log(`WebSocket连接已关闭 (code: ${event.code})`);
          
          // 尝试重连
          if (reconnectAttempts < maxReconnectAttempts) {
            reconnectAttempts++;
            console.log(`尝试重连 WebSocket (${reconnectAttempts}/${maxReconnectAttempts})...`);
            
            reconnectTimer = setTimeout(() => {
              connectWebSocket();
            }, 3000 * reconnectAttempts); // 递增延迟重连
          } else {
            console.log('WebSocket重连次数已达上限，将依赖定时刷新');
            setError('实时数据连接失败，已切换到定时刷新模式');
          }
        };
        
      } catch (error) {
        console.error('WebSocket连接创建失败:', error);
      }
    };

    // 初始连接
    connectWebSocket();

    return () => {
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
      }
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, []);

  // 获取初始数据
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        setLoading(true);
        await fetchData();
      } finally {
        setLoading(false);
      }
    };

    fetchInitialData();
  }, []);

  // 定期刷新数据 - 只有在自动刷新模式下才启用
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchData();
    }, refreshInterval); // 使用可配置的刷新间隔

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval]); // 依赖刷新间隔状态

  const handleStockSelect = (stockCode: string) => {
    setSelectedStock(stockCode);
  };

  // 如果是管理页面视图，直接返回管理组件
  if (currentView === 'management') {
    return (
      <div className="app">
        <div className="view-toggle">
          <button onClick={toggleView} className="toggle-btn">
            ← 返回主界面
          </button>
          <button onClick={switchToVersions} className="toggle-btn">
            🗂️ 版本管理
          </button>
        </div>
        <ManagementDashboard />
      </div>
    );
  }

  if (currentView === 'versions') {
    return (
      <div className="app">
        <div className="view-toggle">
          <button onClick={switchToMain} className="toggle-btn">
            ← 返回主界面
          </button>
          <button onClick={toggleView} className="toggle-btn">
            📊 管理面板
          </button>
        </div>
        <VersionManager />
      </div>
    );
  }

  if (loading) {
    return (
      <div className="app-loading">
        <div className="loading-spinner"></div>
        <p>加载中...</p>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>东风破 - AI异动拉升检测系统</h1>
        <div className="status-bar">
          <div className="refresh-controls">
            <button 
              className={`refresh-mode-btn ${autoRefresh ? 'auto' : 'manual'}`}
              onClick={toggleAutoRefresh}
              title={autoRefresh ? '点击切换到手动模式' : '点击切换到自动模式'}
            >
              {autoRefresh ? '🔄 自动' : '⏸️ 手动'}
            </button>
            <button 
              className="manual-refresh-btn"
              onClick={handleManualRefresh}
              disabled={loading}
              title="手动刷新数据"
            >
              🔄 刷新
            </button>
            <button 
              className="management-btn"
              onClick={toggleView}
              title="打开管理后台"
            >
              🔧 管理后台
            </button>
            <button 
              className="management-btn"
              onClick={switchToVersions}
              title="版本管理"
            >
              🗂️ 版本管理
            </button>
            
            {/* 刷新频率选择器 */}
            <select 
              className="refresh-interval-selector"
              value={refreshInterval}
              onChange={(e) => setRefreshInterval(Number(e.target.value))}
              title="选择刷新间隔"
            >
              <option value={5000}>5秒 (快)</option>
              <option value={10000}>10秒</option>
              <option value={15000}>15秒 (推荐)</option>
              <option value={30000}>30秒</option>
              <option value={60000}>60秒 (省电)</option>
            </select>
            
            {lastUpdateTime && (
              <span className="last-update">
                更新: {lastUpdateTime}
              </span>
            )}
          </div>
          <span className="status-online">
            {autoRefresh ? `🟢 自动刷新中(${refreshInterval/1000}s)` : '🟡 手动模式'}
            {error ? ' | ⚠️ 连接异常' : ' | ✅ 数据正常'}
          </span>
          <span className="time">{new Date().toLocaleString()}</span>
        </div>
      </header>

      {error && (
        <div className="error-banner">
          <span>⚠️ {error}</span>
        </div>
      )}

      <main className="app-main">
        <div className="left-panel">
          {/* 左侧面板Tab头部 */}
          <div className="left-panel-header">
            <div className="panel-tabs">
              <button 
                className={`panel-tab ${leftPanelTab === 'anomalies' ? 'active' : ''}`}
                onClick={() => handleLeftPanelTabChange('anomalies')}
              >
                🤖 AI异动检测
              </button>
              <button 
                className={`panel-tab ${leftPanelTab === 'stocks' ? 'active' : ''}`}
                onClick={() => handleLeftPanelTabChange('stocks')}
              >
                🚨 实时异动
              </button>
            </div>
          </div>

          {/* 左侧面板内容 */}
          <div className="left-panel-content">
            {leftPanelTab === 'anomalies' ? (
              <AnomalyPanel 
                anomalies={anomalies} 
                onStockSelect={handleStockSelect}
                tradingStatus={tradingStatus}
              />
            ) : (
              <AnomalyAlerts onStockSelect={handleStockSelect} />
            )}
          </div>
        </div>

        <div className="center-panel">
          {/* 中心面板内容 - 直接显示图表，不需要标签页 */}
          <div className="center-panel-content">
            <StockChart stockCode={selectedStock} />
          </div>
        </div>

        <div className="right-panel">
          {/* 右侧面板Tab头部 */}
          <div className="right-panel-header">
            <div className="panel-tabs">
              <button 
                className={`panel-tab ${rightPanelTab === 'stocks' ? 'active' : ''}`}
                onClick={() => handleRightPanelTabChange('stocks')}
              >
                📊 自选股
              </button>
              <button 
                className={`panel-tab ${rightPanelTab === 'sectors' ? 'active' : ''}`}
                onClick={() => handleRightPanelTabChange('sectors')}
              >
                🔥 热门板块
              </button>
            </div>
          </div>

          {/* 右侧面板内容 */}
          <div className="right-panel-content">
            {rightPanelTab === 'stocks' ? (
              <StockList 
                stocks={stocks} 
                anomalies={anomalies}
                selectedStock={selectedStock}
                onStockSelect={handleStockSelect}
              />
            ) : (
              <HotSectorsContainer 
                selectedStock={selectedStock}
                onStockSelect={handleStockSelect}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
