import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as echarts from 'echarts';
import './PriceAlertChart.css';

interface AlertPoint {
  time: string;
  price: number;
  type: 'surge' | 'plunge';
  changePercent: number;
  message: string;
  index: number;
}

interface PriceAlertChartProps {
  stockCode: string;
  stockName?: string;
  height?: number;
  surgeThreshold?: number;  // 拉升阈值
  plungeThreshold?: number; // 下跌阈值
  timeWindow?: number;       // 检测时间窗口（分钟）
  refreshInterval?: number;
}

const PriceAlertChart: React.FC<PriceAlertChartProps> = ({
  stockCode,
  stockName = '',
  height = 600,
  surgeThreshold = 1.5,
  plungeThreshold = -1.5,
  timeWindow = 3,
  refreshInterval = 3000
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  const [loading, setLoading] = useState(true);
  const [alertPoints, setAlertPoints] = useState<AlertPoint[]>([]);
  const [latestAlert, setLatestAlert] = useState<AlertPoint | null>(null);
  const lastCheckIndex = useRef(0);

  // 获取分时数据并检测异动
  const fetchAndAnalyze = useCallback(async () => {
    try {
      const response = await fetch(`http://localhost:9000/api/stocks/${stockCode}/timeshare`);
      if (!response.ok) throw new Error('Failed to fetch data');
      
      const data = await response.json();
      const timeshareData = data.timeshare_data || [];
      
      // 检测异动点
      const alerts = detectAlerts(timeshareData, data.yesterday_close);
      
      // 更新图表
      updateChart(data, timeshareData, alerts);
      
      setLoading(false);
    } catch (error) {
      console.error('Error:', error);
      setLoading(false);
    }
  }, [stockCode]);

  // 检测异动点
  const detectAlerts = (timeshareData: any[], yesterdayClose: number) => {
    const alerts: AlertPoint[] = [];
    
    for (let i = lastCheckIndex.current; i < timeshareData.length; i++) {
      if (i < timeWindow) continue;
      
      const current = timeshareData[i];
      const previous = timeshareData[i - timeWindow];
      
      if (!previous) continue;
      
      // 计算变化率
      const changePercent = ((current.price - previous.price) / previous.price) * 100;
      
      // 检测拉升
      if (changePercent >= surgeThreshold) {
        const alert: AlertPoint = {
          time: current.time,
          price: current.price,
          type: 'surge',
          changePercent,
          message: `${timeWindow}分钟拉升${changePercent.toFixed(2)}%`,
          index: i
        };
        alerts.push(alert);
        setLatestAlert(alert);
        
        // 显示浮动提示
        showFloatingAlert(alert);
      }
      // 检测下跌
      else if (changePercent <= plungeThreshold) {
        const alert: AlertPoint = {
          time: current.time,
          price: current.price,
          type: 'plunge',
          changePercent,
          message: `${timeWindow}分钟下跌${Math.abs(changePercent).toFixed(2)}%`,
          index: i
        };
        alerts.push(alert);
        setLatestAlert(alert);
        
        // 显示浮动提示
        showFloatingAlert(alert);
      }
    }
    
    // 更新检查索引
    if (timeshareData.length > 0) {
      lastCheckIndex.current = timeshareData.length - 1;
    }
    
    // 合并新旧异动点
    setAlertPoints(prev => [...prev, ...alerts]);
    
    return [...alertPoints, ...alerts];
  };

  // 显示浮动提示
  const showFloatingAlert = (alert: AlertPoint) => {
    const alertDiv = document.createElement('div');
    alertDiv.className = `floating-alert ${alert.type}`;
    alertDiv.innerHTML = `
      <div class="alert-icon">${alert.type === 'surge' ? '🚀' : '⚠️'}</div>
      <div class="alert-content">
        <div class="alert-title">${alert.message}</div>
        <div class="alert-info">
          <span>${alert.time}</span>
          <span>¥${alert.price.toFixed(2)}</span>
        </div>
      </div>
    `;
    
    document.body.appendChild(alertDiv);
    
    // 动画显示
    setTimeout(() => {
      alertDiv.classList.add('show');
    }, 10);
    
    // 5秒后移除
    setTimeout(() => {
      alertDiv.classList.remove('show');
      setTimeout(() => {
        document.body.removeChild(alertDiv);
      }, 300);
    }, 5000);
  };

  // 更新图表
  const updateChart = (data: any, timeshareData: any[], alerts: AlertPoint[]) => {
    if (!chartInstance.current || !timeshareData || timeshareData.length === 0) return;

    const times = timeshareData.map(item => item.time);
    const prices = timeshareData.map(item => item.price);
    const volumes = timeshareData.map(item => item.volume);
    const avgPrices = timeshareData.map(item => item.avgPrice);

    // 准备异动标记点
    const markPointData = alerts.map(alert => ({
      coord: [alert.index, alert.price],
      value: alert.type === 'surge' ? '↑' : '↓',
      itemStyle: {
        color: alert.type === 'surge' ? '#ff4444' : '#00cc00'
      },
      label: {
        show: true,
        formatter: alert.type === 'surge' ? '拉升' : '下跌',
        color: '#fff',
        backgroundColor: alert.type === 'surge' ? '#ff4444' : '#00cc00',
        padding: [2, 4],
        borderRadius: 2,
        fontSize: 10
      }
    }));

    // 准备异动标记线
    const markLineData = alerts.map(alert => ({
      xAxis: alert.index,
      lineStyle: {
        color: alert.type === 'surge' ? '#ff4444' : '#00cc00',
        type: 'dashed',
        width: 1
      },
      label: {
        show: true,
        formatter: `${alert.time}\n${alert.changePercent > 0 ? '+' : ''}${alert.changePercent.toFixed(2)}%`,
        position: 'end',
        color: alert.type === 'surge' ? '#ff4444' : '#00cc00',
        fontSize: 10
      }
    }));

    const option = {
      animation: true,
      backgroundColor: '#1a1a1a',
      title: {
        text: `${stockName || stockCode} - 实时异动监控`,
        left: '20px',
        top: '10px',
        textStyle: {
          color: '#fff',
          fontSize: 16
        }
      },
      legend: {
        data: ['分时价', '均价'],
        right: '20px',
        top: '10px',
        textStyle: { color: '#999' }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          animation: false
        },
        backgroundColor: 'rgba(50, 50, 50, 0.9)',
        borderColor: '#555',
        textStyle: { color: '#ccc' }
      },
      grid: [
        {
          left: '3%',
          right: '3%',
          top: '12%',
          height: '55%'
        },
        {
          left: '3%',
          right: '3%',
          top: '72%',
          height: '20%'
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: times,
          axisLine: { lineStyle: { color: '#555' } },
          axisTick: { show: false },
          axisLabel: {
            color: '#999',
            interval: (index: number) => {
              const time = times[index];
              return time && (time.endsWith(':00') || time.endsWith(':30'));
            }
          },
          splitLine: {
            show: true,
            interval: (index: number) => {
              const time = times[index];
              return time && time.endsWith(':00');
            },
            lineStyle: { color: '#333', type: 'dashed' }
          }
        },
        {
          type: 'category',
          gridIndex: 1,
          data: times,
          axisLine: { lineStyle: { color: '#555' } },
          axisTick: { show: false },
          axisLabel: { show: false }
        }
      ],
      yAxis: [
        {
          type: 'value',
          scale: true,
          axisLine: { show: false },
          axisTick: { show: false },
          splitLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#999' }
        },
        {
          type: 'value',
          gridIndex: 1,
          axisLine: { show: false },
          axisTick: { show: false },
          splitLine: { lineStyle: { color: '#333' } },
          axisLabel: {
            color: '#999',
            formatter: (value: number) => {
              if (value >= 10000) return `${(value / 10000).toFixed(0)}万`;
              return value;
            }
          }
        }
      ],
      series: [
        {
          name: '分时价',
          type: 'line',
          data: prices,
          smooth: false,
          symbol: 'none',
          lineStyle: { color: '#64B5F6', width: 2 },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0, y: 0, x2: 0, y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(100, 181, 246, 0.3)' },
                { offset: 1, color: 'rgba(100, 181, 246, 0.05)' }
              ]
            }
          },
          markPoint: {
            symbol: 'circle',
            symbolSize: 8,
            data: markPointData,
            animation: true,
            animationDuration: 500,
            animationEasing: 'elasticOut'
          },
          markLine: {
            symbol: 'none',
            data: [
              {
                yAxis: data.yesterday_close,
                lineStyle: { color: '#888', type: 'dashed' },
                label: { formatter: '昨收', position: 'end' }
              },
              ...markLineData
            ]
          }
        },
        {
          name: '均价',
          type: 'line',
          data: avgPrices,
          smooth: false,
          symbol: 'none',
          lineStyle: { color: '#ffc107', width: 1 }
        },
        {
          name: '成交量',
          type: 'bar',
          xAxisIndex: 1,
          yAxisIndex: 1,
          data: volumes.map((vol, index) => ({
            value: vol,
            itemStyle: {
              color: prices[index] >= (index > 0 ? prices[index - 1] : data.yesterday_close) 
                ? '#ff5252' : '#4caf50'
            }
          }))
        }
      ]
    };

    chartInstance.current.setOption(option, true);
  };

  // 初始化图表
  useEffect(() => {
    if (!chartRef.current) return;

    chartInstance.current = echarts.init(chartRef.current);

    const handleResize = () => {
      chartInstance.current?.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      chartInstance.current?.dispose();
    };
  }, []);

  // 定时刷新
  useEffect(() => {
    if (!stockCode) return;

    // 重置状态
    setAlertPoints([]);
    lastCheckIndex.current = 0;
    
    fetchAndAnalyze();

    const interval = setInterval(fetchAndAnalyze, refreshInterval);

    return () => clearInterval(interval);
  }, [stockCode, refreshInterval, fetchAndAnalyze]);

  return (
    <div className="price-alert-chart-container">
      <div ref={chartRef} style={{ width: '100%', height: `${height}px` }} />
      
      {/* 异动统计 */}
      <div className="alert-stats">
        <div className="stat-item">
          <span className="stat-label">拉升次数:</span>
          <span className="stat-value surge">
            {alertPoints.filter(a => a.type === 'surge').length}
          </span>
        </div>
        <div className="stat-item">
          <span className="stat-label">下跌次数:</span>
          <span className="stat-value plunge">
            {alertPoints.filter(a => a.type === 'plunge').length}
          </span>
        </div>
        {latestAlert && (
          <div className="stat-item">
            <span className="stat-label">最新异动:</span>
            <span className={`stat-value ${latestAlert.type}`}>
              {latestAlert.time} {latestAlert.type === 'surge' ? '↑' : '↓'}
              {Math.abs(latestAlert.changePercent).toFixed(2)}%
            </span>
          </div>
        )}
      </div>
      
      {loading && (
        <div className="loading-overlay">
          <div>加载中...</div>
        </div>
      )}
    </div>
  );
};

export default PriceAlertChart;