import React, { useState, useEffect } from 'react';
import HotSectors from './HotSectors';
import SectorFlow from './SectorFlow';
import './SectorAnalysis.css';

interface SectorAnalysisProps {
  className?: string;
  selectedStock?: string;
  onStockSelect?: (stockCode: string) => void;
}

const SectorAnalysis: React.FC<SectorAnalysisProps> = ({ className, selectedStock, onStockSelect }) => {
  const [activeTab, setActiveTab] = useState<'hot' | 'flow'>('hot');
  const [hotSectors, setHotSectors] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // 获取热门板块数据
  const fetchHotSectors = async () => {
    setLoading(true);
    try {
              const response = await fetch('http://localhost:9000/api/anomaly/hot-sectors?sort_by=hot_score&limit=8');
      if (response.ok) {
        const data = await response.json();
        setHotSectors(Array.isArray(data.sectors) ? data.sectors : []);
      }
    } catch (error) {
      console.error('获取热门板块数据失败:', error);
      setHotSectors([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHotSectors();
    
    // 每30秒更新一次数据
    const interval = setInterval(fetchHotSectors, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`sector-analysis ${className || ''}`}>
      <div className="sector-header">
        <div className="header-title">
          <span className="header-icon">📊</span>
          <h3>板块分析</h3>
        </div>
        
        <div className="tab-controls">
          <button 
            className={`tab-control ${activeTab === 'hot' ? 'active' : ''}`}
            onClick={() => setActiveTab('hot')}
          >
            <span className="tab-icon">🔥</span>
            热门板块
          </button>
          <button 
            className={`tab-control ${activeTab === 'flow' ? 'active' : ''}`}
            onClick={() => setActiveTab('flow')}
          >
            <span className="tab-icon">💰</span>
            资金流向
          </button>
        </div>
      </div>

      <div className="sector-content">
        {loading && activeTab === 'hot' ? (
          <div className="loading-state">
            <div className="loading-spinner">⏳</div>
            <span>正在加载数据...</span>
          </div>
        ) : (
          <>
            {activeTab === 'hot' && (
              <div className="tab-panel">
                <HotSectors 
                  sectors={hotSectors}
                  selectedStock={selectedStock}
                  onStockSelect={onStockSelect}
                />
              </div>
            )}
            
            {activeTab === 'flow' && (
              <div className="tab-panel">
                <SectorFlow />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SectorAnalysis; 