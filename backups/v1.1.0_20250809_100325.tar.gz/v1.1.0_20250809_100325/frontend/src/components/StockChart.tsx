import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as echarts from 'echarts';
import './StockChart.css';
import TimeShareChartFixed from './TimeShareChartFixed';

interface StockChartProps {
  stockCode: string;
}

interface KLineData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TimeShareData {
  time: string;
  price: number;
  volume: number;
  amount: number;
  avgPrice: number;
}

interface SupportResistanceLine {
  price: number;
  type: 'support' | 'resistance' | 'pivot';
  label: string;
  color?: string;
  lineStyle?: 'solid' | 'dashed' | 'dotted';
  lineWidth?: number;
}

interface BigOrderData {
  time: string;
  price: number;
  volume: number;
  type: 'buy' | 'sell';
  amount: number;
}

type ChartType = 'kline' | 'timeshare';

// 请求管理器 - 解决竞态条件
class RequestManager {
  private currentRequestId: string | null = null;
  private abortController: AbortController | null = null;

  startRequest(requestId: string): AbortController {
    // 取消之前的请求
    if (this.abortController) {
      this.abortController.abort();
    }
    
    this.currentRequestId = requestId;
    this.abortController = new AbortController();
    return this.abortController;
  }

  isCurrentRequest(requestId: string): boolean {
    return this.currentRequestId === requestId && 
           this.abortController !== null && 
           !this.abortController.signal.aborted;
  }

  cleanup() {
    if (this.abortController) {
      this.abortController.abort();
    }
    this.currentRequestId = null;
    this.abortController = null;
  }
}

const StockChart: React.FC<StockChartProps> = ({ stockCode }) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  const requestManager = useRef(new RequestManager());
  const dataCache = useRef<Map<string, {data: any, timestamp: number}>>(new Map());
  
  const [stockName, setStockName] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [chartType, setChartType] = useState<ChartType>('timeshare');
  const [yesterdayClose, setYesterdayClose] = useState<number>(0);
  const [debugInfo, setDebugInfo] = useState<string>('初始化中...');
  const [showSupportResistance, setShowSupportResistance] = useState<boolean>(true);
  const [stockBasicData, setStockBasicData] = useState<{
    yesterdayHigh: number;
    yesterdayLow: number;
    todayOpen: number;
  } | null>(null);

  // 图表切换处理
  const handleChartTypeChange = useCallback((newType: ChartType) => {
    if (newType === chartType) return;
    
    console.log(`🔄 切换图表类型: ${chartType} -> ${newType}`);
    
    // 立即切换类型，提供快速响应
    setChartType(newType);
    
    // 检查是否有缓存数据可以立即显示
    const cacheKey = `${stockCode}_${newType}`;
    const cached = dataCache.current.get(cacheKey);
    const now = Date.now();
    
    if (cached && (now - cached.timestamp < 30 * 1000)) {
      setDebugInfo(`快速切换到${newType === 'timeshare' ? '分时' : 'K线'}图(缓存)...`);
    } else {
      setDebugInfo(`切换到${newType === 'timeshare' ? '分时' : 'K线'}图...`);
    }
  }, [chartType, stockCode]);

  // 统一的数据获取函数
  const fetchStockData = useCallback(async (code: string, type: ChartType) => {
    if (!code) return;

    const cacheKey = `${code}_${type}`;
    const requestId = `${code}-${type}-${Date.now()}`;
    
    // 检查缓存 (30秒有效期，只用于减少重复请求)
    const cached = dataCache.current.get(cacheKey);
    const now = Date.now();
    if (cached && (now - cached.timestamp < 30 * 1000)) {
      console.log(`💾 使用缓存数据: ${cacheKey}`);
      setLoading(true);
      setError(null);
      setDebugInfo(`正在加载${code}的${type === 'timeshare' ? '分时' : 'K线'}数据(缓存)...`);
      
      try {
        if (type === 'timeshare') {
          // 从缓存获取基础数据
          const cachedBasicData = dataCache.current.get(`${code}_basicData`);
          await handleTimeShareData(cached.data, code, cachedBasicData?.data);
        } else {
          await handleKLineData(cached.data, code);
        }
        setDebugInfo(`✅ ${code} ${type === 'timeshare' ? '分时' : 'K线'}数据加载完成(缓存)`);
        setLoading(false);
        return;
      } catch (err: any) {
        console.warn('⚠️ 缓存数据处理失败，重新获取', err);
        dataCache.current.delete(cacheKey);
      }
    }

    console.log(`🚀 开始请求: ${requestId}`);
    const controller = requestManager.current.startRequest(requestId);
    
    try {
      // 立即设置loading状态，提供即时反馈
      setLoading(true);
      setError(null);
      setDebugInfo(`正在获取${code}的${type === 'timeshare' ? '分时' : 'K线'}数据...`);
      
      // 立即清空之前的数据，提供即时反馈
      setStockName(`${code} 加载中...`);

      let response: Response;
      
      if (type === 'timeshare') {
        // 并行获取分时数据和基础数据
        const [minuteResponse, realtimeResponse] = await Promise.all([
          fetch(`http://localhost:9000/api/stocks/${code}/minute`, {
            signal: controller.signal
          }),
          fetch(`http://localhost:9000/api/stocks/${code}/realtime`, {
            signal: controller.signal
          })
        ]);
        
        response = minuteResponse;
        
        // 处理实时数据以获取今日开盘价
        if (realtimeResponse.ok) {
          const realtimeData = await realtimeResponse.json();
          const todayOpen = realtimeData?.data?.open_price || 0;
          
          // 获取昨日K线数据以获取昨日高低点
          let basicDataForChart = null;
          try {
            const yesterdayResponse = await fetch(`http://localhost:9000/api/stocks/${code}/kline?period=daily&limit=2`, {
              signal: controller.signal
            });
            
            if (yesterdayResponse.ok) {
              const klineData = await yesterdayResponse.json();
              if (klineData.klines && klineData.klines.length >= 2) {
                // 倒数第二条是昨日数据
                const yesterdayData = klineData.klines[klineData.klines.length - 2];
                basicDataForChart = {
                  yesterdayHigh: yesterdayData.high,
                  yesterdayLow: yesterdayData.low,
                  todayOpen: todayOpen
                };
                setStockBasicData(basicDataForChart);
              }
            }
          } catch (err) {
            console.warn('获取昨日K线数据失败:', err);
          }
          
          // 存储基础数据到缓存，以便后续使用
          if (basicDataForChart) {
            dataCache.current.set(`${code}_basicData`, {
              data: basicDataForChart,
              timestamp: Date.now()
            });
          }
        }
      } else {
        response = await fetch(`http://localhost:9000/api/stocks/${code}/kline?period=daily&limit=100`, {
          signal: controller.signal
        });
      }

      // 检查请求是否仍然有效
      if (!requestManager.current.isCurrentRequest(requestId)) {
        console.log(`⏭️ 请求已过期，忽略结果: ${requestId}`);
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      // 再次检查请求有效性
      if (!requestManager.current.isCurrentRequest(requestId)) {
        console.log(`⏭️ 数据解析完成但请求已过期: ${requestId}`);
        return;
      }

      console.log(`✅ 数据获取成功: ${requestId}`, data);

      // 缓存数据
      dataCache.current.set(cacheKey, {
        data: data,
        timestamp: now
      });

      // 更新组件状态
      if (type === 'timeshare') {
        // 从缓存获取基础数据
        const cachedBasicData = dataCache.current.get(`${code}_basicData`);
        await handleTimeShareData(data, code, cachedBasicData?.data);
      } else {
        await handleKLineData(data, code);
      }

      setDebugInfo(`✅ ${code} ${type === 'timeshare' ? '分时' : 'K线'}数据加载完成`);
      
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log(`🛑 请求被取消: ${requestId}`);
        return;
      }

      // 检查请求是否仍然有效
      if (!requestManager.current.isCurrentRequest(requestId)) {
        console.log(`⏭️ 错误处理时请求已过期: ${requestId}`);
        return;
      }

      console.error(`❌ 请求失败: ${requestId}`, err);
      setError(`获取${code}数据失败: ${err.message}`);
      setDebugInfo(`❌ API请求失败: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  // 处理分时数据
  const handleTimeShareData = useCallback(async (data: any, code: string, basicData?: typeof stockBasicData) => {
    console.log('🔍 处理分时数据:', data);
    
    // 严格的真实数据格式处理
    let minuteData = null;
    let name = '未知股票';
    let yesterdayClose = null;
    
    if (data && data.minute_data && Array.isArray(data.minute_data)) {
      minuteData = data.minute_data;
      name = data.name || '未知股票';
      yesterdayClose = data.yesterday_close;
    }
    
    if (minuteData && minuteData.length > 0) {
      setStockName(name);
      
      if (yesterdayClose && yesterdayClose > 0) {
        setYesterdayClose(yesterdayClose);
      } else if (minuteData.length > 0) {
        setYesterdayClose(minuteData[0].price * 0.995);
      }
      
      // 从缓存获取基础数据或使用传入的基础数据
      const cachedBasicData = dataCache.current.get(`${code}_basicData`);
      const dataToUse = basicData || cachedBasicData?.data || stockBasicData;
      
      console.log('📊 使用的基础数据:', dataToUse);
      
      updateTimeShareChart(minuteData, code, name, [], dataToUse, yesterdayClose);
    } else {
      console.warn('⚠️ 分时数据格式无效或为空:', data);
      throw new Error(`分时数据格式无效: ${JSON.stringify(data)}`);
    }
  }, [stockBasicData, showSupportResistance]);

  // 处理K线数据
  const handleKLineData = useCallback(async (data: any, code: string) => {
    if (data && data.klines && data.klines.length > 0) {
      const klineData = data.klines;
      const name = data.name || '未知股票';
      
      setStockName(name);
      
      const formattedData: KLineData[] = klineData.map((item: any) => ({
        date: item.date,
        open: item.open,
        high: item.high,
        low: item.low,
        close: item.close,
        volume: item.volume
      }));
      
      updateKLineChart(formattedData, code, name);
    } else {
      throw new Error('K线数据格式无效');
    }
  }, []);


  // 图表初始化 - 添加chartType依赖，确保切换时重新初始化
  useEffect(() => {
    // 只在K线模式下初始化图表
    if (chartType !== 'kline' || !chartRef.current) return;
    
    console.log('🔧 初始化ECharts图表 - K线模式');
    
    if (chartInstance.current) {
      chartInstance.current.dispose();
    }
    
    const newChart = echarts.init(chartRef.current);
    chartInstance.current = newChart;
    
    const handleResize = () => {
      chartInstance.current?.resize();
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, [chartType]); // 添加chartType依赖

  // 数据获取效果 - 移除fetchStockData依赖避免重复请求
  useEffect(() => {
    if (!stockCode) return;
    
    // K线模式需要等待图表实例初始化
    if (chartType === 'kline' && !chartInstance.current) {
      console.log('⏳ 等待K线图表实例初始化...');
      return;
    }
    
    console.log(`📊 股票数据获取触发: ${stockCode}, 图表类型: ${chartType}`);
    
    // 直接调用，避免依赖引起的重复渲染
    const loadData = async () => {
      await fetchStockData(stockCode, chartType);
    };
    
    loadData();
    
    return () => {
      // 清理请求
      requestManager.current.cleanup();
    };
  }, [stockCode, chartType]); // 移除fetchStockData依赖

  // K线图实例初始化后加载数据
  useEffect(() => {
    if (chartType === 'kline' && chartInstance.current && stockCode) {
      console.log('📊 K线图实例已准备，开始加载数据');
      fetchStockData(stockCode, chartType);
    }
  }, [chartInstance.current, chartType, stockCode, fetchStockData]);

  // 缓存清理函数
  const cleanupCache = useCallback(() => {
    const now = Date.now();
    const maxAge = 2 * 60 * 1000; // 2分钟
    
    dataCache.current.forEach((value, key) => {
      if (now - value.timestamp > maxAge) {
        dataCache.current.delete(key);
      }
    });
  }, []);

  // 定期清理缓存
  useEffect(() => {
    const interval = setInterval(cleanupCache, 5 * 60 * 1000); // 每5分钟清理一次
    return () => clearInterval(interval);
  }, [cleanupCache]);

  // 支撑压力线状态改变时重新绘制
  useEffect(() => {
    if (!stockCode || !chartInstance.current || chartType !== 'timeshare') return;
    
    // 从缓存中获取数据重新绘制
    const cacheKey = `${stockCode}_timeshare`;
    const cached = dataCache.current.get(cacheKey);
    
    if (cached && cached.data) {
      // 从缓存获取基础数据
      const cachedBasicData = dataCache.current.get(`${stockCode}_basicData`);
      handleTimeShareData(cached.data, stockCode, cachedBasicData?.data);
    }
  }, [showSupportResistance, stockCode, chartType, handleTimeShareData]);

  // 组件卸载清理
  useEffect(() => {
    return () => {
      requestManager.current.cleanup();
      dataCache.current.clear();
    };
  }, []);


  // 计算支撑压力线
  const calculateSupportResistanceLines = useCallback((basicData?: typeof stockBasicData): SupportResistanceLine[] => {
    const lines: SupportResistanceLine[] = [];
    
    const dataToUse = basicData || stockBasicData;
    
    console.log('🔍 计算支撑压力线:', {
      basicData,
      stockBasicData,
      dataToUse,
      yesterdayClose
    });
    
    if (!dataToUse || !yesterdayClose) {
      console.warn('⚠️ 缺少基础数据或昨收价，无法计算支撑压力线');
      return lines;
    }
    
    // 昨日收盘价 - 基准线
    lines.push({
      price: yesterdayClose,
      type: 'pivot',
      label: '昨收',
      color: '#999',
      lineStyle: 'dashed',
      lineWidth: 1
    });
    
    // 今日开盘价
    if (dataToUse.todayOpen > 0) {
      lines.push({
        price: dataToUse.todayOpen,
        type: dataToUse.todayOpen > yesterdayClose ? 'resistance' : 'support',
        label: '今开',
        color: '#ff9800',
        lineStyle: 'dashed',
        lineWidth: 1
      });
    }
    
    // 昨日最高价
    if (dataToUse.yesterdayHigh > 0) {
      lines.push({
        price: dataToUse.yesterdayHigh,
        type: 'resistance',
        label: '昨高',
        color: '#ff4444',
        lineStyle: 'dotted',
        lineWidth: 1
      });
    }
    
    // 昨日最低价
    if (dataToUse.yesterdayLow > 0) {
      lines.push({
        price: dataToUse.yesterdayLow,
        type: 'support',
        label: '昨低',
        color: '#00aa00',
        lineStyle: 'dotted',
        lineWidth: 1
      });
    }
    
    return lines;
  }, [yesterdayClose]);

  // 更新分时图
  const updateTimeShareChart = (data: TimeShareData[], code: string, name: string, bigOrders: BigOrderData[] = [], basicData?: typeof stockBasicData, yClose?: number) => {
    if (!chartInstance.current || !data || data.length === 0) return;

    const times = data.map(item => item.time);
    const prices = data.map(item => item.price);
    const avgPrices = data.map(item => item.avgPrice);
    const volumes = data.map(item => item.volume || 0);
    
    // 调试成交量数据
    console.log('📊 成交量数据检查:', {
      dataLength: data.length,
      firstItems: data.slice(0, 5).map(item => ({
        time: item.time,
        volume: item.volume
      })),
      volumesLength: volumes.length,
      hasVolumes: volumes.some(v => v > 0),
      maxVolume: Math.max(...volumes),
      minVolume: Math.min(...volumes)
    });
    
    // 使用传入的基础数据或当前状态
    const currentBasicData = basicData || stockBasicData;
    
    // 获取支撑压力线
    const supportResistanceLines = showSupportResistance ? calculateSupportResistanceLines(currentBasicData) : [];
    
    console.log('🎯 支撑压力线数据:', {
      showSupportResistance,
      currentBasicData,
      yesterdayClose,
      supportResistanceLines,
      linesCount: supportResistanceLines.length
    });
    
    // 调试：打印计算出的具体线条
    if (supportResistanceLines.length > 0) {
      console.log('📊 计算出的支撑压力线:');
      supportResistanceLines.forEach((line, index) => {
        console.log(`  ${index + 1}. ${line.label}: ${line.price} (${line.color}, ${line.lineStyle})`);
      });
    }

    const option = {
      title: {
        text: `${name} (${code}) 分时图`,
        left: 'center',
        textStyle: { color: '#fff', fontSize: 16 }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',  // 十字光标
          lineStyle: {
            color: '#376df4',
            width: 1,
            opacity: 1
          },
          crossStyle: {
            color: '#376df4',
            width: 1,
            opacity: 1
          }
        },
        backgroundColor: 'rgba(50, 50, 50, 0.9)',
        borderColor: '#777',
        borderWidth: 1,
        textStyle: {
          color: '#fff'
        },
        formatter: function(params: any) {
          if (!params || params.length === 0) return '';
          
          const time = params[0].axisValue;
          let result = `时间: ${time}<br/>`;
          
          params.forEach((param: any) => {
            if (param.seriesName === '价格') {
              const price = param.value;
              const color = '#ff6b6b';
              result += `当前价: <span style="color:${color}">${price ? price.toFixed(2) : '0.00'}</span><br/>`;
            } else if (param.seriesName === '均价') {
              const avgPrice = param.value;
              result += `均价: ${avgPrice ? avgPrice.toFixed(2) : '0.00'}<br/>`;
            } else if (param.seriesName === '成交量') {
              const volume = param.value;
              result += `成交量: ${volume ? (volume / 100).toFixed(0) : '0'}手<br/>`;
            }
          });
          
          return result;
        }
      },
      axisPointer: {
        link: [{xAxisIndex: 'all'}],
        label: {
          backgroundColor: '#777'
        }
      },
      grid: [
        { left: '3%', right: '3%', top: '12%', bottom: '22%' },
        { left: '3%', right: '3%', top: '82%', bottom: '6%' }
      ],
      xAxis: [
        {
          type: 'category',
          data: times,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' }
        },
        {
          type: 'category',
          gridIndex: 1,
          data: times,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' }
        }
      ],
      yAxis: [
        {
          type: 'value',
          scale: true,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' },
          splitLine: { lineStyle: { color: '#333' } }
        },
        {
          type: 'value',
          gridIndex: 1,
          scale: true,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { 
            color: '#ccc',
            formatter: function(value: number) {
              return (value / 100).toFixed(0) + '手';
            }
          },
          splitLine: { show: false },
          min: 0
        }
      ],
      series: [
        {
          name: '价格',
          type: 'line',
          data: prices,
          lineStyle: { color: '#ff6b6b' },
          itemStyle: { color: '#ff6b6b' },
          showSymbol: false,
          smooth: true,
          markLine: showSupportResistance && supportResistanceLines.length > 0 ? {
            symbol: 'none',
            animation: false,
            label: {
              position: 'end',
              formatter: function(params: any) {
                const line = supportResistanceLines.find(l => Math.abs(l.price - params.value) < 0.001);
                return line ? line.label : '';
              }
            },
            data: supportResistanceLines.map(line => ({
              yAxis: line.price,
              lineStyle: {
                color: line.color || '#999',
                type: line.lineStyle || 'dashed',
                width: line.lineWidth || 1
              },
              label: {
                show: true,
                position: 'end',
                formatter: `${line.label}: ${line.price.toFixed(2)}`,
                color: line.color || '#999'
              }
            }))
          } : undefined
        },
        {
          name: '均价',
          type: 'line',
          data: avgPrices,
          lineStyle: { color: '#ffd93d' },
          itemStyle: { color: '#ffd93d' },
          showSymbol: false,
          smooth: true
        },
        {
          name: '成交量',
          type: 'bar',
          xAxisIndex: 1,
          yAxisIndex: 1,
          data: volumes.map((vol, index) => {
            const currentPrice = prices[index];
            const prevPrice = index > 0 ? prices[index - 1] : (yClose || yesterdayClose || prices[0]);
            const isUp = currentPrice >= prevPrice;
            return {
              value: vol,
              itemStyle: {
                color: isUp ? '#ef5350' : '#26a69a'
              }
            };
          })
        }
      ]
    };

    // 调试：输出完整的option配置
    console.log('📈 分时图 ECharts Option:', {
      series0MarkLine: option.series[0].markLine,
      supportResistanceLinesLength: supportResistanceLines.length,
      showSupportResistance: showSupportResistance
    });
    
    chartInstance.current.setOption(option);
  };

  // 更新K线图
  const updateKLineChart = (data: KLineData[], code: string, name: string) => {
    if (!chartInstance.current || !data || data.length === 0) return;

    const dates = data.map(item => item.date);
    // ECharts标准K线图数据格式: [open, close, low, high]
    const ohlcData = data.map(item => [item.open, item.close, item.low, item.high]);
    const volumes = data.map(item => item.volume);
    
    // 保存原始K线数据供tooltip使用 - 使用闭包让tooltip可以访问
    const klineDataRef = data;

    const option = {
      title: {
        text: `${name} (${code}) K线图`,
        left: 'center',
        textStyle: { color: '#fff', fontSize: 16 }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',  // 十字光标
          lineStyle: {
            color: '#376df4',
            width: 1,
            opacity: 1
          },
          crossStyle: {
            color: '#376df4',
            width: 1,
            opacity: 1
          }
        },
        backgroundColor: 'rgba(50, 50, 50, 0.9)',
        borderColor: '#777',
        borderWidth: 1,
        textStyle: {
          color: '#fff'
        },
        formatter: function(params: any) {
          if (!params || params.length === 0) return '';
          
          const date = params[0].axisValue;
          let result = `日期: ${date}<br/>`;
          
          params.forEach((param: any) => {
            if (param.componentSubType === 'candlestick') {
              const value = param.value || param.data;
              if (!value || !Array.isArray(value) || value.length < 4) return;
              
              // ECharts K线数据格式: [open, close, low, high] 或 [open, close, low, high, volume]
              let open, close, low, high;
              
              // 直接从原始数据获取，避免解析错误
              const dataIndex = param.dataIndex;
              const currentData = klineDataRef[dataIndex];
              
              if (currentData) {
                // 使用原始数据，确保数据正确
                open = currentData.open;
                close = currentData.close;
                high = currentData.high;
                low = currentData.low;
              } else {
                // 备用方案：从value数组解析
                if (value.length >= 4) {
                  [open, close, low, high] = value;
                }
              }
              
              // 获取前一天的收盘价
              let yesterdayClose = open; // 默认使用开盘价
              
              // 如果不是第一条数据，从原始K线数据中获取前一天的收盘价
              if (dataIndex > 0 && klineDataRef[dataIndex - 1]) {
                yesterdayClose = klineDataRef[dataIndex - 1].close;
                console.log('📅 昨收价:', yesterdayClose, 'from index:', dataIndex - 1);
              }
              
              const change = close - yesterdayClose;
              const changePercent = yesterdayClose !== 0 ? ((change / yesterdayClose) * 100).toFixed(2) : '0.00';
              const color = change >= 0 ? '#ff4757' : '#2ed573';
              
              result += `开盘: ${open.toFixed(2)}<br/>`;
              result += `收盘: <span style="color:${color}">${close.toFixed(2)}</span><br/>`;
              result += `最高: ${high.toFixed(2)}<br/>`;
              result += `最低: ${low.toFixed(2)}<br/>`;
              result += `昨收: ${yesterdayClose.toFixed(2)}<br/>`;
              result += `涨跌: <span style="color:${color}">${change >= 0 ? '+' : ''}${change.toFixed(2)} (${changePercent}%)</span><br/>`;
              
              // 获取成交量 - 从原始数据中获取
              if (currentData && currentData.volume !== undefined) {
                result += `成交量: ${(currentData.volume / 10000).toFixed(2)}万手<br/>`;
              } else if (params.length > 1) {
                // 备用方案：从成交量series中获取
                const volumeParam = params.find((p: any) => p.componentSubType === 'bar');
                if (volumeParam) {
                  const vol = volumeParam.value || 0;
                  result += `成交量: ${(vol / 10000).toFixed(2)}万手<br/>`;
                }
              }
            }
          });
          
          return result;
        }
      },
      axisPointer: {
        link: [{xAxisIndex: 'all'}],
        label: {
          backgroundColor: '#777'
        }
      },
      dataZoom: [
        {
          type: 'inside',
          xAxisIndex: [0, 1]
        },
        {
          show: true,
          xAxisIndex: [0, 1],
          type: 'slider',
          bottom: '0%',
          height: '6%'
        }
      ],
      grid: [
        { 
          left: '3%', 
          right: '3%', 
          top: '12%', 
          bottom: '22%',
          containLabel: false
        },
        { 
          left: '3%', 
          right: '3%', 
          top: '82%', 
          bottom: '6%',
          containLabel: false
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: dates,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' }
        },
        {
          type: 'category',
          gridIndex: 1,
          data: dates,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' }
        }
      ],
      yAxis: [
        {
          type: 'value',
          scale: true,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' },
          splitLine: { lineStyle: { color: '#333' } }
        },
        {
          type: 'value',
          scale: true,
          gridIndex: 1,
          axisLine: { lineStyle: { color: '#333' } },
          axisLabel: { color: '#ccc' },
          splitLine: { show: false }
        }
      ],
      series: [
        {
          name: 'K线',
          type: 'candlestick',
          data: ohlcData,
          itemStyle: {
            color: '#ff4757',      // 阳线颜色 - 红色
            color0: '#2ed573',     // 阴线颜色 - 绿色
            borderColor: '#ff4757', // 阳线边框
            borderColor0: '#2ed573' // 阴线边框
          }
        },
        {
          name: '成交量',
          type: 'bar',
          xAxisIndex: 1,
          yAxisIndex: 1,
          data: volumes,
          itemStyle: { color: '#4ecdc4' }
        }
      ]
    };

    chartInstance.current.setOption(option);
  };

  return (
    <div className="stock-chart">
      <div className="chart-header">
        <h3>{stockCode} {stockName}</h3>
        <div className="debug-info" style={{fontSize: '12px', color: '#666', marginTop: '5px'}}>
          状态: {loading ? '加载中...' : (error ? error : '正常')} | {debugInfo}
        </div>
        <div className="chart-controls">
          <div className="chart-type-selector">
            <button 
              className={chartType === 'timeshare' ? 'active' : ''}
              onClick={() => handleChartTypeChange('timeshare')}
              disabled={loading}
            >
              分时
            </button>
            <button 
              className={chartType === 'kline' ? 'active' : ''}
              onClick={() => handleChartTypeChange('kline')}
              disabled={loading}
            >
              日K
            </button>
          </div>
          
          {chartType === 'timeshare' && (
            <div className="chart-options">
              <label className="option-toggle">
                <input
                  type="checkbox"
                  checked={showSupportResistance}
                  onChange={(e) => setShowSupportResistance(e.target.checked)}
                />
                <span>支撑压力线</span>
              </label>
            </div>
          )}
        </div>
      </div>

      <div className="chart-container" style={{ height: '500px' }}>
        {chartType === 'timeshare' ? (
          <TimeShareChartFixed
            stockCode={stockCode}
            stockName={stockName}
            showVolume={true}
            showMALine={true}
            showSupportResistance={showSupportResistance}
            refreshInterval={5000}
          />
        ) : (
          <>
            <div 
              ref={chartRef} 
              style={{ 
                width: '100%', 
                height: '100%',
                opacity: loading ? 0.5 : 1,
                transition: 'opacity 0.3s'
              }} 
            />
            
            {loading && (
              <div className="loading-overlay" style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontSize: '16px'
              }}>
                🔄 加载中...
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default StockChart;