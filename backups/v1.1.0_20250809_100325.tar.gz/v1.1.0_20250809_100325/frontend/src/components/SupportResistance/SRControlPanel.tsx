/**
 * 支撑压力控制面板
 */

import React from 'react';
import './SRControlPanel.css';

interface SRControlPanelProps {
  showDynamic: boolean;
  showVolumeProfile: boolean;
  showFibonacci: boolean;
  showTrendlines: boolean;
  showMultiTimeframe: boolean;
  strengthFilter: string[];
  timeframeFilter: string[];
  maxLines?: number;
  mergeThreshold?: number;
  onSettingsChange: (settings: any) => void;
}

export const SRControlPanel: React.FC<SRControlPanelProps> = ({
  showDynamic,
  showVolumeProfile,
  showFibonacci,
  showTrendlines,
  showMultiTimeframe,
  strengthFilter,
  timeframeFilter,
  maxLines = 10,
  mergeThreshold = 0.008,
  onSettingsChange
}) => {
  const handleToggle = (key: string, value: boolean) => {
    onSettingsChange({ [key]: value });
  };
  
  const handleStrengthFilterChange = (rating: string) => {
    const newFilter = strengthFilter.includes(rating)
      ? strengthFilter.filter(r => r !== rating)
      : [...strengthFilter, rating];
    onSettingsChange({ strengthFilter: newFilter });
  };
  
  return (
    <div className="sr-control-panel">
      <div className="panel-header">
        <span className="panel-title">🎯 支撑压力系统</span>
      </div>
      
      <div className="panel-section">
        <div className="section-title">显示选项</div>
        <div className="control-group">
          <label className="control-item">
            <input
              type="checkbox"
              checked={showDynamic}
              onChange={(e) => handleToggle('showDynamic', e.target.checked)}
            />
            <span>动态支撑压力</span>
          </label>
          
          <label className="control-item">
            <input
              type="checkbox"
              checked={showVolumeProfile}
              onChange={(e) => handleToggle('showVolumeProfile', e.target.checked)}
            />
            <span>成交密集区</span>
          </label>
          
          <label className="control-item">
            <input
              type="checkbox"
              checked={showFibonacci}
              onChange={(e) => handleToggle('showFibonacci', e.target.checked)}
            />
            <span>斐波那契</span>
          </label>
          
          <label className="control-item">
            <input
              type="checkbox"
              checked={showTrendlines}
              onChange={(e) => handleToggle('showTrendlines', e.target.checked)}
            />
            <span>趋势通道</span>
          </label>
          
          <label className="control-item">
            <input
              type="checkbox"
              checked={showMultiTimeframe}
              onChange={(e) => handleToggle('showMultiTimeframe', e.target.checked)}
            />
            <span>多周期叠加</span>
          </label>
        </div>
      </div>
      
      <div className="panel-section">
        <div className="section-title">强度过滤</div>
        <div className="strength-filter">
          {['S', 'A', 'B', 'C'].map(rating => (
            <button
              key={rating}
              className={`strength-btn ${strengthFilter.includes(rating) ? 'active' : ''} rating-${rating.toLowerCase()}`}
              onClick={() => handleStrengthFilterChange(rating)}
            >
              {rating}
            </button>
          ))}
        </div>
      </div>
      
      <div className="panel-section">
        <div className="section-title">线条密度控制</div>
        <div className="control-group">
          <div className="control-item">
            <label>最大线条数: {maxLines}</label>
            <input
              type="range"
              min="5"
              max="20"
              value={maxLines}
              onChange={(e) => onSettingsChange({ maxLines: parseInt(e.target.value) })}
              className="slider"
            />
          </div>
          
          <div className="control-item">
            <label>合并阈值: {(mergeThreshold * 100).toFixed(1)}%</label>
            <input
              type="range"
              min="0.1"
              max="2.0"
              step="0.1"
              value={mergeThreshold * 100}
              onChange={(e) => onSettingsChange({ mergeThreshold: parseFloat(e.target.value) / 100 })}
              className="slider"
            />
          </div>
        </div>
      </div>
      
      <div className="panel-section">
        <div className="section-title">快捷操作</div>
        <div className="quick-actions">
          <button 
            className="action-btn"
            onClick={() => onSettingsChange({ strengthFilter: ['S', 'A'] })}
          >
            只看强势位
          </button>
          <button 
            className="action-btn"
            onClick={() => onSettingsChange({ strengthFilter: ['S', 'A', 'B', 'C'] })}
          >
            显示全部
          </button>
          <button 
            className="action-btn"
            onClick={() => onSettingsChange({ maxLines: 8, mergeThreshold: 0.01 })}
          >
            简洁模式
          </button>
          <button 
            className="action-btn"
            onClick={() => onSettingsChange({ maxLines: 15, mergeThreshold: 0.005 })}
          >
            详细模式
          </button>
        </div>
      </div>
    </div>
  );
};