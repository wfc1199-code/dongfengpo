/**
 * 支撑压力覆盖层组件
 * 用于在分时图上绘制支撑压力线
 */

import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import { SupportResistanceLevel } from '../../types/supportResistance';

interface SROverlayProps {
  chartInstance: echarts.ECharts | null;
  levels: SupportResistanceLevel[];
  currentPrice: number;
  showLabels?: boolean;
  animationEnabled?: boolean;
  ratingFilter?: string[];
  maxLines?: number;
  mergeThreshold?: number;
}

export const SROverlay: React.FC<SROverlayProps> = ({
  chartInstance,
  levels,
  currentPrice,
  showLabels = true,
  animationEnabled = true,
  ratingFilter = ['S', 'A', 'B', 'C'],
  maxLines = 10,
  mergeThreshold = 0.008
}) => {
  const animationFrameRef = useRef<number>(0);
  const [isDarkTheme, setIsDarkTheme] = React.useState(
    window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
  );

  // 监听主题变化
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleThemeChange = (e: MediaQueryListEvent) => {
      setIsDarkTheme(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleThemeChange);
    return () => mediaQuery.removeEventListener('change', handleThemeChange);
  }, []);
  
  // 合并价格相近的支撑压力线
  const mergeSimilarLevels = (levels: SupportResistanceLevel[], threshold: number = 0.005): SupportResistanceLevel[] => {
    if (levels.length === 0) return [];
    
    // 按价格排序
    const sortedLevels = [...levels].sort((a, b) => a.price - b.price);
    const mergedLevels: SupportResistanceLevel[] = [];
    
    let currentGroup: SupportResistanceLevel[] = [sortedLevels[0]];
    
    for (let i = 1; i < sortedLevels.length; i++) {
      const priceRatio = (sortedLevels[i].price - currentGroup[0].price) / currentGroup[0].price;
      
      if (priceRatio <= threshold) {
        // 价格相近，加入当前组
        currentGroup.push(sortedLevels[i]);
      } else {
        // 价格相差较大，合并当前组并开始新组
        mergedLevels.push(mergeLevelGroup(currentGroup));
        currentGroup = [sortedLevels[i]];
      }
    }
    
    // 合并最后一组
    if (currentGroup.length > 0) {
      mergedLevels.push(mergeLevelGroup(currentGroup));
    }
    
    return mergedLevels;
  };
  
  // 合并一组支撑压力线
  const mergeLevelGroup = (group: SupportResistanceLevel[]): SupportResistanceLevel => {
    if (group.length === 1) return group[0];
    
    // 选择评级最高的线
    const ratingOrder = ['S', 'A', 'B', 'C'];
    group.sort((a, b) => ratingOrder.indexOf(a.rating) - ratingOrder.indexOf(b.rating));
    
    const bestLevel = group[0];
    
    // 计算平均价格
    const avgPrice = group.reduce((sum, level) => sum + level.price, 0) / group.length;
    
    // 合并强度
    const totalStrength = group.reduce((sum, level) => sum + level.strength, 0) / group.length;
    
    return {
      ...bestLevel,
      price: avgPrice,
      strength: totalStrength,
      description: `${bestLevel.description} (合并${group.length}条线)`
    };
  };
  
  useEffect(() => {
    if (!chartInstance || !levels.length) return;
    
    // 获取当前图表的价格范围
    let yAxisMin = 0;
    let yAxisMax = 100;
    
    try {
      const currentOption = chartInstance.getOption() as any;
      if (currentOption && currentOption.yAxis && currentOption.yAxis[0]) {
        yAxisMin = currentOption.yAxis[0].min || 0;
        yAxisMax = currentOption.yAxis[0].max || 100;
      }
    } catch (error) {
      console.log('Error getting chart options, using defaults', error);
    }
    
    // 首先过滤在可见范围内的level
    let visibleLevels = levels.filter(level => {
      // 只显示在可见价格范围内的线条，或者评级为S的线条（始终显示）
      return (level.price >= yAxisMin && level.price <= yAxisMax) || level.rating === 'S';
    });
    
    // 然后按评级过滤
    visibleLevels = visibleLevels.filter(level => 
      ratingFilter.includes(level.rating)
    );
    
    // 合并价格相近的线条
    let filteredLevels = mergeSimilarLevels(visibleLevels, mergeThreshold);
    
    // 限制最大线条数量
    if (filteredLevels.length > maxLines) {
      // 按强度和评级排序，保留最重要的线条
      const ratingOrder = ['S', 'A', 'B', 'C'];
      filteredLevels.sort((a, b) => {
        const ratingDiff = ratingOrder.indexOf(a.rating) - ratingOrder.indexOf(b.rating);
        if (ratingDiff !== 0) return ratingDiff;
        return b.strength - a.strength;
      });
      filteredLevels = filteredLevels.slice(0, maxLines);
    }
    
    // 获取当前的option
    const option = chartInstance.getOption() as any;
    if (!option || !option.series || !option.series[0]) return;
    
    // 获取现有的markLine数据（比如昨收线）
    const existingMarkLine = option.series[0].markLine;
    const existingData = existingMarkLine?.data || [];
    
    // 准备支撑压力markLine数据
    const srMarkLineData = filteredLevels.map(level => {
      const visualStyle = level.visualStyle || {
        color: '#999',
        lineStyle: 'solid' as const,
        lineWidth: 1,
        opacity: 1
      };
      
      // 根据主题调整颜色
      let lineColor = visualStyle.color || '#999';
      if (isDarkTheme) {
        // 暗色主题下使用更亮的颜色
        const colorMap: { [key: string]: string } = {
          '#00C853': '#4CAF50',  // 支撑位：更亮的绿色
          '#FF1744': '#FF5722',  // 压力位：更亮的红色
          '#FF9800': '#FFC107',  // 橙色系
          '#999': '#CCCCCC',     // 灰色系
          '#666': '#AAAAAA'
        };
        lineColor = colorMap[lineColor] || lineColor;
      }
      
      return {
        yAxis: level.price,
        name: level.description || `${level.type} - ${level.rating}级`,
        lineStyle: {
          color: lineColor,
          type: visualStyle.lineStyle || 'solid',
          width: ((visualStyle.lineWidth || 1) + (isDarkTheme ? 1 : 0)) * 0.5, // 线宽减半
          opacity: (visualStyle.opacity || 1) + (isDarkTheme ? 0.2 : 0) // 暗色主题下更不透明
        },
        label: {
          show: showLabels,
          position: 'end',
          formatter: (params: any) => {
            if (level.rating === 'S' || level.rating === 'A') {
              return `${level.rating}级 ¥${level.price.toFixed(2)}`;
            }
            return showLabels ? `¥${level.price.toFixed(2)}` : '';
          },
          color: isDarkTheme ? '#FFFFFF' : lineColor, // 暗色主题下标签用白色
          fontSize: level.rating === 'S' ? 12 : 10,
          fontWeight: level.rating === 'S' ? 'bold' : 'normal',
          backgroundColor: level.rating === 'S' || level.rating === 'A' 
            ? (isDarkTheme ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.8)')
            : 'transparent',
          padding: level.rating === 'S' || level.rating === 'A' ? [2, 4] : 0,
          borderRadius: 2
        },
        emphasis: {
          lineStyle: {
            width: ((visualStyle.lineWidth || 1) + 1 + (isDarkTheme ? 1 : 0)) * 0.5  // 线宽减半
          }
        }
      };
    });
    
    // 合并现有的markLine数据和支撑压力数据
    const markLineData = [...existingData, ...srMarkLineData];
    
    // 添加呼吸灯动画效果（仅S级和A级）
    if (animationEnabled) {
      const animateLevels = () => {
        const time = Date.now() / 1000;
        const animatedData = markLineData.map((data, index) => {
          // 对于现有数据（如昨收线），保持原样
          if (index < existingData.length) {
            return data;
          }
          
          // 对于支撑压力数据，应用动画
          const levelIndex = index - existingData.length;
          const level = filteredLevels[levelIndex];
          if (level && (level.rating === 'S' || level.rating === 'A')) {
            const opacity = 0.7 + Math.sin(time * 2) * 0.3;
            return {
              ...data,
              lineStyle: {
                ...data.lineStyle,
                opacity
              }
            };
          }
          return data;
        });
        
        // 更新markLine
        const newOption = {
          series: [{
            ...option.series[0],
            markLine: {
              symbol: 'none',
              animation: false,
              data: animatedData
            }
          }]
        };
        
        chartInstance.setOption(newOption, { lazyUpdate: true });
        animationFrameRef.current = requestAnimationFrame(animateLevels);
      };
      
      if (filteredLevels.some(l => l.rating === 'S' || l.rating === 'A')) {
        animateLevels();
      }
    } else {
      // 不使用动画，直接设置
      const newOption = {
        series: [{
          ...option.series[0],
          markLine: {
            symbol: 'none',
            animation: false,
            data: markLineData
          }
        }]
      };
      
      chartInstance.setOption(newOption, { lazyUpdate: true });
    }
    
    // 添加接近提醒效果
    const nearestLevels = filteredLevels
      .map(level => ({
        ...level,
        distance: Math.abs(currentPrice - level.price) / level.price
      }))
      .filter(level => level.distance < 0.01) // 1%以内
      .sort((a, b) => a.distance - b.distance);
      
    if (nearestLevels.length > 0) {
      // 高亮最近的支撑压力位
      const highlightData = markLineData.map((data, index) => {
        // 对于现有数据（如昨收线），保持原样
        if (index < existingData.length) {
          return data;
        }
        
        const levelIndex = index - existingData.length;
        const level = filteredLevels[levelIndex];
        const isNearest = level && nearestLevels.some(n => n.price === level.price);
        
        if (isNearest) {
          return {
            ...data,
            lineStyle: {
              ...data.lineStyle,
              width: (data.lineStyle.width || 1) + 1,
              shadowBlur: 10,
              shadowColor: data.lineStyle.color
            },
            label: {
              ...data.label,
              show: true,
              fontSize: 12,
              fontWeight: 'bold'
            }
          };
        }
        return data;
      });
      
      const newOption = {
        series: [{
          ...option.series[0],
          markLine: {
            symbol: 'none',
            animation: false,
            data: highlightData
          }
        }]
      };
      
      chartInstance.setOption(newOption, { lazyUpdate: true });
    }
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [chartInstance, levels, currentPrice, showLabels, animationEnabled, ratingFilter, isDarkTheme, maxLines, mergeThreshold]);
  
  return null; // 这是一个纯逻辑组件，不渲染任何DOM
};