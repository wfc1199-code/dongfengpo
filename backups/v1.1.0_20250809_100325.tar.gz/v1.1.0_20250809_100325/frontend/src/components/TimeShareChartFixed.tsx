import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as echarts from 'echarts';
import { useSupportResistanceTDX as useSupportResistance } from '../hooks/useSupportResistanceTDX';

interface TimeShareChartProps {
  stockCode: string;
  stockName?: string;
  height?: number;
  showVolume?: boolean;
  showMALine?: boolean;
  showSupportResistance?: boolean;
  refreshInterval?: number;
}

interface TimeShareData {
  time: string;
  price: number;
  volume: number;
  amount: number;
  avgPrice: number;
  changePercent: number;
}

interface StockBasicInfo {
  code: string;
  name: string;
  yesterdayClose: number;
  openPrice: number;
  highPrice: number;
  lowPrice: number;
  currentPrice: number;
  volume: number;
  amount: number;
  changeAmount: number;
  changePercent: number;
}


// 生成完整的241分钟时间轴
const generateFullTimeAxis = (): string[] => {
  const times: string[] = [];
  
  // 上午 9:30 - 11:30 (121分钟)
  for (let h = 9; h <= 11; h++) {
    const startMin = (h === 9) ? 30 : 0;
    const endMin = (h === 11) ? 31 : 60;
    for (let m = startMin; m < endMin; m++) {
      times.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }
  
  // 下午 13:00 - 15:00 (120分钟)
  for (let h = 13; h < 15; h++) {
    for (let m = 0; m < 60; m++) {
      times.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }
  
  return times;
};

const FULL_TIME_AXIS = generateFullTimeAxis();
const TOTAL_MINUTES = 241;

const TimeShareChartFixed: React.FC<TimeShareChartProps> = ({
  stockCode,
  stockName = '',
  height = 400,
  showVolume = true,
  showMALine = true,
  showSupportResistance = false,
  refreshInterval = 3000
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stockInfo, setStockInfo] = useState<StockBasicInfo | null>(null);
  const [initialYesterdayClose, setInitialYesterdayClose] = useState<number | null>(null); // 保存初始昨收价
  const [timeshareData, setTimeshareData] = useState<TimeShareData[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);
  
  // 使用支撑压力系统
  const {
    levels: srLevels,
    loading: srLoading,
    error: srError,
    analysis: srAnalysis
  } = useSupportResistance({
    stockCode,
    enabled: showSupportResistance,
    updateInterval: 5000
  });

  // 获取分时数据
  const fetchTimeShareData = useCallback(async () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    
    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;
    
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(`http://localhost:9000/api/stocks/${stockCode}/timeshare`, { signal });
      
      if (signal.aborted) return;
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      
      if (data && data.timeshare_data) {
        // 保存初始昨收价，避免后续更新时跳动
        if (initialYesterdayClose === null && data.yesterday_close) {
          setInitialYesterdayClose(data.yesterday_close);
          console.log('设置初始昨收价:', data.yesterday_close);
        }
        
        // 使用稳定的昨收价
        const stableYesterdayClose = initialYesterdayClose !== null ? initialYesterdayClose : data.yesterday_close;
        
        const basicInfo: StockBasicInfo = {
          code: stockCode,
          name: data.name || stockName,
          yesterdayClose: stableYesterdayClose || 0,
          openPrice: data.open_price || 0,
          highPrice: data.high_price || 0,
          lowPrice: data.low_price || 0,
          currentPrice: data.current_price || 0,
          volume: data.total_volume || 0,
          amount: data.total_amount || 0,
          changeAmount: data.change_amount || 0,
          changePercent: data.change_percent || 0
        };
        
        console.log(`股票 ${stockCode} 数据:`, {
          昨收: stableYesterdayClose,
          今开: data.open_price,
          现价: data.current_price,
          涨跌幅: data.change_percent,
          原始昨收: data.yesterday_close,
          使用昨收: stableYesterdayClose
        });
        
        setStockInfo(basicInfo);
        
        // 更新分时数据状态
        setTimeshareData(data.timeshare_data || []);
        
        // 更新图表
        if (chartInstance.current) {
          updateChart(data.timeshare_data || [], basicInfo);
        }
      }
      
      setLoading(false);
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      
      console.error('获取分时数据失败:', err);
      setError(err.message);
      setLoading(false);
    }
  }, [stockCode, stockName]);

  // 更新图表 - 关键修复在这里
  const updateChart = useCallback((rawData: TimeShareData[], basicInfo: StockBasicInfo) => {
    if (!chartInstance.current) return;
    
    console.log('===== TimeShareChartFixed 调试信息 =====');
    console.log('basicInfo:', basicInfo);
    console.log('昨收价:', initialYesterdayClose || basicInfo.yesterdayClose);
    console.log('rawData长度:', rawData.length);
    console.log('showVolume:', showVolume);
    
    // 初始化241个数据点，全部为null
    const prices: (number | null)[] = new Array(TOTAL_MINUTES).fill(null);
    const avgPrices: (number | null)[] = new Array(TOTAL_MINUTES).fill(null);
    const volumes: number[] = new Array(TOTAL_MINUTES).fill(0);
    
    // 将实际数据映射到正确的时间位置
    if (rawData && rawData.length > 0) {
      rawData.forEach((item) => {
        // 找到时间在完整时间轴中的位置
        const timeIndex = FULL_TIME_AXIS.indexOf(item.time);
        if (timeIndex >= 0 && timeIndex < TOTAL_MINUTES) {
          prices[timeIndex] = item.price;
          avgPrices[timeIndex] = item.avgPrice;
          volumes[timeIndex] = item.volume;
        }
      });
    }

    // 计算Y轴范围
    const validPrices = prices.filter(p => p !== null) as number[];
    const validAvgPrices = avgPrices.filter(p => p !== null) as number[];
    const allPrices = [...validPrices, ...validAvgPrices, initialYesterdayClose || basicInfo.yesterdayClose].filter(p => p > 0);
    
    // 调试成交量数据
    const validVolumes = volumes.filter(v => typeof v === 'number' && v > 0);
    console.log('有效成交量数据点:', validVolumes.length);
    console.log('成交量范围:', validVolumes.length > 0 ? `${Math.min(...validVolumes)} - ${Math.max(...validVolumes)}` : 'N/A');
    console.log('前10个成交量数据:', volumes.slice(0, 10));
    console.log('volumes数据类型检查:', volumes.slice(0, 3).map(v => typeof v));
    
    const stableYesterdayClose = initialYesterdayClose || basicInfo.yesterdayClose;
    
    // 添加调试信息
    console.log('===== Y轴计算调试 =====');
    console.log('initialYesterdayClose:', initialYesterdayClose);
    console.log('basicInfo.yesterdayClose:', basicInfo.yesterdayClose);
    console.log('stableYesterdayClose:', stableYesterdayClose);
    
    // 如果昨收价异常，使用第一个有效价格作为参考
    let finalYesterdayClose = stableYesterdayClose;
    if (!finalYesterdayClose || finalYesterdayClose <= 0) {
      // 使用第一个有效价格作为参考
      const firstValidPrice = validPrices.length > 0 ? validPrices[0] : 0;
      // 如果还是没有有效价格，使用当前价格范围的中间值
      if (firstValidPrice <= 0 && validPrices.length > 0) {
        const avgPrice = validPrices.reduce((a, b) => a + b, 0) / validPrices.length;
        finalYesterdayClose = avgPrice;
      } else {
        finalYesterdayClose = firstValidPrice > 0 ? firstValidPrice : 10;
      }
    }
    console.log('finalYesterdayClose:', finalYesterdayClose);
    
    // 根据股票代码判断涨跌停板限制
    let limitPercent = 0.1; // 默认10%
    if (stockCode.startsWith('sh688') || stockCode.startsWith('sz300')) {
      limitPercent = 0.2; // 科创板和创业板20%
    } else if (stockCode.startsWith('sh68') || stockCode.startsWith('sz30')) {
      limitPercent = 0.2; // 科创板和创业板20%
    }
    
    // 计算基础Y轴范围（涨跌停板）
    let yAxisMax = finalYesterdayClose * (1 + limitPercent);
    let yAxisMin = finalYesterdayClose * (1 - limitPercent);
    
    // 根据实际价格调整范围
    if (allPrices.length > 0) {
      const maxPrice = Math.max(...allPrices);
      const minPrice = Math.min(...allPrices);
      // 确保Y轴范围包含昨收价和所有实际价格
      const adjustedMax = Math.max(maxPrice, finalYesterdayClose);
      const adjustedMin = Math.min(minPrice, finalYesterdayClose);
      const priceRange = adjustedMax - adjustedMin;
      
      // 如果价格波动很小，使用更小的范围
      if (priceRange < finalYesterdayClose * 0.02) {
        // 价格波动小于2%，使用较小的显示范围
        yAxisMax = adjustedMax + finalYesterdayClose * 0.01;
        yAxisMin = adjustedMin - finalYesterdayClose * 0.01;
      } else {
        // 正常波动，留出10%的空间
        yAxisMax = adjustedMax + priceRange * 0.1;
        yAxisMin = adjustedMin - priceRange * 0.1;
      }
    }
    
    console.log('最终Y轴范围:', { yAxisMin, yAxisMax });
    console.log('昨收价位置:', finalYesterdayClose);
    console.log('股票代码:', stockCode);
    console.log('涨跌停限制:', limitPercent);
    console.log('所有价格:', allPrices.slice(0, 10));

    const option = {
      animation: false,
      backgroundColor: '#1a1a1a',
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          animation: false,
          label: {
            backgroundColor: '#505765'
          }
        },
        backgroundColor: 'rgba(50, 50, 50, 0.9)',
        borderColor: '#555',
        textStyle: {
          color: '#ccc'
        },
        formatter: (params: any) => {
          if (!params || params.length === 0) return '';
          
          const index = params[0].dataIndex;
          if (index >= rawData.length) return '';
          
          // 从原始数据中获取对应的数据点
          const timeData = rawData.find((item, i) => {
            const timeIndex = FULL_TIME_AXIS.indexOf(item.time);
            return timeIndex === index;
          });
          
          if (!timeData) return '';
          
          let result = `${params[0].axisValue}<br/>`;
          
          params.forEach((param: any) => {
            if (param.seriesName === '分时价') {
              const tooltipYesterdayClose = initialYesterdayClose || basicInfo.yesterdayClose || timeData.price;
              const color = timeData.price >= tooltipYesterdayClose ? '#FF4444' : '#4CAF50';
              const changePercent = ((timeData.price - tooltipYesterdayClose) / tooltipYesterdayClose * 100);
              result += `${param.seriesName}: <span style="color:${color}">${timeData.price.toFixed(2)}</span><br/>`;
              result += `涨跌幅: <span style="color:${color}">${changePercent >= 0 ? '+' : ''}${changePercent.toFixed(2)}%</span><br/>`;
            } else if (param.seriesName === '均价') {
              result += `${param.seriesName}: ${timeData.avgPrice.toFixed(2)}<br/>`;
            } else if (param.seriesName === '成交量') {
              const volumeColor = '#64B5F6'; // 简化颜色处理
              result += `<span style="color:${volumeColor}">成交量: ${(timeData.volume / 100).toFixed(0)}手</span><br/>`;
              result += `成交额: ${(timeData.amount / 10000).toFixed(2)}万<br/>`;
            }
          });
          
          return result;
        }
      },
      grid: showVolume ? [
        {
          left: 70,
          right: 90,  // 增加右侧空间
          top: '3%',
          height: '65%'
        },
        {
          left: 70,
          right: 90,  // 保持一致
          top: '73%',
          height: '20%'
        }
      ] : [
        {
          left: 70,
          right: 90,  // 增加右侧空间
          top: '3%',
          height: '90%'
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: FULL_TIME_AXIS,
          scale: true,
          boundaryGap: false,
          axisLine: { 
            onZero: false,
            lineStyle: { color: '#555' }
          },
          axisTick: { show: false },
          axisLabel: {
            show: true,
            color: '#999',
            formatter: function(value: string) {
              // 只显示关键时间点
              const keyTimes = ['09:30', '10:00', '10:30', '11:00', '11:30', '13:00', '13:30', '14:00', '14:30', '15:00'];
              return keyTimes.includes(value) ? value : '';
            }
          },
          splitLine: {
            show: true,
            interval: function(index: number) {
              const time = FULL_TIME_AXIS[index];
              return ['10:00', '10:30', '11:00', '11:30', '13:00', '13:30', '14:00', '14:30'].includes(time);
            },
            lineStyle: {
              color: '#333',
              type: 'dashed'
            }
          },
          min: 'dataMin',
          max: 'dataMax'
        },
        ...(showVolume ? [{
          type: 'category',
          gridIndex: 1,
          data: FULL_TIME_AXIS,
          scale: true,
          boundaryGap: false,
          axisLine: { 
            onZero: false,
            lineStyle: { color: '#555' }
          },
          axisTick: { show: false },
          axisLabel: { show: false },
          splitLine: { show: false },
          min: 'dataMin',
          max: 'dataMax'
        }] : [])
      ],
      yAxis: [
        // 左侧价格轴
        {
          type: 'value',
          scale: false,
          position: 'left',
          gridIndex: 0,
          axisLine: { show: true, lineStyle: { color: '#555' } },
          axisTick: { show: true },
          splitNumber: 4,  // 减少刻度数量避免重叠
          min: yAxisMin,
          max: yAxisMax,
          interval: (yAxisMax - yAxisMin) / 4,  // 手动设置间隔
          axisLabel: {
            show: true,
            formatter: (value: number) => value.toFixed(2),
            color: '#999'
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: '#333',
              type: 'dashed'
            }
          }
        },
        // 右侧百分比轴
        {
          type: 'value',
          scale: false,
          position: 'right',
          gridIndex: 0,
          axisLine: { show: true, lineStyle: { color: '#555' } },
          axisTick: { show: true },
          splitNumber: 4,  // 与左侧保持一致
          min: yAxisMin,
          max: yAxisMax,
          interval: (yAxisMax - yAxisMin) / 4,  // 手动设置间隔
          axisLabel: {
            show: true,
            formatter: (function(basePrice) {
              return function(value: number) {
                // 使用闭包捕获的基准价格
                if (!basePrice || basePrice === 0) return '0.00%';
                const percent = ((value - basePrice) / basePrice) * 100;
                return `${percent >= 0 ? '+' : ''}${percent.toFixed(2)}%`;
              };
            })(finalYesterdayClose),
            color: '#999',
            fontSize: 11,  // 稍微减小字体
            margin: 8  // 增加边距
          },
          splitLine: { show: false }
        },
        ...(showVolume ? [{
          type: 'value',
          gridIndex: 1,
          position: 'left',
          min: 0,
          axisLine: { show: true, lineStyle: { color: '#555' } },
          axisTick: { show: false },
          splitNumber: 3,
          axisLabel: {
            show: true,
            formatter: (value: number) => {
              if (value >= 10000) {
                return `${(value / 10000).toFixed(0)}万`;
              }
              return value.toFixed(0);
            },
            color: '#999'
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: '#333',
              type: 'dashed'
            }
          }
        }] : [])
      ],
      series: [
        {
          name: '分时价',
          type: 'line',
          yAxisIndex: 0,  // 绑定到第一个Y轴（左侧价格轴）
          data: prices,
          smooth: false,
          symbol: 'none',
          sampling: 'lttb',
          lineStyle: {
            color: '#64B5F6',
            width: 1
          },
          connectNulls: false, // 关键：不连接null值
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(100, 181, 246, 0.3)' },
                { offset: 1, color: 'rgba(100, 181, 246, 0.05)' }
              ]
            }
          },
          markLine: {
            symbol: 'none',
            silent: false,
            animation: false,
            lineStyle: {
              color: '#999'
            },
            data: [
              // 昨收线（0轴，0%涨跌幅）
              {
                yAxis: finalYesterdayClose,  // 使用计算后的昨收价
                lineStyle: {
                  color: '#ffffff',  // 白色
                  type: 'dashed',  // 虚线
                  width: 2,
                  opacity: 0.8
                },
                label: {
                  show: true,
                  formatter: `昨收 ${finalYesterdayClose.toFixed(2)}`,
                  position: 'insideEndTop',
                  color: '#ffffff',
                  fontSize: 11,
                  backgroundColor: 'rgba(0,0,0,0.6)',
                  padding: [2, 6],
                  borderRadius: 2
                }
              },
              // 添加支撑压力线
              ...(showSupportResistance && srLevels ? srLevels.map(level => ({
                yAxis: level.price,
                lineStyle: {
                  color: level.type === 'support' ? '#00C853' : 
                         level.type === 'resistance' ? '#FF1744' : '#FFC107',
                  type: level.rating === 'S' ? 'solid' : 
                        level.rating === 'A' ? 'solid' :
                        level.rating === 'B' ? 'dashed' : 'dotted',
                  width: level.rating === 'S' ? 3 : 
                         level.rating === 'A' ? 2 :
                         level.rating === 'B' ? 1.5 : 1
                },
                label: {
                  formatter: `${level.description || level.type} ${level.price.toFixed(2)} (${level.rating})`,
                  position: 'end',
                  color: level.type === 'support' ? '#00C853' : 
                         level.type === 'resistance' ? '#FF1744' : '#FFC107',
                  fontSize: 10
                }
              })) : [])
            ]
          }
        },
        ...(showMALine ? [{
          name: '均价',
          type: 'line',
          yAxisIndex: 0,  // 绑定到第一个Y轴（左侧价格轴）
          data: avgPrices,
          smooth: false,
          symbol: 'none',
          sampling: 'lttb',
          lineStyle: {
            color: '#ffc107',
            width: 1
          },
          connectNulls: false // 关键：不连接null值
        }] : []),
        ...(showVolume ? [{
          name: '成交量',
          type: 'bar',
          barWidth: '60%',
          xAxisIndex: 1,
          yAxisIndex: 2,  // 绑定到第三个Y轴（成交量轴）
          data: volumes.map((vol, index) => {
            // 处理可能的对象格式
            let volumeValue = 0;
            if (typeof vol === 'number') {
              volumeValue = vol;
            } else if (vol && typeof vol === 'object' && 'value' in vol) {
              volumeValue = (vol as any).value || 0;
            }
            
            let color = '#64B5F6'; // 默认蓝色
            
            // 根据价格变化确定颜色
            const currentPrice = prices[index];
            const prevPrice = index > 0 ? prices[index - 1] : (initialYesterdayClose || basicInfo.yesterdayClose);
            
            if (currentPrice !== null && prevPrice !== null) {
              if (currentPrice > prevPrice) {
                color = '#FF5252'; // 红色上涨
              } else if (currentPrice < prevPrice) {
                color = '#4CAF50'; // 绿色下跌
              } else {
                color = '#999'; // 灰色平盘
              }
            }
            
            return {
              value: volumeValue,
              itemStyle: {
                color: color
              }
            };
          })
        }] : [])
      ]
    };

    // 调试：输出完整配置
    console.log('ECharts配置 - series数量:', option.series.length);
    console.log('ECharts配置 - yAxis数量:', option.yAxis.length);
    console.log('ECharts配置 - grid数量:', option.grid.length);
    if (showVolume) {
      console.log('成交量series:', option.series[option.series.length - 1]);
    }

    chartInstance.current.setOption(option, true);
  }, [showSupportResistance, srLevels, initialYesterdayClose, stockCode]);

  // 初始化图表
  useEffect(() => {
    if (!chartRef.current) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    chartInstance.current = echarts.init(chartRef.current);
    
    const handleResize = () => {
      chartInstance.current?.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, []);

  // 获取数据
  useEffect(() => {
    if (!stockCode) return;
    
    // 股票代码改变时重置初始昨收价
    setInitialYesterdayClose(null);
    
    fetchTimeShareData();
    const interval = setInterval(fetchTimeShareData, refreshInterval);

    return () => {
      clearInterval(interval);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [stockCode, refreshInterval, fetchTimeShareData]);
  
  // 支撑压力线更新时重新绘制 - 修复成交量数据问题
  useEffect(() => {
    if (!chartInstance.current || !stockInfo || !timeshareData.length) return;
    
    // 只在支撑压力显示状态改变或支撑压力数据改变时更新
    // 避免频繁重绘导致昨收线位置跳动
    if (showSupportResistance || srLevels.length > 0) {
      console.log('支撑压力更新，重绘图表，昨收价:', initialYesterdayClose || stockInfo.yesterdayClose);
      updateChart(timeshareData, stockInfo);
    }
  }, [srLevels, showSupportResistance]); // 移除 stockInfo 和 timeshareData 依赖，避免循环更新

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <div 
        ref={chartRef} 
        style={{ 
          width: '100%', 
          height: '100%',
          opacity: loading ? 0.7 : 1,
          transition: 'opacity 0.3s'
        }} 
      />
      
      {loading && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          color: '#999'
        }}>
          加载中...
        </div>
      )}
      
      {error && (
        <div style={{
          position: 'absolute',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: '#ffebee',
          color: '#c62828',
          padding: '10px',
          borderRadius: '4px'
        }}>
          加载失败: {error}
        </div>
      )}
    </div>
  );
};

export default TimeShareChartFixed;