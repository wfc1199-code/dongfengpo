/**
 * 统一的API服务类
 * 管理所有与后端的HTTP通信
 */

interface RequestOptions extends RequestInit {
  timeout?: number;
}

class APIService {
  private baseURL: string;
  private defaultTimeout: number = 30000; // 30秒超时

  constructor() {
    this.baseURL = process.env.REACT_APP_API_URL || 'http://localhost:9000';
  }

  /**
   * 通用请求方法
   */
  private async request<T>(
    endpoint: string,
    options: RequestOptions = {}
  ): Promise<T> {
    const { timeout = this.defaultTimeout, ...fetchOptions } = options;

    // 创建AbortController用于超时控制
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        ...fetchOptions,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...fetchOptions.headers,
        },
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error: any) {
      clearTimeout(timeoutId);
      
      if (error.name === 'AbortError') {
        throw new Error(`Request timeout after ${timeout}ms`);
      }
      
      throw error;
    }
  }

  /**
   * GET请求
   */
  async get<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'GET',
      ...options,
    });
  }

  /**
   * POST请求
   */
  async post<T>(
    endpoint: string,
    data?: any,
    options?: RequestOptions
  ): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
      ...options,
    });
  }

  /**
   * PUT请求
   */
  async put<T>(
    endpoint: string,
    data?: any,
    options?: RequestOptions
  ): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
      ...options,
    });
  }

  /**
   * DELETE请求
   */
  async delete<T>(endpoint: string, options?: RequestOptions): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'DELETE',
      ...options,
    });
  }
}

// 创建单例实例
export const apiService = new APIService();

// 股票相关API
export const stockAPI = {
  // 获取实时数据
  getRealtime: (stockCode: string) => 
    apiService.get(`/api/stocks/${stockCode}/realtime`),
  
  // 获取分时数据
  getTimeshare: (stockCode: string) =>
    apiService.get(`/api/stocks/${stockCode}/timeshare`),
  
  // 获取K线数据
  getKline: (stockCode: string, period: string = 'daily', limit: number = 100) =>
    apiService.get(`/api/stocks/${stockCode}/kline?period=${period}&limit=${limit}`),
  
  // 获取分钟数据
  getMinute: (stockCode: string) =>
    apiService.get(`/api/stocks/${stockCode}/minute`),
};

// 异动检测API
export const anomalyAPI = {
  // 检测异动
  detect: () => 
    apiService.get('/api/anomaly/detect-legacy'),
  
  // 获取热门板块
  getHotSectors: (sortBy: string = 'hot_score', limit: number = 10) =>
    apiService.get(`/api/anomaly/hot-sectors?sort_by=${sortBy}&limit=${limit}`),
  
  // 获取板块成分股
  getSectorStocks: (sectorName: string) =>
    apiService.get(`/api/anomaly/sector-stocks/${encodeURIComponent(sectorName)}`),
};

// 配置API
export const configAPI = {
  // 获取配置
  getConfig: () =>
    apiService.get('/api/config'),
  
  // 更新配置
  updateConfig: (config: any) =>
    apiService.post('/api/config', config),
};

// 支撑阻力API
export const supportResistanceAPI = {
  // 计算支撑阻力
  calculate: (data: any) =>
    apiService.post('/api/support-resistance/tdx/calculate', data),
};

export default apiService;