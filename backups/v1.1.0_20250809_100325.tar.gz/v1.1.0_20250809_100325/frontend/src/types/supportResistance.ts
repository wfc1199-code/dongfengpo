/**
 * 支撑压力系统类型定义
 */

export interface SupportResistanceLevel {
  id?: string;
  price: number;
  type: 'support' | 'resistance' | 'both' | 'target';
  strength: number; // 0-100
  rating: 'S' | 'A' | 'B' | 'C' | 'D';
  source?: string[]; // ['dynamic', 'volume', 'fibonacci', etc.]
  timeframes?: string[];
  touches?: number;
  lastTouchIndex?: number;
  created?: Date;
  volume?: number;
  description?: string;
  
  // 评级详情
  ratingDetails?: {
    rating: string;
    score: number;
    strongestFactor: string;
    weakestFactor: string;
    recommendation: string;
    confidence: number;
    factors: Record<string, number>;
  };
  
  // 视觉样式
  visualStyle?: {
    color: string;
    lineStyle: 'solid' | 'dashed' | 'dotted';
    lineWidth: number;
    opacity?: number;
    animation?: boolean;
  };
}

export interface VolumeProfile {
  poc: {
    price: number;
    volume: number;
    percentage: number;
  };
  valueArea: {
    high: number;
    low: number;
    volume: number;
    percentage: number;
    range: number;
  };
  hvnLevels: Array<{
    price: number;
    volume: number;
    ratio: number;
    type: 'hvn';
  }>;
  lvnLevels: Array<{
    price: number;
    volume: number;
    ratio: number;
    type: 'lvn';
  }>;
}

export interface SRAnalysisResponse {
  code: string;
  timestamp: string;
  currentPrice: number;
  levels: SupportResistanceLevel[];
  volumeProfile: VolumeProfile;
  statistics: {
    totalLevels: number;
    sRated: number;
    aRated: number;
    bRated: number;
    cRated: number;
  };
}

export interface SRAlert {
  level: SupportResistanceLevel;
  distance: number;
  approaching: 'above' | 'below';
  alertType: 'approaching' | 'breaking' | 'testing';
  message: string;
}

export interface SRControlPanelProps {
  showDynamic: boolean;
  showVolumeProfile: boolean;
  showFibonacci: boolean;
  showTrendlines: boolean;
  showMultiTimeframe: boolean;
  strengthFilter: string[]; // ['S', 'A', 'B', 'C']
  timeframeFilter: string[]; // ['1m', '5m', '15m', etc.]
  onSettingsChange: (settings: Partial<SRControlPanelProps>) => void;
}

export interface VolumeProfileBarData {
  price: number;
  volume: number;
  percentage: number;
  isHVN: boolean;
  isLVN: boolean;
  isPOC: boolean;
  isValueArea: boolean;
}