# 东风破系统 - 版本管理使用指南

## 一、功能概述

版本管理系统提供完整的项目备份、恢复和版本控制功能，确保开发过程中可以随时回退到稳定版本。

## 二、功能特性

### ✅ 核心功能
- **自动备份**：一键创建完整项目备份
- **版本回退**：快速恢复到任意历史版本
- **时间轴视图**：直观查看版本演进历史
- **智能压缩**：自动压缩备份，节省空间
- **安全机制**：回退前自动备份当前版本

## 三、使用方法

### 3.1 命令行使用

#### 快速备份
```bash
# 创建补丁版本 (v1.0.0 -> v1.0.1)
./scripts/version_manager.sh backup patch "修复了某个bug"

# 创建小版本 (v1.0.0 -> v1.1.0)
./scripts/version_manager.sh backup minor "增加了新功能"

# 创建大版本 (v1.0.0 -> v2.0.0)
./scripts/version_manager.sh backup major "重大更新"
```

#### 查看版本
```bash
# 查看版本列表
./scripts/version_manager.sh list

# 查看版本时间轴
./scripts/version_manager.sh timeline
```

#### 版本恢复
```bash
# 恢复到指定版本
./scripts/version_manager.sh restore v1.0.0
```

#### 清理旧备份
```bash
# 清理旧备份（默认保留10个）
./scripts/version_manager.sh clean
```

### 3.2 交互式菜单

```bash
# 启动交互式菜单
./scripts/version_manager.sh

# 或
./scripts/version_manager.sh menu
```

菜单选项：
```
═══════════════════════════════════════
     东风破 - 版本管理系统 v2.0
═══════════════════════════════════════
当前版本: v1.0.1

1) 创建版本备份 (patch)
2) 创建小版本备份 (minor)
3) 创建大版本备份 (major)
4) 查看版本列表
5) 查看版本时间轴
6) 恢复到指定版本
7) 清理旧备份
0) 退出
```

### 3.3 API接口使用

版本管理系统也提供了RESTful API接口：

#### 获取当前版本
```http
GET /api/version/current
```

#### 获取版本列表
```http
GET /api/version/list
```

#### 获取版本时间轴
```http
GET /api/version/timeline
```

#### 创建备份
```http
POST /api/version/backup
{
    "type": "patch",
    "message": "修复bug"
}
```

#### 恢复版本
```http
POST /api/version/restore
{
    "version": "v1.0.0"
}
```

## 四、版本号规则

采用语义化版本号规范（Semantic Versioning）：

```
v<主版本号>.<次版本号>.<修订号>
```

- **主版本号(Major)**：重大架构调整或不兼容的API修改
- **次版本号(Minor)**：新增功能，但保持向后兼容
- **修订号(Patch)**：Bug修复或小改进

## 五、备份内容

每次备份包含以下内容：
- `backend/` - 后端完整代码
- `frontend/src/` - 前端源代码
- `frontend/package.json` - 前端依赖配置
- `scripts/` - 所有脚本文件
- `config/` - 配置文件
- `*.md` - 所有文档文件
- `*.json` - 根目录配置文件
- `*.html` - 测试页面

## 六、存储位置

所有备份文件存储在：
```
/Users/wangfangchun/东风破/backups/
```

备份文件命名格式：
```
v<版本号>_<时间戳>.tar.gz
例如：v1.0.1_20250809_094137.tar.gz
```

## 七、最佳实践

### 📌 开发流程建议

1. **开始新功能前**：创建备份
   ```bash
   ./scripts/version_manager.sh backup patch "开始开发新功能X"
   ```

2. **完成功能后**：创建版本
   ```bash
   ./scripts/version_manager.sh backup minor "完成功能X"
   ```

3. **发现问题时**：快速回退
   ```bash
   ./scripts/version_manager.sh restore v1.0.0
   ```

### ⚠️ 注意事项

1. **定期备份**：建议每天至少备份一次
2. **备注清晰**：备份时写明确的备注信息
3. **空间管理**：定期清理不需要的旧备份
4. **测试验证**：重要更新前先备份，更新后充分测试

## 八、故障处理

### 问题1：备份失败
```bash
# 检查磁盘空间
df -h

# 手动创建备份目录
mkdir -p /Users/wangfangchun/东风破/backups
```

### 问题2：恢复失败
```bash
# 检查备份文件是否存在
ls -la /Users/wangfangchun/东风破/backups/

# 手动解压查看
tar -tzf /Users/wangfangchun/东风破/backups/v1.0.0_*.tar.gz
```

### 问题3：版本数据库损坏
```bash
# 重建版本数据库
rm /Users/wangfangchun/东风破/backups/versions.json
./scripts/version_manager.sh list  # 会自动重建
```

## 九、高级功能

### 自动化备份（可选）
```bash
# 添加到crontab，每天凌晨2点自动备份
crontab -e
0 2 * * * /Users/wangfangchun/东风破/scripts/version_manager.sh backup patch "每日自动备份"
```

### Git集成（可选）
版本管理系统会自动记录Git信息：
- 当前分支
- 最新commit ID
- 便于版本追踪

## 十、版本历史

### 当前版本记录
- **v1.0.1** (2025-08-09 09:41:46)
  - 初始版本备份
  - 增加版本管理功能

---

*文档更新时间：2025-08-09*  
*版本管理系统 v2.0*