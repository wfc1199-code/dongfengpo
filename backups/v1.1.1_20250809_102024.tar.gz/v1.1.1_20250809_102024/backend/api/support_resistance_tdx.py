"""
通达信风格的支撑压力线计算系统
基于7/8和0.5/8的固定比例计算方法
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import numpy as np
from datetime import datetime, timedelta
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/support-resistance/tdx",
    tags=["support-resistance-tdx"]
)

class SRLevel(BaseModel):
    """支撑压力位数据模型"""
    price: float
    type: str  # 'support' | 'resistance' | 'dynamic_support' | 'dynamic_resistance'
    strength: float  # 强度 0-100
    description: str
    color: str  # 显示颜色
    lineStyle: str  # 'solid' | 'dashed' | 'dotted'
    lineWidth: int  # 线宽
    
class SRAnalysis(BaseModel):
    """支撑压力分析结果"""
    current_price: float
    nearest_support: Optional[float]
    nearest_resistance: Optional[float]
    support_strength: float
    resistance_strength: float
    trend_suggestion: str
    risk_level: str

class TDXSupportResistanceCalculator:
    """通达信风格支撑压力计算器"""
    
    def __init__(self):
        self.calculation_period = 240  # 固定计算周期（一个交易日240分钟）
        self.change_threshold = 0.001  # 变化检测阈值
        
    def calculate_fixed_sr(self, high_prices: List[float], low_prices: List[float]) -> Dict[str, float]:
        """
        计算固定周期的支撑压力位
        使用日内高低点计算固定支撑阻力
        """
        if not high_prices or not low_prices:
            return {}
            
        # 日内高低点
        day_high = max(high_prices[-self.calculation_period:]) if len(high_prices) >= self.calculation_period else max(high_prices)
        day_low = min(low_prices[-self.calculation_period:]) if len(low_prices) >= self.calculation_period else min(low_prices)
        price_range = day_high - day_low
        
        if price_range <= 0:
            return {}
        
        # 通达信公式：7/8 和 0.5/8
        fixed_resistance = day_low + price_range * 7 / 8  # 上轨 - 固定阻力
        fixed_support = day_low + price_range * 0.5 / 8  # 下轨 - 固定支撑
        
        # 添加其他重要比例位置（可选）
        mid_point = day_low + price_range * 0.5  # 中轴
        strong_resistance = day_low + price_range * 0.875  # 7/8 强阻力
        strong_support = day_low + price_range * 0.125  # 1/8 强支撑
        
        return {
            'fixed_resistance': fixed_resistance,
            'fixed_support': fixed_support,
            'mid_point': mid_point,
            'strong_resistance': strong_resistance,
            'strong_support': strong_support,
            'day_high': day_high,
            'day_low': day_low
        }
    
    def calculate_dynamic_sr(self, current_price: float, today_open: float, 
                           today_high: float, today_low: float) -> Dict[str, float]:
        """
        计算动态支撑压力位
        使用实时数据计算动态支撑阻力
        """
        # 使用当日实时高低点
        h1 = max(today_open, today_high)
        l1 = min(today_open, today_low)
        p1 = h1 - l1
        
        if p1 <= 0:
            return {}
        
        # 动态计算
        dynamic_resistance = l1 + p1 * 7 / 8  # 动态阻力线
        dynamic_support = l1 + p1 * 0.5 / 8  # 动态支撑线
        
        return {
            'dynamic_resistance': dynamic_resistance,
            'dynamic_support': dynamic_support
        }
    
    def get_historical_levels(self, price_history: List[float], 
                            timestamps: List[str]) -> List[Dict[str, Any]]:
        """
        获取历史支撑压力位
        每30分钟记录一次关键价位
        """
        historical_levels = []
        
        if not price_history or not timestamps:
            return historical_levels
            
        # 每30分钟取一个点
        for i in range(0, len(timestamps), 30):
            if i < len(price_history):
                time = timestamps[i]
                price = price_history[i]
                
                # 判断是否为局部高低点
                window = 15  # 前后15分钟
                start = max(0, i - window)
                end = min(len(price_history), i + window + 1)
                
                local_prices = price_history[start:end]
                if local_prices:
                    if price == max(local_prices):
                        historical_levels.append({
                            'price': price,
                            'type': 'historical_resistance',
                            'time': time,
                            'strength': 30
                        })
                    elif price == min(local_prices):
                        historical_levels.append({
                            'price': price,
                            'type': 'historical_support',
                            'time': time,
                            'strength': 30
                        })
        
        return historical_levels
    
    def merge_nearby_levels(self, levels: List[SRLevel], threshold: float = 0.002) -> List[SRLevel]:
        """
        合并相近的支撑压力位
        阈值为价格的0.2%
        """
        if not levels:
            return []
        
        # 按价格排序
        sorted_levels = sorted(levels, key=lambda x: x.price)
        merged = []
        
        i = 0
        while i < len(sorted_levels):
            current = sorted_levels[i]
            group = [current]
            
            # 找出所有相近的价位
            j = i + 1
            while j < len(sorted_levels):
                if abs(sorted_levels[j].price - current.price) / current.price < threshold:
                    group.append(sorted_levels[j])
                    j += 1
                else:
                    break
            
            # 合并组内价位
            if len(group) > 1:
                avg_price = sum(l.price for l in group) / len(group)
                max_strength = max(l.strength for l in group)
                # 选择最重要的类型
                main_type = group[0].type
                for level in group:
                    if 'fixed' in level.type:
                        main_type = level.type
                        break
                
                merged.append(SRLevel(
                    price=avg_price,
                    type=main_type,
                    strength=min(100, max_strength * 1.2),  # 合并后强度提升
                    description=f"合并{len(group)}个价位",
                    color=group[0].color,
                    lineStyle='solid' if max_strength > 70 else 'dashed',
                    lineWidth=2 if max_strength > 70 else 1
                ))
            else:
                merged.append(current)
            
            i = j
        
        return merged

@router.post("/calculate")
async def calculate_support_resistance(data: Dict[str, Any]):
    """
    计算通达信风格的支撑压力位
    """
    try:
        calculator = TDXSupportResistanceCalculator()
        
        # 提取数据
        current_price = data.get('current_price', 0)
        high_prices = data.get('high_prices', [])
        low_prices = data.get('low_prices', [])
        prices = data.get('prices', [])
        timestamps = data.get('timestamps', [])
        today_open = data.get('today_open', current_price)
        today_high = data.get('today_high', current_price)
        today_low = data.get('today_low', current_price)
        
        levels = []
        
        # 1. 计算固定支撑压力位
        fixed_levels = calculator.calculate_fixed_sr(high_prices, low_prices)
        
        if fixed_levels:
            # 主要支撑压力线
            levels.append(SRLevel(
                price=fixed_levels['fixed_resistance'],
                type='resistance',
                strength=80,
                description='固定阻力(7/8)',
                color='#0000FF',  # 蓝色
                lineStyle='solid',
                lineWidth=2
            ))
            
            levels.append(SRLevel(
                price=fixed_levels['fixed_support'],
                type='support',
                strength=80,
                description='固定支撑(0.5/8)',
                color='#FF00FF',  # 紫色
                lineStyle='solid',
                lineWidth=2
            ))
            
            # 中轴线
            levels.append(SRLevel(
                price=fixed_levels['mid_point'],
                type='pivot',
                strength=60,
                description='中轴线',
                color='#999999',  # 灰色
                lineStyle='dashed',
                lineWidth=1
            ))
        
        # 2. 计算动态支撑压力位
        dynamic_levels = calculator.calculate_dynamic_sr(
            current_price, today_open, today_high, today_low
        )
        
        if dynamic_levels:
            levels.append(SRLevel(
                price=dynamic_levels['dynamic_resistance'],
                type='dynamic_resistance',
                strength=70,
                description='动态阻力',
                color='#FF0000',  # 红色
                lineStyle='dashed',
                lineWidth=1
            ))
            
            levels.append(SRLevel(
                price=dynamic_levels['dynamic_support'],
                type='dynamic_support',
                strength=70,
                description='动态支撑',
                color='#FFFF00',  # 黄色
                lineStyle='dashed',
                lineWidth=1
            ))
        
        # 3. 获取历史关键价位（可选，减少显示）
        if len(prices) > 60 and len(timestamps) > 60:  # 至少有1小时数据
            historical = calculator.get_historical_levels(prices, timestamps)
            for hist in historical[:3]:  # 只取最近3个历史价位
                levels.append(SRLevel(
                    price=hist['price'],
                    type=hist['type'],
                    strength=hist['strength'],
                    description=f"历史关键位 {hist['time']}",
                    color='#99CCFF' if 'resistance' in hist['type'] else '#FF99FF',
                    lineStyle='dotted',
                    lineWidth=1
                ))
        
        # 4. 合并相近的价位
        merged_levels = calculator.merge_nearby_levels(levels)
        
        # 5. 只保留最重要的几条线（限制数量）
        # 按强度排序，保留前6条
        merged_levels.sort(key=lambda x: x.strength, reverse=True)
        final_levels = merged_levels[:6]
        
        # 6. 分析当前价格位置
        analysis = SRAnalysis(
            current_price=current_price,
            nearest_support=None,
            nearest_resistance=None,
            support_strength=0,
            resistance_strength=0,
            trend_suggestion="观望",
            risk_level="中等"
        )
        
        # 找出最近的支撑和阻力
        supports = [l for l in final_levels if 'support' in l.type and l.price < current_price]
        resistances = [l for l in final_levels if 'resistance' in l.type and l.price > current_price]
        
        if supports:
            nearest_support = max(supports, key=lambda x: x.price)
            analysis.nearest_support = nearest_support.price
            analysis.support_strength = nearest_support.strength
        
        if resistances:
            nearest_resistance = min(resistances, key=lambda x: x.price)
            analysis.nearest_resistance = nearest_resistance.price
            analysis.resistance_strength = nearest_resistance.strength
        
        # 趋势建议
        if analysis.nearest_support and analysis.nearest_resistance:
            support_distance = abs(current_price - analysis.nearest_support) / current_price
            resistance_distance = abs(analysis.nearest_resistance - current_price) / current_price
            
            if support_distance < 0.005:  # 接近支撑位
                analysis.trend_suggestion = "接近支撑位，可能反弹"
                analysis.risk_level = "低"
            elif resistance_distance < 0.005:  # 接近阻力位
                analysis.trend_suggestion = "接近阻力位，注意回调"
                analysis.risk_level = "高"
            elif support_distance > resistance_distance * 2:  # 偏向阻力
                analysis.trend_suggestion = "偏向上方阻力"
                analysis.risk_level = "中高"
            elif resistance_distance > support_distance * 2:  # 偏向支撑
                analysis.trend_suggestion = "偏向下方支撑"
                analysis.risk_level = "中低"
            else:
                analysis.trend_suggestion = "区间震荡"
                analysis.risk_level = "中等"
        
        return {
            "success": True,
            "levels": [level.dict() for level in final_levels],
            "analysis": analysis.dict(),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"计算支撑压力位失败: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/test")
async def test_sr_calculation():
    """测试接口"""
    # 模拟数据
    test_data = {
        "current_price": 1450.0,
        "high_prices": [1455, 1458, 1452, 1460, 1456],
        "low_prices": [1445, 1442, 1448, 1440, 1444],
        "prices": [1450, 1452, 1448, 1455, 1451],
        "timestamps": ["09:30", "09:31", "09:32", "09:33", "09:34"],
        "today_open": 1448.0,
        "today_high": 1460.0,
        "today_low": 1440.0
    }
    
    return await calculate_support_resistance(test_data)