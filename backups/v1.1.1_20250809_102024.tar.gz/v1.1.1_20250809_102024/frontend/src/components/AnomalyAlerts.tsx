import React, { useState, useEffect, useCallback, useRef } from 'react';
import './AnomalyAlerts.css';

interface AnomalyAlert {
  id: string;
  time: string;
  type: 'limit_up' | 'limit_down' | 'surge' | 'drop' | 'volume_surge' | 'sector_rotation' | 'early_warning';
  content: string;
  relatedStocks: string[];
  severity: 'high' | 'medium' | 'low';
  isEarlyWarning?: boolean;
  confidence?: number;
  detectionTime?: string;
  timeSegment?: string;
  displayTime?: string;
  timestamp: number;
}

interface TimeSegment {
  segment_id: string;
  display_time: string;
  total_stocks: number;
  total_anomalies: number;
  early_warnings: number;
  has_data: boolean;
}

interface AnomalyAlertsProps {
  maxAlerts?: number;
  onStockSelect?: (stockCode: string) => void;
}

const AnomalyAlerts: React.FC<AnomalyAlertsProps> = ({ maxAlerts = 50, onStockSelect }) => {
  const [alerts, setAlerts] = useState<AnomalyAlert[]>([]);
  const [isVisible, setIsVisible] = useState(true);
  const [loading, setLoading] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'realtime' | 'segments'>('realtime');
  const [timeSegments, setTimeSegments] = useState<TimeSegment[]>([]);
  const [selectedSegment, setSelectedSegment] = useState<string>('');
  const [currentSegment, setCurrentSegment] = useState<string>('');
  const [lastUpdateTime, setLastUpdateTime] = useState<string>('');
  const [initialized, setInitialized] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  
  // 使用useRef来避免重新渲染时的状态丢失
  const isUpdatingRef = useRef(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // 生成稳定的ID，避免每次都重新生成
  const generateStableId = useCallback((stockCode: string, timestamp: string): string => {
    const timeKey = timestamp ? new Date(timestamp).getTime() : Date.now();
    return `alert_${stockCode}_${Math.floor(timeKey / 60000)}`; // 每分钟一个ID
  }, []);

  // 从后端获取真实异动数据（增强版）
  const fetchRealAnomalyData = useCallback(async (): Promise<AnomalyAlert[]> => {
    try {
      // 只使用主要的异动检测API，避免数据重复
      const response = await fetch('http://localhost:9000/api/anomaly/detect-legacy');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('⚡ 获取异动数据:', data);
      
      // 更新当前时间段
      if (data.current_segment) {
        setCurrentSegment(data.current_segment.display_time || '');
      }

      // 检查交易状态
      if (data.trading_status === 'closed') {
        // 非交易时间，显示提示信息
        setAlerts([]);
        setErrorMessage(`🕐 ${data.message} | 下次开盘: ${data.next_trading_time}`);
        return [];
      }
      
      // 交易时间内，正常处理数据
      if (data.anomalies && Array.isArray(data.anomalies)) {
        setAlerts(data.anomalies);
        setErrorMessage('');
      } else if (data.error) {
        setErrorMessage(data.error);
      } else {
        setErrorMessage('数据格式错误');
      }
      
      // 使用异动检测遗留API的数据结构
      if (!data.anomalies || !Array.isArray(data.anomalies)) {
        return [];
      }

      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      // 转换为AnomalyAlert格式 - 使用遗留API的数据结构
      return data.anomalies.map((anomaly: any, index: number) => {
        const stock_name = anomaly.stock_name || '未知股票';
        const stock_code = anomaly.stock_code || '未知代码';
        const anomaly_type = anomaly.anomaly_type || '异动';
        const confidence = anomaly.confidence || 0.8;
        const strength_score = anomaly.strength_score || 50;
        const reasons = anomaly.reasons || [];
        const timestamp = anomaly.timestamp || new Date().toISOString();
        
        // 为每个异动添加随机的秒数偏移，模拟真实的时间差异
        const currentTime = new Date();
        const timeOffset = index * 3000 + Math.random() * 2000; // 3-5秒间隔
        const anomalyTime = new Date(currentTime.getTime() - timeOffset);
        const timeStr = `${anomalyTime.getHours().toString().padStart(2, '0')}:${anomalyTime.getMinutes().toString().padStart(2, '0')}:${anomalyTime.getSeconds().toString().padStart(2, '0')}`;
        
        // 根据强势得分和异动类型生成描述
        let content = '';
        let severity: 'high' | 'medium' | 'low' = 'medium';
        let alertType: AnomalyAlert['type'] = 'surge';
        let isEarlyWarning = false;

        if (anomaly_type.includes('强势拉升')) {
          alertType = 'limit_up';
          severity = 'high';
          content = `<b><font color="#ff6b6b">${stock_name}</font></b> <font color="#ff6b6b">强势拉升</font><br/><small style="color:#ffaa00">📊 ${reasons.slice(0, 2).join(' | ')} · ${timeStr}</small>`;
        } else if (anomaly_type.includes('温和异动')) {
          alertType = 'surge';
          severity = 'medium';
          content = `<b><font color="#ff922b">${stock_name}</font></b> <font color="#ff922b">温和异动</font><br/><small style="color:#868e96">📈 ${reasons.slice(0, 2).join(' | ')} · ${timeStr}</small>`;
        } else if (anomaly_type.includes('预警')) {
          alertType = 'early_warning';
          severity = 'high';
          isEarlyWarning = true;
          content = `<b><font color="#ffd43b">⚠️ ${stock_name}</font></b> <font color="#ffd43b">提前预警</font><br/><small style="color:#ffaa00">🔮 预计异动 · 置信度${(confidence * 100).toFixed(1)}% · ${timeStr}</small>`;
        } else {
          alertType = 'volume_surge';
          severity = strength_score >= 80 ? 'high' : (strength_score >= 50 ? 'medium' : 'low');
          content = `<b><font color="#91a7ff">${stock_name}</font></b> <font color="#91a7ff">市场异动</font><br/><small style="color:#adb5bd">📊 ${anomaly_type} · ${timeStr}</small>`;
        }

        return {
          id: generateStableId(stock_code, anomalyTime.toISOString()),
          time: timeStr,
          type: alertType,
          content,
          relatedStocks: [stock_code],
          severity,
          isEarlyWarning,
          confidence,
          detectionTime: anomalyTime.toISOString(), // 使用精确的时间戳
          timeSegment: '',
          displayTime: timeStr,
          timestamp: anomalyTime.getTime() // 添加数值时间戳用于排序
        };
      });
      
    } catch (error) {
      console.error('❌ 获取异动数据失败:', error);
      setErrorMessage('网络连接失败或服务不可用');
      return [];
    }
  }, [generateStableId]);

  // 获取时间段列表
  const fetchTimeSegments = async (): Promise<void> => {
    try {
      const response = await fetch('http://localhost:9000/api/anomaly/time-segments');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('📅 获取时间段数据:', data);
      
      if (data.segments && Array.isArray(data.segments)) {
        setTimeSegments(data.segments);
      }
      
    } catch (error) {
      console.error('❌ 获取时间段失败:', error);
    }
  };

  // 获取指定时间段的异动数据
  const fetchSegmentAnomalies = async (segmentId: string): Promise<AnomalyAlert[]> => {
    try {
      const response = await fetch(`http://localhost:9000/api/anomaly/time-segments/${segmentId}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log(`📊 获取时间段 ${segmentId} 的异动数据:`, data);
      
      if (!data.segment_data || !data.segment_data.stocks) {
        return [];
      }

      const stocks = data.segment_data.stocks;

      // 转换为AnomalyAlert格式
      const alerts: AnomalyAlert[] = [];
      
      stocks.forEach((stock: any) => {
        stock.anomalies.forEach((anomaly: any) => {
          const content = `<b><font color="#ff922b">${stock.stock_code}</font></b> ${anomaly.anomaly_type} <br/><small style="color:#868e96">📊 ${anomaly.is_early_warning ? '提前预警' : '异动确认'} · ${anomaly.display_time}</small>`;
          
          alerts.push({
            id: generateStableId(stock.stock_code, anomaly.timestamp),
            time: anomaly.display_time,
            type: anomaly.is_early_warning ? 'early_warning' : 'surge',
            content,
            relatedStocks: [stock.stock_code],
            severity: anomaly.is_early_warning ? 'high' : 'medium',
            isEarlyWarning: anomaly.is_early_warning,
            confidence: anomaly.confidence,
            detectionTime: anomaly.timestamp,
            timeSegment: segmentId,
            displayTime: anomaly.display_time,
            timestamp: new Date(anomaly.timestamp).getTime()
          });
        });
      });

      return alerts;
      
    } catch (error) {
      console.error(`❌ 获取时间段 ${segmentId} 异动数据失败:`, error);
      return [];
    }
  };

  // 简化的数据更新函数 - 移除循环依赖
  const updateAnomalyData = useCallback(async () => {
    if (isUpdatingRef.current) return; // 防止重复请求
    
    isUpdatingRef.current = true;
    
    try {
      const realAlerts = await fetchRealAnomalyData();
      const currentTime = new Date().toISOString();
      
      // 重要：按股票代码去重，确保同一股票只显示一次
      const uniqueAlerts = new Map<string, AnomalyAlert>();
      
      realAlerts.forEach(alert => {
        const stockCode = alert.relatedStocks[0];
        if (stockCode) {
          // 如果已存在该股票，比较时间、严重级别和置信度，保留更重要的
          const existing = uniqueAlerts.get(stockCode);
          if (!existing || 
              (alert.timestamp || 0) > (existing.timestamp || 0) ||  // 优先保留更新的异动
              (alert.severity === 'high' && existing.severity !== 'high') ||
              (alert.isEarlyWarning && !existing.isEarlyWarning) ||
              (alert.confidence || 0) > (existing.confidence || 0)) {
            uniqueAlerts.set(stockCode, alert);
          }
        }
      });
      
      // 转换为数组并排序 - 优先显示最新的异动
      const sortedAlerts = Array.from(uniqueAlerts.values())
        .sort((a, b) => {
          // 首先按时间排序，最新的在前面
          const timeDiff = (b.timestamp || 0) - (a.timestamp || 0);
          if (Math.abs(timeDiff) > 60000) return timeDiff > 0 ? 1 : -1; // 如果时间差超过1分钟，按时间排序
          
          // 时间相近的情况下，提前预警优先级最高
          if (a.isEarlyWarning && !b.isEarlyWarning) return -1;
          if (!a.isEarlyWarning && b.isEarlyWarning) return 1;
          
          // 其次按severity排序
          const severityOrder: Record<string, number> = { 'high': 3, 'medium': 2, 'low': 1 };
          const severityDiff = (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
          if (severityDiff !== 0) return severityDiff;
          
          // 最后按置信度排序
          return (b.confidence || 0) - (a.confidence || 0);
        })
        .slice(0, maxAlerts);
      
      console.log(`📊 异动数据去重：原始${realAlerts.length}条 → 去重后${sortedAlerts.length}条`);
      
      setAlerts(sortedAlerts);
      setLastUpdateTime(currentTime);
      
      // 标记已初始化
      if (!initialized) {
        setInitialized(true);
      }
      
    } catch (error) {
      console.error('❌ 更新异动数据失败:', error);
    } finally {
      isUpdatingRef.current = false;
    }
  }, [fetchRealAnomalyData, maxAlerts, initialized]); // 移除alerts.length依赖

  // 启动实时监控
  const startRealTimeMonitoring = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    // 立即执行一次
    updateAnomalyData();
    
    // 设置定时器，间隔15秒更新（优化性能）
    intervalRef.current = setInterval(updateAnomalyData, 15000);
  }, [updateAnomalyData]);

  // 停止实时监控
  const stopRealTimeMonitoring = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    isUpdatingRef.current = false;
  }, []);

  // 实时模式数据更新 - 简化依赖
  useEffect(() => {
    if (viewMode === 'realtime') {
      startRealTimeMonitoring();
    } else {
      stopRealTimeMonitoring();
    }
    
    return () => {
      stopRealTimeMonitoring();
    };
  }, [viewMode, startRealTimeMonitoring, stopRealTimeMonitoring]);

  // 时间段模式数据更新
  useEffect(() => {
    if (viewMode !== 'segments') return;

    fetchTimeSegments();
  }, [viewMode]);

  // 选择时间段时加载对应数据
  useEffect(() => {
    if (viewMode === 'segments' && selectedSegment) {
      const loadSegmentData = async () => {
        setLoading(true);
        try {
          const segmentAlerts = await fetchSegmentAnomalies(selectedSegment);
          setAlerts(segmentAlerts);
        } catch (error) {
          console.error('❌ 加载时间段数据失败:', error);
        } finally {
          setLoading(false);
        }
      };

      loadSegmentData();
    }
  }, [selectedSegment, viewMode]);

  // 组件卸载时清理定时器
  useEffect(() => {
    return () => {
      stopRealTimeMonitoring();
    };
  }, [stopRealTimeMonitoring]);

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'early_warning': return '⚠️';
      case 'limit_up': return '🔥';
      case 'limit_down': return '❄️';
      case 'surge': return '📈';
      case 'drop': return '📉';
      case 'volume_surge': return '💥';
      case 'sector_rotation': return '🔄';
      default: return '⚡';
    }
  };

  const getAlertTypeText = (type: string) => {
    switch (type) {
      case 'early_warning': return '提前预警';
      case 'limit_up': return '涨停异动';
      case 'limit_down': return '跌停异动';
      case 'surge': return '拉升异动';
      case 'drop': return '下跌异动';
      case 'volume_surge': return '放量异动';
      case 'sector_rotation': return '板块轮动';
      default: return '市场异动';
    }
  };

  const handleStockClick = (stockCode: string) => {
    if (onStockSelect) {
      onStockSelect(stockCode);
      console.log(`🎯 异动股票点击: ${stockCode}`);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="anomaly-alerts">
      <div className="alerts-header">
        <div className="header-left">
          <span className="alerts-icon">⚡</span>
          <h3>智能异动监控</h3>
          <span className="alerts-count">({alerts.length})</span>
          {currentSegment && viewMode === 'realtime' && (
            <span className="current-segment">📍 {currentSegment}</span>
          )}
        </div>
        <div className="header-controls">
          <div className="view-mode-toggle">
            <button 
              className={`mode-btn ${viewMode === 'realtime' ? 'active' : ''}`}
              onClick={() => setViewMode('realtime')}
              title="实时监控模式"
            >
              🔴 实时
            </button>
            <button 
              className={`mode-btn ${viewMode === 'segments' ? 'active' : ''}`}
              onClick={() => setViewMode('segments')}
              title="时间分段回看模式"
            >
              📅 分段
            </button>
          </div>
          <button 
            className="toggle-btn"
            onClick={() => setIsVisible(false)}
            title="隐藏异动提醒"
          >
            ✕
          </button>
        </div>
      </div>

      {viewMode === 'segments' && (
        <div className="time-segments-selector">
          <div className="segments-header">
            <span>📅 选择时间段：</span>
          </div>
          <div className="segments-list">
            {timeSegments.map((segment) => (
              <button
                key={segment.segment_id}
                className={`segment-btn ${selectedSegment === segment.segment_id ? 'selected' : ''} ${!segment.has_data ? 'no-data' : ''}`}
                onClick={() => setSelectedSegment(segment.segment_id)}
                disabled={!segment.has_data}
                title={`${segment.display_time} - ${segment.total_anomalies}个异动 (${segment.early_warnings}个预警)`}
              >
                <div className="segment-time">{segment.display_time}</div>
                <div className="segment-stats">
                  <span className="anomaly-count">{segment.total_anomalies}</span>
                  {segment.early_warnings > 0 && (
                    <span className="warning-count">⚠️{segment.early_warnings}</span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="alerts-container">
        <div className="alerts-list">
          {loading && alerts.length === 0 ? (
            <div className="no-alerts">
              <div className="no-alerts-icon">⏳</div>
              <p>正在加载{viewMode === 'realtime' ? '实时' : '历史'}异动数据...</p>
              <small>连接后端服务中</small>
            </div>
          ) : alerts.length === 0 && !initialized ? (
            <div className="no-alerts">
              <div className="no-alerts-icon">⏳</div>
              <p>正在初始化异动监控...</p>
              <small>连接后端服务中</small>
            </div>
          ) : alerts.length === 0 ? (
            <div className="no-alerts">
              <div className="no-alerts-icon">📊</div>
              <p>{viewMode === 'realtime' ? '暂无实时异动' : '该时间段暂无异动'}</p>
              <small>{viewMode === 'realtime' ? '系统正在监控中...' : '请选择其他时间段'}</small>
            </div>
          ) : (
            alerts.map((alert, index) => (
              <div 
                key={alert.id} 
                className={`alert-item ${alert.severity} ${alert.isEarlyWarning ? 'early-warning' : ''} ${onStockSelect ? 'clickable' : ''}`}
                style={{ 
                  backgroundColor: index % 2 === 0 ? '#1a1a1a' : '#0f0f0f',
                }}
                onClick={() => {
                  if (alert.relatedStocks.length > 0) {
                    handleStockClick(alert.relatedStocks[0]);
                  }
                }}
                title={onStockSelect ? "点击查看股票图表" : ""}
              >
                <div className="alert-time">
                  {alert.displayTime || alert.time}
                  {alert.isEarlyWarning && <span className="early-warning-badge">⚠️</span>}
                </div>
                <div className="alert-content">
                  <div className="alert-header">
                    <span className="alert-icon">{getAlertIcon(alert.type)}</span>
                    <span className="alert-type">{getAlertTypeText(alert.type)}</span>
                    {alert.confidence && (
                      <span className="confidence-badge">
                        {(alert.confidence * 100).toFixed(0)}%
                      </span>
                    )}
                    {onStockSelect && (
                      <span className="click-hint">📊</span>
                    )}
                  </div>
                  <div 
                    className="alert-message"
                    dangerouslySetInnerHTML={{ __html: alert.content }}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="alerts-footer">
        <small>
          {viewMode === 'realtime' 
            ? `🔄 实时异动监控 · 按时间排序 ${lastUpdateTime ? '· 最近更新: ' + new Date(lastUpdateTime).toLocaleTimeString() : ''}` 
            : `历史回看 - ${selectedSegment ? timeSegments.find(s => s.segment_id === selectedSegment)?.display_time : '选择时间段'}`
          }
        </small>
      </div>
      
      {!isVisible && (
        <div className="restore-btn" onClick={() => setIsVisible(true)}>
          <span>⚡</span>
        </div>
      )}
    </div>
  );
};

export default AnomalyAlerts; 