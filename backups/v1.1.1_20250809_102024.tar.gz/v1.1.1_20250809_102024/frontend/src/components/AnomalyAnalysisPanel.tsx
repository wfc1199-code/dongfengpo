import React, { useState, useEffect } from 'react';
import './AnomalyAnalysisPanel.css';

interface AnomalyData {
  time: string;
  price: number;
  change_percent: number;
  volume: number;
  intent: string;
  confidence: number;
  volume_features: {
    volume_type: string;
    volume_ratio: number;
    volume_price_match: string;
    continuous_heavy_volume?: boolean;
  };
  price_behavior: {
    speed_type: string;
    pattern: string;
    breakout: string;
    speed_5min?: number;
  };
  large_orders?: {
    large_buy_count: number;
    large_sell_count: number;
    large_buy_amount: number;
    large_sell_amount: number;
    large_order_nature: string;
    order_concentration: number;
  };
  analysis: string;
  trading_suggestion: {
    action: string;
    reason: string;
    risk: string;
    strategy: string;
    confidence: number;
  };
}

interface AnomalyAnalysisPanelProps {
  anomaly: {
    time: string;
    price: number;
    type: 'surge' | 'plunge';
    changePercent: number;
    index: number;
  } | null;
  stockCode: string;
  onClose?: () => void;
}

const AnomalyAnalysisPanel: React.FC<AnomalyAnalysisPanelProps> = ({
  anomaly,
  stockCode,
  onClose
}) => {
  const [analysisData, setAnalysisData] = useState<AnomalyData | null>(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);

  // 获取异动深度分析
  useEffect(() => {
    if (!anomaly) return;

    const fetchAnalysis = async () => {
      setLoading(true);
      try {
        // 模拟API调用，实际应调用后端分析接口
        const mockAnalysis: AnomalyData = {
          time: anomaly.time,
          price: anomaly.price,
          change_percent: anomaly.changePercent,
          volume: 150000,
          intent: anomaly.type === 'surge' ? '拉升' : '洗盘',
          confidence: 0.75,
          volume_features: {
            volume_type: '放量',
            volume_ratio: 2.5,
            volume_price_match: anomaly.type === 'surge' ? '量价齐升' : '放量下跌',
            continuous_heavy_volume: false
          },
          price_behavior: {
            speed_type: '急速',
            pattern: anomaly.type === 'surge' ? '直线拉升' : '直线砸盘',
            breakout: '区间震荡',
            speed_5min: anomaly.changePercent
          },
          large_orders: {
            large_buy_count: 12,
            large_sell_count: 8,
            large_buy_amount: 8500000,
            large_sell_amount: 5200000,
            large_order_nature: '大单净买入',
            order_concentration: 0.35
          },
          analysis: generateAnalysisText(anomaly),
          trading_suggestion: {
            action: anomaly.type === 'surge' ? '持有或适量跟进' : '持有或逢低加仓',
            reason: anomaly.type === 'surge' ? '主力拉升，趋势向上' : '主力洗盘，清洗浮筹',
            risk: '中等',
            strategy: anomaly.type === 'surge' ? '持股待涨，注意量能持续性' : '等待洗盘结束，关注量能变化',
            confidence: 0.75
          }
        };

        setAnalysisData(mockAnalysis);
      } catch (error) {
        console.error('Failed to fetch analysis:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalysis();
  }, [anomaly, stockCode]);

  if (!anomaly) return null;

  const generateAnalysisText = (anomalyData: any) => {
    return `【主力意图】${anomalyData.type === 'surge' ? '拉升' : '洗盘'} (置信度: 75%)

【量价分析】
- 成交量: 放量
- 量比: 2.5
- 量价关系: ${anomalyData.type === 'surge' ? '量价齐升' : '放量下跌'}

【价格行为】
- 走势形态: ${anomalyData.type === 'surge' ? '直线拉升' : '震荡下跌'}
- 速度类型: 急速
- 技术位置: 区间内

【大单分析】
- 大单性质: ${anomalyData.type === 'surge' ? '大单净买入' : '大单平衡'}
- 大买单: 12笔
- 大卖单: 8笔
- 成交集中度: 35%`;
  };

  const getIntentColor = (intent: string) => {
    switch (intent) {
      case '拉升':
      case '吸筹':
        return '#ff4444';
      case '洗盘':
        return '#ff9800';
      case '出货':
      case '打压':
        return '#00cc00';
      default:
        return '#999';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case '高':
        return '#ff4444';
      case '中等':
        return '#ff9800';
      case '低':
        return '#4caf50';
      default:
        return '#999';
    }
  };

  return (
    <div className="anomaly-analysis-panel">
      {/* 标题栏 */}
      <div className="panel-header">
        <div className="header-left">
          <span className="header-icon">
            {anomaly.type === 'surge' ? '🚀' : '⚠️'}
          </span>
          <span className="header-title">异动深度分析</span>
          <span className="header-time">{anomaly.time}</span>
        </div>
        <div className="header-right">
          <button className="expand-btn" onClick={() => setExpanded(!expanded)}>
            {expanded ? '−' : '+'}
          </button>
          {onClose && (
            <button className="close-btn" onClick={onClose}>×</button>
          )}
        </div>
      </div>

      {expanded && (
        <>
          {/* 主要指标 */}
          <div className="main-indicators">
            <div className="indicator-card">
              <div className="indicator-label">当前价格</div>
              <div className="indicator-value">¥{anomaly.price.toFixed(2)}</div>
            </div>
            <div className="indicator-card">
              <div className="indicator-label">涨跌幅</div>
              <div className={`indicator-value ${anomaly.type}`}>
                {anomaly.changePercent > 0 ? '+' : ''}{anomaly.changePercent.toFixed(2)}%
              </div>
            </div>
            {analysisData && (
              <>
                <div className="indicator-card">
                  <div className="indicator-label">主力意图</div>
                  <div 
                    className="indicator-value"
                    style={{ color: getIntentColor(analysisData.intent) }}
                  >
                    {analysisData.intent}
                  </div>
                </div>
                <div className="indicator-card">
                  <div className="indicator-label">置信度</div>
                  <div className="indicator-value">
                    {(analysisData.confidence * 100).toFixed(0)}%
                  </div>
                </div>
              </>
            )}
          </div>

          {loading && (
            <div className="loading-state">分析中...</div>
          )}

          {analysisData && !loading && (
            <>
              {/* 量价特征 */}
              <div className="analysis-section">
                <div className="section-title">📊 量价特征</div>
                <div className="feature-grid">
                  <div className="feature-item">
                    <span className="feature-label">成交量:</span>
                    <span className="feature-value">
                      {analysisData.volume_features.volume_type}
                    </span>
                  </div>
                  <div className="feature-item">
                    <span className="feature-label">量比:</span>
                    <span className="feature-value">
                      {analysisData.volume_features.volume_ratio.toFixed(2)}
                    </span>
                  </div>
                  <div className="feature-item">
                    <span className="feature-label">量价关系:</span>
                    <span className="feature-value">
                      {analysisData.volume_features.volume_price_match}
                    </span>
                  </div>
                  <div className="feature-item">
                    <span className="feature-label">走势形态:</span>
                    <span className="feature-value">
                      {analysisData.price_behavior.pattern}
                    </span>
                  </div>
                </div>
              </div>

              {/* 大单分析 */}
              {analysisData.large_orders && (
                <div className="analysis-section">
                  <div className="section-title">💰 大单分析</div>
                  <div className="large-order-stats">
                    <div className="order-stat">
                      <div className="stat-label">大买单</div>
                      <div className="stat-value buy">
                        {analysisData.large_orders.large_buy_count}笔
                      </div>
                      <div className="stat-amount">
                        ¥{(analysisData.large_orders.large_buy_amount / 10000).toFixed(0)}万
                      </div>
                    </div>
                    <div className="order-stat">
                      <div className="stat-label">大卖单</div>
                      <div className="stat-value sell">
                        {analysisData.large_orders.large_sell_count}笔
                      </div>
                      <div className="stat-amount">
                        ¥{(analysisData.large_orders.large_sell_amount / 10000).toFixed(0)}万
                      </div>
                    </div>
                    <div className="order-stat">
                      <div className="stat-label">净买入</div>
                      <div className={`stat-value ${
                        analysisData.large_orders.large_buy_amount > analysisData.large_orders.large_sell_amount 
                          ? 'buy' : 'sell'
                      }`}>
                        ¥{((analysisData.large_orders.large_buy_amount - analysisData.large_orders.large_sell_amount) / 10000).toFixed(0)}万
                      </div>
                    </div>
                  </div>
                  <div className="concentration-bar">
                    <div className="bar-label">成交集中度</div>
                    <div className="bar-track">
                      <div 
                        className="bar-fill"
                        style={{ 
                          width: `${analysisData.large_orders.order_concentration * 100}%`,
                          background: analysisData.large_orders.order_concentration > 0.3 
                            ? '#ff4444' : '#ff9800'
                        }}
                      />
                    </div>
                    <div className="bar-value">
                      {(analysisData.large_orders.order_concentration * 100).toFixed(1)}%
                    </div>
                  </div>
                </div>
              )}

              {/* 主力意图判断 */}
              <div className="analysis-section intent-section">
                <div className="section-title">🎯 主力意图判断</div>
                <div className="intent-badge" style={{ 
                  borderColor: getIntentColor(analysisData.intent),
                  background: `${getIntentColor(analysisData.intent)}15`
                }}>
                  <span className="intent-text" style={{ color: getIntentColor(analysisData.intent) }}>
                    {analysisData.intent}
                  </span>
                  <span className="confidence-text">
                    置信度: {(analysisData.confidence * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="intent-explanation">
                  {analysisData.intent === '洗盘' && (
                    <>
                      <div className="explanation-item">✓ 快速下跌但成交量未明显放大</div>
                      <div className="explanation-item">✓ 在关键支撑位获得支撑</div>
                      <div className="explanation-item">✓ 大单有承接，并非恐慌性抛售</div>
                    </>
                  )}
                  {analysisData.intent === '出货' && (
                    <>
                      <div className="explanation-item">⚠ 放量下跌，抛压沉重</div>
                      <div className="explanation-item">⚠ 大单持续卖出</div>
                      <div className="explanation-item">⚠ 跌破重要支撑位</div>
                    </>
                  )}
                  {analysisData.intent === '拉升' && (
                    <>
                      <div className="explanation-item">↑ 放量上攻，买盘积极</div>
                      <div className="explanation-item">↑ 大单持续买入</div>
                      <div className="explanation-item">↑ 突破压力位或创新高</div>
                    </>
                  )}
                </div>
              </div>

              {/* 操作建议 */}
              <div className="analysis-section suggestion-section">
                <div className="section-title">💡 操作建议</div>
                <div className="suggestion-card">
                  <div className="suggestion-header">
                    <span className="suggestion-action">
                      {analysisData.trading_suggestion.action}
                    </span>
                    <span 
                      className="risk-badge"
                      style={{ color: getRiskColor(analysisData.trading_suggestion.risk) }}
                    >
                      风险: {analysisData.trading_suggestion.risk}
                    </span>
                  </div>
                  <div className="suggestion-reason">
                    {analysisData.trading_suggestion.reason}
                  </div>
                  <div className="suggestion-strategy">
                    策略: {analysisData.trading_suggestion.strategy}
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default AnomalyAnalysisPanel;