import React, { useState, useEffect } from 'react';
import { performanceMonitor } from '../utils/performance';
import { cacheManager } from '../utils/cache';
import './PerformancePanel.css';

interface PerformancePanelProps {
  isVisible: boolean;
  onClose: () => void;
}

const PerformancePanel: React.FC<PerformancePanelProps> = ({ isVisible, onClose }) => {
  const [performanceData, setPerformanceData] = useState<any>(null);
  const [cacheStats, setCacheStats] = useState<any>(null);

  useEffect(() => {
    if (!isVisible) return;

    const updateStats = () => {
      const performance = performanceMonitor.getPerformanceReport();
      const cache = cacheManager.getStats();
      
      setPerformanceData(performance);
      setCacheStats(cache);
    };

    updateStats();
    const interval = setInterval(updateStats, 5000); // 每5秒更新

    return () => clearInterval(interval);
  }, [isVisible]);

  if (!isVisible) return null;

  const formatMemorySize = (bytes: number): string => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const formatTime = (ms: number): string => {
    return `${ms.toFixed(0)}ms`;
  };

  return (
    <div className="performance-panel-overlay">
      <div className="performance-panel">
        <div className="panel-header">
          <h3>🚀 性能监控面板</h3>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>

        <div className="panel-content">
          {/* 系统健康状态 */}
          <div className="health-indicator">
            <div className={`health-status ${performanceData?.isHealthy ? 'healthy' : 'warning'}`}>
              {performanceData?.isHealthy ? '🟢 系统状态良好' : '🟡 性能需要关注'}
            </div>
          </div>

          {/* 内存使用情况 */}
          {performanceData?.memory && (
            <div className="stats-section">
              <h4>💾 内存使用情况</h4>
              <div className="stats-grid">
                <div className="stat-item">
                  <span className="stat-label">已使用:</span>
                  <span className="stat-value">
                    {formatMemorySize(performanceData.memory.usedJSHeapSize)}
                  </span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">总计:</span>
                  <span className="stat-value">
                    {formatMemorySize(performanceData.memory.totalJSHeapSize)}
                  </span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">使用率:</span>
                  <span className="stat-value">
                    {((performanceData.memory.usedJSHeapSize / performanceData.memory.jsHeapSizeLimit) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* API性能统计 */}
          <div className="stats-section">
            <h4>🌐 API响应时间</h4>
            <div className="api-stats">
              {Object.entries(performanceData?.apiStats || {}).map(([endpoint, stats]: [string, any]) => (
                <div key={endpoint} className="api-stat-item">
                  <div className="api-endpoint">{endpoint}</div>
                  <div className="api-metrics">
                    <span className="metric">
                      平均: {formatTime(stats.avgTime)}
                    </span>
                    <span className="metric">
                      调用: {stats.callCount}次
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 缓存统计 */}
          <div className="stats-section">
            <h4>📦 缓存统计</h4>
            <div className="cache-stats">
              <div className="stat-item">
                <span className="stat-label">缓存项数:</span>
                <span className="stat-value">{cacheStats?.size || 0}</span>
              </div>
              <div className="cache-keys">
                <div className="stat-label">缓存键:</div>
                <div className="keys-list">
                  {cacheStats?.keys?.slice(0, 5).map((key: string, index: number) => (
                    <span key={index} className="cache-key">{key}</span>
                  )) || []}
                  {(cacheStats?.keys?.length || 0) > 5 && (
                    <span className="more-keys">...等{cacheStats.keys.length - 5}个</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="panel-actions">
            <button 
              className="action-btn clear-cache"
              onClick={() => {
                cacheManager.clear();
                setCacheStats({ size: 0, keys: [] });
              }}
            >
              🗑️ 清理缓存
            </button>
            <button 
              className="action-btn refresh"
              onClick={() => window.location.reload()}
            >
              🔄 刷新页面
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformancePanel;