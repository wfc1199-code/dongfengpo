import React, { useState, useEffect } from 'react';
import './SectorFlow.css';

interface SectorFlowData {
  sectorName: string;
  netInflow: number;    // 净流入(万元)
  changePercent: number; // 涨跌幅%
  strongStocks: number;  // 强势股数量
  leadingStock: {
    code: string;
    name: string;
    change: number;
  };
  flowTrend: 'in' | 'out' | 'balanced';
}

interface SectorFlowProps {
  className?: string;
}

const SectorFlow: React.FC<SectorFlowProps> = ({ className }) => {
  const [flowData, setFlowData] = useState<SectorFlowData[]>([]);
  const [updateTime, setUpdateTime] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  // 从后端获取真实数据
  const fetchRealFlowData = async (): Promise<SectorFlowData[]> => {
    try {
      // 获取热门板块数据
              const response = await fetch('http://localhost:9000/api/anomaly/hot-sectors?sort_by=hot_score&limit=8');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('📊 获取板块资金流向数据:', data);
      
      if (!data.sectors || !Array.isArray(data.sectors)) {
        throw new Error('Invalid sectors data format');
      }

      // 转换为SectorFlowData格式
      return data.sectors.map((sector: any, index: number) => {
        // 根据成交额和涨幅计算净流入（简化计算）
        const totalAmount = sector.total_amount || 0;
        const avgChange = sector.avg_change || 0;
        
        // 净流入计算：成交额 * 涨幅系数，转换为万元
        let netInflow = (totalAmount / 10000) * (avgChange / 100) * 0.3; // 简化的资金流向计算
        netInflow = Math.round(netInflow);
        
        // 确定流向趋势
        let flowTrend: 'in' | 'out' | 'balanced' = 'balanced';
        if (avgChange > 0.5) flowTrend = 'in';
        else if (avgChange < -0.5) flowTrend = 'out';
        
        // 假设领涨股数据（实际项目中应该从具体股票数据中获取）
        const leadingStockNames = {
          '银行金融': '招商银行',
          '白酒食品': '贵州茅台',
          '科技硬件': '海康威视',
          '新能源汽车': '宁德时代',
          '医药生物': '恒瑞医药'
        };
        
        const leadingStockName = leadingStockNames[sector.sector_name as keyof typeof leadingStockNames] || sector.sector_name;
        
        return {
          sectorName: sector.sector_name,
          netInflow,
          changePercent: Number(avgChange.toFixed(2)),
          strongStocks: sector.anomaly_count || 0,
          leadingStock: {
            code: '000001', // 占位符，实际项目中应获取真实代码
            name: leadingStockName,
            change: Number((avgChange * 1.2).toFixed(2)) // 领涨股通常涨幅更高
          },
          flowTrend
        };
              }).sort((a: SectorFlowData, b: SectorFlowData) => b.netInflow - a.netInflow);
       
     } catch (error) {
       console.error('❌ 获取板块资金流向数据失败:', error);
       // 返回空数组，避免组件崩溃
       return [];
     }
  };

  useEffect(() => {
    const updateData = async () => {
      setLoading(true);
      try {
        const realData = await fetchRealFlowData();
        setFlowData(realData);
        setUpdateTime(new Date().toLocaleTimeString('zh-CN', { 
          hour: '2-digit', 
          minute: '2-digit',
          second: '2-digit'
        }));
      } catch (error) {
        console.error('❌ 更新板块资金流向数据失败:', error);
      } finally {
        setLoading(false);
      }
    };

    updateData();
    const interval = setInterval(updateData, 30000); // 每30秒更新一次真实数据

    return () => clearInterval(interval);
  }, []);

  const formatAmount = (amount: number) => {
    if (Math.abs(amount) >= 10000) {
      return (amount / 10000).toFixed(1) + '亿';
    }
    return amount.toFixed(0) + '万';
  };

  const getFlowIcon = (trend: string) => {
    switch (trend) {
      case 'in': return '📈';
      case 'out': return '📉';
      default: return '➡️';
    }
  };

  const getFlowClass = (amount: number) => {
    if (amount > 1000) return 'flow-in';
    if (amount < -1000) return 'flow-out';
    return 'flow-balanced';
  };

  const getChangeClass = (change: number) => {
    if (change > 0) return 'positive';
    if (change < 0) return 'negative';
    return 'neutral';
  };

  return (
    <div className={`sector-flow ${className || ''}`}>
      <div className="flow-header">
        <div className="header-left">
          <span className="flow-icon">💰</span>
          <h3>板块资金流向</h3>
        </div>
        <div className="update-info">
          <span className="update-time">{updateTime}</span>
        </div>
      </div>

      <div className="flow-container">
        {loading && flowData.length === 0 ? (
          <div className="loading-state">
            <div className="loading-spinner">⏳</div>
            <span>正在加载真实数据...</span>
          </div>
        ) : (
          <div className="flow-list">
                        {flowData.length > 0 ? flowData.map((sector, index) => (
              <div key={sector.sectorName} className="flow-item">
                <div className="flow-rank">
                  <span className="rank-number">{index + 1}</span>
                </div>
                
                <div className="sector-details">
                  <div className="sector-header">
                    <span className="sector-name">{sector.sectorName}</span>
                    <span className={`flow-trend ${getFlowClass(sector.netInflow)}`}>
                      {getFlowIcon(sector.flowTrend)}
                    </span>
                  </div>
                  
                  <div className="sector-metrics">
                    <div className="metric-item">
                      <span className="metric-label">资金:</span>
                      <span className={`metric-value ${getFlowClass(sector.netInflow)}`}>
                        {sector.netInflow >= 0 ? '+' : ''}{formatAmount(sector.netInflow)}
                      </span>
                    </div>
                    
                    <div className="metric-item">
                      <span className="metric-label">涨幅:</span>
                      <span className={`metric-value ${getChangeClass(sector.changePercent)}`}>
                        {sector.changePercent >= 0 ? '+' : ''}{sector.changePercent}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="leading-stock">
                    <span className="stock-info">
                      领涨: <span className="stock-name">{sector.leadingStock.name}</span>
                      <span className={`stock-change ${getChangeClass(sector.leadingStock.change)}`}>
                        {sector.leadingStock.change >= 0 ? '+' : ''}{sector.leadingStock.change}%
                      </span>
                    </span>
                    <span className="strong-count">
                      强势股: {sector.strongStocks}只
                    </span>
                  </div>
                </div>
              </div>
            )) : (
              <div className="no-data">
                <span>暂无数据</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flow-footer">
        <div className="legend">
          <div className="legend-item">
            <span className="legend-icon flow-in">📈</span>
            <span>资金流入</span>
          </div>
          <div className="legend-item">
            <span className="legend-icon flow-out">📉</span>
            <span>资金流出</span>
          </div>
          <div className="legend-item">
            <span className="legend-icon flow-balanced">➡️</span>
            <span>震荡平衡</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SectorFlow; 