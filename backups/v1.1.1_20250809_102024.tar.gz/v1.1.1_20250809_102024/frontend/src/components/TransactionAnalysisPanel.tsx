import React, { useState, useEffect } from 'react';
import './TransactionAnalysisPanel.css';

interface Transaction {
  time: string;
  price: number;
  volume: number;
  amount: number;
  type: 'buy' | 'sell' | 'neutral';
  level?: 'large' | 'medium' | 'small';  // 大单、中单、小单
}

interface TransactionStats {
  totalCount: number;
  buyCount: number;
  sellCount: number;
  neutralCount: number;
  totalVolume: number;
  totalAmount: number;
  avgPrice: number;
  avgVolume: number;
  largeOrderCount: number;
  largeOrderVolume: number;
  largeOrderAmount: number;
  priceRange: {
    min: number;
    max: number;
    range: number;
  };
  volumeDistribution: {
    large: number;   // 大单占比
    medium: number;  // 中单占比
    small: number;   // 小单占比
  };
  timeDistribution: {
    startTime: string;
    endTime: string;
    duration: number; // 秒
    frequency: number; // 每分钟成交笔数
  };
}

interface TransactionAnalysisPanelProps {
  anomaly: {
    time: string;
    price: number;
    type: 'surge' | 'plunge';
    changePercent: number;
    index: number;
  } | null;
  stockCode: string;
  onClose?: () => void;
}

const TransactionAnalysisPanel: React.FC<TransactionAnalysisPanelProps> = ({
  anomaly,
  stockCode,
  onClose
}) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<TransactionStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const [showDetails, setShowDetails] = useState(false);

  // 获取异动期间的成交明细
  useEffect(() => {
    if (!anomaly) return;

    const fetchTransactions = async () => {
      setLoading(true);
      try {
        // 计算异动的时间范围（前后3分钟）
        const anomalyTime = anomaly.time;
        const [hour, minute] = anomalyTime.split(':').map(Number);
        
        // 开始时间：异动前3分钟
        let startHour = hour;
        let startMinute = minute - 3;
        if (startMinute < 0) {
          startMinute += 60;
          startHour -= 1;
        }
        
        // 结束时间：异动后3分钟
        let endHour = hour;
        let endMinute = minute + 3;
        if (endMinute >= 60) {
          endMinute -= 60;
          endHour += 1;
        }
        
        const startTime = `${startHour.toString().padStart(2, '0')}:${startMinute.toString().padStart(2, '0')}:00`;
        const endTime = `${endHour.toString().padStart(2, '0')}:${endMinute.toString().padStart(2, '0')}:00`;
        
        console.log(`获取成交明细: ${stockCode} ${startTime} - ${endTime}`);
        
        // 调用真实API获取成交明细
        const response = await fetch(
          `http://localhost:9000/api/stocks/${stockCode}/transactions?start_time=${startTime}&end_time=${endTime}`
        );
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.transactions && data.transactions.length > 0) {
          setTransactions(data.transactions);
          
          // 如果API返回了统计数据，使用它；否则自己计算
          if (data.statistics) {
            // 转换API返回的统计数据格式
            const apiStats: TransactionStats = {
              totalCount: data.statistics.basic_stats?.total_count || 0,
              buyCount: data.statistics.basic_stats?.buy_count || 0,
              sellCount: data.statistics.basic_stats?.sell_count || 0,
              neutralCount: data.statistics.basic_stats?.neutral_count || 0,
              totalVolume: data.statistics.basic_stats?.total_volume || 0,
              totalAmount: data.statistics.basic_stats?.total_amount || 0,
              avgPrice: data.statistics.basic_stats?.avg_price || 0,
              avgVolume: data.statistics.basic_stats?.avg_volume || 0,
              largeOrderCount: data.statistics.large_order_stats?.count || 0,
              largeOrderVolume: data.statistics.large_order_stats?.volume || 0,
              largeOrderAmount: data.statistics.large_order_stats?.amount || 0,
              priceRange: {
                min: data.statistics.price_range?.min || 0,
                max: data.statistics.price_range?.max || 0,
                range: data.statistics.price_range?.range || 0
              },
              volumeDistribution: {
                large: data.statistics.volume_distribution?.large || 0,
                medium: data.statistics.volume_distribution?.medium || 0,
                small: data.statistics.volume_distribution?.small || 0
              },
              timeDistribution: {
                startTime: data.statistics.time_distribution?.start_time || startTime,
                endTime: data.statistics.time_distribution?.end_time || endTime,
                duration: data.statistics.time_distribution?.duration_seconds || 0,
                frequency: data.statistics.time_distribution?.frequency_per_minute || 0
              }
            };
            setStats(apiStats);
          } else {
            // 自己计算统计数据
            const statistics = calculateStatistics(data.transactions);
            setStats(statistics);
          }
        } else {
          // 如果没有真实数据，使用模拟数据
          console.log('无真实成交数据，使用模拟数据');
          const mockTransactions = generateMockTransactions(anomaly);
          setTransactions(mockTransactions);
          const statistics = calculateStatistics(mockTransactions);
          setStats(statistics);
        }
      } catch (error) {
        console.error('Failed to fetch transactions:', error);
        // 失败时使用模拟数据
        const mockTransactions = generateMockTransactions(anomaly);
        setTransactions(mockTransactions);
        const statistics = calculateStatistics(mockTransactions);
        setStats(statistics);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [anomaly, stockCode]);

  // 生成模拟成交明细
  const generateMockTransactions = (anomaly: any): Transaction[] => {
    const transactions: Transaction[] = [];
    const basePrice = anomaly.price;
    const isUpward = anomaly.type === 'surge';
    
    // 生成30条成交记录
    for (let i = 0; i < 30; i++) {
      const priceChange = (Math.random() - 0.5) * 0.02; // ±1%
      const price = basePrice * (1 + priceChange);
      const volume = Math.floor(Math.random() * 10000) + 100;
      const isBuy = isUpward ? Math.random() > 0.3 : Math.random() > 0.7;
      
      transactions.push({
        time: `09:${30 + i}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
        price: parseFloat(price.toFixed(2)),
        volume: volume,
        amount: price * volume,
        type: isBuy ? 'buy' : Math.random() > 0.5 ? 'sell' : 'neutral',
        level: volume >= 10000 || (price * volume) >= 200000 ? 'large' : 
               volume >= 5000 || (price * volume) >= 50000 ? 'medium' : 'small'
      });
    }
    
    return transactions.sort((a, b) => a.time.localeCompare(b.time));
  };

  // 计算统计数据
  const calculateStatistics = (transactions: Transaction[]): TransactionStats => {
    const buyTransactions = transactions.filter(t => t.type === 'buy');
    const sellTransactions = transactions.filter(t => t.type === 'sell');
    const neutralTransactions = transactions.filter(t => t.type === 'neutral');
    const largeOrders = transactions.filter(t => t.level === 'large');
    
    const prices = transactions.map(t => t.price);
    const totalVolume = transactions.reduce((sum, t) => sum + t.volume, 0);
    const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
    
    const volumeByLevel = {
      large: transactions.filter(t => t.level === 'large').reduce((sum, t) => sum + t.volume, 0),
      medium: transactions.filter(t => t.level === 'medium').reduce((sum, t) => sum + t.volume, 0),
      small: transactions.filter(t => t.level === 'small').reduce((sum, t) => sum + t.volume, 0)
    };
    
    const startTime = transactions[0]?.time || '';
    const endTime = transactions[transactions.length - 1]?.time || '';
    const duration = calculateDuration(startTime, endTime);
    
    return {
      totalCount: transactions.length,
      buyCount: buyTransactions.length,
      sellCount: sellTransactions.length,
      neutralCount: neutralTransactions.length,
      totalVolume,
      totalAmount,
      avgPrice: totalAmount / totalVolume,
      avgVolume: totalVolume / transactions.length,
      largeOrderCount: largeOrders.length,
      largeOrderVolume: largeOrders.reduce((sum, t) => sum + t.volume, 0),
      largeOrderAmount: largeOrders.reduce((sum, t) => sum + t.amount, 0),
      priceRange: {
        min: Math.min(...prices),
        max: Math.max(...prices),
        range: Math.max(...prices) - Math.min(...prices)
      },
      volumeDistribution: {
        large: (volumeByLevel.large / totalVolume) * 100,
        medium: (volumeByLevel.medium / totalVolume) * 100,
        small: (volumeByLevel.small / totalVolume) * 100
      },
      timeDistribution: {
        startTime,
        endTime,
        duration,
        frequency: duration > 0 ? (transactions.length / (duration / 60)) : 0
      }
    };
  };

  // 计算时间差（秒）
  const calculateDuration = (startTime: string, endTime: string): number => {
    const [sh, sm, ss] = startTime.split(':').map(Number);
    const [eh, em, es] = endTime.split(':').map(Number);
    return (eh - sh) * 3600 + (em - sm) * 60 + (es - ss);
  };

  // 格式化数字
  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return `${(num / 10000).toFixed(2)}万`;
    }
    return num.toFixed(0);
  };

  // 格式化金额
  const formatAmount = (amount: number): string => {
    if (amount >= 100000000) {
      return `${(amount / 100000000).toFixed(2)}亿`;
    }
    if (amount >= 10000) {
      return `${(amount / 10000).toFixed(2)}万`;
    }
    return amount.toFixed(2);
  };

  // 主力意图分析
  const renderMainForceIntention = (stats: TransactionStats, anomaly: any) => {
    const analysis = analyzeMainForceIntention(stats, anomaly);
    
    return (
      <div className="main-force-analysis">
        <div className={`intention-result ${analysis.signal.toLowerCase()}`}>
          <div className="intention-header">
            <span className="intention-icon">{analysis.icon}</span>
            <span className="intention-title">{analysis.title}</span>
            <span className="confidence-badge">{analysis.confidence}%把握</span>
          </div>
          <div className="intention-description">{analysis.description}</div>
          
          <div className="operation-suggestion">
            <div className="suggestion-title">🎪 操作建议</div>
            <div className={`suggestion-content ${analysis.signal.toLowerCase()}`}>
              {analysis.suggestion}
            </div>
          </div>
          
          <div className="evidence-list">
            <div className="evidence-title">📊 分析依据</div>
            {analysis.evidence.map((item, idx) => (
              <div key={idx} className={`evidence-item ${item.type}`}>
                <span className="evidence-icon">{item.type === 'positive' ? '✓' : item.type === 'warning' ? '⚠' : 'ℹ'}</span>
                <span className="evidence-text">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // 主力意图判断算法
  const analyzeMainForceIntention = (stats: TransactionStats, anomaly: any) => {
    const evidence = [];
    let score = 0;
    let signal = 'HOLD';
    let title = '';
    let description = '';
    let suggestion = '';
    let icon = '🤔';
    
    // 1. 大单方向分析
    const buyVolume = stats.buyCount;
    const sellVolume = stats.sellCount;
    const buyRatio = buyVolume / (buyVolume + sellVolume);
    const sellRatio = sellVolume / (buyVolume + sellVolume);
    
    if (buyRatio > 0.65) {
      score += 30;
      evidence.push({ type: 'positive', text: `买单占比${(buyRatio * 100).toFixed(1)}%，买盘力量占优` });
    } else if (sellRatio > 0.65) {
      score -= 30;
      evidence.push({ type: 'warning', text: `卖单占比${(sellRatio * 100).toFixed(1)}%，卖压明显` });
    }
    
    // 2. 大单金额占比分析
    if (stats.volumeDistribution.large > 50) {
      score += 25;
      evidence.push({ type: 'positive', text: `大单成交占比${stats.volumeDistribution.large.toFixed(1)}%，主力高度参与` });
    } else if (stats.volumeDistribution.large < 20) {
      score -= 15;
      evidence.push({ type: 'info', text: `大单占比仅${stats.volumeDistribution.large.toFixed(1)}%，主力参与度较低` });
    }
    
    // 3. 价格走势与成交配合分析
    const isUpwardAnomaly = anomaly?.type === 'surge';
    const isDownwardAnomaly = anomaly?.type === 'plunge';
    
    if (isUpwardAnomaly && buyRatio > 0.6) {
      score += 20;
      evidence.push({ type: 'positive', text: '拉升过程中买单积极，主力有建仓或拉升意图' });
    } else if (isUpwardAnomaly && sellRatio > 0.6) {
      score -= 25;
      evidence.push({ type: 'warning', text: '拉升过程中卖单活跃，疑似诱多出货' });
    } else if (isDownwardAnomaly && sellRatio > 0.6) {
      score -= 20;
      evidence.push({ type: 'warning', text: '下跌过程中卖压沉重，主力可能在出货' });
    } else if (isDownwardAnomaly && buyRatio > 0.6) {
      score += 15;
      evidence.push({ type: 'positive', text: '下跌过程中买单积极，可能是洗盘或抄底' });
    }
    
    // 4. 成交频率分析
    if (stats.timeDistribution.frequency > 15) {
      if (score > 0) {
        score += 10;
        evidence.push({ type: 'positive', text: `成交频繁(${stats.timeDistribution.frequency.toFixed(1)}笔/分)，主力操作紧迫` });
      } else {
        score -= 10;
        evidence.push({ type: 'warning', text: `成交频繁但方向不明，主力意图不清晰` });
      }
    }
    
    // 5. 平均成交价分析
    const avgPrice = stats.avgPrice;
    const currentPrice = anomaly?.price || avgPrice;
    const priceDeviation = Math.abs(currentPrice - avgPrice) / avgPrice;
    
    if (priceDeviation > 0.005) { // 价格偏离超过0.5%
      if (currentPrice > avgPrice && buyRatio > 0.6) {
        score += 15;
        evidence.push({ type: 'positive', text: '价格高于均价且买单活跃，主力推高意图明显' });
      } else if (currentPrice < avgPrice && sellRatio > 0.6) {
        score -= 15;
        evidence.push({ type: 'warning', text: '价格低于均价且卖单活跃，主力压制明显' });
      }
    }
    
    // 根据综合评分判断意图
    const confidence = Math.min(95, Math.max(55, 75 + Math.abs(score) * 0.5));
    
    if (score >= 50) {
      signal = 'BUY';
      title = '主力建仓/拉升';
      icon = '🚀';
      description = '主力资金积极介入，呈现明显的买入建仓或拉升态势，建议关注后续走势';
      suggestion = '可考虑适量跟进，但需设定止损位，防范短线回调风险';
    } else if (score <= -50) {
      signal = 'SELL';
      title = '主力出货/打压';
      icon = '📉';
      description = '主力呈现明显的出货或打压态势，卖压沉重，建议谨慎对待';
      suggestion = '建议减仓或观望，避免在主力出货时接盘';
    } else if (score >= 20) {
      signal = 'HOLD';
      title = '主力偏多操作';
      icon = '📈';
      description = '主力略显积极，但力度有限，可能在试探性建仓或轻度拉升';
      suggestion = '可保持关注，等待更明确的信号再做决策';
    } else if (score <= -20) {
      signal = 'HOLD';
      title = '主力偏空操作';
      icon = '📊';
      description = '主力略显谨慎，可能在进行洗盘或轻度减仓';
      suggestion = '建议观望为主，等待主力意图更加明确';
    } else {
      signal = 'HOLD';
      title = '主力意图不明';
      icon = '❓';
      description = '多空力量相对均衡，主力操作意图不够明确，需要更多观察';
      suggestion = '保持观望，等待更多信号确认主力真实意图';
    }
    
    return {
      signal,
      title,
      description,
      suggestion,
      confidence: Math.round(confidence),
      icon,
      evidence,
      score
    };
  };

  if (!anomaly) return null;

  return (
    <div className="transaction-analysis-panel">
      {/* 标题栏 */}
      <div className="panel-header">
        <div className="header-left">
          <span className="header-icon">
            {anomaly.type === 'surge' ? '📈' : '📉'}
          </span>
          <span className="header-title">主力意图透视</span>
          <span className="header-time">{anomaly.time}</span>
        </div>
        <div className="header-right">
          <button className="expand-btn" onClick={() => setExpanded(!expanded)}>
            {expanded ? '−' : '+'}
          </button>
          {onClose && (
            <button className="close-btn" onClick={onClose}>×</button>
          )}
        </div>
      </div>

      {expanded && (
        <>
          {/* 统计概览 */}
          {stats && (
            <div className="stats-overview">
              <div className="stat-card">
                <div className="stat-label">成交笔数</div>
                <div className="stat-value">{stats.totalCount}笔</div>
                <div className="stat-detail">
                  <span className="buy">买{stats.buyCount}</span>
                  <span className="sell">卖{stats.sellCount}</span>
                  <span className="neutral">中{stats.neutralCount}</span>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-label">成交量</div>
                <div className="stat-value">{formatNumber(stats.totalVolume)}股</div>
                <div className="stat-detail">
                  均量: {formatNumber(stats.avgVolume)}
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-label">成交额</div>
                <div className="stat-value">{formatAmount(stats.totalAmount)}</div>
                <div className="stat-detail">
                  均价: ¥{stats.avgPrice.toFixed(2)}
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-label">大单统计</div>
                <div className="stat-value">{stats.largeOrderCount}笔</div>
                <div className="stat-detail">
                  {formatAmount(stats.largeOrderAmount)}
                </div>
              </div>
            </div>
          )}

          {/* 成交分布 */}
          {stats && (
            <div className="distribution-section">
              <div className="section-title">📊 成交分布</div>
              
              <div className="distribution-grid">
                <div className="distribution-item">
                  <span className="label">价格区间:</span>
                  <span className="value">
                    ¥{stats.priceRange.min.toFixed(2)} ~ ¥{stats.priceRange.max.toFixed(2)}
                  </span>
                  <span className="extra">
                    (振幅: {((stats.priceRange.range / stats.priceRange.min) * 100).toFixed(2)}%)
                  </span>
                </div>
                
                <div className="distribution-item">
                  <span className="label">时间分布:</span>
                  <span className="value">
                    {stats.timeDistribution.startTime} ~ {stats.timeDistribution.endTime}
                  </span>
                  <span className="extra">
                    ({Math.floor(stats.timeDistribution.duration / 60)}分钟, 
                    {stats.timeDistribution.frequency.toFixed(1)}笔/分)
                  </span>
                </div>
                
                <div className="distribution-item">
                  <span className="label">成交结构:</span>
                  <div className="volume-bars">
                    <div className="bar large" style={{ width: `${stats.volumeDistribution.large}%` }}>
                      大单 {stats.volumeDistribution.large.toFixed(1)}%
                    </div>
                    <div className="bar medium" style={{ width: `${stats.volumeDistribution.medium}%` }}>
                      中单 {stats.volumeDistribution.medium.toFixed(1)}%
                    </div>
                    <div className="bar small" style={{ width: `${stats.volumeDistribution.small}%` }}>
                      小单 {stats.volumeDistribution.small.toFixed(1)}%
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 成交明细列表 */}
          <div className="details-section">
            <div className="section-header">
              <span className="section-title">📝 成交明细</span>
              <button 
                className="toggle-btn"
                onClick={() => setShowDetails(!showDetails)}
              >
                {showDetails ? '隐藏' : '显示'}明细
              </button>
            </div>
            
            {showDetails && (
              <div className="transaction-list">
                <div className="list-header">
                  <span className="col-time">时间</span>
                  <span className="col-price">价格</span>
                  <span className="col-volume">成交量</span>
                  <span className="col-amount">成交额</span>
                  <span className="col-type">性质</span>
                </div>
                
                <div className="list-body">
                  {transactions.map((t, idx) => (
                    <div key={idx} className={`transaction-item ${t.type} ${t.level}`}>
                      <span className="col-time">{t.time}</span>
                      <span className="col-price">¥{t.price.toFixed(2)}</span>
                      <span className="col-volume">{formatNumber(t.volume)}</span>
                      <span className="col-amount">{formatAmount(t.amount)}</span>
                      <span className="col-type">
                        <span className={`type-badge ${t.type}`}>
                          {t.type === 'buy' ? '买' : t.type === 'sell' ? '卖' : '中'}
                        </span>
                        {t.level === 'large' && <span className="level-badge">大</span>}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 主力意图分析 */}
          {stats && (
            <div className="analysis-conclusion">
              <div className="section-title">🎯 主力意图判断</div>
              <div className="conclusion-content">
                {renderMainForceIntention(stats, anomaly)}
              </div>
            </div>
          )}

          {loading && (
            <div className="loading-state">加载成交明细中...</div>
          )}
        </>
      )}
    </div>
  );
};

export default TransactionAnalysisPanel;