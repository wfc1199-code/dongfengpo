/**
 * 通达信风格支撑压力系统 Hook
 * 使用7/8和0.5/8的固定比例计算方法
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import type { SupportResistanceLevel as CanonicalSRLevel } from '../types/supportResistance';

export interface SRAnalysis {
  current_price: number;
  nearest_support: number | null;
  nearest_resistance: number | null;
  support_strength: number;
  resistance_strength: number;
  trend_suggestion: string;
  risk_level: string;
}

interface UseSupportResistanceTDXOptions {
  stockCode: string;
  enabled?: boolean;
  updateInterval?: number;
}

interface UseSupportResistanceTDXReturn {
  levels: CanonicalSRLevel[];
  loading: boolean;
  error: string | null;
  analysis: SRAnalysis | null;
  refresh: () => void;
}

export const useSupportResistanceTDX = ({
  stockCode,
  enabled = true,
  updateInterval = 30000  // 默认30秒更新一次
}: UseSupportResistanceTDXOptions): UseSupportResistanceTDXReturn => {
  const [levels, setLevels] = useState<CanonicalSRLevel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<SRAnalysis | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchSupportResistance = useCallback(async () => {
    if (!enabled || !stockCode) return;

    // 取消之前的请求
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;

    try {
      setLoading(true);
      setError(null);

      // 先获取股票的分时数据
      const minuteResponse = await fetch(
        `http://localhost:9000/api/stocks/${stockCode}/minute`,
        { signal }
      );

      if (!minuteResponse.ok) {
        throw new Error('获取分时数据失败');
      }

      const minuteData = await minuteResponse.json();
      
      // 准备计算所需的数据
      const prices = minuteData.minute_data?.map((d: any) => d.price) || [];
      const timestamps = minuteData.minute_data?.map((d: any) => d.time) || [];
      
      // 获取日K线数据来获取高低价
      const klineResponse = await fetch(
        `http://localhost:9000/api/stocks/${stockCode}/kline?period=daily&limit=5`,
        { signal }
      );

      let high_prices = prices;
      let low_prices = prices;
      let today_open = prices[0] || 0;
      let today_high = Math.max(...prices) || 0;
      let today_low = Math.min(...prices) || 0;

      if (klineResponse.ok) {
        const klineData = await klineResponse.json();
        if (klineData.klines && klineData.klines.length > 0) {
          // 使用最近几天的高低价数据
          high_prices = klineData.klines.map((k: any) => k.high);
          low_prices = klineData.klines.map((k: any) => k.low);
          
          const todayKline = klineData.klines[klineData.klines.length - 1];
          today_open = todayKline.open;
          today_high = todayKline.high;
          today_low = todayKline.low;
        }
      }

      // 调用通达信风格的支撑压力计算API
      const response = await fetch(
        'http://localhost:9000/api/support-resistance/tdx/calculate',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            current_price: prices[prices.length - 1] || 0,
            high_prices,
            low_prices,
            prices,
            timestamps,
            today_open,
            today_high,
            today_low
          }),
          signal
        }
      );

      if (signal.aborted) return;

      if (!response.ok) {
        throw new Error('计算支撑压力位失败');
      }

      const data = await response.json();

      if (data.success) {
        // 将通达信风格的 level 映射为全局类型定义的结构
        const formattedLevels: CanonicalSRLevel[] = data.levels.map((level: any) => {
          const mappedType: CanonicalSRLevel['type'] =
            level.type === 'dynamic_support' ? 'support' :
            level.type === 'dynamic_resistance' ? 'resistance' :
            level.type === 'pivot' ? 'target' :
            (level.type === 'support' || level.type === 'resistance' ? level.type : 'target');

          const rating: CanonicalSRLevel['rating'] =
            level.strength >= 80 ? 'S' :
            level.strength >= 70 ? 'A' :
            level.strength >= 50 ? 'B' : 'C';

          return {
            price: level.price,
            type: mappedType,
            strength: level.strength,
            rating,
            description: level.description,
            visualStyle: {
              color: level.color,
              lineStyle: level.lineStyle,
              lineWidth: level.lineWidth,
            }
          } as CanonicalSRLevel;
        });

        setLevels(formattedLevels);
        setAnalysis(data.analysis);
      }

      setLoading(false);
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      
      console.error('获取支撑压力位失败:', err);
      setError(err.message);
      setLoading(false);
    }
  }, [stockCode, enabled]);

  // 初始获取和定时更新
  useEffect(() => {
    if (!enabled) return;

    fetchSupportResistance();

    // 设置定时更新
    intervalRef.current = setInterval(fetchSupportResistance, updateInterval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [fetchSupportResistance, updateInterval, enabled]);

  const refresh = useCallback(() => {
    fetchSupportResistance();
  }, [fetchSupportResistance]);

  return {
    levels,
    loading,
    error,
    analysis,
    refresh
  };
};

export default useSupportResistanceTDX;