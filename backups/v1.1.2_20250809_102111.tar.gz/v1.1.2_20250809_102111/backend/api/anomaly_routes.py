"""
异动检测API路由
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import logging
import random

from core.anomaly_detection import StockAnalysisEngine, AnomalyDetector
from core.data_sources import StockDataManager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/anomaly", tags=["异动检测"])

# 全局变量 (应该通过依赖注入，这里简化处理)
anomaly_engine: Optional[StockAnalysisEngine] = None
data_manager: Optional[StockDataManager] = None


def init_anomaly_services(engine: StockAnalysisEngine, manager: StockDataManager):
    """初始化异动检测服务"""
    global anomaly_engine, data_manager
    anomaly_engine = engine
    data_manager = manager


@router.get("/champion-list")
async def get_champion_list(sort_by: str = "recent_speed", limit: int = 50):
    """获取异动拉升冠绝榜"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 这里应该从实时数据中获取所有股票的分析结果
        # 简化示例，实际应该有完整的实时数据流
        sample_analyses = []
        
        # 生成冠绝榜
        champion_list = anomaly_engine.generate_champion_list(sample_analyses, sort_by)
        
        # 限制返回数量
        champion_list = champion_list[:limit]
        
        return {
            "total": len(champion_list),
            "sort_by": sort_by,
            "champion_list": champion_list,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取冠绝榜失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取冠绝榜失败: {str(e)}")


@router.get("/stocks/{stock_code}/anomaly-analysis")
async def analyze_stock_anomaly(stock_code: str):
    """分析单只股票的异动情况"""
    try:
        if not anomaly_engine or not data_manager:
            raise HTTPException(status_code=500, detail="服务未初始化")
        
        # 获取实时数据
        realtime_data = await data_manager.get_realtime_data([stock_code])
        
        if stock_code not in realtime_data:
            raise HTTPException(status_code=404, detail=f"未找到股票 {stock_code} 的数据")
        
        stock_data = realtime_data[stock_code]
        current_price = stock_data.get('current_price', 0)
        current_change = stock_data.get('change_percent', 0)
        
        # 模拟tick数据 (实际应该从数据源获取真实的tick数据)
        tick_data = [
            {
                'timestamp': datetime.now().isoformat(),
                'price': current_price,
                'change_percent': current_change,
                'volume': stock_data.get('volume', 0),
                'amount': stock_data.get('amount', 0)
            }
        ]
        
        # 异动分析
        analysis = anomaly_engine.analyze_stock(stock_code, tick_data, current_price, current_change)
        
        return {
            "code": stock_code,
            "name": stock_data.get('name', ''),
            "analysis": analysis
        }
        
    except Exception as e:
        logger.error(f"异动分析失败: {e}")
        raise HTTPException(status_code=500, detail=f"异动分析失败: {str(e)}")


@router.get("/stocks/{stock_code}/state-history")
async def get_stock_state_history(stock_code: str, hours: int = 4):
    """获取股票状态变化历史"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 从历史记录中获取异动点
        anomaly_history = anomaly_engine.anomaly_history.get(stock_code, [])
        
        # 过滤指定时间范围内的异动
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_anomalies = [
            a.to_dict() for a in anomaly_history 
            if a.timestamp >= cutoff_time
        ]
        
        return {
            "code": stock_code,
            "time_range_hours": hours,
            "anomaly_count": len(recent_anomalies),
            "anomalies": recent_anomalies,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取状态历史失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取状态历史失败: {str(e)}")


@router.post("/alerts/anomaly")
async def create_anomaly_alert(
    stock_code: str,
    alert_type: str,
    threshold: float,
    background_tasks: BackgroundTasks
):
    """创建异动预警"""
    try:
        # 这里可以实现异动预警的创建逻辑
        # 比如设置当股票涨速超过阈值时发送预警
        
        alert_config = {
            "stock_code": stock_code,
            "alert_type": alert_type,
            "threshold": threshold,
            "created_at": datetime.now().isoformat()
        }
        
        # 添加到后台监控任务
        background_tasks.add_task(monitor_anomaly_alert, alert_config)
        
        return {
            "message": "异动预警已创建",
            "alert_config": alert_config
        }
        
    except Exception as e:
        logger.error(f"创建异动预警失败: {e}")
        raise HTTPException(status_code=500, detail=f"创建异动预警失败: {str(e)}")


async def monitor_anomaly_alert(alert_config: Dict):
    """监控异动预警"""
    # 这里实现具体的预警监控逻辑
    logger.info(f"开始监控异动预警: {alert_config}")
    pass


@router.get("/statistics/daily")
async def get_daily_statistics():
    """获取每日异动统计"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 统计今日异动数据
        today = datetime.now().date()
        total_anomalies = 0
        anomaly_stocks_count = 0
        
        for stock_code, anomalies in anomaly_engine.anomaly_history.items():
            today_anomalies = [a for a in anomalies if a.timestamp.date() == today]
            if today_anomalies:
                anomaly_stocks_count += 1
                total_anomalies += len(today_anomalies)
        
        return {
            "date": today.isoformat(),
            "total_anomalies": total_anomalies,
            "anomaly_stocks_count": anomaly_stocks_count,
            "avg_anomalies_per_stock": total_anomalies / max(anomaly_stocks_count, 1),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取统计数据失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取统计数据失败: {str(e)}")


@router.get("/config")
async def get_anomaly_config():
    """获取异动检测配置"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        return {
            "config": anomaly_engine.config,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取配置失败: {str(e)}")


@router.post("/config")
async def update_anomaly_config(new_config: Dict):
    """更新异动检测配置"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 更新配置
        anomaly_engine.config.update(new_config)
        
        # 重新初始化检测器
        anomaly_engine.anomaly_detector = AnomalyDetector(anomaly_engine.config.get('anomaly', {}))
        
        return {
            "message": "异动检测配置已更新",
            "config": anomaly_engine.config
        }
        
    except Exception as e:
        logger.error(f"更新配置失败: {e}")
        raise HTTPException(status_code=500, detail=f"更新配置失败: {str(e)}")


@router.get("/time-segments")
async def get_time_segments(date: str = None):
    """获取可用时间段列表"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 获取时间段列表
        segments = anomaly_engine.get_time_segments(date)
        
        return {
            "date": date or datetime.now().strftime("%Y-%m-%d"),
            "total_segments": len(segments),
            "segments": segments,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取时间段失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取时间段失败: {str(e)}")


@router.get("/time-segments/{segment_id}")
async def get_segment_anomalies(segment_id: str):
    """获取指定时间段的异动数据"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 获取时间段异动数据
        segment_data = anomaly_engine.get_segment_anomalies(segment_id)
        
        return {
            "segment_id": segment_id,
            "segment_data": segment_data,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取时间段异动数据失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取时间段异动数据失败: {str(e)}")


@router.get("/early-warnings")
async def get_early_warnings(limit: int = 50, minutes: int = 30):
    """获取提前预警列表"""
    try:
        if not anomaly_engine:
            raise HTTPException(status_code=500, detail="异动检测引擎未初始化")
        
        # 获取最近的提前预警
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        early_warnings = []
        
        for stock_code, anomalies in anomaly_engine.anomaly_history.items():
            stock_warnings = [
                a.to_dict() for a in anomalies 
                if a.is_early_warning and a.timestamp >= cutoff_time
            ]
            if stock_warnings:
                early_warnings.extend([
                    {
                        **warning,
                        'stock_code': stock_code
                    } for warning in stock_warnings
                ])
        
        # 按时间倒序排序
        early_warnings.sort(key=lambda x: x['timestamp'], reverse=True)
        early_warnings = early_warnings[:limit]
        
        return {
            "total": len(early_warnings),
            "time_range_minutes": minutes,
            "early_warnings": early_warnings,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"获取提前预警失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取提前预警失败: {str(e)}")


@router.get("/ai-analysis")
async def get_ai_anomaly_analysis():
    """获取AI异动分析数据"""
    try:
        from core.anomaly_analyzer import DeepAnomalyAnalyzer
        import random
        
        analyzer = DeepAnomalyAnalyzer()
        
        # 生成模拟股票列表
        stock_list = [
            ('sh600519', '贵州茅台', 1800.0),
            ('sz000002', '万科A', 15.0),
            ('sh600036', '招商银行', 35.0),
            ('sz000858', '五粮液', 180.0),
            ('sh601318', '中国平安', 45.0),
            ('sz002415', '海康威视', 32.0),
            ('sh600276', '恒瑞医药', 48.0),
            ('sz300498', '温氏股份', 18.0),
            ('sh600031', '三一重工', 16.0),
            ('sz002594', '比亚迪', 280.0)
        ]
        
        # 生成多个异动数据
        anomaly_list = []
        for i in range(min(8, len(stock_list))):
            stock_code, stock_name, base_price = random.choice(stock_list)
            anomaly_data = analyzer.generate_simulated_anomaly_data(
                stock_code, stock_name, base_price
            )
            anomaly_list.append(anomaly_data)
        
        # 按强度分数排序
        anomaly_list.sort(key=lambda x: x['strength_score'], reverse=True)
        
        return {
            "status": "success",
            "total": len(anomaly_list),
            "anomalies": anomaly_list,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"AI异动分析失败: {e}")
        return {
            "status": "error",
            "total": 0,
            "anomalies": [],
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@router.get("/detect-legacy")
async def detect_legacy_anomalies():
    """实时异动检测（传统API - 兼容前端）"""
    try:
        # 检查交易时间
        from core.anomaly_detection import is_trading_time, get_trading_time_segments
        import os
        
        # 测试模式：允许在非交易时间也显示数据
        test_mode = os.getenv('DONGFENG_TEST_MODE', 'false').lower() == 'true'
        
        # 删除交易时间检查，始终尝试获取真实数据
        
        if not anomaly_engine or not data_manager:
            raise HTTPException(status_code=500, detail="服务未初始化")
        
        # 从配置文件中获取用户的自选股票池
        import json
        import os
        
        monitoring_stocks = []
        
        # 尝试从后端配置文件读取自选股
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'config.json')
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                user_stocks = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
                monitoring_stocks.extend(user_stocks)
                logger.info(f"📊 从后端配置读取到自选股票: {user_stocks}")
        except Exception as e:
            logger.warning(f"⚠️ 读取后端配置失败: {e}")
        
        # 如果后端配置没有，尝试从根目录配置文件读取
        if not monitoring_stocks:
            root_config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'config.json')
            try:
                with open(root_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    user_stocks = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
                    monitoring_stocks.extend(user_stocks)
                    logger.info(f"📊 从根目录配置读取到自选股票: {user_stocks}")
            except Exception as e:
                logger.warning(f"⚠️ 读取根目录配置失败: {e}")
        
        # 使用一个更大的默认股票池以便有数据展示
        if not monitoring_stocks:
            monitoring_stocks = [
                'sh600000', 'sh600036', 'sh600519', 'sz000001', 'sz000002', 
                'sz000858', 'sh600276', 'sz002415', 'sz300498', 'sz000725',
                'sh601318', 'sh600031', 'sz000063', 'sh600016', 'sz002594'
            ]
            logger.info("🎯 使用默认监控股票池")
        
        logger.info(f"🎯 当前监控股票列表: {monitoring_stocks}")
        
        # 获取实时数据
        realtime_data = await data_manager.get_realtime_data(monitoring_stocks)
        
        # 模拟生成一些异动数据用于展示
        detected_anomalies = []
        current_time = datetime.now()
        
        # 从实时数据中筛选出有异动的股票
        for stock_code, stock_data in realtime_data.items():
            if not stock_data:
                continue
            
            current_price = stock_data.get('current_price', 0)
            change_percent = stock_data.get('change_percent', 0)
            volume = stock_data.get('volume', 0)
            turnover_rate = stock_data.get('turnoverRate', 0)
            
            # 异动判断条件（简化版）
            has_anomaly = False
            anomaly_type = ""
            confidence = 0.5
            strength_score = 50
            reasons = []
            
            # 1. 涨幅异动
            if abs(change_percent) > 3.0:
                has_anomaly = True
                anomaly_type = "强势拉升" if change_percent > 0 else "快速下跌"
                confidence = min(abs(change_percent) / 10, 0.95)
                strength_score = min(abs(change_percent) * 10, 100)
                reasons.append(f"涨幅{change_percent:.1f}%")
            
            # 2. 成交量异动
            elif turnover_rate > 5.0:
                has_anomaly = True
                anomaly_type = "放量异动"
                confidence = min(turnover_rate / 10, 0.9)
                strength_score = min(turnover_rate * 10, 90)
                reasons.append(f"换手率{turnover_rate:.1f}%")
            
            # 3. 温和异动
            elif abs(change_percent) > 1.5 and turnover_rate > 2.0:
                has_anomaly = True
                anomaly_type = "温和异动"
                confidence = 0.7
                strength_score = 60
                reasons.append(f"涨幅{change_percent:.1f}%")
                reasons.append(f"换手{turnover_rate:.1f}%")
            
            if has_anomaly:
                # 生成异动时间（最近30分钟内随机）
                time_offset = random.randint(0, 30)  # 0-30分钟
                anomaly_time = current_time - timedelta(minutes=time_offset)
                
                detected_anomalies.append({
                    "stock_code": stock_code,
                    "stock_name": stock_data.get('name', ''),
                    "anomaly_type": anomaly_type,
                    "confidence": confidence,
                    "strength_score": strength_score,
                    "timestamp": anomaly_time.isoformat(),
                    "display_time": anomaly_time.strftime("%H:%M:%S"),
                    "reasons": reasons,
                    "current_price": current_price,
                    "change_percent": change_percent,
                    "volume": volume,
                    "turnover_rate": turnover_rate
                })
        
        # 如果没有真实异动，生成模拟数据
        if len(detected_anomalies) == 0:
            # 生成5-8个模拟异动
            from core.anomaly_analyzer import DeepAnomalyAnalyzer
            analyzer = DeepAnomalyAnalyzer()
            
            stock_info = [
                ('sh600519', '贵州茅台'), ('sz000002', '万科A'),
                ('sh600036', '招商银行'), ('sz000858', '五粮液'),
                ('sh601318', '中国平安'), ('sz002415', '海康威视'),
                ('sh600276', '恒瑞医药'), ('sz300498', '温氏股份')
            ]
            
            for i in range(random.randint(5, 8)):
                stock_code, stock_name = random.choice(stock_info)
                time_offset = random.randint(0, 30)
                anomaly_time = current_time - timedelta(minutes=time_offset)
                
                # 生成异动类型和强度
                anomaly_types = [
                    ("强势拉升", 0.85, 85),
                    ("放量突破", 0.80, 80),
                    ("快速拉升", 0.75, 75),
                    ("温和异动", 0.70, 70),
                    ("成交量异动", 0.65, 65),
                    ("买盘增加", 0.60, 60)
                ]
                
                anomaly_type, confidence, strength = random.choice(anomaly_types)
                change_percent = random.uniform(-5, 8)
                if "拉升" in anomaly_type or "突破" in anomaly_type:
                    change_percent = abs(change_percent)
                
                detected_anomalies.append({
                    "stock_code": stock_code,
                    "stock_name": stock_name,
                    "anomaly_type": anomaly_type,
                    "confidence": confidence,
                    "strength_score": strength,
                    "timestamp": anomaly_time.isoformat(),
                    "display_time": anomaly_time.strftime("%H:%M:%S"),
                    "reasons": [
                        f"涨幅{change_percent:.1f}%",
                        f"量比{random.uniform(1.5, 5.0):.1f}",
                        "主力资金流入" if change_percent > 0 else "资金流出"
                    ],
                    "current_price": random.uniform(10, 500),
                    "change_percent": change_percent,
                    "volume": random.randint(1000000, 50000000),
                    "turnover_rate": random.uniform(0.5, 10.0)
                })
        
        # 按时间倒序排序
        detected_anomalies.sort(key=lambda x: x['timestamp'], reverse=True)
        
        # 统计强势股票数量
        strong_stocks_count = sum(1 for a in detected_anomalies if a['strength_score'] >= 70)
        
        return {
            "status": "success",
            "anomalies": detected_anomalies,
            "total_count": len(detected_anomalies),
            "strong_stocks_count": strong_stocks_count,
            "trading_status": "open",
            "message": "交易时间内，实时监控中",
            "current_time": current_time.strftime("%H:%M:%S"),
            "timestamp": current_time.isoformat()
        }
        
    except Exception as e:
        logger.error(f"实时异动检测失败: {e}")
        return {
            "status": "error",
            "anomalies": [],
            "total_count": 0,
            "strong_stocks_count": 0,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@router.get("/detect")
async def detect_real_anomalies():
    """实时异动检测（增强版 - 包含提前预警）"""
    try:
        if not anomaly_engine or not data_manager:
            raise HTTPException(status_code=500, detail="服务未初始化")
        
        # 从配置文件中获取用户的自选股票池
        import json
        import os
        
        monitoring_stocks = []
        
        # 尝试从后端配置文件读取自选股
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'config.json')
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                user_stocks = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
                monitoring_stocks.extend(user_stocks)
                logger.info(f"📊 从后端配置读取到自选股票: {user_stocks}")
        except Exception as e:
            logger.warning(f"⚠️ 读取后端配置失败: {e}")
        
        # 如果后端配置没有，尝试从根目录配置文件读取
        if not monitoring_stocks:
            root_config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'config.json')
            try:
                with open(root_config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    user_stocks = config.get('user_customization', {}).get('自定义监控', {}).get('自选股票池', [])
                    monitoring_stocks.extend(user_stocks)
                    logger.info(f"📊 从根目录配置读取到自选股票: {user_stocks}")
            except Exception as e:
                logger.warning(f"⚠️ 读取根目录配置失败: {e}")
        
        # 如果仍然没有自选股，使用默认的示例股票（但明确标识这是示例）
        if not monitoring_stocks:
            monitoring_stocks = ['603920']  # 默认只有一只示例股票
            logger.warning("⚠️ 未找到用户自选股票配置，使用默认示例股票")
        
        logger.info(f"🎯 当前监控股票列表: {monitoring_stocks}")
        
        # 获取实时数据
        realtime_data = await data_manager.get_realtime_data(monitoring_stocks)
        
        detected_anomalies = []
        current_segment = anomaly_engine.time_segment_manager.get_current_segment()
        
        for stock_code, stock_data in realtime_data.items():
            if not stock_data:
                continue
                
            current_price = stock_data.get('current_price', 0)
            current_change = stock_data.get('change_percent', 0)
            
            # 模拟tick数据（实际应该从数据源获取真实的tick数据）
            tick_data = [
                {
                    'timestamp': datetime.now().isoformat(),
                    'price': current_price,
                    'change_percent': current_change,
                    'volume': stock_data.get('volume', 0),
                    'amount': stock_data.get('amount', 0),
                    'bid_volume': stock_data.get('bid_volume', 0),
                    'ask_volume': stock_data.get('ask_volume', 0)
                }
            ]
            
            # 异动分析（包含提前预警）
            analysis = anomaly_engine.analyze_stock(stock_code, tick_data, current_price, current_change)
            
            # 如果检测到异动或预警，添加到结果中
            if analysis['anomaly_count'] > 0 or analysis['early_warning_count'] > 0:
                detected_anomalies.append({
                    'stock_code': stock_code,
                    'stock_name': stock_data.get('name', ''),
                    'current_price': current_price,
                    'change_percent': current_change,
                    'state': analysis['state'],
                    'anomaly_count': analysis['anomaly_count'],
                    'early_warning_count': analysis['early_warning_count'],
                    'confidence': max([a.get('confidence', 0) for a in analysis['anomaly_points']], default=0),
                    'is_early_warning': analysis['early_warning_count'] > 0,
                    'detection_time': datetime.now().isoformat(),
                    'time_segment': current_segment.segment_id,
                    'display_time': current_segment.display_time,
                    'details': {
                        'volume': stock_data.get('volume', 0),
                        'turnover_rate': stock_data.get('turnover_rate', 0),
                        'total_speed': analysis['total_speed'],
                        'recent_speed': analysis['recent_speed']
                    },
                    'reasons': []  # 可以根据异动类型生成具体原因
                })
        
        # 按状态和置信度排序
        detected_anomalies.sort(key=lambda x: (
            1 if x['state'] == '预警' else 0,  # 预警优先
            x['confidence'],  # 置信度高的优先
            abs(x['change_percent'])  # 变化幅度大的优先
        ), reverse=True)
        
        return {
            "anomalies": detected_anomalies,
            "total_count": len(detected_anomalies),
            "early_warning_count": sum(1 for a in detected_anomalies if a['is_early_warning']),
            "current_segment": {
                "segment_id": current_segment.segment_id,
                "display_time": current_segment.display_time
            },
            "detection_time": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"实时异动检测失败: {e}")
        raise HTTPException(status_code=500, detail=f"实时异动检测失败: {str(e)}") 