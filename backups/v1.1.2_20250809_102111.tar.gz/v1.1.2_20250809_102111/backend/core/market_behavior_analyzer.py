"""
主力行为分析模块
分析分时图中的主力行为，判断是洗盘还是出货
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timedelta
import pandas as pd

class MarketBehaviorAnalyzer:
    """主力行为分析器"""
    
    def __init__(self):
        self.behavior_signals = []
        self.trade_suggestions = []
        
    def analyze_timeshare_behavior(self, 
                                  timeshare_data: List[Dict],
                                  trade_details: List[Dict] = None) -> Dict:
        """
        分析分时图主力行为
        
        参数:
            timeshare_data: 分时数据列表
            trade_details: 成交明细数据
            
        返回:
            包含行为分析和操作建议的字典
        """
        if not timeshare_data or len(timeshare_data) < 10:
            return {
                'behavior': 'unknown',
                'confidence': 0,
                'signals': [],
                'suggestions': []
            }
        
        # 转换为DataFrame便于分析
        df = pd.DataFrame(timeshare_data)
        
        # 计算各项指标
        volume_analysis = self._analyze_volume_pattern(df)
        price_analysis = self._analyze_price_movement(df)
        support_resistance = self._analyze_support_resistance(df)
        
        # 如果有成交明细，进行深度分析
        detail_analysis = {}
        if trade_details:
            detail_analysis = self._analyze_trade_details(trade_details)
        
        # 综合判断主力行为
        behavior_type, confidence = self._judge_main_behavior(
            volume_analysis, 
            price_analysis,
            support_resistance,
            detail_analysis
        )
        
        # 生成操作建议
        suggestions = self._generate_suggestions(
            behavior_type,
            confidence,
            df.iloc[-1]['price'] if not df.empty else 0
        )
        
        return {
            'behavior': behavior_type,
            'confidence': confidence,
            'volume_pattern': volume_analysis,
            'price_pattern': price_analysis,
            'support_resistance': support_resistance,
            'detail_analysis': detail_analysis,
            'signals': self.behavior_signals,
            'suggestions': suggestions,
            'alert_level': self._get_alert_level(behavior_type, confidence)
        }
    
    def _analyze_volume_pattern(self, df: pd.DataFrame) -> Dict:
        """分析成交量模式"""
        if df.empty or 'volume' not in df.columns:
            return {}
        
        volumes = df['volume'].values
        prices = df['price'].values
        
        # 计算量价关系
        volume_ma = np.mean(volumes[-20:]) if len(volumes) >= 20 else np.mean(volumes)
        recent_volume = np.mean(volumes[-5:]) if len(volumes) >= 5 else volumes[-1]
        
        # 判断放量或缩量
        volume_ratio = recent_volume / volume_ma if volume_ma > 0 else 1
        
        # 计算量价背离
        if len(volumes) >= 10 and len(prices) >= 10:
            price_trend = (prices[-1] - prices[-10]) / prices[-10] if prices[-10] > 0 else 0
            volume_trend = (volumes[-1] - volumes[-10]) / volumes[-10] if volumes[-10] > 0 else 0
            divergence = abs(price_trend - volume_trend)
        else:
            divergence = 0
        
        pattern = {
            'volume_ratio': volume_ratio,
            'is_heavy_volume': volume_ratio > 1.5,
            'is_shrinking_volume': volume_ratio < 0.7,
            'divergence': divergence,
            'has_divergence': divergence > 0.3
        }
        
        # 添加行为信号
        if pattern['is_heavy_volume'] and prices[-1] < prices[-2]:
            self.behavior_signals.append({
                'type': 'volume',
                'signal': '放量下跌',
                'meaning': '可能是主力出货',
                'strength': 'strong'
            })
        elif pattern['is_shrinking_volume'] and prices[-1] < prices[-2]:
            self.behavior_signals.append({
                'type': 'volume',
                'signal': '缩量下跌',
                'meaning': '可能是主力洗盘',
                'strength': 'medium'
            })
        
        return pattern
    
    def _analyze_price_movement(self, df: pd.DataFrame) -> Dict:
        """分析价格走势特征"""
        if df.empty or 'price' not in df.columns:
            return {}
        
        prices = df['price'].values
        times = df['time'].values if 'time' in df.columns else None
        
        # 计算价格波动特征
        price_changes = np.diff(prices)
        volatility = np.std(price_changes) if len(price_changes) > 0 else 0
        
        # 识别急跌和缓涨
        rapid_drops = []
        slow_rises = []
        
        if len(prices) >= 5:
            for i in range(5, len(prices)):
                # 检测5分钟内的急跌（跌幅超过1%）
                drop_rate = (prices[i] - prices[i-5]) / prices[i-5] if prices[i-5] > 0 else 0
                if drop_rate < -0.01:
                    rapid_drops.append({
                        'index': i,
                        'drop_rate': drop_rate,
                        'time': times[i] if times is not None else i
                    })
                
                # 检测缓慢上涨
                if i >= 10:
                    rise_rate = (prices[i] - prices[i-10]) / prices[i-10] if prices[i-10] > 0 else 0
                    if 0.003 < rise_rate < 0.01:  # 0.3%-1%的温和上涨
                        slow_rises.append({
                            'index': i,
                            'rise_rate': rise_rate,
                            'time': times[i] if times is not None else i
                        })
        
        # 计算尾盘走势
        tail_movement = 'neutral'
        if len(prices) >= 30:
            tail_change = (prices[-1] - prices[-30]) / prices[-30] if prices[-30] > 0 else 0
            if tail_change > 0.005:
                tail_movement = 'pull_up'
                self.behavior_signals.append({
                    'type': 'price',
                    'signal': '尾盘拉升',
                    'meaning': '可能是洗盘结束信号',
                    'strength': 'medium'
                })
            elif tail_change < -0.005:
                tail_movement = 'dump'
                self.behavior_signals.append({
                    'type': 'price',
                    'signal': '尾盘跳水',
                    'meaning': '可能是出货信号',
                    'strength': 'strong'
                })
        
        return {
            'volatility': volatility,
            'rapid_drops': len(rapid_drops),
            'slow_rises': len(slow_rises),
            'tail_movement': tail_movement,
            'pattern': self._identify_price_pattern(rapid_drops, slow_rises)
        }
    
    def _analyze_support_resistance(self, df: pd.DataFrame) -> Dict:
        """分析支撑和压力位"""
        if df.empty or 'price' not in df.columns:
            return {}
        
        prices = df['price'].values
        current_price = prices[-1]
        
        # 找出关键价位
        high_price = np.max(prices)
        low_price = np.min(prices)
        avg_price = np.mean(prices)
        
        # 计算价格在区间中的位置
        price_position = (current_price - low_price) / (high_price - low_price) if high_price > low_price else 0.5
        
        # 检测是否在支撑位附近
        near_support = abs(current_price - low_price) / low_price < 0.005 if low_price > 0 else False
        near_resistance = abs(current_price - high_price) / high_price < 0.005 if high_price > 0 else False
        
        # 计算支撑强度
        support_tests = 0
        resistance_tests = 0
        
        for i in range(1, len(prices)):
            if abs(prices[i] - low_price) / low_price < 0.01:
                support_tests += 1
            if abs(prices[i] - high_price) / high_price < 0.01:
                resistance_tests += 1
        
        result = {
            'current_position': price_position,
            'near_support': near_support,
            'near_resistance': near_resistance,
            'support_strength': min(support_tests / 3, 1.0),  # 归一化到0-1
            'resistance_strength': min(resistance_tests / 3, 1.0)
        }
        
        if near_support and support_tests >= 2:
            self.behavior_signals.append({
                'type': 'support',
                'signal': '接近支撑位',
                'meaning': '可能获得支撑反弹',
                'strength': 'medium'
            })
        
        return result
    
    def _analyze_trade_details(self, trade_details: List[Dict]) -> Dict:
        """分析成交明细"""
        if not trade_details:
            return {}
        
        # 统计大单情况
        large_buys = 0
        large_sells = 0
        total_buy_amount = 0
        total_sell_amount = 0
        
        # 对倒交易检测
        paired_trades = []
        
        for i, trade in enumerate(trade_details):
            amount = trade.get('amount', 0)
            trade_type = trade.get('type', '')
            
            # 大单统计（金额超过50万）
            if amount > 500000:
                if trade_type == 'buy':
                    large_buys += 1
                    total_buy_amount += amount
                elif trade_type == 'sell':
                    large_sells += 1
                    total_sell_amount += amount
            
            # 检测对倒（相同价格、相近时间的买卖单）
            if i > 0:
                prev_trade = trade_details[i-1]
                if (abs(trade['price'] - prev_trade['price']) < 0.01 and
                    abs(trade['volume'] - prev_trade['volume']) < 100 and
                    trade['type'] != prev_trade['type']):
                    paired_trades.append({
                        'price': trade['price'],
                        'volume': trade['volume'],
                        'time': trade.get('time', '')
                    })
        
        # 计算内外盘比例
        df_trades = pd.DataFrame(trade_details)
        if 'type' in df_trades.columns:
            buy_volume = df_trades[df_trades['type'] == 'buy']['volume'].sum()
            sell_volume = df_trades[df_trades['type'] == 'sell']['volume'].sum()
            inner_outer_ratio = buy_volume / sell_volume if sell_volume > 0 else 1
        else:
            inner_outer_ratio = 1
        
        analysis = {
            'large_buy_count': large_buys,
            'large_sell_count': large_sells,
            'large_buy_amount': total_buy_amount,
            'large_sell_amount': total_sell_amount,
            'paired_trades': len(paired_trades),
            'has_pairing': len(paired_trades) > 5,
            'inner_outer_ratio': inner_outer_ratio,
            'buy_dominant': inner_outer_ratio > 1.2,
            'sell_dominant': inner_outer_ratio < 0.8
        }
        
        # 添加信号
        if analysis['has_pairing']:
            self.behavior_signals.append({
                'type': 'detail',
                'signal': '检测到对倒交易',
                'meaning': '主力可能在制造交投活跃假象',
                'strength': 'strong'
            })
        
        if large_sells > large_buys * 1.5:
            self.behavior_signals.append({
                'type': 'detail',
                'signal': '大单净卖出',
                'meaning': '主力可能在出货',
                'strength': 'strong'
            })
        
        return analysis
    
    def _identify_price_pattern(self, rapid_drops: List, slow_rises: List) -> str:
        """识别价格模式"""
        if len(rapid_drops) > len(slow_rises) * 2:
            return 'distribution'  # 派发模式
        elif len(slow_rises) > len(rapid_drops) * 2:
            return 'accumulation'  # 吸筹模式
        elif len(rapid_drops) > 0 and len(slow_rises) > 0:
            return 'shakeout'  # 洗盘模式
        else:
            return 'neutral'  # 中性
    
    def _judge_main_behavior(self, 
                            volume: Dict, 
                            price: Dict,
                            support: Dict,
                            detail: Dict) -> Tuple[str, float]:
        """综合判断主力行为"""
        
        wash_score = 0  # 洗盘得分
        ship_score = 0  # 出货得分
        
        # 成交量判断
        if volume.get('is_shrinking_volume', False):
            wash_score += 2
        if volume.get('is_heavy_volume', False) and not price.get('tail_movement') == 'pull_up':
            ship_score += 2
        
        # 价格走势判断
        if price.get('pattern') == 'shakeout':
            wash_score += 3
        elif price.get('pattern') == 'distribution':
            ship_score += 3
        
        if price.get('tail_movement') == 'pull_up':
            wash_score += 2
        elif price.get('tail_movement') == 'dump':
            ship_score += 2
        
        # 支撑位判断
        if support.get('near_support', False) and support.get('support_strength', 0) > 0.5:
            wash_score += 2
        
        # 成交明细判断
        if detail:
            if detail.get('has_pairing', False):
                wash_score += 1  # 对倒可能是洗盘
            if detail.get('sell_dominant', False):
                ship_score += 2
            if detail.get('large_sell_count', 0) > detail.get('large_buy_count', 0) * 1.5:
                ship_score += 3
        
        # 计算置信度
        total_score = wash_score + ship_score
        if total_score == 0:
            return 'unknown', 0
        
        if wash_score > ship_score:
            confidence = wash_score / (wash_score + ship_score)
            return 'washing', confidence
        elif ship_score > wash_score:
            confidence = ship_score / (wash_score + ship_score)
            return 'shipping', confidence
        else:
            return 'neutral', 0.5
    
    def _generate_suggestions(self, behavior: str, confidence: float, current_price: float) -> List[Dict]:
        """生成操作建议"""
        suggestions = []
        
        if behavior == 'washing' and confidence > 0.6:
            suggestions.append({
                'action': 'hold_or_buy',
                'reason': '主力洗盘中，可持有或逢低买入',
                'confidence': confidence,
                'risk_level': 'medium',
                'entry_price': current_price * 0.99,  # 建议在当前价下方1%买入
                'stop_loss': current_price * 0.97,    # 止损位3%
                'target': current_price * 1.05        # 目标位5%
            })
        elif behavior == 'shipping' and confidence > 0.6:
            suggestions.append({
                'action': 'sell_or_avoid',
                'reason': '主力出货中，建议减仓或回避',
                'confidence': confidence,
                'risk_level': 'high',
                'exit_price': current_price * 1.005,  # 建议反弹时卖出
                'stop_loss': current_price * 0.98,    # 止损位2%
                'target': None
            })
        elif behavior == 'neutral':
            suggestions.append({
                'action': 'wait_and_see',
                'reason': '走势不明朗，建议观望',
                'confidence': confidence,
                'risk_level': 'low',
                'entry_price': None,
                'stop_loss': None,
                'target': None
            })
        
        return suggestions
    
    def _get_alert_level(self, behavior: str, confidence: float) -> str:
        """获取警报级别"""
        if behavior == 'shipping' and confidence > 0.7:
            return 'high'
        elif behavior == 'washing' and confidence > 0.7:
            return 'opportunity'
        elif confidence > 0.5:
            return 'medium'
        else:
            return 'low'
    
    def get_realtime_alerts(self, analysis_result: Dict) -> List[Dict]:
        """获取实时警报"""
        alerts = []
        
        # 根据分析结果生成警报
        if analysis_result['alert_level'] == 'high':
            alerts.append({
                'type': 'danger',
                'title': '⚠️ 风险提示',
                'message': f"检测到主力{analysis_result['behavior']}行为，置信度{analysis_result['confidence']*100:.1f}%",
                'time': datetime.now().strftime('%H:%M:%S')
            })
        elif analysis_result['alert_level'] == 'opportunity':
            alerts.append({
                'type': 'opportunity',
                'title': '💡 机会提示',
                'message': f"可能是洗盘机会，置信度{analysis_result['confidence']*100:.1f}%",
                'time': datetime.now().strftime('%H:%M:%S')
            })
        
        # 添加具体信号警报
        for signal in analysis_result.get('signals', []):
            if signal['strength'] == 'strong':
                alerts.append({
                    'type': 'signal',
                    'title': signal['signal'],
                    'message': signal['meaning'],
                    'time': datetime.now().strftime('%H:%M:%S')
                })
        
        return alerts