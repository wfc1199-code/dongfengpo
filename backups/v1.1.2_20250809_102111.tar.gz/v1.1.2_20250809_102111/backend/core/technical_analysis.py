"""
横盘突破技术分析模块
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class TechnicalIndicators:
    """技术指标计算类"""
    
    @staticmethod
    def moving_average(prices: List[float], period: int) -> List[float]:
        """计算移动平均线"""
        if len(prices) < period:
            return []
        
        ma_values = []
        for i in range(period - 1, len(prices)):
            ma = sum(prices[i - period + 1:i + 1]) / period
            ma_values.append(ma)
        
        return ma_values
    
    @staticmethod
    def bollinger_bands(prices: List[float], period: int = 20, std_dev: float = 2.0) -> Tuple[List[float], List[float], List[float]]:
        """计算布林带"""
        if len(prices) < period:
            return [], [], []
        
        ma_values = TechnicalIndicators.moving_average(prices, period)
        upper_band = []
        lower_band = []
        
        for i in range(len(ma_values)):
            price_slice = prices[i:i + period]
            std = np.std(price_slice)
            upper_band.append(ma_values[i] + std_dev * std)
            lower_band.append(ma_values[i] - std_dev * std)
        
        return ma_values, upper_band, lower_band
    
    @staticmethod
    def rsi(prices: List[float], period: int = 14) -> List[float]:
        """计算相对强弱指标 RSI"""
        if len(prices) < period + 1:
            return []
        
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gains = []
        avg_losses = []
        rsi_values = []
        
        # 初始平均值
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])
        
        for i in range(period, len(deltas)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
            
            if avg_loss == 0:
                rsi = 100
            else:
                rs = avg_gain / avg_loss
                rsi = 100 - (100 / (1 + rs))
            
            rsi_values.append(rsi)
        
        return rsi_values
    
    @staticmethod
    def volume_ratio(volumes: List[int], period: int = 5) -> List[float]:
        """计算量比"""
        if len(volumes) < period:
            return []
        
        ratios = []
        for i in range(period - 1, len(volumes)):
            current_volume = volumes[i]
            avg_volume = sum(volumes[i - period + 1:i]) / (period - 1)
            
            if avg_volume > 0:
                ratio = current_volume / avg_volume
            else:
                ratio = 1.0
            
            ratios.append(ratio)
        
        return ratios


class SidewaysPattern:
    """横盘形态识别类"""
    
    def __init__(self, config: Dict):
        self.sideways_days = config.get('sideways_days', 5)
        self.price_fluctuation = config.get('price_fluctuation', 3.0)  # 价格波动幅度百分比
        self.volume_threshold = config.get('volume_threshold', 1.2)
        self.breakthrough_percent = config.get('breakthrough_percent', 2.0)
    
    def identify_sideways(self, kline_data: List[Dict]) -> Dict:
        """识别横盘形态"""
        if len(kline_data) < self.sideways_days + 2:
            return {'is_sideways': False, 'reason': '数据不足'}
        
        # 取最近的数据进行分析
        recent_data = kline_data[-self.sideways_days-2:]
        prices = [float(k['close']) for k in recent_data]
        volumes = [int(k['volume']) for k in recent_data]
        highs = [float(k['high']) for k in recent_data]
        lows = [float(k['low']) for k in recent_data]
        
        # 分析横盘区间（不包括最新两天）
        sideways_prices = prices[:-2]
        sideways_highs = highs[:-2]
        sideways_lows = lows[:-2]
        
        # 1. 价格波动范围检查
        max_price = max(sideways_prices)
        min_price = min(sideways_prices)
        price_range = (max_price - min_price) / min_price * 100
        
        if price_range > self.price_fluctuation:
            return {'is_sideways': False, 'reason': f'价格波动过大: {price_range:.2f}%'}
        
        # 2. 检查是否在横盘区间内震荡
        upper_bound = max_price
        lower_bound = min_price
        
        # 3. 成交量相对稳定
        recent_volumes = volumes[:-2]
        avg_volume = sum(recent_volumes) / len(recent_volumes)
        volume_std = np.std(recent_volumes)
        volume_cv = volume_std / avg_volume if avg_volume > 0 else 0
        
        # 4. 返回横盘分析结果
        return {
            'is_sideways': True,
            'upper_bound': upper_bound,
            'lower_bound': lower_bound,
            'price_range_percent': price_range,
            'avg_volume': avg_volume,
            'volume_cv': volume_cv,
            'sideways_days': self.sideways_days,
            'analysis_date': recent_data[-1]['date']
        }
    
    def check_breakthrough(self, kline_data: List[Dict], sideways_info: Dict) -> Dict:
        """检查突破情况"""
        if not sideways_info.get('is_sideways', False):
            return {'is_breakthrough': False, 'reason': '非横盘状态'}
        
        if len(kline_data) < 2:
            return {'is_breakthrough': False, 'reason': '数据不足'}
        
        latest = kline_data[-1]
        previous = kline_data[-2]
        
        current_price = float(latest['close'])
        current_volume = int(latest['volume'])
        current_high = float(latest['high'])
        current_low = float(latest['low'])
        
        upper_bound = sideways_info['upper_bound']
        lower_bound = sideways_info['lower_bound']
        avg_volume = sideways_info['avg_volume']
        
        # 检查价格突破
        upward_break = current_price > upper_bound * (1 + self.breakthrough_percent / 100)
        downward_break = current_price < lower_bound * (1 - self.breakthrough_percent / 100)
        
        # 检查成交量放大
        volume_amplified = current_volume > avg_volume * self.volume_threshold
        
        breakthrough_type = None
        if upward_break and volume_amplified:
            breakthrough_type = 'upward'
        elif downward_break and volume_amplified:
            breakthrough_type = 'downward'
        
        if breakthrough_type:
            breakthrough_percent = 0
            if breakthrough_type == 'upward':
                breakthrough_percent = (current_price - upper_bound) / upper_bound * 100
            else:
                breakthrough_percent = (lower_bound - current_price) / lower_bound * 100
            
            return {
                'is_breakthrough': True,
                'type': breakthrough_type,
                'breakthrough_percent': breakthrough_percent,
                'current_price': current_price,
                'volume_ratio': current_volume / avg_volume,
                'upper_bound': upper_bound,
                'lower_bound': lower_bound,
                'date': latest['date'],
                'confidence': self._calculate_confidence(kline_data, sideways_info, breakthrough_type)
            }
        
        return {
            'is_breakthrough': False,
            'reason': '未满足突破条件',
            'current_price': current_price,
            'upper_bound': upper_bound,
            'lower_bound': lower_bound,
            'volume_ratio': current_volume / avg_volume if avg_volume > 0 else 0
        }
    
    def _calculate_confidence(self, kline_data: List[Dict], sideways_info: Dict, breakthrough_type: str) -> float:
        """计算突破信号的可信度"""
        confidence = 0.5  # 基础可信度
        
        # 1. 横盘时间越长，突破可信度越高
        sideways_days = sideways_info.get('sideways_days', 0)
        if sideways_days >= 7:
            confidence += 0.2
        elif sideways_days >= 5:
            confidence += 0.1
        
        # 2. 价格突破幅度
        latest = kline_data[-1]
        current_price = float(latest['close'])
        
        if breakthrough_type == 'upward':
            break_percent = (current_price - sideways_info['upper_bound']) / sideways_info['upper_bound'] * 100
        else:
            break_percent = (sideways_info['lower_bound'] - current_price) / sideways_info['lower_bound'] * 100
        
        if break_percent >= 3:
            confidence += 0.2
        elif break_percent >= 2:
            confidence += 0.1
        
        # 3. 成交量放大程度
        current_volume = int(latest['volume'])
        volume_ratio = current_volume / sideways_info['avg_volume']
        
        if volume_ratio >= 2.0:
            confidence += 0.2
        elif volume_ratio >= 1.5:
            confidence += 0.1
        
        # 4. 价格波动幅度（横盘期间波动越小，突破越可信）
        price_range_percent = sideways_info.get('price_range_percent', 0)
        if price_range_percent <= 2:
            confidence += 0.1
        
        return min(confidence, 1.0)


class HorizontalBreakAnalyzer:
    """横盘突破分析器"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.sideways_pattern = SidewaysPattern(config.get('technical', {}))
        self.indicators = TechnicalIndicators()
    
    def analyze_stock(self, stock_code: str, kline_data: List[Dict]) -> Dict:
        """分析单只股票的横盘突破情况"""
        try:
            if len(kline_data) < 10:
                return {
                    'code': stock_code,
                    'status': 'insufficient_data',
                    'message': '历史数据不足'
                }
            
            # 1. 识别横盘形态
            sideways_info = self.sideways_pattern.identify_sideways(kline_data)
            
            # 2. 检查突破
            breakthrough_info = self.sideways_pattern.check_breakthrough(kline_data, sideways_info)
            
            # 3. 计算技术指标
            prices = [float(k['close']) for k in kline_data]
            volumes = [int(k['volume']) for k in kline_data]
            
            # 移动平均线
            ma5 = self.indicators.moving_average(prices, 5)
            ma10 = self.indicators.moving_average(prices, 10)
            ma20 = self.indicators.moving_average(prices, 20)
            
            # RSI
            rsi = self.indicators.rsi(prices)
            
            # 量比
            volume_ratio = self.indicators.volume_ratio(volumes)
            
            # 4. 生成分析结果
            result = {
                'code': stock_code,
                'analysis_time': datetime.now().isoformat(),
                'sideways_info': sideways_info,
                'breakthrough_info': breakthrough_info,
                'technical_indicators': {
                    'ma5': ma5[-1] if ma5 else None,
                    'ma10': ma10[-1] if ma10 else None,
                    'ma20': ma20[-1] if ma20 else None,
                    'rsi': rsi[-1] if rsi else None,
                    'volume_ratio': volume_ratio[-1] if volume_ratio else None,
                    'current_price': prices[-1] if prices else None
                },
                'recommendation': self._generate_recommendation(sideways_info, breakthrough_info)
            }
            
            return result
            
        except Exception as e:
            logger.error(f"分析股票 {stock_code} 时发生错误: {e}")
            return {
                'code': stock_code,
                'status': 'error',
                'message': str(e)
            }
    
    def _generate_recommendation(self, sideways_info: Dict, breakthrough_info: Dict) -> Dict:
        """生成投资建议"""
        if not sideways_info.get('is_sideways', False):
            return {
                'action': 'hold',
                'reason': '未处于横盘状态',
                'confidence': 0.3
            }
        
        if breakthrough_info.get('is_breakthrough', False):
            breakthrough_type = breakthrough_info['type']
            confidence = breakthrough_info.get('confidence', 0.5)
            
            if breakthrough_type == 'upward' and confidence > 0.7:
                return {
                    'action': 'buy',
                    'reason': f"向上突破，可信度: {confidence:.2f}",
                    'confidence': confidence,
                    'target_price': breakthrough_info['current_price'] * 1.05,
                    'stop_loss': breakthrough_info['lower_bound']
                }
            elif breakthrough_type == 'downward' and confidence > 0.7:
                return {
                    'action': 'sell',
                    'reason': f"向下突破，可信度: {confidence:.2f}",
                    'confidence': confidence,
                    'stop_loss': breakthrough_info['upper_bound']
                }
        
        return {
            'action': 'watch',
            'reason': '横盘中，等待突破机会',
            'confidence': 0.6,
            'watch_levels': {
                'resistance': sideways_info.get('upper_bound'),
                'support': sideways_info.get('lower_bound')
            }
        }
    
    def batch_analyze(self, stocks_data: Dict[str, List[Dict]]) -> List[Dict]:
        """批量分析多只股票"""
        results = []
        
        for stock_code, kline_data in stocks_data.items():
            analysis = self.analyze_stock(stock_code, kline_data)
            results.append(analysis)
        
        # 按突破信号的可信度排序
        breakthrough_stocks = [r for r in results if r.get('breakthrough_info', {}).get('is_breakthrough', False)]
        breakthrough_stocks.sort(key=lambda x: x.get('breakthrough_info', {}).get('confidence', 0), reverse=True)
        
        return {
            'total_analyzed': len(results),
            'breakthrough_count': len(breakthrough_stocks),
            'breakthrough_stocks': breakthrough_stocks,
            'all_results': results,
            'analysis_time': datetime.now().isoformat()
        }


# 测试函数
def test_horizontal_break_analyzer():
    """测试横盘突破分析器"""
    config = {
        'technical': {
            'sideways_days': 5,
            'price_fluctuation': 3.0,
            'volume_threshold': 1.2,
            'breakthrough_percent': 2.0
        }
    }
    
    # 模拟K线数据
    test_kline = [
        {'date': '2023-12-01', 'open': 10.0, 'high': 10.2, 'low': 9.8, 'close': 10.0, 'volume': 100000},
        {'date': '2023-12-02', 'open': 10.0, 'high': 10.3, 'low': 9.9, 'close': 10.1, 'volume': 95000},
        {'date': '2023-12-03', 'open': 10.1, 'high': 10.2, 'low': 9.9, 'close': 9.95, 'volume': 98000},
        {'date': '2023-12-04', 'open': 9.95, 'high': 10.1, 'low': 9.8, 'close': 10.05, 'volume': 102000},
        {'date': '2023-12-05', 'open': 10.05, 'high': 10.15, 'low': 9.9, 'close': 10.0, 'volume': 97000},
        {'date': '2023-12-06', 'open': 10.0, 'high': 10.1, 'low': 9.85, 'close': 9.9, 'volume': 99000},
        {'date': '2023-12-07', 'open': 9.9, 'high': 10.45, 'low': 9.9, 'close': 10.4, 'volume': 150000},  # 突破
    ]
    
    analyzer = HorizontalBreakAnalyzer(config)
    result = analyzer.analyze_stock('test001', test_kline)
    
    print("横盘突破分析结果:")
    print(f"横盘状态: {result['sideways_info']}")
    print(f"突破信息: {result['breakthrough_info']}")
    print(f"投资建议: {result['recommendation']}")


if __name__ == "__main__":
    test_horizontal_break_analyzer() 