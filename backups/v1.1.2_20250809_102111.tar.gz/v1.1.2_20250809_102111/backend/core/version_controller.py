"""
版本管理控制器
提供版本备份、恢复、查询等功能的API接口
"""

import os
import json
import shutil
import tarfile
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
from fastapi import HTTPException
from pydantic import BaseModel
import subprocess

class VersionInfo(BaseModel):
    """版本信息模型"""
    version: str
    timestamp: str
    date: str
    message: str
    size: str
    file: str
    is_current: bool = False

class VersionCreateRequest(BaseModel):
    """创建版本请求"""
    type: str = "patch"  # major, minor, patch
    message: str = "手动备份"

class VersionRestoreRequest(BaseModel):
    """恢复版本请求"""
    version: str

class VersionController:
    """版本控制器"""
    
    def __init__(self):
        self.project_root = Path("/Users/wangfangchun/东风破")
        self.backup_dir = self.project_root / "backups"
        self.version_db = self.backup_dir / "versions.json"
        self.current_version_file = self.project_root / ".current_version"
        
        # 确保目录存在
        self.backup_dir.mkdir(exist_ok=True)
        
        # 初始化版本数据库
        if not self.version_db.exists():
            self.init_version_db()
    
    def init_version_db(self):
        """初始化版本数据库"""
        with open(self.version_db, 'w') as f:
            json.dump({"versions": []}, f, indent=2)
    
    def get_current_version(self) -> str:
        """获取当前版本"""
        if self.current_version_file.exists():
            return self.current_version_file.read_text().strip()
        return "v1.0.0"
    
    def generate_new_version(self, version_type: str) -> str:
        """生成新版本号"""
        current = self.get_current_version()
        version = current.lstrip('v')
        parts = version.split('.')
        
        major = int(parts[0]) if len(parts) > 0 else 1
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        
        if version_type == "major":
            major += 1
            minor = 0
            patch = 0
        elif version_type == "minor":
            minor += 1
            patch = 0
        else:  # patch
            patch += 1
        
        return f"v{major}.{minor}.{patch}"
    
    async def create_backup(self, version_type: str = "patch", message: str = "手动备份") -> Dict:
        """创建版本备份"""
        new_version = self.generate_new_version(version_type)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{new_version}_{timestamp}"
        backup_path = self.backup_dir / backup_name
        
        # 创建临时备份目录
        backup_path.mkdir(exist_ok=True)
        
        # 要备份的项目
        backup_items = [
            "backend",
            "frontend/src",
            "frontend/package.json",
            "scripts",
            "config",
        ]
        
        # 复制文件
        for item in backup_items:
            source = self.project_root / item
            if source.exists():
                dest = backup_path / item
                if source.is_dir():
                    shutil.copytree(source, dest, dirs_exist_ok=True)
                else:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, dest)
        
        # 复制根目录的配置文件
        for pattern in ["*.md", "*.json", "*.html"]:
            for file in self.project_root.glob(pattern):
                if file.is_file():
                    shutil.copy2(file, backup_path / file.name)
        
        # 创建备份信息
        backup_info = {
            "version": new_version,
            "previous_version": self.get_current_version(),
            "timestamp": timestamp,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "message": message,
            "files_count": sum(1 for _ in backup_path.rglob("*") if _.is_file())
        }
        
        with open(backup_path / "backup_info.json", 'w') as f:
            json.dump(backup_info, f, indent=2, ensure_ascii=False)
        
        # 压缩备份
        tar_file = self.backup_dir / f"{backup_name}.tar.gz"
        with tarfile.open(tar_file, "w:gz") as tar:
            tar.add(backup_path, arcname=backup_name)
        
        # 删除临时目录
        shutil.rmtree(backup_path)
        
        # 计算文件大小
        size = self.format_size(tar_file.stat().st_size)
        
        # 更新版本数据库
        self.update_version_db(new_version, timestamp, message, f"{backup_name}.tar.gz", size)
        
        # 更新当前版本
        self.current_version_file.write_text(new_version)
        
        # 清理旧备份
        self.cleanup_old_backups()
        
        return {
            "version": new_version,
            "timestamp": timestamp,
            "message": message,
            "file": str(tar_file),
            "size": size,
            "status": "success"
        }
    
    def update_version_db(self, version: str, timestamp: str, message: str, file: str, size: str):
        """更新版本数据库"""
        with open(self.version_db, 'r') as f:
            data = json.load(f)
        
        new_version = {
            "version": version,
            "timestamp": timestamp,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "message": message,
            "file": file,
            "size": size
        }
        
        data["versions"].insert(0, new_version)
        
        # 只保留最近20个版本记录
        data["versions"] = data["versions"][:20]
        
        with open(self.version_db, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_versions(self) -> List[VersionInfo]:
        """获取版本列表"""
        if not self.version_db.exists():
            return []
        
        with open(self.version_db, 'r') as f:
            data = json.load(f)
        
        current_version = self.get_current_version()
        versions = []
        
        for v in data.get("versions", []):
            version_info = VersionInfo(**v)
            version_info.is_current = (version_info.version == current_version)
            versions.append(version_info)
        
        return versions
    
    def get_version_timeline(self) -> List[Dict]:
        """获取版本时间轴"""
        versions = self.get_versions()
        timeline = []
        
        for i, v in enumerate(versions[:10]):  # 只显示最近10个
            timeline.append({
                "version": v.version,
                "date": v.date,
                "message": v.message,
                "size": v.size,
                "is_current": v.is_current,
                "is_latest": i == 0
            })
        
        return timeline
    
    async def restore_version(self, target_version: str) -> Dict:
        """恢复到指定版本"""
        # 查找目标版本
        versions = self.get_versions()
        target = None
        
        for v in versions:
            if v.version == target_version:
                target = v
                break
        
        if not target:
            raise HTTPException(status_code=404, detail=f"版本 {target_version} 不存在")
        
        # 检查备份文件
        backup_file = self.backup_dir / target.file
        if not backup_file.exists():
            raise HTTPException(status_code=404, detail=f"备份文件不存在: {target.file}")
        
        # 先创建当前版本的备份
        await self.create_backup("patch", f"恢复到{target_version}前的自动备份")
        
        # 停止服务
        try:
            subprocess.run([str(self.project_root / "scripts" / "stop_dongfeng.sh")], check=True)
        except:
            pass  # 服务可能未运行
        
        # 解压备份
        extract_dir = self.backup_dir / "temp_restore"
        extract_dir.mkdir(exist_ok=True)
        
        with tarfile.open(backup_file, "r:gz") as tar:
            tar.extractall(extract_dir)
        
        # 恢复文件
        backup_content = extract_dir / target.file.replace(".tar.gz", "")
        
        # 恢复项目文件
        for item in ["backend", "frontend/src", "scripts", "config"]:
            source = backup_content / item
            if source.exists():
                dest = self.project_root / item
                if dest.exists():
                    if dest.is_dir():
                        shutil.rmtree(dest)
                    else:
                        dest.unlink()
                
                if source.is_dir():
                    shutil.copytree(source, dest)
                else:
                    shutil.copy2(source, dest)
        
        # 恢复根目录文件
        for file in backup_content.glob("*.md"):
            shutil.copy2(file, self.project_root / file.name)
        for file in backup_content.glob("*.json"):
            if file.name != "backup_info.json":
                shutil.copy2(file, self.project_root / file.name)
        for file in backup_content.glob("*.html"):
            shutil.copy2(file, self.project_root / file.name)
        
        # 清理临时目录
        shutil.rmtree(extract_dir)
        
        # 更新当前版本
        self.current_version_file.write_text(target_version)
        
        return {
            "status": "success",
            "version": target_version,
            "message": f"成功恢复到版本 {target_version}"
        }
    
    def cleanup_old_backups(self, keep_count: int = 10):
        """清理旧备份，保留最近的N个"""
        backups = sorted(
            self.backup_dir.glob("*.tar.gz"),
            key=lambda x: x.stat().st_mtime,
            reverse=True
        )
        
        if len(backups) > keep_count:
            for backup in backups[keep_count:]:
                backup.unlink()
    
    def format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f}{unit}"
            size /= 1024.0
        return f"{size:.1f}TB"
    
    def get_backup_stats(self) -> Dict:
        """获取备份统计信息"""
        backups = list(self.backup_dir.glob("*.tar.gz"))
        total_size = sum(b.stat().st_size for b in backups)
        
        versions = self.get_versions()
        
        return {
            "total_backups": len(backups),
            "total_size": self.format_size(total_size),
            "current_version": self.get_current_version(),
            "latest_backup": versions[0].date if versions else None,
            "oldest_backup": versions[-1].date if versions else None,
            "backup_directory": str(self.backup_dir)
        }

# 创建全局实例
version_controller = VersionController()