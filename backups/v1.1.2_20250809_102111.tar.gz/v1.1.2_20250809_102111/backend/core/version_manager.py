"""
版本管理模块
负责系统版本的创建、存储和管理
"""

import json
import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import zipfile
import hashlib


class VersionManager:
    """版本管理器"""
    
    def __init__(self, project_root: str = None):
        if project_root is None:
            project_root = Path(__file__).parent.parent
        
        self.project_root = Path(project_root)
        self.versions_dir = self.project_root / "versions"
        self.db_path = self.versions_dir / "versions.db"
        
        # 确保版本目录存在
        self.versions_dir.mkdir(exist_ok=True)
        
        # 初始化数据库
        self._init_database()
    
    def _init_database(self):
        """初始化版本数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version_name TEXT NOT NULL,
                version_code TEXT UNIQUE NOT NULL,
                description TEXT,
                created_at TEXT NOT NULL,
                created_by TEXT DEFAULT 'system',
                file_path TEXT NOT NULL,
                file_size INTEGER,
                checksum TEXT,
                tags TEXT,
                status TEXT DEFAULT 'active',
                metadata TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS version_changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version_id INTEGER,
                change_type TEXT NOT NULL,
                file_path TEXT NOT NULL,
                change_description TEXT,
                FOREIGN KEY (version_id) REFERENCES versions (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_version(self, version_name: str, description: str = "", tags: List[str] = None) -> Dict:
        """创建新版本"""
        try:
            # 生成版本代码
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            version_code = f"v{timestamp}"
            
            # 创建版本快照
            snapshot_path = self._create_snapshot(version_code)
            
            # 计算文件校验和
            checksum = self._calculate_checksum(snapshot_path)
            file_size = os.path.getsize(snapshot_path)
            
            # 收集变更信息
            changes = self._collect_changes()
            
            # 保存版本信息到数据库
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO versions 
                (version_name, version_code, description, created_at, file_path, 
                 file_size, checksum, tags, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                version_name,
                version_code,
                description,
                datetime.now().isoformat(),
                str(snapshot_path),
                file_size,
                checksum,
                json.dumps(tags or []),
                json.dumps({
                    "changes_count": len(changes),
                    "snapshot_size": file_size,
                    "python_version": "3.12",
                    "system_info": "macOS"
                })
            ))
            
            version_id = cursor.lastrowid
            
            # 保存变更记录
            for change in changes:
                cursor.execute('''
                    INSERT INTO version_changes 
                    (version_id, change_type, file_path, change_description)
                    VALUES (?, ?, ?, ?)
                ''', (version_id, change['type'], change['path'], change['description']))
            
            conn.commit()
            conn.close()
            
            print(f"✅ 版本 {version_code} 创建成功: {version_name}")
            print(f"📁 快照路径: {snapshot_path}")
            print(f"📊 文件大小: {file_size / 1024 / 1024:.2f} MB")
            print(f"🔍 变更数量: {len(changes)}")
            
            return {
                "version_id": version_id,
                "version_code": version_code,
                "version_name": version_name,
                "description": description,
                "created_at": datetime.now().isoformat(),
                "file_path": str(snapshot_path),
                "file_size": file_size,
                "checksum": checksum,
                "changes_count": len(changes)
            }
            
        except Exception as e:
            print(f"❌ 创建版本失败: {e}")
            raise
    
    def _create_snapshot(self, version_code: str) -> Path:
        """创建系统快照"""
        snapshot_path = self.versions_dir / f"{version_code}.zip"
        
        # 需要包含的文件和目录
        include_patterns = [
            "backend/**/*.py",
            "frontend/src/**/*",
            "frontend/public/**/*",
            "frontend/package.json",
            "frontend/package-lock.json",
            "scripts/**/*",
            "*.md",
            "*.json",
            "*.sh"
        ]
        
        # 排除的文件和目录
        exclude_patterns = [
            "node_modules/**/*",
            "backend/venv/**/*",
            "backend/__pycache__/**/*",
            "backend/**/__pycache__/**/*",
            "logs/**/*",
            "versions/**/*",
            ".git/**/*",
            "*.pyc",
            "*.log"
        ]
        
        with zipfile.ZipFile(snapshot_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for pattern in include_patterns:
                for file_path in self.project_root.glob(pattern):
                    if file_path.is_file():
                        # 检查是否应该排除
                        should_exclude = False
                        for exclude_pattern in exclude_patterns:
                            if file_path.match(exclude_pattern):
                                should_exclude = True
                                break
                        
                        if not should_exclude:
                            arcname = file_path.relative_to(self.project_root)
                            zipf.write(file_path, arcname)
        
        return snapshot_path
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """计算文件MD5校验和"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    def _collect_changes(self) -> List[Dict]:
        """收集系统变更信息"""
        changes = []
        
        # 这里可以通过Git或文件系统分析收集变更
        # 暂时返回预定义的变更信息
        changes.extend([
            {
                "type": "enhancement",
                "path": "frontend/src/components/StockChart.tsx",
                "description": "优化K线图性能，添加数据缓存机制"
            },
            {
                "type": "enhancement", 
                "path": "backend/main.py",
                "description": "改进错误处理，添加非交易时间检测"
            },
            {
                "type": "enhancement",
                "path": "backend/core/data_sources.py", 
                "description": "优化请求间隔，提高API响应速度"
            },
            {
                "type": "feature",
                "path": "frontend/src/components/StockChart.tsx",
                "description": "实现请求竞态条件防护和缓存系统"
            }
        ])
        
        return changes
    
    def get_versions(self, limit: int = 50) -> List[Dict]:
        """获取版本列表"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, version_name, version_code, description, created_at, 
                   file_size, checksum, tags, status, metadata
            FROM versions 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (limit,))
        
        versions = []
        for row in cursor.fetchall():
            version = {
                "id": row[0],
                "version_name": row[1],
                "version_code": row[2], 
                "description": row[3],
                "created_at": row[4],
                "file_size": row[5],
                "checksum": row[6],
                "tags": json.loads(row[7]) if row[7] else [],
                "status": row[8],
                "metadata": json.loads(row[9]) if row[9] else {}
            }
            versions.append(version)
        
        conn.close()
        return versions
    
    def get_version_changes(self, version_id: int) -> List[Dict]:
        """获取版本变更记录"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT change_type, file_path, change_description
            FROM version_changes 
            WHERE version_id = ?
        ''', (version_id,))
        
        changes = []
        for row in cursor.fetchall():
            changes.append({
                "type": row[0],
                "path": row[1],
                "description": row[2]
            })
        
        conn.close()
        return changes
    
    def delete_version(self, version_id: int) -> bool:
        """删除版本"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 获取版本信息
            cursor.execute('SELECT file_path FROM versions WHERE id = ?', (version_id,))
            result = cursor.fetchone()
            
            if result:
                file_path = Path(result[0])
                
                # 删除快照文件
                if file_path.exists():
                    file_path.unlink()
                
                # 删除数据库记录
                cursor.execute('DELETE FROM version_changes WHERE version_id = ?', (version_id,))
                cursor.execute('DELETE FROM versions WHERE id = ?', (version_id,))
                
                conn.commit()
                conn.close()
                
                print(f"✅ 版本 {version_id} 删除成功")
                return True
            
            conn.close()
            return False
            
        except Exception as e:
            print(f"❌ 删除版本失败: {e}")
            return False


# 全局版本管理器实例
version_manager = VersionManager()