#!/usr/bin/env python3
"""简单测试数据获取"""

import asyncio
import sys
sys.path.insert(0, '/Users/wangfangchun/东风破/backend')

from core.data_sources import StockDataManager

async def test_data():
    """测试数据获取"""
    
    print("=" * 60)
    print("🧪 测试实时数据获取")
    print("=" * 60)
    
    # 初始化数据管理器
    data_manager = StockDataManager()
    
    # 测试股票
    test_stocks = ["sh600519", "sz000858", "sz300750"]
    
    print(f"\n📊 测试股票: {test_stocks}")
    print("\n获取实时数据...")
    
    # 获取实时数据
    data = await data_manager.get_realtime_data(test_stocks)
    
    if data:
        print(f"\n✅ 成功获取 {len(data)} 只股票数据:\n")
        for code, info in data.items():
            if info:
                print(f"  {info.get('name', '未知')} ({code})")
                print(f"    当前价: ¥{info.get('current', 0):.2f}")
                print(f"    涨跌幅: {info.get('change_percent', 0):+.2f}%")
                print(f"    成交量: {info.get('volume', 0)/10000:.0f}万手")
                print()
    else:
        print("\n❌ 未能获取数据")
    
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_data())