import React, { useState } from 'react';
import './HotSectors.css';

interface HotSector {
  sector_name: string;
  stock_count: number;
  avg_change: number;
  total_amount: number;
  rank: number;
  anomaly_count?: number;
  anomaly_ratio?: number;
  avg_volume_ratio?: number;
  hot_score?: number;
  trend?: string;
  category?: string;
  description?: string;
}

interface SectorStock {
  stock_code: string;
  stock_name: string;
  current_price: number;
  change_percent: number;
  volume: number;
  amount: number;
  market_value: number;
  turnover_rate: number;
  is_leader: boolean;
}

interface HotSectorsProps {
  sectors: HotSector[];
  selectedStock?: string;
  onStockSelect?: (stockCode: string) => void;
}

const HotSectors: React.FC<HotSectorsProps> = ({ sectors, selectedStock, onStockSelect }) => {
  const [expandedSector, setExpandedSector] = useState<string | null>(null);
  const [sectorStocks, setSectorStocks] = useState<{[key: string]: SectorStock[]}>({});
  const [loadingStocks, setLoadingStocks] = useState<{[key: string]: boolean}>({});
  const [sortBy, setSortBy] = useState<{[key: string]: string}>({});
  const [sortOrder, setSortOrder] = useState<{[key: string]: 'asc' | 'desc'}>({});

  const formatAmount = (amount: number) => {
    if (amount >= 100000000) {
      return (amount / 100000000).toFixed(1) + '亿';
    } else if (amount >= 10000) {
      return (amount / 10000).toFixed(1) + '万';
    }
    return amount.toFixed(0);
  };

  const getChangeClass = (change: number) => {
    if (change > 0) return 'positive';
    if (change < 0) return 'negative';
    return 'neutral';
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return `${rank}`;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case '强势上涨': return '🚀';
      case '温和上涨': return '📈';
      case '震荡整理': return '➡️';
      case '轻微下跌': return '📉';
      case '明显下跌': return '🔻';
      default: return '📊';
    }
  };

  const getTrendClass = (trend: string) => {
    if (trend?.includes('上涨')) return 'trend-up';
    if (trend?.includes('下跌')) return 'trend-down';
    return 'trend-neutral';
  };

  // 获取板块成分股数据
  const fetchSectorStocks = async (sectorName: string) => {
    console.log('📡 开始获取成分股数据:', sectorName);
    setLoadingStocks(prev => ({...prev, [sectorName]: true}));
    
    try {
                const response = await fetch(`http://localhost:9000/api/anomaly/sector-stocks/${encodeURIComponent(sectorName)}?limit=200`);
      console.log('📡 API响应状态:', response.status, response.ok);
      
      if (response.ok) {
        const data = await response.json();
        console.log('📊 获取到成分股数据:', data);
        console.log('📊 股票数量:', data.stocks?.length || 0);
        console.log('📊 龙头股数量:', data.stocks?.filter((s: any) => s.is_leader).length || 0);
        
        setSectorStocks(prev => ({
          ...prev,
          [sectorName]: data.stocks || []
        }));
        
        // 初始化排序状态（默认按涨跌幅降序）
        if (!sortBy[sectorName]) {
          setSortBy(prev => ({ ...prev, [sectorName]: 'change_percent' }));
          setSortOrder(prev => ({ ...prev, [sectorName]: 'desc' }));
        }
      } else {
        console.error('❌ API请求失败:', response.status);
      }
    } catch (error) {
      console.error(`❌ 获取${sectorName}成分股失败:`, error);
      setSectorStocks(prev => ({
        ...prev,
        [sectorName]: []
      }));
    } finally {
      setLoadingStocks(prev => ({...prev, [sectorName]: false}));
      console.log('✅ 成分股数据获取完成');
    }
  };

  // 处理股票点击事件
  const handleStockClick = (stockCode: string) => {
    if (onStockSelect) {
      onStockSelect(stockCode);
    }
  };

  // 排序函数
  const sortStocks = (stocks: SectorStock[], sortKey: string, order: 'asc' | 'desc') => {
    return [...stocks].sort((a, b) => {
      let aValue, bValue;
      
      switch (sortKey) {
        case 'change_percent':
          aValue = a.change_percent;
          bValue = b.change_percent;
          break;
        case 'current_price':
          aValue = a.current_price;
          bValue = b.current_price;
          break;
        case 'turnover_rate':
          aValue = a.turnover_rate || 0;
          bValue = b.turnover_rate || 0;
          break;
        case 'market_value':
          aValue = a.market_value || 0;
          bValue = b.market_value || 0;
          break;
        case 'volume':
          aValue = a.volume || 0;
          bValue = b.volume || 0;
          break;
        case 'amount':
          aValue = a.amount || 0;
          bValue = b.amount || 0;
          break;
        case 'stock_name':
          aValue = a.stock_name || '';
          bValue = b.stock_name || '';
          break;
        default:
          return 0;
      }
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return order === 'asc' 
          ? aValue.localeCompare(bValue, 'zh-CN')
          : bValue.localeCompare(aValue, 'zh-CN');
      }
      
      // 确保数值类型
      const numA = typeof aValue === 'number' ? aValue : 0;
      const numB = typeof bValue === 'number' ? bValue : 0;
      
      if (order === 'asc') {
        return numA - numB;
      } else {
        return numB - numA;
      }
    });
  };

  // 处理排序变化
  const handleSortChange = (sectorName: string, sortKey: string) => {
    const currentSortBy = sortBy[sectorName];
    const currentOrder = sortOrder[sectorName];
    
    let newOrder: 'asc' | 'desc' = 'desc';
    
    // 如果点击的是同一个排序字段，则切换排序方向
    if (currentSortBy === sortKey) {
      newOrder = currentOrder === 'desc' ? 'asc' : 'desc';
    }
    
    setSortBy(prev => ({ ...prev, [sectorName]: sortKey }));
    setSortOrder(prev => ({ ...prev, [sectorName]: newOrder }));
  };

  // 获取排序后的股票列表
  const getSortedStocks = (sectorName: string, stocks: SectorStock[], isLeader: boolean = false) => {
    if (!stocks || stocks.length === 0) return [];
    
    const filteredStocks = stocks.filter(stock => stock.is_leader === isLeader);
    const currentSortBy = sortBy[sectorName] || 'change_percent';
    const currentOrder = sortOrder[sectorName] || 'desc';
    
    return sortStocks(filteredStocks, currentSortBy, currentOrder);
  };

  // 处理板块点击事件
  const handleSectorClick = async (sectorName: string) => {
    console.log('🔍 点击板块:', sectorName);
    console.log('当前展开的板块:', expandedSector);
    
    if (expandedSector === sectorName) {
      console.log('折叠板块:', sectorName);
      setExpandedSector(null);
    } else {
      console.log('展开板块:', sectorName);
      setExpandedSector(sectorName);
      if (!sectorStocks[sectorName]) {
        console.log('获取成分股数据:', sectorName);
        await fetchSectorStocks(sectorName);
      } else {
        console.log('使用缓存的成分股数据:', sectorStocks[sectorName].length, '只股票');
      }
    }
  };

  return (
    <div className="hot-sectors">
      <div className="panel-header">
        <h3>热门板块</h3>
        <div className="update-time">
          {new Date().toLocaleTimeString('zh-CN', { 
            hour: '2-digit', 
            minute: '2-digit' 
          })} 更新
        </div>
      </div>

      <div className="sectors-list">
        {sectors.length === 0 ? (
          <div className="no-sectors">
            <div className="no-data-icon">📈</div>
            <p>暂无热门板块数据</p>
            <small>正在分析中...</small>
          </div>
        ) : (
          sectors.slice(0, 10).map((sector, index) => (
            <div key={sector.sector_name} className="sector-item">
              <div 
                className="sector-main" 
                onClick={() => handleSectorClick(sector.sector_name)}
                style={{ cursor: 'pointer' }}
              >
                <div className="sector-rank">
                  <span className="rank-icon">
                    {getRankIcon(index + 1)}
                  </span>
                </div>
                
                <div className="sector-info">
                  <div className="sector-header">
                    <div className="sector-name">
                      {sector.sector_name}
                      <span className="expand-icon">
                        {expandedSector === sector.sector_name ? '▼' : '▶'}
                      </span>
                    </div>
                    {sector.trend && (
                      <div className={`sector-trend ${getTrendClass(sector.trend)}`}>
                        <span className="trend-icon">{getTrendIcon(sector.trend)}</span>
                        <span className="trend-text">{sector.trend}</span>
                      </div>
                    )}
                  </div>
                  <div className="sector-stats">
                    <span className="stock-count">
                      {sector.stock_count}只股票
                    </span>
                    {sector.anomaly_count !== undefined && (
                      <span className="anomaly-count">
                        异动: {sector.anomaly_count}只
                      </span>
                    )}
                    <span className="amount">
                      成交: {formatAmount(sector.total_amount)}
                    </span>
                  </div>
                </div>
                
                <div className="sector-metrics">
                  {sector.hot_score !== undefined && (
                    <div className="hot-score">
                      <div className="score-label">热度</div>
                      <div className="score-value">{sector.hot_score.toFixed(1)}</div>
                    </div>
                  )}
                  <div className="sector-change">
                    <span className={`change-value ${getChangeClass(sector.avg_change)}`}>
                      {sector.avg_change >= 0 ? '+' : ''}{sector.avg_change.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* 展开的成分股列表 */}
              {expandedSector === sector.sector_name && (
                <div className="sector-stocks">
                  
                  {loadingStocks[sector.sector_name] ? (
                    <div className="stocks-loading">
                      <span>⏳ 加载成分股中...</span>
                    </div>
                  ) : (
                    <div className="stocks-container">
                      {sectorStocks[sector.sector_name]?.length > 0 ? (
                        <>
                          {/* 排序控制 */}
                          <div className="sort-controls">
                            <span className="sort-label">排序：</span>
                            <button 
                              className={`sort-btn ${(sortBy[sector.sector_name] || 'change_percent') === 'change_percent' ? 'active' : ''}`}
                              onClick={() => handleSortChange(sector.sector_name, 'change_percent')}
                            >
                              涨跌幅 {(sortBy[sector.sector_name] || 'change_percent') === 'change_percent' ? ((sortOrder[sector.sector_name] || 'desc') === 'asc' ? '↑' : '↓') : ''}
                            </button>
                            <button 
                              className={`sort-btn ${sortBy[sector.sector_name] === 'current_price' ? 'active' : ''}`}
                              onClick={() => handleSortChange(sector.sector_name, 'current_price')}
                            >
                              价格 {sortBy[sector.sector_name] === 'current_price' ? (sortOrder[sector.sector_name] === 'asc' ? '↑' : '↓') : ''}
                            </button>
                            <button 
                              className={`sort-btn ${sortBy[sector.sector_name] === 'turnover_rate' ? 'active' : ''}`}
                              onClick={() => handleSortChange(sector.sector_name, 'turnover_rate')}
                            >
                              换手率 {sortBy[sector.sector_name] === 'turnover_rate' ? (sortOrder[sector.sector_name] === 'asc' ? '↑' : '↓') : ''}
                            </button>
                            <button 
                              className={`sort-btn ${sortBy[sector.sector_name] === 'market_value' ? 'active' : ''}`}
                              onClick={() => handleSortChange(sector.sector_name, 'market_value')}
                            >
                              市值 {sortBy[sector.sector_name] === 'market_value' ? (sortOrder[sector.sector_name] === 'asc' ? '↑' : '↓') : ''}
                            </button>
                          </div>

                          {/* 龙头股部分 */}
                          {getSortedStocks(sector.sector_name, sectorStocks[sector.sector_name], true).length > 0 && (
                            <div className="leader-stocks">
                              <h4 className="stocks-title">🚀 龙头股 ({getSortedStocks(sector.sector_name, sectorStocks[sector.sector_name], true).length}只)</h4>
                              <div className="stocks-list">
                                {getSortedStocks(sector.sector_name, sectorStocks[sector.sector_name], true)
                                  .map(stock => (
                                    <div 
                                      key={stock.stock_code} 
                                      className={`stock-item-inline leader-stock ${selectedStock === stock.stock_code ? 'selected' : ''}`}
                                      onClick={() => handleStockClick(stock.stock_code)}
                                    >
                                      <span className="stock-code">{stock.stock_code}</span>
                                      <span className="stock-name">{stock.stock_name} 👑</span>
                                      <span className={`stock-price ${getChangeClass(stock.change_percent)}`}>
                                        {stock.current_price.toFixed(2)}
                                      </span>
                                      <span className={`stock-change ${getChangeClass(stock.change_percent)}`}>
                                        {stock.change_percent >= 0 ? '+' : ''}{stock.change_percent.toFixed(2)}%
                                      </span>
                                      <span className="stock-turnover">
                                        {stock.turnover_rate != null && stock.turnover_rate >= 0 ? `${stock.turnover_rate.toFixed(2)}%` : '--'}
                                      </span>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          )}

                          {/* 成分股部分 */}
                          <div className="normal-stocks">
                            <h4 className="stocks-title">📊 成分股 ({getSortedStocks(sector.sector_name, sectorStocks[sector.sector_name], false).length}只)</h4>
                            <div className="stocks-list">
                              {getSortedStocks(sector.sector_name, sectorStocks[sector.sector_name], false)
                                .map(stock => (
                                  <div 
                                    key={stock.stock_code} 
                                    className={`stock-item-inline ${selectedStock === stock.stock_code ? 'selected' : ''}`}
                                    onClick={() => handleStockClick(stock.stock_code)}
                                  >
                                    <span className="stock-code">{stock.stock_code}</span>
                                    <span className="stock-name">{stock.stock_name}</span>
                                    <span className={`stock-price ${getChangeClass(stock.change_percent)}`}>
                                      {stock.current_price.toFixed(2)}
                                    </span>
                                    <span className={`stock-change ${getChangeClass(stock.change_percent)}`}>
                                      {stock.change_percent >= 0 ? '+' : ''}{stock.change_percent.toFixed(2)}%
                                    </span>
                                    <span className="stock-turnover">
                                      {stock.turnover_rate != null && stock.turnover_rate >= 0 ? `${stock.turnover_rate.toFixed(2)}%` : '--'}
                                    </span>
                                  </div>
                                ))}
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="no-stocks">
                          <span style={{ color: '#999', fontSize: '14px' }}>
                            {loadingStocks[sector.sector_name] ? '加载中...' : '该板块暂无成分股数据'}
                          </span>
                          <span style={{ color: '#666', fontSize: '12px', marginTop: '5px', display: 'block' }}>
                            部分特殊板块可能无法获取详细成分股信息
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <div className="panel-footer">
        <small>点击板块查看全部成分股 • 支持按涨跌幅、价格、换手率、市值排序</small>
      </div>
    </div>
  );
};

export default HotSectors; 