import React, { useState, useEffect } from 'react';
import './ManagementDashboard.css';

interface ConfigState {
  [key: string]: any;
}

interface MonitoringStock {
  code: string;
  name: string;
  current_price: number;
  change_percent: number;
  source: 'base' | 'hot_sector' | 'favorite';
}

interface MonitoringStocksData {
  total_monitoring: number;
  base_stocks_count: number;
  hot_sector_stocks_count: number;
  base_stocks: MonitoringStock[];
  hot_sector_stocks: MonitoringStock[];
}

const ManagementDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [config, setConfig] = useState<ConfigState>({});
  const [systemStatus, setSystemStatus] = useState<any>({});
  const [monitoringStocks, setMonitoringStocks] = useState<MonitoringStocksData | null>(null);
  const [favoriteStocks, setFavoriteStocks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');
  const [selectedStocks, setSelectedStocks] = useState<Set<string>>(new Set());
  // 基础监控股票功能已删除

  useEffect(() => {
    fetchSystemStatus();
    fetchConfig();
    fetchMonitoringStocks();
    fetchFavoriteStocks();
    // 基础监控股票功能已删除
  }, []);

  const fetchSystemStatus = async () => {
    try {
              const response = await fetch('http://localhost:9000/api/system/status');
      if (response.ok) {
        const data = await response.json();
        setSystemStatus(data);
      }
    } catch (error) {
      console.error('获取系统状态失败:', error);
    }
  };

  const fetchConfig = async () => {
    try {
              const response = await fetch('http://localhost:9000/api/config');
      if (response.ok) {
        const data = await response.json();
        setConfig(data);
      }
    } catch (error) {
      console.error('获取配置失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMonitoringStocks = async () => {
    try {
      const response = await fetch('http://localhost:9000/api/system/monitoring-stocks');
      if (response.ok) {
        const data = await response.json();
        setMonitoringStocks(data);
      }
    } catch (error) {
      console.error('获取监控股票失败:', error);
    }
  };

  const fetchFavoriteStocks = async () => {
    try {
      const response = await fetch('http://localhost:9000/api/config/favorites');
      if (response.ok) {
        const data = await response.json();
        setFavoriteStocks(data.favorites || []);
      }
    } catch (error) {
      console.error('获取自选股失败:', error);
    }
  };

  // 基础监控股票获取函数已删除

  const updateConfig = async (configUpdate: any) => {
    try {
      setSaveStatus('saving');
      const response = await fetch('http://localhost:9000/api/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(configUpdate),
      });
      
      if (response.ok) {
        await fetchConfig();
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 2000);
      } else {
        setSaveStatus('error');
        setTimeout(() => setSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('更新配置失败:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const handleNestedConfigChange = (path: string[], value: any) => {
    const newConfig = { ...config };
    let current = newConfig;
    
    // 创建嵌套路径
    for (let i = 0; i < path.length - 1; i++) {
      if (!current[path[i]]) {
        current[path[i]] = {};
      }
      current = current[path[i]];
    }
    
    // 设置最终值
    current[path[path.length - 1]] = value;
    setConfig(newConfig);
  };

  const removeStockFromFavorites = async (stockCode: string) => {
    try {
      setSaveStatus('saving');
      
      // 使用新的DELETE API端点
      const response = await fetch(`http://localhost:9000/api/config/favorites/${stockCode}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        const result = await response.json();
        console.log('删除成功:', result);
        
        // 刷新数据
        await fetchFavoriteStocks();
        await fetchMonitoringStocks();
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 2000);
      } else {
        const errorData = await response.json();
        console.error('删除失败:', errorData);
        setSaveStatus('error');
        setTimeout(() => setSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('删除股票失败:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const removeBatchStocks = async () => {
    if (selectedStocks.size === 0) return;

    try {
      setSaveStatus('saving');
      
      // 从自选股中批量移除
      const stocksToRemove = Array.from(selectedStocks);
      const newFavorites = favoriteStocks
        .filter(stock => !stocksToRemove.includes(stock.code))
        .map(stock => stock.code);

      const response = await fetch('http://localhost:9000/api/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_customization: {
            自定义监控: {
              自选股票池: newFavorites
            }
          }
        }),
      });

      if (response.ok) {
        await fetchFavoriteStocks();
        await fetchMonitoringStocks();
        setSelectedStocks(new Set());
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 2000);
      } else {
        setSaveStatus('error');
        setTimeout(() => setSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('批量删除股票失败:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const toggleStockSelection = (stockCode: string) => {
    const newSelected = new Set(selectedStocks);
    if (newSelected.has(stockCode)) {
      newSelected.delete(stockCode);
    } else {
      newSelected.add(stockCode);
    }
    setSelectedStocks(newSelected);
  };

  const selectAllFavorites = () => {
    const allFavoriteCodes = favoriteStocks.map(stock => stock.code);
    setSelectedStocks(new Set(allFavoriteCodes));
  };

  const clearSelection = () => {
    setSelectedStocks(new Set());
  };

  // 基础监控股票管理功能已删除

  const tabs = [
    { id: 'overview', label: '系统概览', icon: '📊' },
    { id: 'stocks', label: '股票管理', icon: '📈' },
    { id: 'anomaly', label: '异动检测', icon: '🚨' },
    { id: 'scoring', label: '强势评分', icon: '⭐' },
    { id: 'sector', label: '板块筛选', icon: '🔥' },
    { id: 'alerts', label: '预警系统', icon: '🔔' },
    { id: 'technical', label: '技术分析', icon: '📈' },
    { id: 'advanced', label: '高级设置', icon: '⚙️' },
  ];

  if (loading) {
    return (
      <div className="management-dashboard">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>加载配置中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="management-dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <h1>🔧 东风破管理后台</h1>
          <div className="header-info">
            <span className="version">{config.system?.version || 'v1.0.8'}</span>
            <span className={`status ${systemStatus.status === 'running' ? 'online' : 'offline'}`}>
              {systemStatus.status === 'running' ? '● 运行中' : '● 离线'}
            </span>
          </div>
        </div>
        <div className="header-stats">
          <div className="stat-item">
            <span className="stat-label">监控股票</span>
            <span className="stat-value">{systemStatus.monitoring_stocks || 0}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">连接数</span>
            <span className="stat-value">{systemStatus.connected_clients || 0}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">最后更新</span>
            <span className="stat-value">
              {systemStatus.timestamp ? new Date(systemStatus.timestamp).toLocaleTimeString() : '--:--:--'}
            </span>
          </div>
        </div>
      </header>

      <div className="dashboard-container">
        <nav className="dashboard-nav">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <span className="tab-icon">{tab.icon}</span>
              <span className="tab-label">{tab.label}</span>
            </button>
          ))}
        </nav>

        <main className="dashboard-content">
          {activeTab === 'overview' && (
            <div className="config-section">
              <h2>📊 系统概览</h2>
              
              <div className="overview-grid">
                <div className="overview-card">
                  <h3>🎯 监控范围</h3>
                  <div className="overview-stats">
                    <div className="stat-row">
                      <span>基础股票</span>
                      <span>{config.monitoring?.stock_limits?.base_stocks || 10}</span>
                    </div>
                    <div className="stat-row">
                      <span>热门板块股票</span>
                      <span>{config.monitoring?.stock_limits?.hot_sector_stocks || 64}</span>
                    </div>
                    <div className="stat-row">
                      <span>最大监控板块</span>
                      <span>{config.monitoring?.stock_limits?.max_sectors || 8}</span>
                    </div>
                  </div>
                </div>

                <div className="overview-card">
                  <h3>🔥 板块筛选</h3>
                  <div className="overview-stats">
                    <div className="stat-row">
                      <span>涨幅门槛</span>
                      <span>{(config.sector_filtering?.['热门板块筛选']?.['板块涨幅门槛'] || 0.5) * 100}%</span>
                    </div>
                    <div className="stat-row">
                      <span>热度最低分</span>
                      <span>{config.sector_filtering?.['热门板块筛选']?.['综合热度最低分'] || 30}</span>
                    </div>
                    <div className="stat-row">
                      <span>成交额门槛</span>
                      <span>{config.sector_filtering?.['热门板块筛选']?.['成交额门槛_亿'] || 50}亿</span>
                    </div>
                  </div>
                </div>

                <div className="overview-card">
                  <h3>⭐ 强势评分</h3>
                  <div className="overview-stats">
                    <div className="stat-row">
                      <span>涨幅权重</span>
                      <span>{((config.strong_stock_scoring?.['评分权重体系']?.['涨幅异动'] || 0.4) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="stat-row">
                      <span>换手率权重</span>
                      <span>{((config.strong_stock_scoring?.['评分权重体系']?.['换手率'] || 0.25) * 100).toFixed(0)}%</span>
                    </div>
                    <div className="stat-row">
                      <span>成交额权重</span>
                      <span>{((config.strong_stock_scoring?.['评分权重体系']?.['成交额'] || 0.2) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>

                <div className="overview-card">
                  <h3>🚨 异动检测</h3>
                  <div className="overview-stats">
                    <div className="stat-row">
                      <span>检测间隔</span>
                      <span>{config.anomaly_detection?.['实时异动检测']?.['检测间隔_秒'] || 5}秒</span>
                    </div>
                    <div className="stat-row">
                      <span>异动速度阈值</span>
                      <span>{config.anomaly_detection?.['实时异动检测']?.['异动速度阈值_%每分钟'] || 0.5}%/分</span>
                    </div>
                    <div className="stat-row">
                      <span>放量比例阈值</span>
                      <span>{config.anomaly_detection?.['实时异动检测']?.['放量比例阈值'] || 2.0}倍</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="quick-actions">
                <h3>🚀 快速操作</h3>
                <div className="action-buttons">
                  <button 
                    className="action-btn primary"
                    onClick={() => updateConfig({ 
                      monitoring: { 
                        ...config.monitoring,
                        update_intervals: { 
                          ...config.monitoring?.update_intervals,
                          realtime_data: 2 
                        }
                      }
                    })}
                  >
                    🔥 极速模式（2秒更新）
                  </button>
                  <button 
                    className="action-btn secondary"
                    onClick={() => updateConfig({ 
                      monitoring: { 
                        ...config.monitoring,
                        update_intervals: { 
                          ...config.monitoring?.update_intervals,
                          realtime_data: 5 
                        }
                      }
                    })}
                  >
                    💪 平衡模式（5秒更新）
                  </button>
                  <button 
                    className="action-btn safe"
                    onClick={() => updateConfig({ 
                      monitoring: { 
                        ...config.monitoring,
                        update_intervals: { 
                          ...config.monitoring?.update_intervals,
                          realtime_data: 10 
                        }
                      }
                    })}
                  >
                    🛡️ 省资源模式（10秒更新）
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'stocks' && (
            <div className="config-section">
              <h2>📈 股票监控管理</h2>
              
              {/* 监控概览 */}
              <div className="overview-grid" style={{marginBottom: '24px'}}>
                <div className="overview-card">
                  <h3>📊 监控统计</h3>
                  <div className="overview-stats">
                    <div className="stat-row">
                      <span>总监控股票</span>
                      <span>{monitoringStocks?.total_monitoring || 0}</span>
                    </div>
                    <div className="stat-row">
                      <span>自选股</span>
                      <span>{favoriteStocks.length}</span>
                    </div>
                    <div className="stat-row">
                      <span>热门板块股票</span>
                      <span>{monitoringStocks?.hot_sector_stocks_count || 0}</span>
                    </div>
                    <div className="stat-row">
                      <span>自选股</span>
                      <span>{favoriteStocks.length}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 自选股管理 */}
              <div className="config-group">
                <div className="group-header">
                  <h3>⭐ 自选股管理</h3>
                  <div className="batch-actions">
                    {favoriteStocks.length > 0 && (
                      <>
                        <button 
                          className="action-btn secondary small"
                          onClick={selectAllFavorites}
                          disabled={selectedStocks.size === favoriteStocks.length}
                        >
                          全选 ({favoriteStocks.length})
                        </button>
                        <button 
                          className="action-btn secondary small"
                          onClick={clearSelection}
                          disabled={selectedStocks.size === 0}
                        >
                          清空选择
                        </button>
                        <button 
                          className="action-btn danger small"
                          onClick={removeBatchStocks}
                          disabled={selectedStocks.size === 0 || saveStatus === 'saving'}
                        >
                          批量删除 ({selectedStocks.size})
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {favoriteStocks.length > 0 ? (
                  <div className="stocks-table">
                    <div className="table-header">
                      <span>选择</span>
                      <span>代码</span>
                      <span>名称</span>
                      <span>当前价</span>
                      <span>涨跌幅</span>
                      <span>操作</span>
                    </div>
                    {favoriteStocks.map((stock, index) => (
                      <div key={stock.code} className="table-row">
                        <input
                          type="checkbox"
                          checked={selectedStocks.has(stock.code)}
                          onChange={() => toggleStockSelection(stock.code)}
                        />
                        <span className="stock-code">{stock.code}</span>
                        <span className="stock-name">{stock.name}</span>
                        <span className="stock-price">¥{stock.current_price?.toFixed(2) || '--'}</span>
                        <span className={`stock-change ${stock.change_percent >= 0 ? 'positive' : 'negative'}`}>
                          {stock.change_percent >= 0 ? '+' : ''}{stock.change_percent?.toFixed(2) || '--'}%
                        </span>
                        <button
                          className="action-btn danger small"
                          onClick={() => removeStockFromFavorites(stock.code)}
                          disabled={saveStatus === 'saving'}
                        >
                          删除
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-state">
                    <p>📭 暂无自选股</p>
                    <p>您可以在主界面搜索并添加股票到自选股</p>
                  </div>
                )}
              </div>

              {/* 基础监控股票功能已删除 */}

              {/* 热门板块股票 (动态) */}
              <div className="config-group">
                <h3>🔥 热门板块股票 (动态筛选)</h3>
                <p className="info-text">以下股票来自热门板块，每10分钟自动更新</p>
                {monitoringStocks?.hot_sector_stocks && monitoringStocks.hot_sector_stocks.length > 0 ? (
                  <div className="stocks-table readonly">
                    <div className="table-header">
                      <span>代码</span>
                      <span>名称</span>
                      <span>当前价</span>
                      <span>涨跌幅</span>
                      <span>状态</span>
                    </div>
                    {monitoringStocks.hot_sector_stocks.map((stock, index) => (
                      <div key={stock.code} className="table-row">
                        <span className="stock-code">{stock.code}</span>
                        <span className="stock-name">{stock.name}</span>
                        <span className="stock-price">¥{stock.current_price?.toFixed(2) || '--'}</span>
                        <span className={`stock-change ${stock.change_percent >= 0 ? 'positive' : 'negative'}`}>
                          {stock.change_percent >= 0 ? '+' : ''}{stock.change_percent?.toFixed(2) || '--'}%
                        </span>
                        <span className="stock-status dynamic">动态监控</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-state">
                    <p>🔥 热门板块股票数据加载中...</p>
                  </div>
                )}
              </div>

              <div className="config-actions">
                <button 
                  onClick={() => {
                    fetchMonitoringStocks();
                    fetchFavoriteStocks();
                    // 基础监控股票功能已删除
                  }} 
                  className="action-btn primary"
                  disabled={saveStatus === 'saving'}
                >
                  🔄 刷新数据
                </button>
              </div>
            </div>
          )}

          {activeTab === 'anomaly' && (
            <div className="config-section">
              <h2>🚨 异动检测参数</h2>
              
              <div className="config-group">
                <h3>📈 异动检测参数</h3>
                <div className="config-grid">
                  <div className="input-row">
                    <label>涨速异动阈值（%/分钟）</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="5.0"
                      value={config.anomaly_detection?.['实时异动检测']?.['异动速度阈值_%每分钟'] || 0.5}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '异动速度阈值_%每分钟'], 
                        parseFloat(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="input-row">
                    <label>放量异动阈值（倍数）</label>
                    <input
                      type="number"
                      step="0.1"
                      min="1.0"
                      max="10.0"
                      value={config.anomaly_detection?.['实时异动检测']?.['放量比例阈值'] || 2.0}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '放量比例阈值'], 
                        parseFloat(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="input-row">
                    <label>检测间隔（秒）</label>
                    <input
                      type="number"
                      min="1"
                      max="60"
                      value={config.anomaly_detection?.['实时异动检测']?.['检测间隔_秒'] || 5}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '检测间隔_秒'], 
                        parseInt(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="input-row">
                    <label>大单阈值（手）</label>
                    <input
                      type="number"
                      min="1000"
                      max="50000"
                      step="1000"
                      value={config.anomaly_detection?.['实时异动检测']?.['大单阈值_手'] || 6000}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '大单阈值_手'], 
                        parseInt(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="input-row">
                    <label>资金流入阈值（万元）</label>
                    <input
                      type="number"
                      min="1000"
                      max="50000"
                      step="1000"
                      value={config.anomaly_detection?.['实时异动检测']?.['资金流入阈值_万'] || 3000}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '资金流入阈值_万'], 
                        parseInt(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="input-row">
                    <label>连续异动确认次数</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={config.anomaly_detection?.['实时异动检测']?.['连续异动确认次数'] || 2}
                      onChange={(e) => handleNestedConfigChange(
                        ['anomaly_detection', '实时异动检测', '连续异动确认次数'], 
                        parseInt(e.target.value)
                      )}
                    />
                  </div>
                </div>
              </div>

              <div className="config-group">
                <h3>🎯 监控设置</h3>
                <div className="config-grid">
                  <div className="input-row">
                    <label>监控间隔（秒）</label>
                    <input
                      type="number"
                      min="1"
                      max="60"
                      value={config.monitoring?.update_intervals?.realtime_data || 3}
                      onChange={(e) => handleNestedConfigChange(
                        ['monitoring', 'update_intervals', 'realtime_data'], 
                        parseInt(e.target.value)
                      )}
                    />
                  </div>
                  
                  <div className="checkbox-row">
                    <label className="checkbox-label">
                      <input
                        type="checkbox"
                        checked={config.alert_system?.['提醒设置']?.['声音提醒'] || true}
                        onChange={(e) => handleNestedConfigChange(
                          ['alert_system', '提醒设置', '声音提醒'], 
                          e.target.checked
                        )}
                      />
                      <span>启用预警</span>
                    </label>
                  </div>
                  
                  <div className="input-row">
                    <label>预警阈值（0-1）</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="1.0"
                      value={0.7}
                      onChange={(e) => handleNestedConfigChange(
                        ['alert_threshold'], 
                        parseFloat(e.target.value)
                      )}
                    />
                  </div>
                </div>
              </div>

              <button 
                onClick={() => updateConfig(config)} 
                className="save-btn"
                disabled={saveStatus === 'saving'}
              >
                {saveStatus === 'saving' ? '⏳ 保存中...' : '💾 保存配置'}
              </button>
            </div>
          )}

          {/* 保存状态提示 */}
          {saveStatus !== 'idle' && (
            <div className={`save-status ${saveStatus}`}>
              {saveStatus === 'saving' && '⏳ 保存中...'}
              {saveStatus === 'success' && '✅ 配置已保存'}
              {saveStatus === 'error' && '❌ 保存失败'}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default ManagementDashboard; 