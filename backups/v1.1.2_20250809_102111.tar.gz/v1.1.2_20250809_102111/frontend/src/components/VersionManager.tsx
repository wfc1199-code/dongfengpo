import React, { useState, useEffect } from 'react';
import './VersionManager.css';

interface Version {
  id: number;
  version_name: string;
  version_code: string;
  description: string;
  created_at: string;
  file_size: number;
  file_size_formatted?: string;
  checksum: string;
  tags: string[];
  status: string;
  metadata: any;
  changes_count: number;
}

interface VersionChange {
  type: string;
  path: string;
  description: string;
}

const VersionManager: React.FC = () => {
  const [versions, setVersions] = useState<Version[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<Version | null>(null);
  const [changes, setChanges] = useState<VersionChange[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newVersionName, setNewVersionName] = useState('');
  const [newVersionDesc, setNewVersionDesc] = useState('');
  const [stats, setStats] = useState<any>(null);

  // 获取版本列表
  const fetchVersions = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:9000/api/versions/list');
      const data = await response.json();
      // 确保data是数组
      if (Array.isArray(data)) {
        setVersions(data);
      } else {
        console.error('API返回的不是数组:', data);
        setVersions([]);
      }
    } catch (error) {
      console.error('获取版本列表失败:', error);
      setVersions([]);
    } finally {
      setLoading(false);
    }
  };

  // 获取版本变更
  const fetchVersionChanges = async (versionId: number) => {
    try {
      const response = await fetch(`http://localhost:9000/api/versions/${versionId}/changes`);
      const data = await response.json();
      setChanges(data);
    } catch (error) {
      console.error('获取版本变更失败:', error);
    }
  };

  // 获取统计信息
  const fetchStats = async () => {
    try {
      const response = await fetch('http://localhost:9000/api/versions/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('获取统计信息失败:', error);
    }
  };

  // 创建版本
  const createVersion = async () => {
    if (!newVersionName.trim()) {
      alert('请输入版本名称');
      return;
    }

    try {
      setCreating(true);
      const response = await fetch('http://localhost:9000/api/versions/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          version_name: newVersionName,
          description: newVersionDesc,
          tags: ['manual', 'custom']
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        alert('版本创建成功！');
        setNewVersionName('');
        setNewVersionDesc('');
        fetchVersions();
      } else {
        alert('版本创建失败: ' + result.message);
      }
    } catch (error) {
      console.error('创建版本失败:', error);
      alert('创建版本失败');
    } finally {
      setCreating(false);
    }
  };

  // 保存当前版本
  const saveCurrentVersion = async () => {
    try {
      setCreating(true);
      const response = await fetch('http://localhost:9000/api/versions/save-current', {
        method: 'POST',
      });

      const result = await response.json();
      
      if (result.success) {
        alert('当前版本保存成功！');
        fetchVersions();
        fetchStats();
      } else {
        alert('保存失败: ' + result.message);
      }
    } catch (error) {
      console.error('保存当前版本失败:', error);
      alert('保存当前版本失败');
    } finally {
      setCreating(false);
    }
  };

  // 删除版本
  const deleteVersion = async (versionId: number) => {
    if (!window.confirm('确定要删除这个版本吗？')) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:9000/api/versions/${versionId}`, {
        method: 'DELETE',
      });

      const result = await response.json();
      
      if (result.success) {
        alert('版本删除成功！');
        fetchVersions();
        setSelectedVersion(null);
        setChanges([]);
      } else {
        alert('删除失败: ' + result.message);
      }
    } catch (error) {
      console.error('删除版本失败:', error);
      alert('删除版本失败');
    }
  };

  // 选择版本
  const selectVersion = async (version: Version) => {
    setSelectedVersion(version);
    await fetchVersionChanges(version.id);
  };

  // 格式化文件大小
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN');
  };

  // 获取变更类型图标
  const getChangeIcon = (type: string) => {
    switch (type) {
      case 'enhancement': return '🔧';
      case 'feature': return '✨';
      case 'bugfix': return '🐛';
      case 'security': return '🔒';
      default: return '📝';
    }
  };

  // 获取变更类型文本
  const getChangeTypeText = (type: string) => {
    switch (type) {
      case 'enhancement': return '优化';
      case 'feature': return '新功能';
      case 'bugfix': return '修复';
      case 'security': return '安全';
      default: return '其他';
    }
  };

  useEffect(() => {
    fetchVersions();
    fetchStats();
  }, []);

  return (
    <div className="version-manager">
      <div className="version-header">
        <h2>🗂️ 版本管理</h2>
        <div className="version-actions">
          <button 
            onClick={saveCurrentVersion} 
            disabled={creating}
            className="btn-primary"
          >
            {creating ? '保存中...' : '💾 保存当前版本'}
          </button>
        </div>
      </div>

      {/* 统计信息 */}
      {stats && (
        <div className="version-stats">
          <div className="stat-card">
            <div className="stat-number">{stats.total_versions}</div>
            <div className="stat-label">总版本数</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{stats.total_size_mb}</div>
            <div className="stat-label">总大小 (MB)</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">
              {stats.latest_version ? stats.latest_version.version_code : 'N/A'}
            </div>
            <div className="stat-label">最新版本</div>
          </div>
        </div>
      )}

      <div className="version-content">
        {/* 版本列表 */}
        <div className="version-list">
          <h3>版本时间轴</h3>
          {loading ? (
            <div className="loading">加载中...</div>
          ) : (
            <div className="timeline">
              {versions.map((version, index) => (
                <div 
                  key={version.id} 
                  className={`timeline-item ${selectedVersion?.id === version.id ? 'selected' : ''}`}
                  onClick={() => selectVersion(version)}
                >
                  <div className="timeline-marker">
                    <div className="timeline-dot"></div>
                    {index < versions.length - 1 && <div className="timeline-line"></div>}
                  </div>
                  <div className="timeline-content">
                    <div className="version-card">
                      <div className="version-header-card">
                        <h4>{version.version_name}</h4>
                        <span className="version-code">{version.version_code}</span>
                      </div>
                      <div className="version-meta">
                        <span className="version-date">{formatDate(version.created_at)}</span>
                        <span className="version-size">{version.file_size_formatted || formatFileSize(version.file_size)}</span>
                        <span className="version-changes">{version.changes_count} 项变更</span>
                      </div>
                      <div className="version-tags">
                        {version.tags.map((tag, i) => (
                          <span key={i} className={`tag tag-${tag}`}>{tag}</span>
                        ))}
                      </div>
                      {version.description && (
                        <p className="version-description">{version.description.substring(0, 100)}...</p>
                      )}
                      <div className="version-actions-card">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteVersion(version.id);
                          }}
                          className="btn-danger btn-small"
                        >
                          🗑️ 删除
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 版本详情 */}
        <div className="version-detail">
          {selectedVersion ? (
            <div>
              <h3>版本详情: {selectedVersion.version_name}</h3>
              
              <div className="detail-section">
                <h4>基本信息</h4>
                <div className="detail-grid">
                  <div className="detail-item">
                    <label>版本代码:</label>
                    <span>{selectedVersion.version_code}</span>
                  </div>
                  <div className="detail-item">
                    <label>创建时间:</label>
                    <span>{formatDate(selectedVersion.created_at)}</span>
                  </div>
                  <div className="detail-item">
                    <label>文件大小:</label>
                    <span>{selectedVersion.file_size_formatted || formatFileSize(selectedVersion.file_size)}</span>
                  </div>
                  <div className="detail-item">
                    <label>校验和:</label>
                    <span className="checksum">{selectedVersion.checksum}</span>
                  </div>
                </div>
              </div>

              {selectedVersion.description && (
                <div className="detail-section">
                  <h4>版本描述</h4>
                  <div className="description-content">
                    {selectedVersion.description.split('\n').map((line, i) => (
                      <p key={i}>{line}</p>
                    ))}
                  </div>
                </div>
              )}

              <div className="detail-section">
                <h4>变更记录 ({changes.length})</h4>
                <div className="changes-list">
                  {changes.map((change, i) => (
                    <div key={i} className="change-item">
                      <div className="change-icon">
                        {getChangeIcon(change.type)}
                      </div>
                      <div className="change-content">
                        <div className="change-header">
                          <span className="change-type">{getChangeTypeText(change.type)}</span>
                          <span className="change-path">{change.path}</span>
                        </div>
                        <div className="change-description">{change.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="no-selection">
              <h3>选择一个版本查看详情</h3>
              <p>点击左侧时间轴中的版本卡片来查看详细信息</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VersionManager;