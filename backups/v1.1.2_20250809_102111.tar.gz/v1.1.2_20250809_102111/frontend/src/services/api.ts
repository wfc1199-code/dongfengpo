// API基础配置
import cacheManager from '../utils/cache';

const API_BASE_URL = 'http://localhost:9000/api';
const API_TIMEOUT = 15000; // 增加超时时间以避免请求超时

// 请求配置接口
interface RequestConfig {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: any;
  timeout?: number;
}

// 统一的fetch封装
class ApiService {
  private baseURL: string;
  private defaultTimeout: number;

  constructor(baseURL: string, timeout: number = 10000) {
    this.baseURL = baseURL;
    this.defaultTimeout = timeout;
  }

  private async request(endpoint: string, config: RequestConfig = {}): Promise<any> {
    const {
      method = 'GET',
      headers = {},
      body,
      timeout = this.defaultTimeout
    } = config;

    const url = `${this.baseURL}${endpoint}`;
    
    console.log(`🌐 API请求: ${method} ${url}`);

    // 创建AbortController用于超时控制
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    const attemptRequest = async (retryIndex: number): Promise<{ data: any; status: number }> => {
      try {
        const response = await fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            ...headers,
          },
          body: body ? JSON.stringify(body) : undefined,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);
        console.log(`✅ API响应: ${url} - ${response.status}`);

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        return { data, status: response.status };
      } catch (error: any) {
        console.warn(`⚠️ API请求失败(第${retryIndex + 1}次): ${url} -> ${error?.message || error}`);
        if (retryIndex >= 2) {
          clearTimeout(timeoutId);
          console.error('API请求错误: 达到重试上限');
          throw error;
        }
        // 指数退避 300ms * 2^retryIndex
        const backoff = 300 * Math.pow(2, retryIndex);
        await new Promise((r) => setTimeout(r, backoff));
        return attemptRequest(retryIndex + 1);
      }
    };

    return attemptRequest(0);
  }

  // GET请求
  async get(endpoint: string, config?: Omit<RequestConfig, 'method' | 'body'>) {
    return this.request(endpoint, { ...config, method: 'GET' });
  }

  // POST请求
  async post(endpoint: string, body?: any, config?: Omit<RequestConfig, 'method'>) {
    return this.request(endpoint, { ...config, method: 'POST', body });
  }

  // PUT请求
  async put(endpoint: string, body?: any, config?: Omit<RequestConfig, 'method'>) {
    return this.request(endpoint, { ...config, method: 'PUT', body });
  }

  // DELETE请求
  async delete(endpoint: string, config?: Omit<RequestConfig, 'method' | 'body'>) {
    return this.request(endpoint, { ...config, method: 'DELETE' });
  }
}

// 创建API实例
const api = new ApiService(API_BASE_URL, API_TIMEOUT);

export default api; 