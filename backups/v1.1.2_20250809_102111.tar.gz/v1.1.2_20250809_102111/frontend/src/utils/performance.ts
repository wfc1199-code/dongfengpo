/**
 * 前端性能监控工具
 * 监控内存使用、API响应时间等性能指标
 */
import React from 'react';

interface PerformanceMetrics {
  memoryUsage?: {
    usedJSHeapSize: number;
    totalJSHeapSize: number;
    jsHeapSizeLimit: number;
  };
  apiResponseTimes: Record<string, number[]>;
  componentRenderTimes: Record<string, number[]>;
  lastUpdate: number;
}

class PerformanceMonitor {
  private metrics: PerformanceMetrics = {
    apiResponseTimes: {},
    componentRenderTimes: {},
    lastUpdate: Date.now()
  };

  /**
   * 记录API响应时间
   */
  recordApiTime(endpoint: string, duration: number): void {
    if (!this.metrics.apiResponseTimes[endpoint]) {
      this.metrics.apiResponseTimes[endpoint] = [];
    }
    
    this.metrics.apiResponseTimes[endpoint].push(duration);
    
    // 只保留最近50次记录
    if (this.metrics.apiResponseTimes[endpoint].length > 50) {
      this.metrics.apiResponseTimes[endpoint] = 
        this.metrics.apiResponseTimes[endpoint].slice(-50);
    }

    this.metrics.lastUpdate = Date.now();
  }

  /**
   * 记录组件渲染时间
   */
  recordRenderTime(componentName: string, duration: number): void {
    if (!this.metrics.componentRenderTimes[componentName]) {
      this.metrics.componentRenderTimes[componentName] = [];
    }
    
    this.metrics.componentRenderTimes[componentName].push(duration);
    
    // 只保留最近30次记录
    if (this.metrics.componentRenderTimes[componentName].length > 30) {
      this.metrics.componentRenderTimes[componentName] = 
        this.metrics.componentRenderTimes[componentName].slice(-30);
    }

    this.metrics.lastUpdate = Date.now();
  }

  /**
   * 获取内存使用情况
   */
  getMemoryUsage(): PerformanceMetrics['memoryUsage'] | null {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      return {
        usedJSHeapSize: memory.usedJSHeapSize,
        totalJSHeapSize: memory.totalJSHeapSize,
        jsHeapSizeLimit: memory.jsHeapSizeLimit
      };
    }
    return null;
  }

  /**
   * 获取API平均响应时间
   */
  getApiAverageTime(endpoint: string): number {
    const times = this.metrics.apiResponseTimes[endpoint];
    if (!times || times.length === 0) return 0;
    
    return times.reduce((sum, time) => sum + time, 0) / times.length;
  }

  /**
   * 获取组件平均渲染时间
   */
  getComponentAverageRenderTime(componentName: string): number {
    const times = this.metrics.componentRenderTimes[componentName];
    if (!times || times.length === 0) return 0;
    
    return times.reduce((sum, time) => sum + time, 0) / times.length;
  }

  /**
   * 获取完整的性能报告
   */
  getPerformanceReport(): {
    memory: PerformanceMetrics['memoryUsage'];
    apiStats: Record<string, { avgTime: number; callCount: number }>;
    componentStats: Record<string, { avgTime: number; renderCount: number }>;
    isHealthy: boolean;
  } {
    const memory = this.getMemoryUsage();
    
    const apiStats: Record<string, { avgTime: number; callCount: number }> = {};
    for (const [endpoint, times] of Object.entries(this.metrics.apiResponseTimes)) {
      apiStats[endpoint] = {
        avgTime: this.getApiAverageTime(endpoint),
        callCount: times.length
      };
    }

    const componentStats: Record<string, { avgTime: number; renderCount: number }> = {};
    for (const [name, times] of Object.entries(this.metrics.componentRenderTimes)) {
      componentStats[name] = {
        avgTime: this.getComponentAverageRenderTime(name),
        renderCount: times.length
      };
    }

    // 简单的健康检查
    const avgApiTime = Object.values(apiStats).reduce((sum, stat) => sum + stat.avgTime, 0) / 
                      Math.max(Object.keys(apiStats).length, 1);
    const memoryUsagePercent = memory ? (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100 : 0;
    
    const isHealthy = avgApiTime < 3000 && memoryUsagePercent < 80;

    return {
      memory: memory || undefined,
      apiStats,
      componentStats,
      isHealthy
    };
  }

  /**
   * 清理过期的性能数据
   */
  cleanup(): void {
    const oneHourAgo = Date.now() - 60 * 60 * 1000;
    
    if (this.metrics.lastUpdate < oneHourAgo) {
      this.metrics.apiResponseTimes = {};
      this.metrics.componentRenderTimes = {};
      this.metrics.lastUpdate = Date.now();
      console.log('🧹 性能监控数据已清理');
    }
  }
}

// 创建全局性能监控实例
export const performanceMonitor = new PerformanceMonitor();

// 定期清理过期数据
setInterval(() => {
  performanceMonitor.cleanup();
}, 30 * 60 * 1000); // 每30分钟清理一次

/**
 * 高阶组件：用于监控组件渲染性能
 */
export function withPerformanceMonitoring<P extends object>(
  Component: React.ComponentType<P>,
  componentName: string
): React.ComponentType<P> {
  return React.memo<P>((props) => {
    const renderStartTime = React.useRef<number>(0);
    
    React.useEffect(() => {
      renderStartTime.current = performance.now();
    });

    React.useLayoutEffect(() => {
      const renderTime = performance.now() - renderStartTime.current;
      performanceMonitor.recordRenderTime(componentName, renderTime);
    });

    return React.createElement(Component, props);
  });
}

export default performanceMonitor;